# Fandi + Google Drive sign-in audit (2026-10-09)

## Source changes
- Fandi worker quick-entry now labels the field selector `खेत (वैकल्पिक)` and offers `खेत नहीं चुनें`.
- Blank field is allowed for the quick add flow; a nonblank but stale field ID is rejected.
- Existing deduplication for a labour/date/field record remains in Store.addCanePeeling.
- Google Sign-In status 10 is reported as `DEVELOPER_ERROR` with a direct explanation: configure Android OAuth for package `com.majdoor.hisaabpro` and the SHA-1 of the exact release keystore, and enable Google Drive API.
- Workflow source checks include the optional field label and DEVELOPER_ERROR diagnostic.

## Important external requirement
`DEVELOPER_ERROR` (status 10) is an OAuth/Google Cloud configuration failure, not something that can be conclusively fixed by Kotlin alone. The Google Cloud Android OAuth client must use package `com.majdoor.hisaabpro` and the SHA-1 printed by the workflow for the stable release keystore. Build and device verification remain required.

## Verification performed
- ZIP structure and compressed-data integrity are checked when the archive is created.
- Static source/workflow checks are included in the GitHub Actions workflow.
- Android Release compilation and real-device Google sign-in were not run in this environment.
