package com.majdoor.hisaab

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.view.*
import android.widget.*
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.feature.AppServices
import com.majdoor.hisaab.security.SecurityManager
import com.majdoor.hisaab.BuildConfig
import com.majdoor.hisaab.notification.NotificationHelper
import com.majdoor.hisaab.notification.NotificationSettings
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import com.majdoor.hisaab.security.AutoLockManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.graphics.BitmapFactory
import android.content.res.Configuration

class MainActivity:Activity(){
    internal lateinit var app:AppServices
    internal lateinit var security:SecurityManager
    internal lateinit var root:LinearLayout
    internal val green=Color.rgb(46,125,50)
    internal val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    internal val bg get() = if (isDarkTheme()) Color.rgb(25,28,26) else Color.rgb(245,248,245)
    internal var unlocked=false
    internal var lastUserActivity=System.currentTimeMillis()
    internal var autoLockFromBackground=0L
    internal var failedPinAttempts=0
    internal var pinBlockedUntil=0L
    internal var editingWorker:String?=null
    internal var editingAttendance:String?=null
    internal var editingWork:String?=null
    internal var editingField:String?=null
    internal var exportType:String=""
    internal var pendingWorkerPhoto:String=""
    internal var pendingFieldPhoto:String=""
    internal var currentRoute:String="dashboard"
    internal var restoredRoute:String?=null
    internal val autoLockHandler = Handler(Looper.getMainLooper())
    internal val autoLockChecker = object : Runnable {
        override fun run() {
            if (::security.isInitialized && AutoLockManager.shouldLock(
                    security.hasPin(), unlocked, lastUserActivity, System.currentTimeMillis(), autoLockTimeout())) {
                lockApp()
            }
            autoLockHandler.postDelayed(this, 10_000L)
        }
    }
    internal val today get()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

    override fun onCreate(b:Bundle?){
        applySavedTheme()
        super.onCreate(b)
        restoredRoute=b?.getString("route")
        showSplash()
        Handler(Looper.getMainLooper()).postDelayed({ initializeStartup() }, 650L)
        autoLockHandler.postDelayed(autoLockChecker, 10_000L)
    }

    override fun onBackPressed() {
        if (currentRoute != "dashboard") {
            dashboard()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        autoLockHandler.removeCallbacks(autoLockChecker)
        super.onDestroy()
    }



    override fun onSaveInstanceState(outState:Bundle){
        outState.putString("route", currentRoute)
        outState.putBoolean("unlocked", unlocked)
        outState.putString("editingWorker", editingWorker)
        outState.putString("editingAttendance", editingAttendance)
        outState.putString("editingWork", editingWork)
        outState.putString("editingField", editingField)
        super.onSaveInstanceState(outState)
    }


    override fun onResume(){
        super.onResume()
        if(::security.isInitialized){
            val now=System.currentTimeMillis()
            val timeout=autoLockTimeout()
            if(unlocked && security.hasPin() && timeout>0 && autoLockFromBackground>0 && now-autoLockFromBackground>=timeout) lockApp()
            lastUserActivity=now
            autoLockFromBackground=0L
            if(security.hasPin() && !unlocked) unlockDialog()
        }
    }

    override fun onPause(){
        super.onPause()
        if(unlocked && ::security.isInitialized && security.hasPin() && autoLockTimeout()>0) autoLockFromBackground=System.currentTimeMillis()
    }

    override fun dispatchTouchEvent(ev:MotionEvent):Boolean{
        if(ev.actionMasked==MotionEvent.ACTION_DOWN || ev.actionMasked==MotionEvent.ACTION_MOVE) lastUserActivity=System.currentTimeMillis()
        return super.dispatchTouchEvent(ev)
    }





    private fun LinearLayout.padding(p:Int){setPadding(dp(p),dp(p),dp(p),dp(p))}


    internal fun applySelectedFieldPhoto(uri: android.net.Uri, data: Intent? = null) {
        persistUriPermission(uri, data)
        pendingFieldPhoto=uri.toString()
        toast("Field photo selected")
        fieldForm(editingField)
    }




















}
