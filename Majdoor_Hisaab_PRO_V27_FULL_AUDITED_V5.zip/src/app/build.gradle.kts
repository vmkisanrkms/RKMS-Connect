plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.majdoor.hisaab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.majdoor.hisaab"
        minSdk = 26
        targetSdk = 35
        versionCode = 30
        versionName = "2.10"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    signingConfigs {
        create("release") {
            val storeFilePath = providers.gradleProperty("releaseStoreFile").orNull
            val storePasswordValue = providers.gradleProperty("releaseStorePassword").orNull
            val keyAliasValue = providers.gradleProperty("releaseKeyAlias").orNull
            val keyPasswordValue = providers.gradleProperty("releaseKeyPassword").orNull
            if (!storeFilePath.isNullOrBlank() && !storePasswordValue.isNullOrBlank() && !keyAliasValue.isNullOrBlank() && !keyPasswordValue.isNullOrBlank()) {
                storeFile = file(storeFilePath)
                storePassword = storePasswordValue
                keyAlias = keyAliasValue
                keyPassword = keyPasswordValue
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            // A production release must NEVER silently fall back to the debug key.
            // CI supplies the permanent release keystore through Gradle properties.
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
