# V25 Settings Artwork / Version Fix

- Light Hindi settings artwork rebuilt from clean reference.
- Dark Hindi settings artwork rebuilt from clean reference.
- Removed stale Version 2.4 text.
- Current displayed version is Hindi `संस्करण 2.10`.
- Removed English Settings/Backup/Restore/Language/Theme/Reset labels from these Hindi artwork assets.
- GitHub Actions package/version verification updated to versionCode 30 / versionName 2.10.
- App Gradle remains versionCode 30 / versionName 2.10.
