# Majdoor Hisaab PRO V27 — Fixed Audit Notes

Applied fixes in this build:

1. Home dashboard live worker, today's attendance, total wages and pending balance values.
2. Workers screen now renders the real database worker list with scrolling, search/filter entry point, photos, ID, wage and active state.
3. Fields screen now renders the real database field list with scrolling, crop, photo, days and total cost.
4. Worker profile now shows live name/ID/wage/status, total days, wages, paid and balance.
5. Field details now show live crop/status, workers, total days, total cost, field-linked paid amount and field balance.
6. Payments screen now shows recent payment history; tapping a record gives Edit/Delete actions.
7. CSV export now includes Paid and Balance per worker/field/date row.
8. PDF export now includes Paid and Balance columns.
9. Field report now includes Wages, Paid and Balance and opens the field details on tap.
10. Backup ZIP now includes readable worker/field photos in addition to the SQLite database and metadata.
11. Restore now extracts backed-up photos into app-private storage and reconnects their URIs to restored worker/field records.
12. Existing database uniqueness/foreign-key/attendance/payment field-link protections were preserved.
13. Version remains 2.10.

Build limitation: Android/Gradle runtime build could not be executed in this environment because the Gradle distribution was not locally available and external download/network DNS was unavailable. Source syntax was checked separately; a real Android device/APK test is still required before calling this release production-final.
