# Majdoor Hisaab PRO — Master Fixed Source Package

Revision: V23 master-fix source package
App version: 2.10 / versionCode 30

## Included
- Home, Attendance, Workers, Worker Profile, Make Payment, Fields/Crops, Field Details, Reports, Daily Report and Settings.
- One worker can work on multiple plots/fields.
- Duplicate worker and duplicate date + worker + plot work records are protected at database level.
- Worker and field/crop photo select/change/remove flows are implemented.
- Full/Half/None attendance, All Full, All Half and Clear All are implemented.
- Field-linked payments are supported; unassigned/general payments remain outside field-specific balances.
- Worker/field/date report filtering is implemented.
- Daily field detail uses the selected field ID and includes team members whose attendance is None/absent.
- Share opens a choice between WhatsApp and other apps; WhatsApp uses the same worker/date/field filters.
- CSV headers and PDF headings use Hindi when Hindi mode is selected.
- Native cards, inputs and dialogs use the active light/dark theme.
- Hindi reference artwork variants are included for all ten reference screens.
- Release workflow builds only the signed release APK and verifies package metadata and APK signature.

## Build configuration
- Android Gradle Plugin: 8.9.1
- Gradle: 8.11.1
- Java/JVM: 17
- compileSdk/targetSdk: 35
- Release task: `:app:assembleRelease`
- No AAB build is configured.
- No debug APK is uploaded by the workflow.

## Release signing
The release workflow expects the permanent release keystore through GitHub Actions secrets. Release signing is intentionally not silently replaced by the debug key.

## Verification note
The source package has been statically audited in this environment. A local Android/Gradle release build could not be executed here because the environment has no Android SDK/Gradle distribution cache and cannot resolve `services.gradle.org`. The included GitHub Actions workflow is the reproducible release-build gate and verifies the generated APK before upload.
