# Majdoor Hisaab PRO V27 — Theme Resource Hardening

- Removed hard-coded white surface/navigation/window fallback from runtime theme paths.
- Added resource-backed light surface/window/navigation colors.
- Added `values-night` theme resources for Android dark-mode resource selection.
- Kept the app's explicit Dark/Light preference runtime overrides intact.
- Kept intentional white button/header text unchanged.
- Version remains 2.10 / versionCode 30.
