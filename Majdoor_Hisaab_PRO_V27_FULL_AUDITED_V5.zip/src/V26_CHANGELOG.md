# V26 Master Fix

- Fixed Hindi payment-method runtime display and canonical storage.
- Hindi payment methods: नकद, बैंक ट्रांसफर, यूपीआई, अन्य.
- Existing payment notes are localized at display time without corrupting stored canonical values.
- Fixed dark-theme native surfaces/inputs/cards that were using hard-coded white backgrounds.
- Release artifact name updated from v2.9 to v2.10.
- Removed stale FINAL_AUDIT_V23.md.
- App version remains 2.10 / versionCode 30.

Release APK could not be built in the current environment because Gradle 8.11.1 download requires services.gradle.org and DNS/network access is unavailable.
