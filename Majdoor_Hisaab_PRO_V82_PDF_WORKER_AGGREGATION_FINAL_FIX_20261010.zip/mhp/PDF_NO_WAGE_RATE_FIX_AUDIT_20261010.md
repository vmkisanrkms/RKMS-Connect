# PDF wage-rate visibility fix audit — 2026-10-10

- Updated `exportWorkerLedgerPdf` summary: removed the `कुल दिहाड़ी दर` label and current daily rate value.
- Replaced that summary slot with total attendance (`कुल हाजिरी`, in days).
- Kept total wages, total paid, and outstanding balance summary values.
- Verified by source scan that this individual ledger PDF summary no longer renders `कुल दिहाड़ी दर` or `प्रति दिन`.
- ZIP integrity can be verified; Android Kotlin compilation/device PDF rendering were not run in this environment.
