#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'custom date/field screen separate': 'if(showCustomReport)' in s and 'तारीख और खेत के अनुसार रिपोर्ट' in s,
 'date selector includes attendance and payment dates': 'val reportDates=(store.attendances.map{it.date}+store.payments.map{it.date}).distinct().sortedDescending()' in s,
 'payment-only workers included in report summary': 'val matchingLabourIds=(matchingAttendance.map{it.labourId}+matchingPayments.map{it.labourId}).toSet()' in s,
 'payments filtered once using same selected date and field scope': 'val matchingPayments=store.payments.filter{(chosenDates.isEmpty() || it.date in chosenDates) && (allFields || it.fieldId in chosenFieldIds)}' in s,
 'field selection filter applies': '(allFields || it.fieldId in chosenFieldIds)' in s,
 'attendance detail exports date field worker': 'हाजिरी और मजदूरी का खेतवार विवरण' in s and 'खेत $field • $labour • $attendance' in s,
 'payment detail exports date field worker': 'भुगतान का विवरण' in s and 'खेत $field • $labour • भुगतान' in s,
 'fractional attendance wages preserved': 'a.fraction* a.rate' in s or 'a.fraction*a.rate' in s,
 'summary totals generated from selected rows': 'selectedAttendance.sumOf{it.fraction*it.rate}' in s and 'selectedPayments.sumOf{it.amount}' in s,
 'uses existing PDF share flow': 'detailLines,background=true' in s and 'private fun exportReportPdf' in s,
 'monthly lock screen remains separate': 'if(selectedLockMonth.isNotBlank())' in s and 'महीना लॉक करें' in s,
}
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} date/field report checks passed')
sys.exit(bool(failed))
