# Date & Field Report Fix Audit — 2026-10-10

## Fixes applied
- The report date selector now includes dates from both saved attendance and payment records.
- Payment records are filtered by the same chosen date and field scope as attendance records.
- Workers who have a payment in the selected scope but no attendance row in that scope are included in the report summary.
- PDF detail lines retain date, field, worker, fractional attendance/wage, and payment amount.
- Month lock/ledger screen remains a separate screen; report does not finalize or lock accounts.

## Static audit
- `scripts_date_field_report_audit.py`: run after changes; expected 11/11 checks.
- `scripts_daily_labour_audit_check.py`: 26/26 checks.

## Limits
Static source checks are not a substitute for Kotlin/Gradle compilation or running the APK on a device. Those must be verified by GitHub Actions / Android runtime before calling the build fully verified.
