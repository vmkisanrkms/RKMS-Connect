# PDF Selected Date/Field List Fix Audit — 2026-10-10

Scope intentionally limited to the selected date/field PDF export list and its filtering. No attendance-entry, payment-entry, month lock, or other screen behavior was changed.

Changes:
- When specific fields are selected, dated payment rows are included for workers who have attendance in the selected fields; payment rows are not incorrectly filtered by a possibly empty/stale payment field ID.
- Missing/stale field names render as an em dash (`—`) in PDF rows instead of the misleading `खेत हटाया गया` label.
- Per-row balance now uses that worker's full ledger (all attendance wages minus all payments), rather than starting at zero within the selected subset and producing misleading negative running balances.
- The report's on-screen summary was intentionally left unchanged.
- Wage-rate column remains absent.

Static checks: 6/6 passed; ZIP integrity passed. Android Kotlin compilation and real-device PDF rendering were not run, so those remain unverified.
