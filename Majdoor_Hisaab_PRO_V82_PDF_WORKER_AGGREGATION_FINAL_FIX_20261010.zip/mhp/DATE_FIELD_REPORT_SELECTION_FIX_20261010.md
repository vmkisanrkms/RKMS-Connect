# Date and Field Report Selection Fix — 2026-10-10

- Added a separate “तारीख और खेत के अनुसार PDF रिपोर्ट” action to the existing joint labour report landing screen.
- Kept the monthly lock/unlock list and month-detail flow separate; did not replace it with a worker-finalization screen.
- The new selection screen lets the user select one or more attendance dates and fields, then calculates the matching attendance/wage and payments and exports the filtered worker summary PDF.
- The selection list is sourced from saved attendance dates and existing fields; no data migration or deletion is performed.
- Static daily-labour audit script: 26/26 checks passed.
- Limitation: the existing PDF layout is worker-summary based. It labels the chosen dates/fields and filters totals, but has not yet been extended to print every individual attendance row grouped by field and date. Android Gradle compilation/runtime test was not run in this environment.
