package com.majdoor.hisaab.storage

import android.content.Context
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.calculation.WorkRateEngine
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Offline-first JSON repository. No database engine is used. */
class LocalStore(private val context: Context) {

    /** Test-only cleanup entry point used by instrumentation; never called by production UI. */
    internal fun clearAllForE2E() {
        listOf("workers","worker_documents","worker_wage_history","fields","crops","crop_varieties","teams","attendance","work","payments","expenses","production","revenue","work_templates","audit_log").forEach { key -> runCatching { save(key, emptyList()) { it } } }
    }
    companion object {
        private const val MAX_BACKUP_BYTES = 100L * 1024L * 1024L
        private const val MAX_BACKUP_ENTRIES = 256
        private val ISO_DATE = Regex("\\d{4}-\\d{2}-\\d{2}")
        private val ALLOWED_EXPENSE_CATEGORIES = setOf("Labour","Fertilizer","Seed","Pesticide","Irrigation","Machinery","Diesel","Transport","Repair","Other")
        private val ALLOWED_WAGE_UNITS = setOf("DAY","HALF_DAY","HOUR","ACRE","QUANTITY","PIECE")
        private fun requireIsoDate(value:String, label:String){
            require(value.matches(ISO_DATE)){ "$label must use yyyy-MM-dd." }
            val parts=value.split('-').map{it.toInt()}
            val cal=java.util.GregorianCalendar(java.util.TimeZone.getTimeZone("UTC"), java.util.Locale.US)
            cal.isLenient=false; cal.clear(); cal.set(parts[0],parts[1]-1,parts[2]); cal.timeInMillis
        }
    }
    private val root = File(context.getExternalFilesDir(null), "majdoor_hisaab").apply { mkdirs() }
    private val data = File(root, "data").apply { mkdirs() }
    private val backups = File(root, "backups").apply { mkdirs() }
    private val version = 2
    private val schemaVersion = 4
    private val allowed = setOf("workers.json","worker_documents.json","worker_wage_history.json","work_templates.json","fields.json","crops.json","crop_varieties.json","attendance.json","teams.json","work.json","payments.json","expenses.json","production.json","revenue.json","backup_metadata.json","audit_log.json")
    init {
        allowed.forEach { name -> val file=File(data,name); if(!file.exists()) file.writeText("[]") }
        migrateLocalModelIfNeeded()
        if (File(data,"backup_metadata.json").length() == 0L) write("backup_metadata", JSONArray().put(BackupMetadata(schemaVersion=schemaVersion).json()))
    }

    private fun migrateLocalModelIfNeeded(){
        val historyFile=File(data,"worker_wage_history.json")
        if (JSONArray(historyFile.readText()).length()==0 && workers().isNotEmpty()) {
            val a=JSONArray(); workers().forEach { w ->
                val effective=w.joiningDate.ifBlank { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()) }
                a.put(WorkerWageHistory(workerId=w.id,effectiveFrom=effective,rate=w.defaultRate,rateUnit=w.rateUnit.uppercase(),source="MIGRATION").json())
            }; write("worker_wage_history",a)
        }
        val varietyFile=File(data,"crop_varieties.json")
        if (JSONArray(varietyFile.readText()).length()==0 && crops().any{it.variety.isNotBlank()}) {
            val a=JSONArray(); val seen=mutableSetOf<String>(); crops().filter{it.variety.isNotBlank()}.forEach { c ->
                val key=c.id+"|"+c.variety.trim().lowercase()
                if(seen.add(key)) a.put(CropVariety(cropId=c.id,name=c.variety.trim(),active=true).json())
            }; write("crop_varieties",a)
        } else if (JSONArray(varietyFile.readText()).any { it is JSONObject && it.optString("cropId").isBlank() && it.optString("cropName").isNotBlank() }) {
            val a=JSONArray(); val seen=mutableSetOf<String>(); val old=JSONArray(varietyFile.readText())
            for(i in 0 until old.length()) {
                val v=old.getJSONObject(i); val oldName=v.optString("cropName").trim(); val oldVariety=v.optString("name").trim()
                crops().filter{it.name.equals(oldName,true) && it.variety.equals(oldVariety,true)}.forEach { c ->
                    val key=c.id+"|"+oldVariety.lowercase(); if(seen.add(key)) a.put(CropVariety(id=v.optString("id").ifBlank{UUID.randomUUID().toString()},cropId=c.id,name=oldVariety,notes=v.optString("notes"),active=v.optBoolean("active",true)).json())
                }
            }
            write("crop_varieties",a)
        }
    }

    private fun f(name:String)=File(data,"$name.json")
    private fun read(name:String):JSONArray { val file=f(name); if(!file.exists()) return JSONArray(); return try { JSONArray(file.readText()) } catch(e:Exception){ throw IllegalStateException("Corrupt $name.json",e) } }
    private fun write(name:String,array:JSONArray){
        val target=f(name)
        val tmp=File(data,".${name}.${UUID.randomUUID()}.tmp")
        val bytes=array.toString(2).toByteArray(Charsets.UTF_8)
        FileOutputStream(tmp).use { out -> out.write(bytes); out.flush(); out.fd.sync() }
        if(!tmp.renameTo(target)) { tmp.copyTo(target,true); tmp.delete() }
    }
    private fun <T> list(name:String,parser:(JSONObject)->T):List<T>{ val a=read(name); return buildList { for(i in 0 until a.length()) add(parser(a.getJSONObject(i))) } }
    private fun <T> save(name:String,items:List<T>,serializer:(T)->JSONObject){ val a=JSONArray(); items.forEach{a.put(serializer(it))}; write(name,a) }
    private fun atomicMutation(vararg names:String, block:()->Unit){
        synchronized(this){
            val snapshots=names.distinct().associateWith{ name -> val file=f(name); if(file.exists()) file.readBytes() else null }
            try { block() } catch (e:Exception) {
                snapshots.forEach{(name,bytes)-> val file=f(name); if(bytes==null) file.delete() else file.writeBytes(bytes) }
                throw e
            }
        }
    }

    fun workers()=list("workers",Worker::from)
    fun workerDocuments()=list("worker_documents",WorkerDocument::from)
    fun workerWageHistory()=list("worker_wage_history",WorkerWageHistory::from)
    fun upsertWorkerWage(x:WorkerWageHistory){
        require(workers().any{it.id==x.workerId}){"Worker not found."}
        require(x.rate.isFinite() && x.rate>=0){"Wage rate must be a finite non-negative number."}
        require(x.rateUnit.uppercase() in ALLOWED_WAGE_UNITS){"Invalid wage unit."}
        requireIsoDate(x.effectiveFrom,"Wage effective date")
        val l=workerWageHistory().toMutableList()
        if(l.any{it.id!=x.id && it.workerId==x.workerId && it.effectiveFrom==x.effectiveFrom}) throw IllegalArgumentException("A wage rate already exists for this worker and effective date.")
        val i=l.indexOfFirst{it.id==x.id}; if(i>=0) l[i]=x else l.add(x)
        save("worker_wage_history",l){it.json()}
        audit(if(i>=0)"UPDATE" else "CREATE","worker_wage",x.id,"${x.effectiveFrom} ${x.rate}/${x.rateUnit}")
    }
    fun deleteWorkerWage(id:String){
        val x=workerWageHistory().firstOrNull{it.id==id} ?: return
        save("worker_wage_history",workerWageHistory().filter{it.id!=id}){it.json()}
        audit("DELETE","worker_wage",id)
    }
    fun wageFor(workerId:String, date:String, fallback:Double=0.0):Pair<Double,String>{
        requireIsoDate(date,"Wage date")
        val h=workerWageHistory().filter{it.workerId==workerId && it.effectiveFrom<=date}.maxByOrNull{it.effectiveFrom}
        return if(h!=null) h.rate to h.rateUnit else fallback to "DAY"
    }
    fun workTemplates()=list("work_templates",WorkTemplate::from)
    fun fields()=list("fields",Field::from)
    fun crops()=list("crops",Crop::from)
    fun cropVarieties()=list("crop_varieties",CropVariety::from)
    fun attendance()=list("attendance",Attendance::from)
    fun teams()=list("teams",Team::from)
    fun work()=list("work",WorkRecord::from)
    fun payments()=list("payments",Payment::from)
    fun expenses()=list("expenses",Expense::from)
    fun production()=list("production",Production::from)
    fun revenue()=list("revenue",Revenue::from)
    fun backupMetadata():BackupMetadata = list("backup_metadata",BackupMetadata::from).firstOrNull() ?: BackupMetadata()

    private fun audit(action:String, entity:String, entityId:String = "", summary:String = "", source:String = "UI") {
        try {
            val a = read("audit_log")
            val entry = JSONObject()
                .put("id", UUID.randomUUID().toString())
                .put("timestamp", System.currentTimeMillis())
                .put("action", action)
                .put("entity", entity)
                .put("entityId", entityId)
                .put("summary", summary)
                .put("source", source)
            a.put(entry)
            while (a.length() > 2000) {
                val trimmed = JSONArray()
                for (i in 1 until a.length()) trimmed.put(a.getJSONObject(i))
                write("audit_log", trimmed)
                return
            }
            write("audit_log", a)
        } catch (_: Exception) {
            // Audit logging must never make a successful business-data mutation fail.
        }
    }
    fun auditLog(): List<JSONObject> = try {
        val a = read("audit_log")
        buildList { for (i in 0 until a.length()) add(a.getJSONObject(i)) }
    } catch (_: Exception) { emptyList() }
    fun clearAuditLog() { write("audit_log", JSONArray()); audit("CLEAR", "audit_log", summary="Audit log cleared", source="UI") }
    fun logSettingChange(setting:String, value:String) { val sensitive=setting.lowercase() in setOf("pin","password","passwd","secret","token","api_key","apikey"); audit("UPDATE","setting",setting,"$setting = ${if(sensitive) "<redacted>" else value}") }

    fun upsertWorkTemplate(x:WorkTemplate){
        require(x.name.isNotBlank()){"Template name required."}; require(x.rate>=0){"Rate cannot be negative."}; require(WorkRateEngine.normalize(x.rateType,x.unit) in WorkRateEngine.types){"Invalid rate type."}
        val l=workTemplates().toMutableList(); val i=l.indexOfFirst{it.id==x.id}; if(i>=0)l[i]=x else l.add(x); save("work_templates",l){it.json()}
        audit(if(i>=0) "UPDATE" else "CREATE", "work_template", x.id, x.name)
    }
    fun deleteWorkTemplate(id:String){save("work_templates",workTemplates().filter{it.id!=id}){it.json()}; audit("DELETE","work_template",id)}

    fun upsertWorkerDocument(x:WorkerDocument){
        require(workers().any{it.id==x.workerId}){"Worker not found."}
        require(x.name.isNotBlank() && x.uri.isNotBlank()){"Document name and URI are required."}
        val l=workerDocuments().toMutableList(); val i=l.indexOfFirst{it.id==x.id}; if(i>=0)l[i]=x else l.add(x); save("worker_documents",l){it.json()}
        audit(if(i>=0) "UPDATE" else "CREATE", "worker_document", x.id, x.name)
    }
    fun deleteWorkerDocument(id:String){save("worker_documents",workerDocuments().filter{it.id!=id}){it.json()}; audit("DELETE","worker_document",id)}

    fun upsertWorker(x:Worker){
        require(x.name.trim().isNotBlank()){ "Worker name required." }
        require(x.mobile.isBlank() || x.mobile.trim().matches(Regex("[0-9]{10}"))){ "Mobile number must be exactly 10 digits." }
        require(x.defaultRate.isFinite() && x.defaultRate>=0){ "Worker wage must be a finite non-negative number." }
        require(x.rateUnit.uppercase() in ALLOWED_WAGE_UNITS){ "Invalid wage unit." }
        if(x.joiningDate.isNotBlank()) requireIsoDate(x.joiningDate,"Joining date")
        val l=workers().toMutableList()
        if(l.any{it.id!=x.id && x.mobile.isNotBlank() && it.mobile.equals(x.mobile,true)}) throw IllegalArgumentException("A worker with this mobile number already exists.")
        if(l.any{it.id!=x.id && it.name.trim().equals(x.name.trim(),true)}) throw IllegalArgumentException("A worker with this name already exists.")
        val i=l.indexOfFirst{it.id==x.id}; val previous=if(i>=0) l[i] else null
        if(i>=0) l[i]=x else l.add(x)
        atomicMutation("workers","worker_wage_history","audit_log") {
            save("workers",l){it.json()}
            val today=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(java.util.Date())
            val effectiveDate=if(previous==null) x.joiningDate.ifBlank{today} else today
            if(previous==null || previous.defaultRate!=x.defaultRate || previous.rateUnit.uppercase()!=x.rateUnit.uppercase()){
                val history=workerWageHistory().toMutableList()
                if(history.none{it.workerId==x.id && it.effectiveFrom==effectiveDate && it.rate==x.defaultRate && it.rateUnit.equals(x.rateUnit,true)}){
                    history.add(WorkerWageHistory(workerId=x.id,effectiveFrom=effectiveDate,rate=x.defaultRate,rateUnit=x.rateUnit.uppercase(),source="WORKER"))
                    save("worker_wage_history",history){it.json()}
                }
            }
            audit(if(i>=0) "UPDATE" else "CREATE","worker",x.id,x.name)
        }
    }
    fun deleteWorker(id:String){
        if(attendance().any{it.workerId==id} || payments().any{it.workerId==id} || work().any{it.workerIds.contains(id)} || workerDocuments().any{it.workerId==id} || workerWageHistory().any{it.workerId==id} || teams().any{it.workerIds.contains(id)}) throw IllegalArgumentException("Worker has linked records. Deactivate the worker instead of deleting.")
        save("workers",workers().filter{it.id!=id}){it.json()}
        audit("DELETE","worker",id)
    }
    fun upsertField(x:Field){ require(x.name.trim().isNotBlank()){ "Field name required." }; require(x.area.isFinite() && x.area>=0){ "Field area must be a finite non-negative number." }; val l=fields().toMutableList(); if(l.any{it.id!=x.id && it.name.trim().equals(x.name.trim(),true)}) throw IllegalArgumentException("A field with this name already exists."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("fields",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "field", x.id, x.name) }
    fun deleteField(id:String){ if(crops().any{it.fieldId==id} || attendance().any{it.fieldId==id} || work().any{it.fieldId==id} || expenses().any{it.fieldId==id}) throw IllegalArgumentException("Field has linked records. Deactivate it instead."); save("fields",fields().filter{it.id!=id}){it.json()}; audit("DELETE","field",id) }
    fun upsertCrop(x:Crop){
        require(x.name.trim().isNotBlank()){ "Crop name required." }
        require(x.area.isFinite() && x.area>0){ "Crop area must be a finite number greater than zero." }
        require(x.plantingDate.isNotBlank()){ "Planting date required." }
        requireIsoDate(x.plantingDate,"Planting date")
        val l=crops().toMutableList()
        if(x.fieldId.isNotBlank() && fields().none{it.id==x.fieldId}) throw IllegalArgumentException("Field not found.")
        if(x.fieldId.isNotBlank()){
            val field=fields().first{it.id==x.fieldId}
            if(field.area>0.0) require(x.area<=field.area){ "Crop area cannot exceed field area (${field.area})." }
        }
        if(l.any{it.id!=x.id && it.fieldId==x.fieldId && it.name.trim().equals(x.name.trim(),true) && it.variety.trim().equals(x.variety.trim(),true) && it.plantingDate==x.plantingDate}) throw IllegalArgumentException("This crop already exists for the selected field and planting date.")
        atomicMutation("crops","crop_varieties","audit_log") {
            if(x.variety.isNotBlank() && cropVarieties().none{it.cropId==x.id && it.name.equals(x.variety,true)}) {
                val varieties=cropVarieties().toMutableList(); varieties.add(CropVariety(cropId=x.id,name=x.variety.trim())); save("crop_varieties",varieties){it.json()}
            }
            val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("crops",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "crop", x.id, x.name)
        }
    }
    fun deleteCrop(id:String){ if(work().any{it.cropId==id} || production().any{it.cropId==id} || revenue().any{it.cropId==id} || expenses().any{it.cropId==id}) throw IllegalArgumentException("Crop has linked records. Deactivate it instead."); save("crops",crops().filter{it.id!=id}){it.json()}; audit("DELETE","crop",id) }
    fun upsertCropVariety(x:CropVariety){
        require(x.cropId.isNotBlank() && crops().any{it.id==x.cropId}){ "Crop reference is required and must exist." }
        require(x.name.isNotBlank()){ "Variety name is required." }
        val l=cropVarieties().toMutableList()
        if(l.any{it.id!=x.id && it.cropId==x.cropId && it.name.equals(x.name,true)}) throw IllegalArgumentException("Crop variety already exists.")
        val i=l.indexOfFirst{it.id==x.id}; if(i>=0)l[i]=x else l.add(x)
        save("crop_varieties",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE","crop_variety",x.id,x.name)
    }
    fun deleteCropVariety(id:String){ val v=cropVarieties().firstOrNull{it.id==id}; if(v!=null && crops().any{it.id==v.cropId && it.variety.equals(v.name,true)}) throw IllegalArgumentException("Crop variety is in use. Deactivate it instead."); save("crop_varieties",cropVarieties().filter{it.id!=id}){it.json()}; audit("DELETE","crop_variety",id) }

    fun upsertAttendance(x:Attendance){
        requireIsoDate(x.date,"Attendance date"); require(x.rate.isFinite() && x.rate>=0){ "Attendance rate must be a finite non-negative number." }; require(workers().any{it.id==x.workerId}){ "Worker not found." }; require(x.fieldId.isBlank() || fields().any{it.id==x.fieldId}){ "Field not found." }; require(x.status.uppercase() in setOf("FULL","HALF","NONE")){ "Invalid attendance status." }
        val l=attendance().toMutableList(); val duplicate=l.indexOfFirst{it.date==x.date && it.workerId==x.workerId && it.fieldId==x.fieldId && it.id!=x.id}; if(duplicate>=0) throw IllegalArgumentException("Attendance already exists for this worker, date and field.")
        val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("attendance",l){it.json()}
        audit(if(i>=0) "UPDATE" else "CREATE", "attendance", x.id, "${x.date} ${x.status}")
    }
    fun deleteAttendance(id:String){save("attendance",attendance().filter{it.id!=id}){it.json()}; audit("DELETE","attendance",id)}
    fun upsertTeam(x:Team){ require(x.name.isNotBlank()){"Team name required."}; require(x.workerIds.distinct().size==x.workerIds.size){"Duplicate worker in team."}; require(x.workerIds.all{id->workers().any{it.id==id}}){"One or more workers were not found."}; val exists=teams().any{it.id==x.id}; save("teams",teams().filter{it.id!=x.id}+x){it.json()}; audit(if(exists) "UPDATE" else "CREATE", "team", x.id, x.name) }
    fun deleteTeam(id:String){ save("teams",teams().filter{it.id!=id}){it.json()}; audit("DELETE","team",id) }
    fun upsertWork(x:WorkRecord){
        requireIsoDate(x.date,"Work date")
        require(x.workType.trim().isNotBlank()){ "Work type required." }
        require(x.workerIds.isNotEmpty()){"At least one worker is required."}; require(x.workerIds.distinct().size==x.workerIds.size){"Duplicate worker selected."}; require(x.quantity.isFinite() && x.rate.isFinite() && x.quantity>=0 && x.rate>=0){"Quantity and rate must be finite non-negative numbers."}; require(WorkRateEngine.normalize(x.rateType,x.unit) in WorkRateEngine.types){"Invalid rate type."}; if(WorkRateEngine.normalize(x.rateType,x.unit)==WorkRateEngine.HOURLY && x.quantity==0.0 && (x.startTime.isBlank() || x.endTime.isBlank())) throw IllegalArgumentException("Hourly work needs hours or both start and end time.")
        require(fields().any{it.id==x.fieldId}){"Field not found."}; require(crops().any{it.id==x.cropId}){"Crop not found."}; require(crops().first{it.id==x.cropId}.fieldId==x.fieldId){"Selected crop does not belong to selected field."}; require(x.workerIds.all{id->workers().any{it.id==id}}){"One or more workers were not found."}
        val timePattern = Regex("(?:[01]\\d|2[0-3]):[0-5]\\d")
        require(x.startTime.isBlank() || x.startTime.matches(timePattern)){"Start time must use HH:mm."}
        require(x.endTime.isBlank() || x.endTime.matches(timePattern)){"End time must use HH:mm."}
        val l=work().toMutableList(); if(l.any{it.id!=x.id && it.fingerprint()==x.fingerprint()}) throw IllegalArgumentException("Duplicate work record detected."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("work",l){it.json()}
        audit(if(i>=0) "UPDATE" else "CREATE", "work", x.id, x.workType)
    }
    fun deleteWork(id:String){save("work",work().filter{it.id!=id}){it.json()}; audit("DELETE","work",id)}
    fun upsertPayment(x:Payment){ requireIsoDate(x.date,"Payment date"); require(x.amount.isFinite() && x.amount>0){"Payment amount must be a finite number greater than zero."}; require(x.method in setOf("Cash","Bank","UPI")){"Payment method must be Cash, Bank or UPI."}; require(workers().any{it.id==x.workerId}){"Worker not found."}; val l=payments().toMutableList(); if(l.any{it.id!=x.id && it.workerId==x.workerId && it.date==x.date && it.amount==x.amount && it.method.equals(x.method,true) && it.reference==x.reference && it.advance==x.advance}) throw IllegalArgumentException("Duplicate payment detected."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("payments",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "payment", x.id, "${x.date} ${x.amount}") }
    fun deletePayment(id:String){save("payments",payments().filter{it.id!=id}){it.json()}; audit("DELETE","payment",id)}
    fun upsertExpense(x:Expense){ requireIsoDate(x.date,"Expense date"); val configuredExpenseCategories = context.getSharedPreferences("settings", Context.MODE_PRIVATE).getString("expense_categories", "")?.split(",")?.map{it.trim()}?.filter{it.isNotBlank()}?.toSet().orEmpty()
        require(x.category in (ALLOWED_EXPENSE_CATEGORIES + configuredExpenseCategories)){"Invalid expense category."}; require(x.amount.isFinite() && x.amount>0){"Expense amount must be a finite number greater than zero."}; require(x.fieldId.isBlank()||fields().any{it.id==x.fieldId}){"Field not found."}; require(x.cropId.isBlank()||crops().any{it.id==x.cropId}){"Crop not found."}; require(x.cropId.isBlank() || x.fieldId.isBlank() || crops().first{it.id==x.cropId}.fieldId.isBlank() || crops().first{it.id==x.cropId}.fieldId==x.fieldId){"Selected crop does not belong to selected field."}; val l=expenses().toMutableList(); if(l.any{it.id!=x.id && it.date==x.date && it.category.equals(x.category,true) && it.amount==x.amount && it.fieldId==x.fieldId && it.cropId==x.cropId && it.notes==x.notes}) throw IllegalArgumentException("Duplicate expense detected."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("expenses",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "expense", x.id, "${x.date} ${x.amount}") }
    fun deleteExpense(id:String){save("expenses",expenses().filter{it.id!=id}){it.json()}; audit("DELETE","expense",id)}
    fun upsertProduction(x:Production){ requireIsoDate(x.date,"Production date"); require(x.quantity.isFinite() && x.quantity>0){"Production quantity must be a finite number greater than zero."}; require(crops().any{it.id==x.cropId}){"Crop not found."}; val l=production().toMutableList(); if(l.any{it.id!=x.id && it.cropId==x.cropId && it.date==x.date && it.quantity==x.quantity && it.unit.equals(x.unit,true) && it.note==x.note}) throw IllegalArgumentException("Duplicate production record detected."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("production",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "production", x.id, "${x.date} ${x.quantity}") }
    fun deleteProduction(id:String){save("production",production().filter{it.id!=id}){it.json()}; audit("DELETE","production",id)}
    fun upsertRevenue(x:Revenue){ requireIsoDate(x.date,"Revenue date"); require(x.amount.isFinite() && x.amount>0){"Revenue amount must be a finite number greater than zero."}; require(crops().any{it.id==x.cropId}){"Crop not found."}; val l=revenue().toMutableList(); if(l.any{it.id!=x.id && it.cropId==x.cropId && it.date==x.date && it.amount==x.amount && it.note==x.note}) throw IllegalArgumentException("Duplicate revenue record detected."); val i=l.indexOfFirst{it.id==x.id};if(i>=0)l[i]=x else l.add(x);save("revenue",l){it.json()}; audit(if(i>=0) "UPDATE" else "CREATE", "revenue", x.id, "${x.date} ${x.amount}") }
    fun deleteRevenue(id:String){save("revenue",revenue().filter{it.id!=id}){it.json()}; audit("DELETE","revenue",id)}

    private fun sha256(file:File):String {
        val md=java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val buf=ByteArray(8192); while(true){ val n=input.read(buf); if(n<0) break; md.update(buf,0,n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
    private fun backupFiles():List<File> = data.listFiles()?.filter{it.isFile && it.name in allowed}.orEmpty().sortedBy{it.name}
    private fun manifest():JSONObject {
        val files=JSONArray()
        backupFiles().forEach { f -> files.put(JSONObject().put("name",f.name).put("bytes",f.length()).put("sha256",sha256(f))) }
        return JSONObject().put("app","Majdoor Hisaab PRO").put("formatVersion",version).put("schemaVersion",schemaVersion)
            .put("createdAt",System.currentTimeMillis()).put("storage","JSON").put("fileCount",files.length()).put("files",files)
    }
    private fun persistBackupMetadata(operation:String){
        val m=BackupMetadata(lastBackupAt=System.currentTimeMillis(),formatVersion=version,schemaVersion=schemaVersion,storage="JSON",lastOperation=operation)
        write("backup_metadata",JSONArray().put(m.json()))
    }
    private fun writeZip(out:OutputStream, operation:String="EXPORT"){
        persistBackupMetadata(operation)
        ZipOutputStream(BufferedOutputStream(out)).use{z-> z.putNextEntry(ZipEntry("manifest.json")); z.write(manifest().toString().toByteArray(Charsets.UTF_8)); z.closeEntry(); backupFiles().forEach{file->z.putNextEntry(ZipEntry("data/${file.name}"));file.inputStream().use{it.copyTo(z)};z.closeEntry()} }
    }
    fun backupToInternal():File{ val out=File(backups,"Majdoor_Hisaab_${System.currentTimeMillis()}.zip"); FileOutputStream(out).use{writeZip(it,"INTERNAL")}; audit("CREATE","backup",out.name,"Local backup created", "SYSTEM"); return out }
    fun exportBackup(out:OutputStream){writeZip(out,"EXPORT"); audit("EXPORT","backup",summary="Backup exported",source="UI")}

    /**
     * Import a validated backup without silently overwriting local records.
     * Records with the same ID must be byte-for-byte equivalent; otherwise the
     * import is rejected and the user can choose the explicit Replace/Restore flow.
     */
    private fun canonicalJsonValue(value:Any?):String = when(value){
        is JSONObject -> value.keys().asSequence().toList().sorted().joinToString(prefix="{",postfix="}"){ k -> JSONObject.quote(k)+":"+canonicalJsonValue(value.get(k)) }
        is JSONArray -> (0 until value.length()).joinToString(prefix="[",postfix="]"){ i -> canonicalJsonValue(value.get(i)) }
        JSONObject.NULL -> "null"
        is Number, is Boolean, is String -> JSONObject.valueToString(value)
        else -> JSONObject.quote(value.toString())
    }
    private fun canonicalRecord(value:JSONObject):String = canonicalJsonValue(value)

    fun importBackupMerge(input:InputStream):String{
        val temp=File(context.cacheDir,"import_${UUID.randomUUID()}").apply{mkdirs()}
        val staged=File(context.cacheDir,"import_stage_${UUID.randomUUID()}").apply{mkdirs()}
        val rollback=File(context.cacheDir,"import_rollback_${UUID.randomUUID()}").apply{mkdirs()}
        var committed=false
        try{
            extract(input,temp)
            val manifestFile=File(temp,"manifest.json")
            if(!manifestFile.exists()) throw IllegalArgumentException("Manifest missing")
            val mj=JSONObject(manifestFile.readText())
            if(mj.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Wrong app backup.")
            if(mj.optInt("formatVersion",-1)!=version) throw IllegalArgumentException("Unsupported backup version ${mj.optInt("formatVersion")}")
            val incomingSchema=mj.optInt("schemaVersion",-1); if(incomingSchema!=schemaVersion && incomingSchema!=3 && incomingSchema!=2) throw IllegalArgumentException("Unsupported schema version $incomingSchema")
            val incomingDir=File(temp,"data")
            validateManifestFiles(mj, incomingDir)
            migrateLegacySchemaIfNeeded(mj, incomingDir)
            validateDataFolder(incomingDir)
            validateRelationalFolder(incomingDir)

            val conflicts=mutableListOf<String>(); var added=0; var skipped=0
            allowed.forEach{fileName->
                val name=fileName.removeSuffix(".json")
                if(fileName=="backup_metadata.json") {
                    File(staged,fileName).writeText(File(incomingDir,fileName).readText())
                    return@forEach
                }
                val existing=read(name).associateBy{it.optString("id")}
                val incoming=JSONArray(File(incomingDir,fileName).readText())
                val merged=JSONArray(); existing.values.forEach{merged.put(it)}
                for(i in 0 until incoming.length()){
                    val obj=incoming.getJSONObject(i); val id=obj.optString("id"); val old=existing[id]
                    if(id.isBlank()) throw IllegalArgumentException("Blank ID in $fileName")
                    if(old==null){merged.put(obj);added++}
                    else if(canonicalRecord(old)==canonicalRecord(obj)){skipped++}
                    else conflicts.add("$fileName: conflicting ID $id")
                }
                File(staged,fileName).writeText(merged.toString(2))
            }
            if(conflicts.isNotEmpty()) throw IllegalArgumentException("Import stopped: ${conflicts.size} conflicting record ID(s). Use Restore/Replace only after reviewing the backup.")

            validateDataFolder(staged)
            validateRelationalFolder(staged)
            // Verify a COMPLETE rollback snapshot before modifying live data. If
            // snapshot creation fails, import aborts without touching live data.
            val liveFiles = data.listFiles()?.filter{it.isFile && it.name in allowed}.orEmpty()
            val expectedRollbackNames = liveFiles.map{it.name}.toSet()
            try {
                liveFiles.forEach { src ->
                    val dst=File(rollback,src.name)
                    src.copyTo(dst,true)
                    require(dst.exists() && dst.length()==src.length()) { "Import rollback snapshot verification failed for ${src.name}" }
                }
                require(rollback.listFiles()?.filter{it.isFile}?.map{it.name}?.toSet().orEmpty()==expectedRollbackNames) { "Import rollback snapshot is incomplete." }
            } catch(snapshotError:Exception) {
                rollback.deleteRecursively()
                throw IllegalStateException("Import aborted safely: rollback snapshot could not be completed. Existing data was not modified.",snapshotError)
            }
            staged.listFiles()?.filter{it.isFile && it.name in allowed}?.forEach{it.copyTo(File(data,it.name),true)}
            validateDataFolder(data)
            validateRelationalFolder(data)
            committed=true
            audit("IMPORT","data",summary="Merged backup: $added added, $skipped skipped",source="UI")
            "Import successful: $added new record(s) added, $skipped identical record(s) skipped. Existing data was not overwritten."
        } catch(e:Exception){
            if(!committed){
                data.listFiles()?.filter{it.isFile && it.name in allowed}?.forEach{it.delete()}
                rollback.listFiles()?.filter{it.isFile}?.forEach{it.copyTo(File(data,it.name),true)}
            }
            throw e
        } finally { temp.deleteRecursively(); staged.deleteRecursively(); rollback.deleteRecursively() }
    }

    private fun validateDataFolder(dir:File){
        if(!dir.exists()) throw IllegalArgumentException("Backup data folder missing.")
        val files=dir.listFiles()?.filter{it.isFile} ?: emptyList()
        if(files.any{it.name !in allowed}) throw IllegalArgumentException("Unexpected backup file: ${files.first{it.name !in allowed}.name}")
        val names=files.map{it.name}.toSet()
        val required=allowed.filter{it!="audit_log.json"}
        val missing=required.filter{it !in names}
        if(missing.isNotEmpty()) throw IllegalArgumentException("Backup is incomplete. Missing: ${missing.joinToString()}")
        files.forEach{ val arr=JSONArray(it.readText()); for(i in 0 until arr.length()){ if(!arr.get(i).toString().trim().startsWith("{")) throw IllegalArgumentException("Invalid record in ${it.name}") } }
    }
    private fun validateRelationalFolder(dir:File){
        fun arr(name:String)=JSONArray(File(dir,name).readText())
        fun ids(name:String):Set<String>{
            val a=arr(name); val set=mutableSetOf<String>()
            for(i in 0 until a.length()) { val id=a.getJSONObject(i).optString("id"); if(id.isBlank()) throw IllegalArgumentException("$name contains blank id"); if(!set.add(id)) throw IllegalArgumentException("$name contains duplicate id: $id") }
            return set
        }
        val workers=ids("workers.json"); val fields=ids("fields.json"); val crops=ids("crops.json")
        val attendance=arr("attendance.json"); for(i in 0 until attendance.length()){ val x=attendance.getJSONObject(i); if(x.optString("workerId") !in workers) throw IllegalArgumentException("attendance references missing worker '${x.optString("workerId")}'"); val f=x.optString("fieldId"); if(f.isNotBlank()&&f !in fields) throw IllegalArgumentException("attendance references missing field '$f'") }
        val teams=arr("teams.json"); for(i in 0 until teams.length()){ val x=teams.getJSONObject(i); val ws=x.optJSONArray("workerIds")?:JSONArray(); for(j in 0 until ws.length()) if(ws.optString(j) !in workers) throw IllegalArgumentException("team references missing worker '${ws.optString(j)}'") }
        val work=arr("work.json"); for(i in 0 until work.length()){ val x=work.getJSONObject(i); if(x.optString("fieldId") !in fields) throw IllegalArgumentException("work references missing field '${x.optString("fieldId")}'"); if(x.optString("cropId") !in crops) throw IllegalArgumentException("work references missing crop '${x.optString("cropId")}'"); val ws=x.optJSONArray("workerIds")?:JSONArray(); for(j in 0 until ws.length()) if(ws.optString(j) !in workers) throw IllegalArgumentException("work references missing worker '${ws.optString(j)}'") }
        val payments=arr("payments.json"); for(i in 0 until payments.length()) if(payments.getJSONObject(i).optString("workerId") !in workers) throw IllegalArgumentException("payment references missing worker")
        val expenses=arr("expenses.json"); for(i in 0 until expenses.length()){ val x=expenses.getJSONObject(i); val f=x.optString("fieldId"); val c=x.optString("cropId"); if(f.isNotBlank()&&f !in fields) throw IllegalArgumentException("expense references missing field '$f'"); if(c.isNotBlank()&&c !in crops) throw IllegalArgumentException("expense references missing crop '$c'") }
        val production=arr("production.json"); for(i in 0 until production.length()) if(production.getJSONObject(i).optString("cropId") !in crops) throw IllegalArgumentException("production references missing crop")
        val revenue=arr("revenue.json"); for(i in 0 until revenue.length()) if(revenue.getJSONObject(i).optString("cropId") !in crops) throw IllegalArgumentException("revenue references missing crop")
        val docs=arr("worker_documents.json"); for(i in 0 until docs.length()) if(docs.getJSONObject(i).optString("workerId") !in workers) throw IllegalArgumentException("worker document references missing worker")
        val wageHistory=arr("worker_wage_history.json"); for(i in 0 until wageHistory.length()){ val x=wageHistory.getJSONObject(i); if(x.optString("workerId") !in workers) throw IllegalArgumentException("worker wage history references missing worker"); if(x.optDouble("rate",Double.NaN).isNaN() || x.optDouble("rate")<0) throw IllegalArgumentException("worker wage history has invalid rate"); requireIsoDate(x.optString("effectiveFrom"),"Wage history effective date") }
        val varieties=arr("crop_varieties.json"); val cropIdSet=(0 until arr("crops.json").length()).map{arr("crops.json").getJSONObject(it).optString("id")}.toSet(); val varietyKeys=mutableSetOf<String>(); for(i in 0 until varieties.length()){ val x=varieties.getJSONObject(i); val cropId=x.optString("cropId"); if(cropId.isBlank() || cropId !in cropIdSet) throw IllegalArgumentException("crop variety references missing crop '$cropId'"); val key=cropId+"|"+x.optString("name").trim().lowercase(); if(!varietyKeys.add(key)) throw IllegalArgumentException("Duplicate crop variety: $key") }
        val cropArr=arr("crops.json"); for(i in 0 until cropArr.length()){ val x=cropArr.getJSONObject(i); val f=x.optString("fieldId"); if(f.isNotBlank()&&f !in fields) throw IllegalArgumentException("crop references missing field '$f'"); if(x.optString("variety").isNotBlank()){ val ok=(0 until varieties.length()).any{j-> val v=varieties.getJSONObject(j); v.optString("cropId")==x.optString("id")&&v.optString("name").equals(x.optString("variety"),true)}; if(!ok) throw IllegalArgumentException("crop references missing variety '${x.optString("variety")}'") } }
        val metadata=arr("backup_metadata.json"); if(metadata.length()>1) throw IllegalArgumentException("backup_metadata must contain at most one current record"); if(metadata.length()==1){ val m=metadata.getJSONObject(0); if(m.optString("id")!="current") throw IllegalArgumentException("backup_metadata id must be current"); if(m.optInt("schemaVersion",-1)!=schemaVersion) throw IllegalArgumentException("backup_metadata schema mismatch") }
    }

    fun validateBackup(input:InputStream):Pair<Boolean,String>{ return try { val temp=File(context.cacheDir,"validate_${UUID.randomUUID()}").apply{mkdirs()}; extract(input,temp); val mj=JSONObject(File(temp,"manifest.json").readText()); if(mj.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Wrong app backup."); if(mj.optInt("formatVersion",-1)!=version) throw IllegalArgumentException("Unsupported backup version ${mj.optInt("formatVersion")}")
            val incomingSchema=mj.optInt("schemaVersion",-1); if(incomingSchema!=schemaVersion && incomingSchema!=3 && incomingSchema!=2) throw IllegalArgumentException("Unsupported schema version $incomingSchema")
            validateManifestFiles(mj, File(temp,"data")); migrateLegacySchemaIfNeeded(mj, File(temp,"data")); validateDataFolder(File(temp,"data")); validateRelationalFolder(File(temp,"data")); temp.deleteRecursively(); true to "Backup validated." } catch(e:Exception){ false to (e.message ?: "Invalid backup") } }
    private fun migrateLegacySchemaIfNeeded(mj:JSONObject, dir:File){
        val incomingSchema=mj.optInt("schemaVersion",-1)
        if((incomingSchema==2 || incomingSchema==3) && schemaVersion==4){
            val defaults=mapOf("worker_wage_history.json" to "[]", "crop_varieties.json" to "[]", "backup_metadata.json" to JSONArray().put(BackupMetadata(schemaVersion=4).json()).toString())
            defaults.forEach{(name,content)-> val f=File(dir,name); if(!f.exists()) f.writeText(content) }
        }
    }

    private fun validateManifestFiles(mj:JSONObject, dir:File){
        if(mj.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Wrong app backup.")
        if(mj.optInt("formatVersion",-1)!=version) throw IllegalArgumentException("Unsupported backup version ${mj.optInt("formatVersion")}")
        val incomingSchema=mj.optInt("schemaVersion",-1); if(incomingSchema!=schemaVersion && incomingSchema!=3 && incomingSchema!=2) throw IllegalArgumentException("Unsupported schema version $incomingSchema")
        if(mj.optLong("createdAt",0L)<=0L) throw IllegalArgumentException("Backup metadata has invalid createdAt")
        if(mj.optString("storage","")!="JSON") throw IllegalArgumentException("Unsupported backup storage")
        val list=mj.optJSONArray("files") ?: throw IllegalArgumentException("Backup metadata missing file manifest")
        if(mj.optInt("fileCount",-1)!=list.length()) throw IllegalArgumentException("Backup metadata fileCount mismatch")
        val legacyAllowed=allowed - setOf("worker_wage_history.json","crop_varieties.json","backup_metadata.json")
        val expected=if(incomingSchema==2) legacyAllowed.sorted().toSet() else allowed.sorted().toSet()
        if(list.length()!=expected.size) throw IllegalArgumentException("Backup metadata file count mismatch")
         val actual=mutableSetOf<String>()
        for(i in 0 until list.length()){
            val x=list.getJSONObject(i); val name=x.optString("name"); if(!actual.add(name)||name !in expected) throw IllegalArgumentException("Invalid backup metadata file: $name")
            val f=File(dir,name); if(!f.exists()) throw IllegalArgumentException("Backup file missing: $name")
            if(f.length()!=x.optLong("bytes",-1L)) throw IllegalArgumentException("Backup size mismatch: $name")
            if(sha256(f)!=x.optString("sha256")) throw IllegalArgumentException("Backup checksum mismatch: $name")
        }
        if(actual!=expected) throw IllegalArgumentException("Backup metadata does not describe the complete dataset")
    }

    private fun extract(input:InputStream,temp:File){
        ZipInputStream(BufferedInputStream(input)).use{z->
            val seen=mutableSetOf<String>(); var count=0; var total=0L; var e=z.nextEntry
            while(e!=null){
                count++; if(count>MAX_BACKUP_ENTRIES) throw SecurityException("Backup contains too many entries.")
                val clean=e.name.replace("\\","/")
                if(clean.contains("..")||clean.startsWith("/")||clean.contains(":/")) throw SecurityException("Unsafe backup path")
                if(!seen.add(clean)) throw SecurityException("Duplicate backup entry: $clean")
                val target=File(temp,clean); if(e.isDirectory) target.mkdirs() else {
                    target.parentFile?.mkdirs(); FileOutputStream(target).use{out->
                        val buffer=ByteArray(8192)
                        while(true){ val n=z.read(buffer); if(n<0) break; total+=n; if(total>MAX_BACKUP_BYTES) throw SecurityException("Backup exceeds 100 MB limit."); out.write(buffer,0,n) }
                    }
                }
                e=z.nextEntry
            }
        }
    }
    fun restore(input:InputStream){
        val temp=File(context.cacheDir,"restore_${UUID.randomUUID()}").apply{mkdirs()}; val rollback=File(context.cacheDir,"rollback_${UUID.randomUUID()}").apply{mkdirs()}
        try{
            extract(input,temp); val manifestFile=File(temp,"manifest.json"); if(!manifestFile.exists()) throw IllegalArgumentException("Manifest missing")
            val mj=JSONObject(manifestFile.readText()); if(mj.optString("app")!="Majdoor Hisaab PRO" || mj.optInt("formatVersion",-1)!=version) throw IllegalArgumentException("Unsupported backup")
            val incomingSchema=mj.optInt("schemaVersion",-1); if(incomingSchema!=schemaVersion && incomingSchema!=3 && incomingSchema!=2) throw IllegalArgumentException("Unsupported schema version $incomingSchema")
            val incoming=File(temp,"data"); validateManifestFiles(mj,incoming); migrateLegacySchemaIfNeeded(mj,incoming); validateDataFolder(incoming); validateRelationalFolder(incoming)
            // Build and verify a COMPLETE rollback snapshot before touching live data.
            // If snapshot creation fails, live data is left completely untouched.
            val liveFiles = data.listFiles()?.filter{it.isFile && it.name in allowed}.orEmpty()
            val expectedRollbackNames = liveFiles.map{it.name}.toSet()
            try {
                liveFiles.forEach { src ->
                    val dst = File(rollback, src.name)
                    src.copyTo(dst, true)
                    require(dst.exists() && dst.length() == src.length()) { "Rollback snapshot verification failed for ${src.name}" }
                }
                val actualRollbackNames = rollback.listFiles()?.filter{it.isFile}?.map{it.name}?.toSet().orEmpty()
                require(actualRollbackNames == expectedRollbackNames) { "Rollback snapshot is incomplete." }
            } catch (snapshotError: Exception) {
                rollback.deleteRecursively()
                throw IllegalStateException("Restore aborted safely: rollback snapshot could not be completed. Existing data was not modified.", snapshotError)
            }

            var destructiveStarted = false
            try {
                destructiveStarted = true
                data.listFiles()?.filter{it.isFile && it.name in allowed}?.forEach{it.delete()}
                incoming.listFiles()?.filter{it.isFile && it.name in allowed}?.forEach{it.copyTo(File(data,it.name),true)}
                // Post-commit validation must include BOTH structural and relational checks.
                validateDataFolder(data)
                validateRelationalFolder(data)
                audit("RESTORE","data",summary="Backup restored (replace)",source="UI")
            } catch (commitError: Exception) {
                if (destructiveStarted) {
                    data.listFiles()?.filter{it.isFile && it.name in allowed}?.forEach{it.delete()}
                    val rollbackFiles = rollback.listFiles()?.filter{it.isFile && it.name in allowed}.orEmpty()
                    require(rollbackFiles.map{it.name}.toSet() == expectedRollbackNames) { "Rollback snapshot became incomplete; live data was not safely restorable." }
                    rollbackFiles.forEach{it.copyTo(File(data,it.name),true)}
                    validateDataFolder(data)
                    validateRelationalFolder(data)
                }
                throw commitError
            }
        } catch(e:Exception){
            // Snapshot failures occur before destructiveStarted and therefore never
            // delete existing data. Commit failures are already rolled back above.
            throw e
        } finally { temp.deleteRecursively(); rollback.deleteRecursively() }
    }
    /**
     * Full local-data health check. JSON parsing alone is not enough: every stored
     * relationship is checked so orphaned/duplicate references are surfaced before
     * reports or ledger calculations can silently use bad data.
     */
    fun health():List<String>{
        val out=mutableListOf<String>()
        val errors=mutableListOf<String>()
        val warnings=mutableListOf<String>()
        val counts=mutableMapOf<String,Int>()
        fun addError(message:String){ errors.add("ERROR: $message") }
        fun addWarning(message:String){ warnings.add("WARNING: $message") }
        fun ids(name:String, records:List<JSONObject>):Set<String>{
            val seen=mutableSetOf<String>()
            records.forEachIndexed{index,j->
                val id=j.optString("id")
                if(id.isBlank()) addError("$name[$index] has blank id")
                else if(!seen.add(id)) addError("$name has duplicate id: $id")
            }
            return seen
        }
        try{
            // Parse every collection first; a corrupt file is a hard integrity error.
            val raw=allowed.associateWith{fileName->
                try{ read(fileName.removeSuffix(".json")) }
                catch(e:Exception){ addError("$fileName cannot be read: ${e.message}"); JSONArray() }
            }
            raw.forEach{(name,array)-> counts[name]=array.length() }

            val workers=workers(); val fields=fields(); val crops=crops(); val attendance=attendance()
            val teams=teams(); val work=work(); val payments=payments(); val expenses=expenses()
            val production=production(); val revenue=revenue(); val documents=workerDocuments(); val templates=workTemplates()

            val workerIds=ids("workers",workers.map{it.json()})
            val fieldIds=ids("fields",fields.map{it.json()})
            val cropIds=ids("crops",crops.map{it.json()})
            val attendanceIds=ids("attendance",attendance.map{it.json()})
            val teamIds=ids("teams",teams.map{it.json()})
            val workIds=ids("work",work.map{it.json()})
            val paymentIds=ids("payments",payments.map{it.json()})
            val expenseIds=ids("expenses",expenses.map{it.json()})
            val productionIds=ids("production",production.map{it.json()})
            val revenueIds=ids("revenue",revenue.map{it.json()})
            ids("worker_documents",documents.map{it.json()})
            ids("work_templates",templates.map{it.json()})

            // Master-record duplicates that can make selection/reporting ambiguous.
            workers.groupBy{it.name.trim().lowercase()}.filter{it.key.isNotBlank() && it.value.size>1}.forEach{(name,list)->addError("workers duplicate name '$name' (${list.size})")}
            workers.filter{it.mobile.isNotBlank()}.groupBy{it.mobile.trim()}.filter{it.value.size>1}.forEach{(mobile,list)->addError("workers duplicate mobile '$mobile' (${list.size})")}
            fields.groupBy{it.name.trim().lowercase()}.filter{it.key.isNotBlank() && it.value.size>1}.forEach{(name,list)->addError("fields duplicate name '$name' (${list.size})")}
            crops.groupBy{listOf(it.fieldId,it.name.trim().lowercase(),it.variety.trim().lowercase()).joinToString("|")}.filter{it.value.size>1}.forEach{(key,list)->addError("crops duplicate record '$key' (${list.size})")}

            // Worker relationships.
            documents.forEach{d-> if(d.workerId !in workerIds) addError("worker_documents '${d.id}' references missing worker '${d.workerId}'") }
            attendance.forEach{a->
                if(a.workerId !in workerIds) addError("attendance '${a.id}' references missing worker '${a.workerId}'")
                if(a.fieldId.isNotBlank() && a.fieldId !in fieldIds) addError("attendance '${a.id}' references missing field '${a.fieldId}'")
                if(a.status.uppercase() !in setOf("FULL","HALF","NONE")) addError("attendance '${a.id}' has invalid status '${a.status}'")
                if(a.rate < 0) addError("attendance '${a.id}' has negative rate")
                if(a.date.isBlank()) addError("attendance '${a.id}' has blank date")
            }
            teams.forEach{t->
                val duplicates=t.workerIds.groupingBy{it}.eachCount().filterValues{it>1}.keys
                if(duplicates.isNotEmpty()) addError("team '${t.id}' contains duplicate workers: ${duplicates.joinToString()}")
                t.workerIds.filter{it !in workerIds}.forEach{id->addError("team '${t.id}' references missing worker '$id'")}
            }
            work.forEach{w->
                if(w.fieldId !in fieldIds) addError("work '${w.id}' references missing field '${w.fieldId}'")
                if(w.cropId !in cropIds) addError("work '${w.id}' references missing crop '${w.cropId}'")
                val crop=crops.firstOrNull{it.id==w.cropId}
                if(crop!=null && crop.fieldId.isNotBlank() && crop.fieldId!=w.fieldId) addError("work '${w.id}' field/crop relationship mismatch")
                w.workerIds.filter{it !in workerIds}.forEach{id->addError("work '${w.id}' references missing worker '$id'")}
                if(w.workerIds.isEmpty()) addError("work '${w.id}' has no workers")
                if(w.quantity<0 || w.rate<0) addError("work '${w.id}' has negative quantity/rate")
                if(w.date.isBlank()) addError("work '${w.id}' has blank date")
            }
            payments.forEach{p->
                if(p.workerId !in workerIds) addError("payment '${p.id}' references missing worker '${p.workerId}'")
                if(p.amount<=0) addError("payment '${p.id}' has non-positive amount")
                if(p.method !in setOf("Cash","Bank","UPI")) addError("payment '${p.id}' has invalid method '${p.method}'")
                if(p.date.isBlank()) addError("payment '${p.id}' has blank date")
            }

            // Field/crop relationships.
            crops.forEach{c->
                if(c.fieldId.isNotBlank() && c.fieldId !in fieldIds) addError("crop '${c.id}' references missing field '${c.fieldId}'")
                if(c.name.isBlank()) addError("crop '${c.id}' has blank name")
            }
            expenses.forEach{e->
                if(e.fieldId.isNotBlank() && e.fieldId !in fieldIds) addError("expense '${e.id}' references missing field '${e.fieldId}'")
                if(e.cropId.isNotBlank() && e.cropId !in cropIds) addError("expense '${e.id}' references missing crop '${e.cropId}'")
                if(e.cropId.isNotBlank() && e.fieldId.isNotBlank()){
                    val crop=crops.firstOrNull{it.id==e.cropId}
                    if(crop!=null && crop.fieldId.isNotBlank() && crop.fieldId!=e.fieldId) addError("expense '${e.id}' field/crop relationship mismatch")
                }
                if(e.amount<=0) addError("expense '${e.id}' has non-positive amount")
                if(e.date.isBlank()) addError("expense '${e.id}' has blank date")
            }
            production.forEach{p->
                if(p.cropId !in cropIds) addError("production '${p.id}' references missing crop '${p.cropId}'")
                if(p.quantity<=0) addError("production '${p.id}' has non-positive quantity")
                if(p.date.isBlank()) addError("production '${p.id}' has blank date")
            }
            revenue.forEach{r->
                if(r.cropId !in cropIds) addError("revenue '${r.id}' references missing crop '${r.cropId}'")
                if(r.amount<=0) addError("revenue '${r.id}' has non-positive amount")
                if(r.date.isBlank()) addError("revenue '${r.id}' has blank date")
            }
            templates.forEach{t-> if(t.name.isBlank()) addError("work_template '${t.id}' has blank name") }

            // Duplicate attendance is a critical ledger/report integrity issue.
            attendance.groupBy{listOf(it.date,it.workerId,it.fieldId).joinToString("|")}.filter{it.value.size>1}.forEach{(key,list)->addError("attendance duplicate date/worker/field '$key' (${list.size})")}
            work.groupBy{it.fingerprint()}.filter{it.value.size>1}.forEach{(_,list)->addError("work contains duplicate fingerprint (${list.size})")}

            // Referentially valid but inactive parents are useful warnings rather than errors.
            work.filter{w->workers.any{it.id in w.workerIds && !it.active}}.take(10).forEach{addWarning("work '${it.id}' contains inactive worker")}
            crops.filter{c->c.fieldId.isNotBlank() && fields.none{it.id==c.fieldId}}.forEach{addError("crop '${it.id}' has unresolved field")}

            val total=counts.values.sum()
            out.add("RELATIONAL DATA HEALTH")
            out.add("Records scanned: $total across ${allowed.size} collections")
            out.add("Workers=${workers.size}, Fields=${fields.size}, Crops=${crops.size}, Attendance=${attendance.size}")
            out.add("Work=${work.size}, Payments=${payments.size}, Expenses=${expenses.size}, Production=${production.size}, Revenue=${revenue.size}")
            out.add("Relationships checked: worker, field, crop, attendance, team, work, payment, expense, production, revenue, documents")
            if(errors.isEmpty() && warnings.isEmpty()) out.add("RESULT: HEALTHY — no relational integrity errors found")
            else {
                out.add("RESULT: ${errors.size} error(s), ${warnings.size} warning(s)")
                out.addAll(errors.take(80))
                out.addAll(warnings.take(20))
                if(errors.size>80) out.add("... ${errors.size-80} additional errors not shown")
                if(warnings.size>20) out.add("... ${warnings.size-20} additional warnings not shown")
            }
            out.add("File status: all ${allowed.size} JSON collections were inspected")
            // Keep local variables referenced so future compiler optimisations do not alter the health contract.
            @Suppress("UNUSED_VARIABLE") val _ids = listOf(attendanceIds,teamIds,workIds,paymentIds,expenseIds,productionIds,revenueIds)
        }catch(e:Exception){
            out.add("RELATIONAL DATA HEALTH")
            out.add("RESULT: CHECK FAILED — ${e.message ?: "unknown error"}")
        }
        return out
    }
    fun storageInfo()="Phone app storage: ${root.absolutePath}\nJSON files: ${data.listFiles()?.count{it.isFile} ?: 0}\nBackups: ${backups.listFiles()?.count{it.isFile} ?: 0}"
}
