package com.majdoor.hisaab.security

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.util.Base64
import java.security.MessageDigest
import java.util.concurrent.Executor

class SecurityManager(context: Context) {
    private val p: SharedPreferences = context.getSharedPreferences("security", Context.MODE_PRIVATE)
    fun setPin(pin: String) { p.edit().putString("pin", hash(pin)).apply() }
    fun hasPin() = p.contains("pin")
    fun verifyPin(pin: String) = p.getString("pin", "") == hash(pin)
    fun clearPin() { p.edit().remove("pin").apply() }
    fun biometricEnabled() = p.getBoolean("biometric", false)
    fun setBiometricEnabled(enabled: Boolean) { p.edit().putBoolean("biometric", enabled).apply() }
    fun biometricAvailable(): Boolean = Build.VERSION.SDK_INT >= 30 &&
        BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    fun authenticate(activity: Activity, executor: Executor, onSuccess: () -> Unit, onFailure: () -> Unit) {
        if (Build.VERSION.SDK_INT < 28) { onFailure(); return }
        val prompt = BiometricPrompt.Builder(activity)
            .setTitle("Unlock Majdoor Hisaab PRO")
            .setSubtitle("Use your enrolled biometric")
            .setDescription("Your local farm records remain on this device.")
            .setNegativeButton("Use PIN", executor) { _, _ -> onFailure() }
            .build()
        prompt.authenticate(object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = onFailure()
            override fun onAuthenticationFailed() { }
        }, executor)
    }

    private fun hash(s: String): String = Base64.encodeToString(
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()), Base64.NO_WRAP)
}
