package com.majdoor.hisaab.domain.usecase

import android.content.Context
import com.majdoor.hisaab.data.repository.LocalRepository
import com.majdoor.hisaab.report.ReportService
import com.majdoor.hisaab.report.ReportData
import com.majdoor.hisaab.report.ReportFilter
import com.majdoor.hisaab.report.ReportEngine
import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.WorkRecord
import com.majdoor.hisaab.security.AutoLockManager
import java.io.OutputStream

class DashboardUseCase(private val r:LocalRepository) {
    fun snapshot() = DashboardSnapshot(r.workers(), r.attendance(), r.work(), r.payments(), r.expenses(), r.fields(), r.crops())
}
data class DashboardSnapshot(val workers:List<com.majdoor.hisaab.model.Worker>, val attendance:List<com.majdoor.hisaab.model.Attendance>, val work:List<com.majdoor.hisaab.model.WorkRecord>, val payments:List<com.majdoor.hisaab.model.Payment>, val expenses:List<com.majdoor.hisaab.model.Expense>, val fields:List<com.majdoor.hisaab.model.Field>, val crops:List<com.majdoor.hisaab.model.Crop>)
class ReportsUseCase(context:Context, private val r:LocalRepository) { private val service=ReportService(context,r); fun period(title:String,f:ReportFilter,anchor:String)=ReportEngine.periodFilter(title,f,anchor); fun workerSummary(w:com.majdoor.hisaab.model.Worker,d:ReportData)=ReportEngine.workerSummary(w,d); fun preview(f:ReportFilter):ReportData=ReportEngine.filter(f,r.attendance(),r.work(),r.payments(),r.expenses(),r.revenue(),r.production(),r.crops().associate{it.id to it.fieldId}); fun csvWorkers(o:OutputStream)=service.csvWorkers(o); fun csvLedger(o:OutputStream)=service.csvLedger(o); fun csvReport(t:String,o:OutputStream)=service.csvReport(t,o); fun pdfReport(t:String,o:OutputStream)=service.pdfReport(t,o); fun pdfSummary(o:OutputStream)=service.pdfSummary(o) }
class ExportUseCase(private val reports:ReportsUseCase) { fun csvWorkers(o:OutputStream)=reports.csvWorkers(o); fun csvLedger(o:OutputStream)=reports.csvLedger(o); fun csvReport(t:String,o:OutputStream)=reports.csvReport(t,o); fun pdfReport(t:String,o:OutputStream)=reports.pdfReport(t,o); fun pdfSummary(o:OutputStream)=reports.pdfSummary(o) }
class SettingsUseCase(private val context:Context) {
    private val prefs=context.getSharedPreferences("settings",Context.MODE_PRIVATE)
    fun get(key:String, default:String="")=prefs.getString(key,default) ?: default
    fun put(key:String,value:String)=prefs.edit().putString(key,value).apply()
    fun getBoolean(key:String,default:Boolean=false)=prefs.getBoolean(key,default)
    fun putBoolean(key:String,value:Boolean)=prefs.edit().putBoolean(key,value).apply()
}
class SecurityUseCase(private val context:Context) { fun autoLockTimeout(value:String)=AutoLockManager.timeoutMinutes(value) }

class CalculationUseCase(private val r:LocalRepository) {
    fun ledger(workerId:String)=LedgerCalculator.summary(workerId,r.attendance(),r.work(),r.payments())
    fun workCost(work:WorkRecord)=WorkRateEngine.cost(work)
    fun normalize(rateType:String,unit:String)=WorkRateEngine.normalize(rateType,unit)
    fun workTypes()=WorkRateEngine.workTypes
    fun rateTypes()=WorkRateEngine.types
}

class AuditUseCase(private val r:LocalRepository) {
    fun list() = r.auditLog()
    fun clear() = r.clearAuditLog()
    fun logSettingChange(key:String, value:String) = r.logSettingChange(key,value)
}
