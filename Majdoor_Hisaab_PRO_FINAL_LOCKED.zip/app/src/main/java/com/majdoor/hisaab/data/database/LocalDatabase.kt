package com.majdoor.hisaab.data.database

import android.content.Context
import com.majdoor.hisaab.storage.LocalStore

/** Database boundary. The current implementation is offline JSON storage. */
class LocalDatabase(context: Context) {
    internal val store = LocalStore(context)
}
