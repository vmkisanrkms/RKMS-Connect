package com.majdoor.hisaab.report

import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*

/** Single source of truth for all report calculations. */
data class ReportFilter(
    val from: String = "",
    val to: String = "",
    val workerId: String = "",
    val fieldId: String = "",
    val cropId: String = ""
) {
    fun dateOk(date: String) = (from.isBlank() || date >= from) && (to.isBlank() || date <= to)
}

data class ReportData(
    val attendance: List<Attendance>,
    val work: List<WorkRecord>,
    val payments: List<Payment>,
    val expenses: List<Expense>,
    val revenues: List<Revenue>,
    val production: List<Production>
) {
    fun attendanceCost() = attendance.sumOf { when (it.status.uppercase()) { "FULL" -> it.rate.coerceAtLeast(0.0); "HALF" -> (it.rate.coerceAtLeast(0.0) / 2.0); else -> 0.0 } }
    fun workCost() = work.sumOf { WorkRateEngine.cost(it).coerceAtLeast(0.0) }
    fun expenseCost() = expenses.sumOf { it.amount.coerceAtLeast(0.0) }
    fun revenueTotal() = revenues.sumOf { it.amount.coerceAtLeast(0.0) }
    fun totalLabourCost() = attendanceCost() + workCost()
    fun trackedCost() = totalLabourCost() + expenseCost()
    fun profitLoss() = revenueTotal() - trackedCost()
}

object ReportEngine {
    /** Resolve report-specific periods from the user filter. Daily = one day; Weekly = Monday-Sunday; Monthly = calendar month. */
    fun periodFilter(title: String, filter: ReportFilter, anchorDate: String): ReportFilter {
        if (title == "Custom Report" || title == "Worker Report" || title == "Field Report" || title == "Crop Report" ||
            title == "Attendance Report" || title == "Payment Report" || title == "Expense Report" || title == "Outstanding Report" ||
            title == "Labour Cost Report" || title == "Profit/Loss Report") return filter
        val anchor = runCatching { java.time.LocalDate.parse(
            when { filter.from.isNotBlank() -> filter.from; filter.to.isNotBlank() -> filter.to; else -> anchorDate }
        ) }.getOrElse { java.time.LocalDate.parse(anchorDate) }
        return when (title) {
            "Daily Labour" -> filter.copy(from = anchor.toString(), to = anchor.toString())
            "Weekly Labour" -> {
                val start = anchor.with(java.time.DayOfWeek.MONDAY)
                filter.copy(from = start.toString(), to = start.plusDays(6).toString())
            }
            "Monthly Labour" -> {
                val start = anchor.withDayOfMonth(1)
                filter.copy(from = start.toString(), to = start.withDayOfMonth(start.lengthOfMonth()).toString())
            }
            else -> filter
        }
    }

    fun filter(
        filter: ReportFilter,
        attendance: List<Attendance>, work: List<WorkRecord>, payments: List<Payment>,
        expenses: List<Expense>, revenues: List<Revenue>, production: List<Production>, cropFieldById: Map<String, String> = emptyMap()
    ): ReportData {
        val a = attendance.filter { filter.dateOk(it.date) && (filter.workerId.isBlank() || it.workerId == filter.workerId) && (filter.fieldId.isBlank() || it.fieldId == filter.fieldId) }
        val w = work.filter { filter.dateOk(it.date) && (filter.workerId.isBlank() || filter.workerId in it.workerIds) && (filter.fieldId.isBlank() || it.fieldId == filter.fieldId) && (filter.cropId.isBlank() || it.cropId == filter.cropId) }
        val p = payments.filter { filter.dateOk(it.date) && (filter.workerId.isBlank() || it.workerId == filter.workerId) }
        val e = expenses.filter { filter.dateOk(it.date) && (filter.fieldId.isBlank() || it.fieldId == filter.fieldId) && (filter.cropId.isBlank() || it.cropId == filter.cropId) }
        val r = revenues.filter {
            filter.dateOk(it.date) &&
                (filter.cropId.isBlank() || it.cropId == filter.cropId) &&
                (filter.fieldId.isBlank() || cropFieldById[it.cropId] == filter.fieldId)
        }
        val prod = production.filter {
            filter.dateOk(it.date) &&
                (filter.cropId.isBlank() || it.cropId == filter.cropId) &&
                (filter.fieldId.isBlank() || cropFieldById[it.cropId] == filter.fieldId)
        }
        return ReportData(a, w, p, e, r, prod)
    }

    fun workerSummary(worker: Worker, d: ReportData): LedgerSummary =
        LedgerCalculator.summary(worker.id, d.attendance, d.work, d.payments)
}
