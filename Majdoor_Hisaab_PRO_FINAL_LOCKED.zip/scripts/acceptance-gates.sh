#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app"
fail(){ echo "FAIL: $*" >&2; exit 1; }

echo "[0/10] Version consistency"
EXPECTED_CODE=77
EXPECTED_NAME=1.77.0
grep -q "versionCode = ${EXPECTED_CODE}" "$APP/build.gradle.kts" || fail "app versionCode is not ${EXPECTED_CODE}"
grep -q "versionName = \"${EXPECTED_NAME}\"" "$APP/build.gradle.kts" || fail "app versionName is not ${EXPECTED_NAME}"
for f in scripts/debug-build-gate.sh scripts/release-build-gate.sh scripts/production-signing-gate.sh .github/workflows/build-release-apk.yml; do
  grep -q "${EXPECTED_NAME}" "$f" || fail "stale versionName in $f"
done
for f in scripts/debug-build-gate.sh scripts/release-build-gate.sh scripts/production-signing-gate.sh .github/workflows/build-release-apk.yml; do
  grep -qE "versionCode = ${EXPECTED_CODE}|version-code .*grep -Fx ['\"]?${EXPECTED_CODE}['\"]?|VERSION_CODE.*[=] ['\"]?${EXPECTED_CODE}['\"]?" "$f" || fail "stale versionCode in $f"
done

echo "[1/10] Project structure"
test -f "$ROOT/settings.gradle.kts"
test -f "$APP/build.gradle.kts"
test -f "$APP/src/main/AndroidManifest.xml"

echo "[2/10] Local-only storage / no database backend"
if grep -RniE 'room|android\.database\.sqlite|FirebaseDatabase|FirebaseFirestore|supabase' "$APP/src/main" "$APP/build.gradle.kts"; then
  echo "Forbidden database/backend reference found" >&2; exit 1
fi

echo "[3/10] Critical attendance implementation"
grep -R -q --include='*.kt' 'status' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'Previous Team' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'All Full' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'All Half' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'Clear All' "$APP/src/main/java/com/majdoor/hisaab"

echo "[4A] Repository architecture boundary"
test -f "$APP/src/main/java/com/majdoor/hisaab/data/repository/LocalRepository.kt"
grep -R -q --include='*.kt' 'AppServices' "$APP/src/main/java/com/majdoor/hisaab"
if grep -qE 'import com\.majdoor\.hisaab\.(storage\.LocalStore|data\.repository\.LocalRepository|data\.database)' "$APP/src/main/java/com/majdoor/hisaab/MainActivity.kt"; then echo 'MainActivity bypasses architecture boundary' >&2; exit 1; fi
test -f "$APP/src/test/java/com/majdoor/hisaab/ArchitectureBoundaryContractTest.kt"
test -f "$APP/src/test/java/com/majdoor/hisaab/LocalStoreValidationTest.kt"
echo 'REPOSITORY_ARCHITECTURE_GATE=PASS'

echo "[4/10] Complete calculation engines + automated CRUD tests"
test -f "$APP/src/main/java/com/majdoor/hisaab/calculation/LedgerCalculator.kt"
test -f "$APP/src/main/java/com/majdoor/hisaab/calculation/WorkRateEngine.kt"
test -f "$APP/src/main/java/com/majdoor/hisaab/report/ReportEngine.kt"
test -f "$APP/src/test/java/com/majdoor/hisaab/FullAcceptanceTestSuite.kt"
test -f "$APP/src/test/java/com/majdoor/hisaab/LocalStoreCrudTest.kt"
grep -q 'attendance_crud_preserves_field_id' "$APP/src/test/java/com/majdoor/hisaab/LocalStoreCrudTest.kt"

echo "[5/10] Attendance field ID persistence"
grep -R -q --include='*.kt' 'Attendance(old?.id?:UUID.randomUUID().toString(),dateValue,id,fieldId' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'fun MainActivity.attendanceForm(old:Attendance)' "$APP/src/main/java/com/majdoor/hisaab"

echo "[6/10] Backup reboot handling"
grep -q 'RECEIVE_BOOT_COMPLETED' "$APP/src/main/AndroidManifest.xml"
test -f "$APP/src/main/java/com/majdoor/hisaab/backup/BootCompletedReceiver.kt"
test -f "$APP/src/main/java/com/majdoor/hisaab/backup/AutoBackupReceiver.kt"

echo "[7/10] Photo persistence mechanism"
grep -Rniq 'takePersistableUriPermission' "$APP/src/main/java"

echo "[8/10] Report exports"
grep -q 'pdfReport' "$APP/src/main/java/com/majdoor/hisaab/report/ReportService.kt"
grep -q 'csvReport' "$APP/src/main/java/com/majdoor/hisaab/report/ReportService.kt"

echo "[9/10] Runtime launcher declaration"
grep -q 'android.intent.action.MAIN' "$APP/src/main/AndroidManifest.xml"
grep -q 'android.intent.category.LAUNCHER' "$APP/src/main/AndroidManifest.xml"

echo "Restart persistence acceptance"
test -f "$APP/src/test/java/com/majdoor/hisaab/RestartPersistenceTest.kt"
grep -q 'class RestartPersistenceTest' "$APP/src/test/java/com/majdoor/hisaab/RestartPersistenceTest.kt"
grep -q 'out.fd.sync' "$APP/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
echo 'RESTART_PERSISTENCE_GATE=PASS'
echo 'Offline core workflow acceptance'
test -f "$APP/src/test/java/com/majdoor/hisaab/OfflineCoreWorkflowTest.kt"
grep -q 'coreCrudReportAndBackupWorkWithoutNetwork' "$APP/src/test/java/com/majdoor/hisaab/OfflineCoreWorkflowTest.kt"
# App must not request network access; core records are local JSON files.
if grep -q 'android.permission.INTERNET' "$APP/src/main/AndroidManifest.xml"; then
  echo 'Unexpected INTERNET permission found' >&2; exit 1
fi
if grep -RniE 'Retrofit|OkHttp|FirebaseDatabase|FirebaseFirestore|supabase|java.net\.|HttpURLConnection' "$APP/src/main" "$APP/build.gradle.kts"; then
  echo 'Unexpected network/backend dependency found' >&2; exit 1
fi
grep -q 'Offline-first JSON repository' "$APP/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
echo 'OFFLINE_CORE_WORKFLOW_GATE=PASS'

echo "Phase 9 Crop acceptance"
test -f app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -q 'same_field_crop_can_repeat_in_later_season_but_exact_same_date_is_rejected' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -q 'crop_cost_categories_production_revenue_and_profit_are_deterministic' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -q 'production_and_revenue_reject_invalid_values_and_keep_crop_link' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -R -q --include='*.kt' 'Crop Calendar' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'getActualMaximum(Calendar.DAY_OF_MONTH)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Crop Labour Cost' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'cropProduction(id)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'cropRevenue(id)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Fertilizer' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Seed' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Pesticide' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Irrigation' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Machinery' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Transport' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Incomplete data:' app/src/main/java/com/majdoor/hisaab
grep -q 'plantingDate==x.plantingDate' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -R -q --include='*.kt' 'Crop Master' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'productionFormForCrop(id)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'revenueFormForCrop(id)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'viewCal.add(Calendar.MONTH,-1)' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'viewCal.add(Calendar.MONTH,1)' app/src/main/java/com/majdoor/hisaab
grep -q 'crop_requires_positive_area_and_planting_date' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -q 'crop_cost_categories_each_persist_and_sum' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
grep -q 'production_and_revenue_round_trip_edit_keep_crop_link' app/src/test/java/com/majdoor/hisaab/CropModuleContractTest.kt
echo 'PHASE9_CROP_STATIC_GATE=PASS'

echo "Phase 11 Reports acceptance"
"$ROOT/scripts/phase11-reports-gate.sh"
echo "[10/10] Static gates complete"
echo "ALL STATIC ACCEPTANCE GATES PASSED"

grep -R -q --include='*.kt' 'Previous' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'Next' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'MMMM yyyy' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'getActualMaximum(Calendar.DAY_OF_MONTH)' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'selectedDate' "$APP/src/main/java/com/majdoor/hisaab"
echo "[PASS] Real attendance month calendar gates"

# V16 auto-lock gate
grep -R -q --include='*.kt' 'Auto-Lock' "$APP/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'AutoLockManager.shouldLock' "$APP/src/main/java/com/majdoor/hisaab"
test -f app/src/main/java/com/majdoor/hisaab/security/AutoLockManager.kt
test -f app/src/test/java/com/majdoor/hisaab/AutoLockManagerTest.kt
echo 'AUTO_LOCK_GATE=PASS'

echo "Notification settings acceptance"
grep -R -q --include='*.kt' 'NotificationSettings' app/src/main/java/com/majdoor/hisaab
grep -q 'notification_attendance' app/src/main/java/com/majdoor/hisaab/notification/NotificationSettings.kt
grep -q 'notification_payment' app/src/main/java/com/majdoor/hisaab/notification/NotificationSettings.kt
grep -R -q --include='*.kt' 'POST_NOTIFICATIONS' app/src/main/java/com/majdoor/hisaab
grep -q 'NotificationReceiver' app/src/main/AndroidManifest.xml

echo "Report settings acceptance"
grep -R -q --include='*.kt' 'fun MainActivity.reportSettingsDialog' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Report Settings' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'report_page_size' app/src/main/java/com/majdoor/hisaab
grep -q 'report_orientation' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'report_include_header' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'report_include_filters' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'report_include_footer' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'report_csv_headers' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'report_csv_bom' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
grep -q 'drawFooter' app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
echo 'REPORT_SETTINGS_GATE=PASS'

# Clean-checkout build + Gradle Wrapper reproducibility gate
test -f .github/workflows/build-release-apk.yml || { echo "FAIL: release workflow missing"; exit 1; }
test -x gradlew || { echo "FAIL: gradlew missing or not executable"; exit 1; }
test -f gradlew.bat || { echo "FAIL: gradlew.bat missing"; exit 1; }
test -f gradle/wrapper/gradle-wrapper.properties || { echo "FAIL: Gradle wrapper properties missing"; exit 1; }
grep -q 'distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip' gradle/wrapper/gradle-wrapper.properties || { echo "FAIL: Gradle 8.11.1 wrapper distribution not pinned"; exit 1; }
grep -q 'distributionSha256Sum=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6' gradle/wrapper/gradle-wrapper.properties || { echo "FAIL: Gradle distribution SHA-256 not pinned"; exit 1; }
grep -q './gradlew --no-daemon' .github/workflows/build-release-apk.yml || { echo "FAIL: workflow does not use repository Gradle Wrapper"; exit 1; }
if grep -E '^[[:space:]]*gradle --' .github/workflows/build-release-apk.yml | grep -v 'gradle --version' >/dev/null; then echo "FAIL: workflow invokes system Gradle directly for build tasks" >&2; exit 1; fi
./scripts/gradle-agp-compatibility.sh
scripts/gradle-kotlin-compatibility.sh
grep -q 'compileDebugKotlin' .github/workflows/build-release-apk.yml || { echo "FAIL: Debug Kotlin compilation gate missing"; exit 1; }
grep -q 'compileE2eReleaseKotlin' .github/workflows/build-release-apk.yml || { echo "FAIL: E2E Release Kotlin compilation gate missing"; exit 1; }
grep -q 'compileReleaseKotlin' .github/workflows/build-release-apk.yml || { echo "FAIL: Release Kotlin compilation gate missing"; exit 1; }
echo "PASS: Clean-checkout + pinned Gradle Wrapper + AGP + Kotlin compatibility gates"

echo "Real Android rotation + error-state E2E acceptance"
test -f app/src/androidTest/java/com/majdoor/hisaab/RotationAndErrorStateE2ETest.kt
grep -q 'setOrientationLeft' app/src/androidTest/java/com/majdoor/hisaab/RotationAndErrorStateE2ETest.kt
grep -q 'setOrientationNatural' app/src/androidTest/java/com/majdoor/hisaab/RotationAndErrorStateE2ETest.kt
grep -q 'Something went wrong' app/src/androidTest/java/com/majdoor/hisaab/RotationAndErrorStateE2ETest.kt
grep -q 'connectedE2eReleaseAndroidTest' .github/workflows/build-release-apk.yml
grep -R -q --include='*.kt' 'e2e_error_state' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'E2E_ERROR_TEST' app/src/main/java/com/majdoor/hisaab
test -f app/src/androidTest/java/com/majdoor/hisaab/RealCoreWorkflowE2ETest.kt
echo "REAL_ANDROID_ROTATION_ERROR_E2E_GATE=READY"



# Phase 1 / Point 5: dependency resolution contract.
# Every external dependency must be explicitly version-pinned; dynamic versions make clean builds non-reproducible.
if grep -RniE 'SNAPSHOT|:[[:space:]]*[0-9A-Za-z_.-]*\+(["\)]|$)' app/build.gradle.kts build.gradle.kts settings.gradle.kts; then
  echo "FAIL: dynamic/SNAPSHOT dependency version found" >&2; exit 1
fi
# Required repositories must be declared centrally; project-level repositories are forbidden.
grep -q 'RepositoriesMode.FAIL_ON_PROJECT_REPOS' settings.gradle.kts || { echo "FAIL: repository resolution is not centrally controlled" >&2; exit 1; }
grep -q 'google()' settings.gradle.kts || { echo "FAIL: Google Maven repository missing" >&2; exit 1; }
grep -q 'mavenCentral()' settings.gradle.kts || { echo "FAIL: Maven Central repository missing" >&2; exit 1; }
# The CI workflow must force a fresh dependency-resolution pass before compilation/build.
grep -q -- '--refresh-dependencies' .github/workflows/build-release-apk.yml || { echo "FAIL: clean dependency resolution is not explicitly tested" >&2; exit 1; }
grep -q 'dependencies --configuration' .github/workflows/build-release-apk.yml || { echo "FAIL: dependency graph resolution gate missing" >&2; exit 1; }
echo 'DEPENDENCY_RESOLUTION_STATIC_GATE=PASS'
test -x scripts/dependency-health.sh || { echo 'FAIL: dependency health script missing'; exit 1; }
echo 'DEPENDENCY_HEALTH_STATIC_CONTRACT=PASS'

# Final runtime/reproducibility contracts
test -f .github/workflows/build-release-apk.yml
test -f .github/workflows/build-release-apk.yml
test -f scripts/release-e2e.sh
grep -q 'assembleRelease' .github/workflows/build-release-apk.yml
grep -q 'connectedE2eReleaseAndroidTest' .github/workflows/build-release-apk.yml
grep -q 'release-e2e.sh' .github/workflows/build-release-apk.yml

# Phase 1 / Point 3: exact Gradle + Android Gradle Plugin compatibility contract.
[ -x scripts/gradle-agp-compatibility.sh ] || fail "Missing Gradle/AGP compatibility gate"
scripts/gradle-agp-compatibility.sh

# Phase 1 / Point 7: Debug build must have an explicit, reproducible build-and-APK gate.
test -x scripts/debug-build-gate.sh || { echo 'FAIL: debug-build-gate.sh missing or not executable'; exit 1; }
grep -q ':app:compileDebugKotlin' scripts/debug-build-gate.sh || { echo 'FAIL: debug Kotlin compilation gate missing'; exit 1; }
grep -q ':app:assembleDebug' scripts/debug-build-gate.sh || { echo 'FAIL: debug APK assembly gate missing'; exit 1; }
grep -q 'app-debug.apk' scripts/debug-build-gate.sh || { echo 'FAIL: debug APK artifact verification missing'; exit 1; }
grep -q 'Install and launch Debug APK' .github/workflows/build-release-apk.yml || { echo 'FAIL: debug emulator verification missing'; exit 1; }
grep -q 'adb install -r.*app/build/outputs/apk/debug/app-debug.apk' .github/workflows/build-release-apk.yml || { echo 'FAIL: debug APK install verification missing'; exit 1; }
grep -q 'DEBUG_BUILD_GATE=PASS' scripts/debug-build-gate.sh || { echo 'FAIL: debug gate result missing'; exit 1; }
echo 'DEBUG_BUILD_STATIC_GATE=PASS'

# Phase 1 / Point 8: Release build must be explicitly assembled and independently verified.
test -x scripts/release-build-gate.sh || { echo 'FAIL: release-build-gate.sh missing or not executable'; exit 1; }
grep -q ':app:compileReleaseKotlin' scripts/release-build-gate.sh || { echo 'FAIL: release Kotlin compilation gate missing'; exit 1; }
grep -q ':app:assembleRelease' scripts/release-build-gate.sh || { echo 'FAIL: release APK assembly gate missing'; exit 1; }
grep -q 'app-release-unsigned.apk' scripts/release-build-gate.sh || { echo 'FAIL: release APK artifact verification missing'; exit 1; }
grep -q 'apkanalyzer manifest application-id' scripts/release-build-gate.sh || { echo 'FAIL: release APK metadata verification missing'; exit 1; }
grep -q 'unzip -t' scripts/release-build-gate.sh || { echo 'FAIL: release APK integrity verification missing'; exit 1; }
grep -q 'release-build-gate.sh' .github/workflows/build-release-apk.yml || { echo 'FAIL: CI does not invoke release build gate'; exit 1; }
grep -q 'assembleRelease' .github/workflows/build-release-apk.yml || { echo 'FAIL: CI release assembly missing'; exit 1; }
echo 'RELEASE_BUILD_STATIC_GATE=PASS'

# Phase 1 Points 12-17: release identity, production signing, signature, ZIP integrity and alignment.
test -x scripts/production-signing-gate.sh
grep -q 'versionName = "1.77.0"' app/build.gradle.kts
grep -q 'MH_RELEASE_KEYSTORE_BASE64' .github/workflows/build-release-apk.yml
grep -q 'MH_RELEASE_CERT_SHA256' .github/workflows/build-release-apk.yml
grep -q 'apksigner sign' .github/workflows/build-release-apk.yml
grep -q 'apksigner verify' .github/workflows/build-release-apk.yml
grep -q 'zipalign -c -v 4' .github/workflows/build-release-apk.yml
grep -q 'unzip -t' .github/workflows/build-release-apk.yml
grep -q 'production-signing-gate.sh' .github/workflows/build-release-apk.yml
# Phase 1 Points 18-25: release artifact SHA-256, clean runner/manual/push triggers, install/launch evidence.
grep -q 'sha256sum .*artifacts/Majdoor-Hisaab-PRO-release.sha256' .github/workflows/build-release-apk.yml || fail "Point 18 SHA-256 generation missing"
grep -q 'workflow_dispatch:' .github/workflows/build-release-apk.yml || fail "Point 20 workflow_dispatch missing"
grep -q 'branches: \[ main \]' .github/workflows/build-release-apk.yml || fail "Point 21 main push trigger missing"
grep -q 'actions/upload-artifact@v4' .github/workflows/build-release-apk.yml || fail "Point 23 artifact upload missing"
grep -q 'adb install' scripts/release-e2e.sh || fail "Point 24 release APK install missing"
grep -q 'am start -W' scripts/release-e2e.sh || fail "Point 25 release APK launch missing"
test -x scripts/phase1-points-18-25-gate.sh || fail "Points 18-25 gate not executable"

# Phase 2 — Security / Startup gates
bash scripts/phase2-security-startup-gate.sh

# Phase 6 — Work module gates
test -x scripts/phase6-work-gate.sh || fail "Phase 6 Work gate missing or not executable"
bash scripts/phase6-work-gate.sh

# Phase 12 — Backup / Restore / Data Safety
test -x scripts/phase12-backup-gate.sh || fail "Phase 12 backup gate missing or not executable"
bash scripts/phase12-backup-gate.sh

# Phase 13 — Settings
bash scripts/phase13-settings-gate.sh

echo "Phase 17 Real Android runtime test contract"
"$ROOT/scripts/phase17-real-android-runtime-gate.sh"
echo 'PHASE17_REAL_ANDROID_RUNTIME_CONTRACT=PASS'

# Phase 21 UI/UX
"$ROOT/scripts/phase21-ui-ux-gate.sh"

# Phase 22 final red-list acceptance gate
./scripts/phase22-final-red-list-gate.sh
