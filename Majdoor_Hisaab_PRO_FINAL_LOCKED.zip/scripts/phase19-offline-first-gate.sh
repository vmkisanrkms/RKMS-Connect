#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST="$ROOT/app/src/androidTest/java/com/majdoor/hisaab/Phase19OfflineFirstE2ETest.kt"
for n in $(seq 469 481); do grep -q "p${n}_" "$TEST" || { echo "PHASE19_MISSING_TEST=$n"; exit 1; }; done
for n in 473 474 475 476 477 478 479; do grep -A18 -q "p${n}_" "$TEST" || { echo "PHASE19_MISSING_BEHAVIOR=$n"; exit 1; }; done
for n in 473 474 475 476 478; do body=$(awk "/p${n}_/{flag=1} flag{print} /enableNetwork\(\)/{if(flag){exit}}" "$TEST"); echo "$body" | grep -q 'clickText' || { echo "PHASE19_UI_SAVE_MISSING=$n"; exit 1; }; done
grep -q 'p479_restoreWorksOffline' "$TEST" || exit 1
grep -q "offlineOpen().use" "$TEST"
! grep -q 'android.permission.INTERNET' "$ROOT/app/src/main/AndroidManifest.xml"
grep -q 'Offline-first JSON repository' "$ROOT/app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
grep -q 'exportBackup' "$TEST"
grep -q 'restore' "$TEST"
grep -q 'ReportService' "$TEST"
grep -q 'enableNetwork' "$TEST"
grep -q 'svc wifi disable' "$TEST"
grep -q 'svc data disable' "$TEST"
grep -q 'settings put global airplane_mode_on 1' "$TEST"
grep -q 'ActivityScenario.launch' "$TEST"
echo 'PHASE19_TESTS=13'
echo 'PHASE19_OFFLINE_FIRST_GATE=PASS'
