package com.majdoor.hisaab

import android.app.*
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.text.InputType
import android.view.*
import android.widget.*
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.text.SimpleDateFormat
import java.util.*

private object C {
    const val GREEN = 0xFF1B5E20.toInt()
    const val GREEN2 = 0xFF2E7D32.toInt()
    const val GREEN_LIGHT = 0xFFE8F5E9.toInt()
    const val ORANGE = 0xFFEF6C00.toInt()
    const val RED = 0xFFC62828.toInt()
    const val BLUE = 0xFF1565C0.toInt()
    const val TEXT = 0xFF263238.toInt()
    const val MUTED = 0xFF607D8B.toInt()
    const val BG = 0xFFF5F7F6.toInt()
    const val WHITE = Color.WHITE
    const val BORDER = 0xFFE0E6E2.toInt()
}

private const val DB_VERSION = 4
private const val DB_NAME = "majdoor_hisaab.db"
private const val APP_MARKER = "MAJDOOR_HISAAB_LOCAL_SQLITE_V4"

class DB(c: Context) : SQLiteOpenHelper(c, DB_NAME, null, DB_VERSION) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,name TEXT NOT NULL,rate REAL NOT NULL CHECK(rate>=0),active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)))")
        d.execSQL("CREATE TABLE fields(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)))")
        d.execSQL("CREATE TABLE work_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
        createIndexes(d)
        setMetadata(d)
    }

    private fun createIndexes(d: SQLiteDatabase) {
        d.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS ux_work_date_worker_field ON work_entries(date,worker_id,field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_worker ON work_entries(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_field ON work_entries(field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_date ON work_entries(date)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_worker ON payments(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_date ON payments(date)")
    }

    private fun setMetadata(d: SQLiteDatabase) {
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('app_marker',?)", arrayOf(APP_MARKER))
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version',?)", arrayOf(DB_VERSION.toString()))
        d.execSQL("PRAGMA user_version=$DB_VERSION")
    }

    override fun onUpgrade(d: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        d.beginTransaction()
        try {
            if (oldVersion < 3) {
                d.execSQL("DELETE FROM work_entries WHERE id NOT IN (SELECT MAX(id) FROM work_entries GROUP BY date,worker_id,field_id)")
            }
            if (oldVersion < 4) migrateToV4(d)
            createIndexes(d)
            setMetadata(d)
            d.setTransactionSuccessful()
        } finally {
            d.endTransaction()
        }
    }

    private fun migrateToV4(d: SQLiteDatabase) {
        d.execSQL("DROP INDEX IF EXISTS ux_work_date_worker_field")
        d.execSQL("CREATE TABLE work_entries_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("INSERT INTO work_entries_v4(id,date,worker_id,field_id,days,rate) SELECT w.id,w.date,w.worker_id,w.field_id,w.days,w.rate FROM work_entries w INNER JOIN workers wo ON wo.id=w.worker_id INNER JOIN fields f ON f.id=w.field_id WHERE w.days>=0 AND w.days<=1 AND w.rate>=0")
        d.execSQL("DROP TABLE work_entries")
        d.execSQL("ALTER TABLE work_entries_v4 RENAME TO work_entries")

        d.execSQL("CREATE TABLE payments_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("INSERT INTO payments_v4(id,date,worker_id,amount,note) SELECT p.id,p.date,p.worker_id,p.amount,COALESCE(p.note,'') FROM payments p INNER JOIN workers w ON w.id=p.worker_id WHERE p.amount>0")
        d.execSQL("DROP TABLE payments")
        d.execSQL("ALTER TABLE payments_v4 RENAME TO payments")
    }
}

class MainActivity : Activity() {
    lateinit var db: DB
    lateinit var content: LinearLayout
    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDf = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))
    private var selectedDate = today()
    private var reportFrom = monthStart()
    private var reportTo = today()

    private fun today() = df.format(Date())
    private fun monthStart(): String { val c = Calendar.getInstance(); c.set(Calendar.DAY_OF_MONTH, 1); return df.format(c.time) }
    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.0f", v)
    private fun days(v: Double) = if (v % 1.0 == 0.0) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        db = DB(this)
        db.writableDatabase
        home()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val current = (findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0)?.tag?.toString() ?: ""
        when {
            current.startsWith("👷 ") -> workers()
            current == "👷 मजदूर रिपोर्ट" || current == "🌾 खेत रिपोर्ट" || current == "💵 भुगतान" -> reports()
            current == "💾 Local Backup / Restore" -> home()
            current == "🌾 खेत / फसल" || current == "📅 आज का काम" || current == "📊 रिपोर्ट" || current == "👷 मजदूर" -> home()
            else -> super.onBackPressed()
        }
    }

    private fun bg(color: Int, radius: Int = 16, stroke: Int = 0, strokeColor: Int = C.BORDER): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke > 0) setStroke(dp(stroke), strokeColor) }

    private fun tv(text: String, size: Float = 15f, color: Int = C.TEXT, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false; setTextColor(C.GREEN); background = bg(Color.WHITE, 12, 1)
        setOnClickListener { action() }; minHeight = dp(46); stateListAnimator = null
    }

    private fun primary(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false; setTextColor(Color.WHITE); background = bg(C.GREEN2, 13)
        setOnClickListener { action() }; minHeight = dp(48); stateListAnimator = null
    }

    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 15f; setPadding(dp(14), 0, dp(14), 0); background = bg(Color.WHITE, 12, 1); minHeight = dp(50)
    }

    private fun page(title: String, subtitle: String = "", active: Int = 0): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG); tag = title }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); setBackgroundColor(C.GREEN) }
        header.addView(tv(title, 23f, Color.WHITE, true))
        if (subtitle.isNotBlank()) header.addView(tv(subtitle, 13f, 0xFFD7EAD9.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(header)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(100)) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(5), dp(6), dp(5)); setBackgroundColor(Color.WHITE); elevation = dp(8).toFloat() }
        listOf("⌂\nहोम", "👷\nमजदूर", "🌾\nखेत", "📅\nकाम", "📊\nरिपोर्ट").forEachIndexed { i, label ->
            val b = TextView(this).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(if (i == active) C.GREEN else C.MUTED); setPadding(0, dp(5), 0, dp(5)); setOnClickListener { when (i) { 0 -> home(); 1 -> workers(); 2 -> fields(); 3 -> work(); else -> reports() } } }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        root.addView(nav); return root
    }

    private fun card(title: String, value: String, accent: Int = C.GREEN2): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.WHITE, 15, 1)
        addView(tv(title, 12f, C.MUTED)); addView(tv(value, 20f, accent, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun addGap(h: Int = 10) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun addTo(parent: LinearLayout, child: View, gap: Int) { parent.addView(Space(this), LinearLayout.LayoutParams(1, dp(gap))); parent.addView(child, LinearLayout.LayoutParams(-1, dp(52))) }
    private fun empty(text: String) = tv("$text\n\nऊपर से नई entry जोड़ें।", 14f, C.MUTED).apply { gravity = Gravity.CENTER; setPadding(dp(12), dp(28), dp(12), dp(28)); background = bg(Color.WHITE, 15, 1) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun scalar(sql: String, args: Array<String> = emptyArray()): Double = db.readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else 0.0 }
    private fun count(table: String, where: String = "1=1"): Long = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table WHERE $where", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    private fun parseDate(s: String): Date = try { df.parse(s) ?: Date() } catch (_: Exception) { Date() }

    private fun home() {
        setContentView(page("मजदूर हिसाब", "खेती के मजदूर, काम और भुगतान — एक जगह", 0))
        val activeWorkers = count("workers", "active=1"); val activeFields = count("fields", "active=1")
        val todayDays = scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE date=?", arrayOf(today()))
        val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries"); val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments"); val balance = earned - paid
        content.addView(tv("आज का सारांश", 17f, C.TEXT, true)); addGap(8)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(card("मजदूर", activeWorkers.toString()), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) }); top.addView(card("खेत", activeFields.toString(), C.ORANGE), LinearLayout.LayoutParams(0, -2, 1f)); content.addView(top); addGap(10)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(card("आज के दिन", days(todayDays)), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) }); row.addView(card("कुल बाकी", money(balance), if (balance > 0) C.RED else C.GREEN2), LinearLayout.LayoutParams(0, -2, 1f)); content.addView(row); addGap(14)
        content.addView(primary("📅  आज का काम दर्ज करें") { selectedDate = today(); work() }, LinearLayout.LayoutParams(-1, dp(50))); addGap(8)
        content.addView(button("💵  भुगतान दर्ज करें") { payments() }, LinearLayout.LayoutParams(-1, dp(48))); addGap(8)
        content.addView(button("📊  पूरा हिसाब / रिपोर्ट") { reports() }, LinearLayout.LayoutParams(-1, dp(48))); addGap(8)
        content.addView(button("💾  Local Backup / Restore") { backup() }, LinearLayout.LayoutParams(-1, dp(48))); addGap(14)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(button("👷 मजदूर") { workers() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) }); quick.addView(button("🌾 खेत") { fields() }, LinearLayout.LayoutParams(0, dp(46), 1f)); content.addView(quick)
    }

    private fun workers() {
        setContentView(page("👷 मजदूर", "नाम, मजदूरी और पूरा हिसाब", 1))
        content.addView(primary("＋  नया मजदूर जोड़ें") { workerDialog(null) }, LinearLayout.LayoutParams(-1, dp(50))); addGap(10)
        val search = field("🔎 मजदूर खोजें")
        content.addView(search, LinearLayout.LayoutParams(-1, dp(50))); addGap(10)
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(listBox)
        fun render(q: String) {
            listBox.removeAllViews(); val like = q.trim().lowercase(Locale.getDefault()); val items = mutableListOf<Array<Any>>()
            db.readableDatabase.rawQuery("SELECT id,code,name,rate,active FROM workers ORDER BY id", null).use { c -> while (c.moveToNext()) { if (like.isEmpty() || c.getString(1).lowercase(Locale.getDefault()).contains(like) || c.getString(2).lowercase(Locale.getDefault()).contains(like)) items.add(arrayOf(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3), c.getInt(4))) } }
            if (items.isEmpty()) { listBox.addView(empty(if (like.isEmpty()) "अभी कोई मजदूर नहीं है" else "कोई मजदूर नहीं मिला")); return }
            items.forEach { item ->
                val id = item[0] as Long; val code = item[1] as String; val name = item[2] as String; val rate = item[3] as Double; val active = item[4] as Int
                val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?", arrayOf(id.toString())); val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?", arrayOf(id.toString()))
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.WHITE, 15, 1) }
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; line.addView(tv("$code  $name", 16f, C.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f)); line.addView(tv("${money(rate)}/दिन", 14f, C.GREEN2, true)); row.addView(line)
                row.addView(tv(if (active == 1) "बाकी: ${money(earned - paid)}" else "निष्क्रिय • बाकी: ${money(earned - paid)}", 12f, if (earned - paid > 0) C.RED else C.MUTED).apply { setPadding(0, dp(6), 0, dp(7)) })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(button("देखें") { workerDetail(id) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
                actions.addView(button("✎ Edit") { workerDialog(id) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
                actions.addView(button(if (active == 1) "निष्क्रिय" else "सक्रिय") { toggleWorker(id, active == 1) }, LinearLayout.LayoutParams(0, dp(42), 1f)); row.addView(actions)
                listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            }
        }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {} ; override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { render(s?.toString() ?: "") }; override fun afterTextChanged(e: Editable?) {} })
        render("")
    }

    private fun workerDialog(id: Long?) {
        val old = if (id == null) null else db.readableDatabase.rawQuery("SELECT name,rate FROM workers WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getString(0) to c.getDouble(1) else null }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }; val name = field("मजदूर का नाम", old?.first ?: ""); val rate = field("दैनिक मजदूरी ₹", old?.second?.toString() ?: ""); rate.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        box.addView(name, LinearLayout.LayoutParams(-1, dp(52))); addTo(box, rate, 8)
        AlertDialog.Builder(this).setTitle(if (id == null) "नया मजदूर" else "मजदूर Edit").setView(box).setPositiveButton("सेव") { _, _ ->
            val n = name.text.toString().trim(); val r = rate.text.toString().replace(",", ".").toDoubleOrNull()
            if (n.isBlank() || r == null || r < 0) { toast("नाम और सही मजदूरी भरें"); return@setPositiveButton }
            try {
                if (id == null) {
                    db.writableDatabase.beginTransaction(); try { val next = scalar("SELECT COALESCE(MAX(CAST(SUBSTR(code,3) AS INTEGER)),0)+1 FROM workers WHERE code LIKE 'L-%'").toInt(); db.writableDatabase.execSQL("INSERT INTO workers(code,name,rate,active) VALUES(?,?,?,1)", arrayOf("L-%03d".format(Locale.US, next), n, r)); db.writableDatabase.setTransactionSuccessful() } finally { db.writableDatabase.endTransaction() }
                } else db.writableDatabase.execSQL("UPDATE workers SET name=?,rate=? WHERE id=?", arrayOf(n, r, id))
                workers()
            } catch (e: Exception) { toast("सेव नहीं हुआ: ${e.message}") }
        }.setNegativeButton("रद्द", null).show()
    }

    private fun toggleWorker(id: Long, deactivate: Boolean) { db.writableDatabase.execSQL("UPDATE workers SET active=? WHERE id=?", arrayOf(if (deactivate) 0 else 1, id)); workers() }

    private fun workerDetail(id: Long) {
        val info = db.readableDatabase.rawQuery("SELECT code,name,rate,active FROM workers WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) arrayOf(c.getString(0), c.getString(1), c.getDouble(2), c.getInt(3)) else null }
        if (info == null) { workers(); return }
        setContentView(page("👷 ${info[0]}", "${info[1]} • ${money(info[2] as Double)}/दिन", 1)); val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?", arrayOf(id.toString())); val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?", arrayOf(id.toString())); val daysTotal = scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE worker_id=?", arrayOf(id.toString()))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; row.addView(card("दिन", days(daysTotal)), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }); row.addView(card("कमाई", money(earned)), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }); row.addView(card("बाकी", money(earned - paid), if (earned - paid > 0) C.RED else C.GREEN2), LinearLayout.LayoutParams(0, -2, 1f)); content.addView(row); addGap(14)
        content.addView(tv("काम की history", 16f, C.TEXT, true)); addGap(7)
        db.readableDatabase.rawQuery("SELECT w.date,f.name,w.days,w.rate FROM work_entries w JOIN fields f ON f.id=w.field_id WHERE w.worker_id=? ORDER BY w.date DESC,w.id DESC", arrayOf(id.toString())).use { c -> if (!c.moveToFirst()) content.addView(empty("अभी काम की entry नहीं है")) else do { content.addView(tv("${c.getString(0)}  •  ${c.getString(1)}  •  ${days(c.getDouble(2))} दिन  •  ${money(c.getDouble(2) * c.getDouble(3))}", 13f, C.TEXT).apply { setPadding(dp(12), dp(10), dp(12), dp(10)); background = bg(Color.WHITE, 12, 1) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) } while (c.moveToNext()) }
        addGap(10); content.addView(tv("Payment history", 16f, C.TEXT, true)); addGap(7)
        db.readableDatabase.rawQuery("SELECT date,amount,note FROM payments WHERE worker_id=? ORDER BY date DESC,id DESC", arrayOf(id.toString())).use { c -> if (!c.moveToFirst()) content.addView(empty("अभी payment नहीं है")) else do { content.addView(tv("${c.getString(0)}  •  ${money(c.getDouble(1))}  ${c.getString(2)}", 13f, C.TEXT).apply { setPadding(dp(12), dp(10), dp(12), dp(10)); background = bg(Color.WHITE, 12, 1) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) } while (c.moveToNext()) }
    }

    private fun fields() {
        setContentView(page("🌾 खेत / फसल", "अलग-अलग खेतों का हिसाब", 2)); content.addView(primary("＋  नया खेत / फसल जोड़ें") { fieldDialog(null) }, LinearLayout.LayoutParams(-1, dp(50))); addGap(10)
        val search = field("🔎 खेत / फसल खोजें"); content.addView(search, LinearLayout.LayoutParams(-1, dp(50))); addGap(10); val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(listBox)
        fun render(q: String) { listBox.removeAllViews(); val like = q.trim().lowercase(Locale.getDefault()); val items = mutableListOf<Array<Any>>(); db.readableDatabase.rawQuery("SELECT id,name,active FROM fields ORDER BY name", null).use { c -> while (c.moveToNext()) if (like.isEmpty() || c.getString(1).lowercase(Locale.getDefault()).contains(like)) items.add(arrayOf(c.getLong(0), c.getString(1), c.getInt(2))) }
            if (items.isEmpty()) { listBox.addView(empty(if (like.isEmpty()) "अभी कोई खेत नहीं है" else "कोई खेत नहीं मिला")); return }
            items.forEach { item -> val id = item[0] as Long; val name = item[1] as String; val active = item[2] as Int; val total = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?", arrayOf(id.toString())); val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(10), dp(12)); background = bg(Color.WHITE, 15, 1) }; row.addView(tv("🌾 $name", 16f, C.TEXT, true)); row.addView(tv(if (active == 1) "कुल मजदूरी: ${money(total)}" else "निष्क्रिय • कुल मजदूरी: ${money(total)}", 12f, C.MUTED).apply { setPadding(0, dp(5), 0, dp(8)) }); val a = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; a.addView(button("✎ Edit") { fieldDialog(id) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) }); a.addView(button(if (active == 1) "निष्क्रिय" else "सक्रिय") { toggleField(id, active == 1) }, LinearLayout.LayoutParams(0, dp(42), 1f)); row.addView(a); listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }) }
        }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { render(s?.toString() ?: "") }; override fun afterTextChanged(e: Editable?) {} }); render("")
    }

    private fun fieldDialog(id: Long?) { val old = if (id == null) "" else db.readableDatabase.rawQuery("SELECT name FROM fields WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) c.getString(0) else "" }; val e = field("खेत / फसल का नाम", old); AlertDialog.Builder(this).setTitle(if (id == null) "नया खेत / फसल" else "खेत Edit").setView(e).setPositiveButton("सेव") { _, _ -> val n = e.text.toString().trim(); if (n.isBlank()) { toast("नाम भरें"); return@setPositiveButton }; try { if (id == null) db.writableDatabase.execSQL("INSERT INTO fields(name,active) VALUES(?,1)", arrayOf(n)) else db.writableDatabase.execSQL("UPDATE fields SET name=? WHERE id=?", arrayOf(n, id)); fields() } catch (x: Exception) { toast("सेव नहीं हुआ: ${x.message}") } }.setNegativeButton("रद्द", null).show() }
    private fun toggleField(id: Long, deactivate: Boolean) { db.writableDatabase.execSQL("UPDATE fields SET active=? WHERE id=?", arrayOf(if (deactivate) 0 else 1, id)); fields() }

    private fun work() {
        setContentView(page("📅 आज का काम", "तारीख + खेत + हर मजदूर", 3)); content.addView(button("📅  ${displayDf.format(parseDate(selectedDate))}") { pickDate(selectedDate) { selectedDate = it; work() } }, LinearLayout.LayoutParams(-1, dp(48))); addGap(8)
        val fs = mutableListOf<Pair<Long, String>>(); db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name", null).use { c -> while (c.moveToNext()) fs.add(c.getLong(0) to c.getString(1)) }; if (fs.isEmpty()) { content.addView(empty("पहले खेत / फसल जोड़ें")); return }
        val spinner = Spinner(this); spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fs.map { it.second }); content.addView(spinner, LinearLayout.LayoutParams(-1, dp(52))); addGap(8)
        val copy = button("↶  पिछली तारीख का काम कॉपी करें") { copyPreviousWork(selectedDate, fs[spinner.selectedItemPosition].first) }; content.addView(copy, LinearLayout.LayoutParams(-1, dp(46))); addGap(8)
        val rows = mutableListOf<Pair<Long, EditText>>(); val rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(rowsBox)
        fun loadRows() { rows.clear(); rowsBox.removeAllViews(); val fieldId = fs[spinner.selectedItemPosition].first; db.readableDatabase.rawQuery("SELECT w.id,w.code,w.name,w.rate,COALESCE((SELECT days FROM work_entries e WHERE e.date=? AND e.worker_id=w.id AND e.field_id=?),0) FROM workers w WHERE w.active=1 ORDER BY w.id", arrayOf(selectedDate, fieldId.toString())).use { c -> while (c.moveToNext()) { val id = c.getLong(0); val code = c.getString(1); val name = c.getString(2); val rate = c.getDouble(3); val current = c.getDouble(4); val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(9), dp(8), dp(9)); background = bg(Color.WHITE, 14, 1) }; val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; info.addView(tv("$code  $name", 15f, C.TEXT, true)); info.addView(tv("${money(rate)}/दिन", 11f, C.MUTED)); row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); val e = EditText(this).apply { setText(if (current == 0.0) "0" else days(current)); textSize = 15f; gravity = Gravity.CENTER; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; background = bg(C.GREEN_LIGHT, 10, 1); minWidth = dp(70); minHeight = dp(44) }; row.addView(e, LinearLayout.LayoutParams(dp(75), dp(44))); rows.add(id to e); rowsBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }) } }
        }
        loadRows(); spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}; override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) { loadRows() } }
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; val b1 = button("सब 1 दिन") { rows.forEach { it.second.setText("1") } }; val b2 = button("सब ½ दिन") { rows.forEach { it.second.setText("0.5") } }; val b0 = button("सब 0") { rows.forEach { it.second.setText("0") } }; quick.addView(b1, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }); quick.addView(b2, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) }); quick.addView(b0, LinearLayout.LayoutParams(0, dp(44), 1f)); content.addView(quick); addGap(8)
        content.addView(primary("✓  काम सेव करें") { saveWork(fs[spinner.selectedItemPosition].first, rows) }, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun copyPreviousWork(date: String, fieldId: Long) {
        val cal = Calendar.getInstance(); cal.time = parseDate(date); cal.add(Calendar.DAY_OF_MONTH, -1); val prev = df.format(cal.time)
        val previous = mutableMapOf<Long, Double>()
        db.readableDatabase.rawQuery("SELECT e.worker_id,e.days FROM work_entries e JOIN workers w ON w.id=e.worker_id WHERE e.date=? AND e.field_id=? AND w.active=1", arrayOf(prev, fieldId.toString())).use { c -> while (c.moveToNext()) previous[c.getLong(0)] = c.getDouble(1) }
        if (previous.isEmpty()) { toast("पिछली तारीख में इस खेत के सक्रिय मजदूरों का काम नहीं मिला"); return }
        val msg = "${displayDf.format(parseDate(prev))} का काम कॉपी होगा। आज के सभी सक्रिय मजदूरों की इस खेत वाली entries previous day के अनुसार replace होंगी। निष्क्रिय मजदूरों की पुरानी history सुरक्षित रहेगी।"
        AlertDialog.Builder(this).setTitle("पिछला काम कॉपी करें?").setMessage(msg).setPositiveButton("कॉपी") { _, _ ->
            val wdb = db.writableDatabase
            wdb.beginTransaction()
            try {
                // Replace only today's active-worker entries for this field. Historical/inactive records are untouched.
                wdb.delete("work_entries", "date=? AND field_id=? AND worker_id IN (SELECT id FROM workers WHERE active=1)", arrayOf(date, fieldId.toString()))
                previous.forEach { (workerId, d) ->
                    if (d > 0) wdb.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) SELECT ?,id,?, ?,rate FROM workers WHERE id=? AND active=1", arrayOf(date, fieldId, d, workerId))
                }
                wdb.setTransactionSuccessful()
            } finally { wdb.endTransaction() }
            work()
        }.setNegativeButton("रद्द", null).show()
    }

    private fun saveWork(fieldId: Long, rows: List<Pair<Long, EditText>>) {
        val wdb = db.writableDatabase
        try {
            wdb.beginTransaction()
            rows.forEach { (workerId, e) ->
                val d = e.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0
                if (d !in 0.0..1.0) throw IllegalArgumentException("दिन 0, 0.5 या 1 ही रखें")
                // Only replace the selected active worker's entry. Never delete the whole
                // date/field set, because that could erase history for workers who were
                // later deactivated and are therefore not shown in the work-entry screen.
                wdb.delete("work_entries", "date=? AND field_id=? AND worker_id=? AND EXISTS (SELECT 1 FROM workers WHERE id=? AND active=1)", arrayOf(selectedDate, fieldId.toString(), workerId.toString(), workerId.toString()))
                if (d > 0) wdb.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) SELECT ?,id,?, ?,rate FROM workers WHERE id=? AND active=1", arrayOf(selectedDate, fieldId, d, workerId))
            }
            wdb.setTransactionSuccessful()
            toast("काम सेव हो गया")
            work()
        } catch (e: Exception) {
            toast("काम सेव नहीं हुआ: ${e.message}")
        } finally {
            if (wdb.inTransaction) wdb.endTransaction()
        }
    }

    private fun reports() {
        setContentView(page("📊 रिपोर्ट", "तारीख के अनुसार पूरा हिसाब", 4)); val range = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; range.addView(button("से ${displayDf.format(parseDate(reportFrom))}") { pickDate(reportFrom) { reportFrom = it; reports() } }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) }); range.addView(button("तक ${displayDf.format(parseDate(reportTo))}") { pickDate(reportTo) { reportTo = it; reports() } }, LinearLayout.LayoutParams(0, dp(46), 1f)); content.addView(range); addGap(10)
        val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date BETWEEN ? AND ?", arrayOf(reportFrom, reportTo)); val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?", arrayOf(reportFrom, reportTo)); val bal = earned - paid
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; cards.addView(card("मजदूरी", money(earned)), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }); cards.addView(card("भुगतान", money(paid), C.BLUE), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }); cards.addView(card("बाकी", money(bal), if (bal > 0) C.RED else C.GREEN2), LinearLayout.LayoutParams(0, -2, 1f)); content.addView(cards); addGap(12)
        content.addView(primary("👷 मजदूर-वार detail") { workerReport() }); addGap(8); content.addView(button("🌾 खेत-वार detail") { fieldReport() }); addGap(8); content.addView(button("💵 भुगतान ledger") { payments() }); addGap(14)
        content.addView(tv("खेत का सारांश", 16f, C.TEXT, true)); addGap(7); db.readableDatabase.rawQuery("SELECT f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0) FROM work_entries w JOIN fields f ON f.id=w.field_id WHERE w.date BETWEEN ? AND ? GROUP BY f.id ORDER BY f.name", arrayOf(reportFrom, reportTo)).use { c -> if (!c.moveToFirst()) content.addView(empty("इस अवधि में काम नहीं है")) else do { content.addView(tv("🌾 ${c.getString(0)}   •   ${days(c.getDouble(1))} दिन   •   ${money(c.getDouble(2))}", 14f, C.TEXT, true).apply { setPadding(dp(12), dp(12), dp(12), dp(12)); background = bg(Color.WHITE, 13, 1) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }) } while (c.moveToNext()) }
    }

    private fun workerReport() { setContentView(page("👷 मजदूर रिपोर्ट", "इस अवधि: ${displayDf.format(parseDate(reportFrom))} — ${displayDf.format(parseDate(reportTo))}", 4)); db.readableDatabase.rawQuery("SELECT id,code,name,active FROM workers ORDER BY id", null).use { c -> if (!c.moveToFirst()) content.addView(empty("कोई मजदूर नहीं")) else do { val id = c.getLong(0); val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=? AND date BETWEEN ? AND ?", arrayOf(id.toString(), reportFrom, reportTo)); val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=? AND date BETWEEN ? AND ?", arrayOf(id.toString(), reportFrom, reportTo)); val td = scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE worker_id=? AND date BETWEEN ? AND ?", arrayOf(id.toString(), reportFrom, reportTo)); val status = if (c.getInt(3) == 1) "" else " • निष्क्रिय"; val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.WHITE, 15, 1) }; row.addView(tv("${c.getString(1)}  ${c.getString(2)}$status", 16f, C.TEXT, true)); row.addView(tv("${days(td)} दिन  •  कमाई ${money(earned)}  •  भुगतान ${money(paid)}  •  बाकी ${money(earned - paid)}", 13f, if (earned - paid > 0) C.RED else C.GREEN2, true).apply { setPadding(0, dp(5), 0, dp(8)) }); row.setOnClickListener { workerDetail(id) }; content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }) } while (c.moveToNext()) }; addGap(6); content.addView(button("← रिपोर्ट") { reports() }) }

    private fun fieldReport() {
        setContentView(page("🌾 खेत रिपोर्ट", "पूरा history — active और inactive दोनों", 2))
        val fs = mutableListOf<Pair<Long, String>>()
        db.readableDatabase.rawQuery("SELECT id,name FROM fields ORDER BY name", null).use { c ->
            while (c.moveToNext()) fs.add(c.getLong(0) to c.getString(1))
        }
        if (fs.isEmpty()) { content.addView(empty("कोई खेत नहीं")); return }
        fs.forEach { (id, name) ->
            val active = scalar("SELECT active FROM fields WHERE id=?", arrayOf(id.toString())).toInt() == 1
            val td = scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE field_id=? AND date BETWEEN ? AND ?", arrayOf(id.toString(), reportFrom, reportTo))
            val total = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=? AND date BETWEEN ? AND ?", arrayOf(id.toString(), reportFrom, reportTo))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13))
                background = bg(Color.WHITE, 15, 1)
            }
            row.addView(tv("🌾 $name${if (active) "" else " • निष्क्रिय"}", 16f, C.TEXT, true))
            row.addView(tv("कुल ${days(td)} दिन  •  ${money(total)}", 14f, C.GREEN2, true).apply { setPadding(0, dp(5), 0, dp(8)) })
            db.readableDatabase.rawQuery(
                "SELECT w.date,wo.name,w.days,w.rate FROM work_entries w JOIN workers wo ON wo.id=w.worker_id WHERE w.field_id=? AND w.date BETWEEN ? AND ? ORDER BY w.date DESC,w.id DESC",
                arrayOf(id.toString(), reportFrom, reportTo)
            ).use { c ->
                while (c.moveToNext()) {
                    val line = "${c.getString(0)}  •  ${c.getString(1)}  •  ${days(c.getDouble(2))} दिन  •  ${money(c.getDouble(2) * c.getDouble(3))}"
                    row.addView(tv(line, 12f, C.MUTED).apply { setPadding(0, dp(3), 0, dp(3)) })
                }
            }
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        content.addView(button("← रिपोर्ट") { reports() })
    }

    private fun payments() {
        setContentView(page("💵 भुगतान", "Local payment ledger", 4)); val range = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; range.addView(button("से ${displayDf.format(parseDate(reportFrom))}") { pickDate(reportFrom) { reportFrom = it; payments() } }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) }); range.addView(button("तक ${displayDf.format(parseDate(reportTo))}") { pickDate(reportTo) { reportTo = it; payments() } }, LinearLayout.LayoutParams(0, dp(46), 1f)); content.addView(range); addGap(8); content.addView(primary("＋  भुगतान दर्ज करें") { paymentDialog(null) }); addGap(12)
        db.readableDatabase.rawQuery("SELECT p.id,p.date,w.code,w.name,p.amount,p.note FROM payments p JOIN workers w ON w.id=p.worker_id WHERE p.date BETWEEN ? AND ? ORDER BY p.date DESC,p.id DESC", arrayOf(reportFrom, reportTo)).use { c -> if (!c.moveToFirst()) content.addView(empty("इस अवधि में कोई भुगतान नहीं है")) else do { val id = c.getLong(0); val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(13), dp(11), dp(10), dp(11)); background = bg(Color.WHITE, 14, 1) }; val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; info.addView(tv("${c.getString(2)}  ${c.getString(3)}", 15f, C.TEXT, true)); info.addView(tv("${c.getString(1)}  •  ${c.getString(5)}", 11f, C.MUTED)); row.addView(info, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(tv(money(c.getDouble(4)), 16f, C.BLUE, true)); row.setOnClickListener { paymentDialog(id) }; row.setOnLongClickListener { confirmDeletePayment(id); true }; content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }) } while (c.moveToNext()) }
        content.addView(tv("Entry पर tap = Edit • long press = Delete", 12f, C.MUTED).apply { setPadding(0, dp(8), 0, 0) })
    }

    private fun paymentDialog(editId: Long?) {
        val old = if (editId == null) null else db.readableDatabase.rawQuery("SELECT worker_id,date,amount,note FROM payments WHERE id=?", arrayOf(editId.toString())).use { c -> if (c.moveToFirst()) arrayOf(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3)) else null }
        val ids = mutableListOf<Long>(); val names = mutableListOf<String>(); db.readableDatabase.rawQuery("SELECT id,code,name FROM workers ORDER BY active DESC,id", null).use { c -> while (c.moveToNext()) { ids.add(c.getLong(0)); names.add("${c.getString(1)} ${c.getString(2)}${if (c.getInt(0) == 0) "" else ""}") } }; if (ids.isEmpty()) { toast("पहले मजदूर जोड़ें"); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, dp(8), 0) }; val s = Spinner(this); s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names); val oldWorker = old?.get(0) as? Long; if (oldWorker != null) ids.indexOf(oldWorker).takeIf { it >= 0 }?.let { s.setSelection(it) }
        var payDate = (old?.get(1) as? String) ?: today(); val date = button("📅  ${displayDf.format(parseDate(payDate))}") { }; date.setOnClickListener { pickDate(payDate) { payDate = it; date.text = "📅  ${displayDf.format(parseDate(payDate))}" } }; val amount = field("भुगतान राशि ₹", old?.get(2)?.toString() ?: ""); amount.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; val note = field("नोट (वैकल्पिक)", old?.get(3)?.toString() ?: ""); box.addView(s, LinearLayout.LayoutParams(-1, dp(52))); addTo(box, date, 7); addTo(box, amount, 7); addTo(box, note, 7)
        AlertDialog.Builder(this).setTitle(if (editId == null) "नकद भुगतान" else "भुगतान Edit").setView(box).setPositiveButton("सेव") { _, _ -> val a = amount.text.toString().replace(",", ".").toDoubleOrNull() ?: 0.0; if (a <= 0) { toast("सही राशि भरें"); return@setPositiveButton }; try { if (editId == null) db.writableDatabase.execSQL("INSERT INTO payments(date,worker_id,amount,note) VALUES(?,?,?,?)", arrayOf(payDate, ids[s.selectedItemPosition], a, note.text.toString().trim())) else db.writableDatabase.execSQL("UPDATE payments SET date=?,worker_id=?,amount=?,note=? WHERE id=?", arrayOf(payDate, ids[s.selectedItemPosition], a, note.text.toString().trim(), editId)); payments() } catch (e: Exception) { toast("Payment सेव नहीं हुआ: ${e.message}") } }.setNegativeButton("रद्द", null).show()
    }

    private fun confirmDeletePayment(id: Long) { AlertDialog.Builder(this).setTitle("भुगतान हटाएं?").setMessage("यह payment record हट जाएगा।").setPositiveButton("हटाएं") { _, _ -> db.writableDatabase.execSQL("DELETE FROM payments WHERE id=?", arrayOf(id)); payments() }.setNegativeButton("रद्द", null).show() }

    private fun backup() { setContentView(page("💾 Local Backup / Restore", "SQLite • Offline • बिना Internet", 0)); content.addView(card("डेटा कहाँ है?", "सिर्फ इस डिवाइस की local SQLite database")); addGap(12); content.addView(primary("⬇  Backup ZIP फाइल सेव करें") { createBackup() }); addGap(8); content.addView(button("⬆  Backup ZIP से Restore करें") { pickRestore() }); addGap(15); content.addView(tv("इस app में Online Backup, Cloud Sync, Supabase या Firebase data backup नहीं है। Backup एक local ZIP file है। ZIP को फोन की storage में सुरक्षित रखें; चाहें तो आप इसे स्वयं किसी अन्य स्थान पर कॉपी कर सकते हैं।", 13f, C.MUTED)) }

    private fun createBackup() { try { val d = db.writableDatabase; d.execSQL("PRAGMA wal_checkpoint(TRUNCATE)"); validateDatabase(d); val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { type = "application/zip"; putExtra(Intent.EXTRA_TITLE, "Majdoor_Hisaab_Backup_${today()}.zip"); addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(intent, 901) } catch (e: Exception) { toast("Backup नहीं बन सका: ${e.message}") } }
    private fun pickRestore() { val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/zip"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/octet-stream")); addCategory(Intent.CATEGORY_OPENABLE) }; startActivityForResult(intent, 900) }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { super.onActivityResult(requestCode, resultCode, data); if (resultCode != RESULT_OK || data?.data == null) return; try { if (requestCode == 901) { createZipBackup(data.data!!); toast("Backup ZIP सफलतापूर्वक सेव हो गया") } else if (requestCode == 900) validateAndConfirmRestore(data.data!!) } catch (e: Exception) { toast("Backup/Restore error: ${e.message}") } }

    private fun createZipBackup(uri: Uri) {
        val dbFile = getDatabasePath(DB_NAME)
        contentResolver.openOutputStream(uri)?.use { output ->
            ZipOutputStream(output).use { zip ->
                zip.putNextEntry(ZipEntry("majdoor_hisaab.db")); dbFile.inputStream().use { it.copyTo(zip) }; zip.closeEntry()
                val info = "Majdoor Hisaab Local SQLite Backup\nApp Marker: $APP_MARKER\nSchema Version: $DB_VERSION\nSQLite User Version: $DB_VERSION\nBackup Date: ${today()}\nOnline Database: NO\n"
                zip.putNextEntry(ZipEntry("backup_info.txt")); zip.write(info.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
        } ?: throw Exception("फाइल सेव नहीं हुई")
    }

    private fun validateDatabase(d: SQLiteDatabase) {
        d.rawQuery("PRAGMA integrity_check", null).use { if (!it.moveToFirst() || it.getString(0) != "ok") throw Exception("Database integrity check failed") }
        d.rawQuery("SELECT value FROM settings WHERE key='app_marker'", null).use { if (!it.moveToFirst() || it.getString(0) != APP_MARKER) throw Exception("App database marker missing") }
        d.rawQuery("SELECT value FROM settings WHERE key='schema_version'", null).use { if (!it.moveToFirst() || it.getString(0).toIntOrNull() != DB_VERSION) throw Exception("Database schema version mismatch") }
        if (d.version != DB_VERSION) throw Exception("SQLite user_version mismatch")
        d.rawQuery("PRAGMA foreign_key_check", null).use { if (it.moveToFirst()) throw Exception("Foreign key data error") }
    }

    private fun extractBackupDatabase(zipFile: File, destination: File) {
        var found = false
        zipFile.inputStream().use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name == "majdoor_hisaab.db") {
                        destination.outputStream().use { out -> zip.copyTo(out) }
                        found = true
                    }
                    zip.closeEntry(); entry = zip.nextEntry
                }
            }
        } ?: throw Exception("Backup ZIP नहीं पढ़ी जा सकी")
        if (!found || !destination.exists() || destination.length() == 0L) throw Exception("Valid Majdoor Hisaab ZIP backup नहीं है")
    }

    private fun validateAndConfirmRestore(uri: Uri) {
        val tempZip = File(cacheDir, "restore_check.zip"); val tempDb = File(cacheDir, "restore_check.db")
        try {
            contentResolver.openInputStream(uri)?.use { inp -> tempZip.outputStream().use { out -> inp.copyTo(out) } } ?: throw Exception("Backup ZIP नहीं पढ़ी जा सकी")
            extractBackupDatabase(tempZip, tempDb)
            val test = SQLiteDatabase.openDatabase(tempDb.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val required = listOf("workers", "fields", "work_entries", "payments", "settings")
                for (t in required) test.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", arrayOf(t)).use { if (!it.moveToFirst()) throw Exception("यह valid मजदूर हिसाब backup नहीं है") }
                test.rawQuery("SELECT value FROM settings WHERE key='app_marker'", null).use { if (!it.moveToFirst() || it.getString(0) != APP_MARKER) throw Exception("यह backup किसी दूसरे app/database का है") }
                test.rawQuery("SELECT value FROM settings WHERE key='schema_version'", null).use { if (!it.moveToFirst() || it.getString(0).toIntOrNull() != DB_VERSION) throw Exception("Backup schema version ${DB_VERSION} नहीं है") }
                if (test.version != DB_VERSION) throw Exception("Backup SQLite user_version mismatch")
                test.rawQuery("PRAGMA integrity_check", null).use { if (!it.moveToFirst() || it.getString(0) != "ok") throw Exception("Backup database corrupt है") }
                test.rawQuery("PRAGMA foreign_key_check", null).use { if (it.moveToFirst()) throw Exception("Backup में foreign-key error है") }
            } finally { test.close() }
            AlertDialog.Builder(this).setTitle("Restore करें?").setMessage("Local ZIP backup valid है। मौजूदा हिसाब replace होगा।").setPositiveButton("Restore") { _, _ -> restoreFrom(uri) }.setNegativeButton("रद्द", null).show()
        } catch (e: Exception) { toast(e.message ?: "Invalid backup ZIP") } finally { tempZip.delete(); tempDb.delete() }
    }

    private fun restoreFrom(uri: Uri) {
        val dbFile = getDatabasePath(DB_NAME); val tempZip = File(cacheDir, "restore_ready.zip"); val tempDb = File(cacheDir, "restore_ready.db"); val oldBackup = File(dbFile.absolutePath + ".before_restore")
        try {
            contentResolver.openInputStream(uri)?.use { inp -> tempZip.outputStream().use { out -> inp.copyTo(out) } } ?: throw Exception("Backup ZIP नहीं पढ़ी जा सकी")
            extractBackupDatabase(tempZip, tempDb)
            val test = SQLiteDatabase.openDatabase(tempDb.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            try { validateDatabase(test) } finally { test.close() }
            db.close()
            if (dbFile.exists()) dbFile.copyTo(oldBackup, true)
            tempDb.copyTo(dbFile, true)
            tempDb.delete(); tempZip.delete(); db = DB(this); db.writableDatabase; validateDatabase(db.readableDatabase); oldBackup.delete(); toast("Local ZIP restore पूरा हो गया"); home()
        } catch (e: Exception) {
            tempDb.delete(); tempZip.delete()
            try {
                if (oldBackup.exists()) { if (::db.isInitialized) db.close(); oldBackup.copyTo(dbFile, true); oldBackup.delete() }
            } catch (_: Exception) {}
            db = DB(this)
            toast("Restore error: ${e.message}")
        }
    }

    private fun pickDate(current: String, done: (String) -> Unit) { val cal = Calendar.getInstance(); try { cal.time = df.parse(current) ?: Date() } catch (_: Exception) {}; DatePickerDialog(this, { _, y, m, d -> val c = Calendar.getInstance(); c.set(y, m, d); done(df.format(c.time)) }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show() }
}
