# मजदूर हिसाब — PRO v2.2

ऑफलाइन खेती-मजदूर हिसाब ऐप। **डेटा केवल local SQLite में रहता है।**

## Data policy
- कोई online backup नहीं।
- कोई cloud sync नहीं।
- कोई Supabase/Firebase data storage नहीं।
- कोई login/account/server नहीं।
- Backup एक **local ZIP file** होता है, जिसमें SQLite database और backup metadata रहता है। Restore भी केवल इसी valid ZIP से होता है।

## मुख्य सुविधाएँ
- मजदूर: नाम, दैनिक मजदूरी, स्थायी `L-001` जैसे ID
- मजदूर खोज और active/inactive management
- खेत/फसल: add, edit, search, active/inactive
- तारीख + खेत के अनुसार काम
- 0 / 0.5 / 1 दिन
- सभी को 1 दिन / ½ दिन / 0 दिन quick entry
- पिछली तारीख का उसी खेत का काम copy
- duplicate date + worker + field रोकने के लिए unique index
- मजदूर की पूरी work/payment history
- payment add/edit/delete
- payment date-range ledger
- date-range worker और field reports
- inactive मजदूर/खेत की historical entries भी reports में दिखाई देती हैं
- historical wage work entry में सुरक्षित रहता है
- local SQLite backup/restore as ZIP
- backup से पहले integrity + foreign-key validation
- restore में app marker + schema + integrity + foreign-key validation
- foreign-key protected database

## Build
- Android SDK 35
- Java 17
- Gradle 8.11.1+ compatible
- AGP 8.9.1
- Kotlin 2.1.20
