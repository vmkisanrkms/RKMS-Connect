# Majdoor Hisaab PRO — Audited Kotlin Fix

Audited against the uploaded v10 ZIP.

Fixed only the verified compile blockers:

1. Added the missing `androidx.activity.compose.setContent` import.
2. Fixed the exact `JSONArray.mapList()` parser syntax.
3. Replaced only the broken `LabourDetail()` function with a structurally balanced version using the existing v10 APIs.
4. Corrected `ExpenseDialog()` argument order.
5. Corrected `SaleDialog()` argument order.

No generic brace deletion/repair was used.
No unrelated application logic was changed.

Local Kotlin parser verification was performed after the fixes:
- No `expecting a '>'` syntax error.
- No `expecting a top level declaration` error.
- No `Boolean` vs `() -> Unit` argument-order error.
Remaining standalone `kotlinc` errors are Android/Compose dependency-resolution errors because the local parser test is not an Android Gradle build.
