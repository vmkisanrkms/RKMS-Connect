plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace="com.majdoor.hisaab"
    compileSdk=35

    defaultConfig {
        applicationId="com.majdoor.hisaab"
        minSdk=26
        targetSdk=35
        versionCode=5
        versionName="2.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}