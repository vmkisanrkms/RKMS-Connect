package com.majdoor.hisaab

import android.app.*
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.*
import android.text.InputType
import android.view.*
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private object C {
    const val GREEN = 0xFF087A3D.toInt()
    const val GREEN_DARK = 0xFF04572C.toInt()
    const val GREEN_SOFT = 0xFFE8F6EE.toInt()
    const val BLUE = 0xFF1677D2.toInt()
    const val BLUE_SOFT = 0xFFEAF3FF.toInt()
    const val ORANGE = 0xFFF59E0B.toInt()
    const val ORANGE_SOFT = 0xFFFFF5DB.toInt()
    const val RED = 0xFFDC3545.toInt()
    const val RED_SOFT = 0xFFFFECEE.toInt()
    const val PURPLE = 0xFF7C4DFF.toInt()
    const val PURPLE_SOFT = 0xFFF1ECFF.toInt()
    const val TEXT = 0xFF18231D.toInt()
    const val MUTED = 0xFF66736C.toInt()
    const val BG = 0xFFF4F7F5.toInt()
    const val WHITE = Color.WHITE
    const val BORDER = 0xFFE0E7E2.toInt()
}

private const val DB_VERSION = 5
private const val DB_NAME = "majdoor_hisaab.db"
private const val APP_MARKER = "MAJDOOR_HISAAB_LOCAL_SQLITE_V5"

class DB(c: Context) : SQLiteOpenHelper(c, DB_NAME, null, DB_VERSION) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,name TEXT NOT NULL,rate REAL NOT NULL CHECK(rate>=0),active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)))")
        d.execSQL("CREATE TABLE fields(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)))")
        d.execSQL("CREATE TABLE work_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
        d.execSQL("CREATE TABLE team_members(date TEXT NOT NULL,field_id INTEGER NOT NULL REFERENCES fields(id) ON DELETE CASCADE,worker_id INTEGER NOT NULL REFERENCES workers(id) ON DELETE RESTRICT,PRIMARY KEY(date,field_id,worker_id))")
        createIndexes(d)
        setMetadata(d)
    }

    private fun createIndexes(d: SQLiteDatabase) {
        d.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS ux_work_date_worker_field ON work_entries(date,worker_id,field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_worker ON work_entries(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_field ON work_entries(field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_date ON work_entries(date)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_worker ON payments(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_date ON payments(date)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_team_date_field ON team_members(date,field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_team_worker ON team_members(worker_id)")
    }

    private fun setMetadata(d: SQLiteDatabase) {
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('app_marker',?)", arrayOf(APP_MARKER))
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version',?)", arrayOf(DB_VERSION.toString()))
        d.execSQL("PRAGMA user_version=$DB_VERSION")
    }

    override fun onUpgrade(d: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        d.beginTransaction()
        try {
            if (oldVersion < 3) d.execSQL("DELETE FROM work_entries WHERE id NOT IN (SELECT MAX(id) FROM work_entries GROUP BY date,worker_id,field_id)")
            if (oldVersion < 4) migrateToV4(d)
            if (oldVersion < 5) migrateToV5(d)
            createIndexes(d)
            setMetadata(d)
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    private fun migrateToV4(d: SQLiteDatabase) {
        d.execSQL("DROP INDEX IF EXISTS ux_work_date_worker_field")
        d.execSQL("CREATE TABLE work_entries_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("INSERT INTO work_entries_v4(id,date,worker_id,field_id,days,rate) SELECT w.id,w.date,w.worker_id,w.field_id,w.days,w.rate FROM work_entries w INNER JOIN workers wo ON wo.id=w.worker_id INNER JOIN fields f ON f.id=w.field_id WHERE w.days>=0 AND w.days<=1 AND w.rate>=0")
        d.execSQL("DROP TABLE work_entries")
        d.execSQL("ALTER TABLE work_entries_v4 RENAME TO work_entries")
        d.execSQL("CREATE TABLE payments_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("INSERT INTO payments_v4(id,date,worker_id,amount,note) SELECT p.id,p.date,p.worker_id,p.amount,COALESCE(p.note,'') FROM payments p INNER JOIN workers w ON w.id=p.worker_id WHERE p.amount>0")
        d.execSQL("DROP TABLE payments")
        d.execSQL("ALTER TABLE payments_v4 RENAME TO payments")
    }
    private fun migrateToV5(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS team_members(date TEXT NOT NULL,field_id INTEGER NOT NULL REFERENCES fields(id) ON DELETE CASCADE,worker_id INTEGER NOT NULL REFERENCES workers(id) ON DELETE RESTRICT,PRIMARY KEY(date,field_id,worker_id))")
        d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) SELECT date,field_id,worker_id FROM work_entries")
    }
}

class MainActivity : Activity() {
    private lateinit var db: DB
    private lateinit var content: LinearLayout
    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDf = SimpleDateFormat("dd MMM yyyy", Locale.US)
    private var selectedDate = today()
    private var reportFrom = monthStart()
    private var reportTo = today()
    private var pendingExport: ByteArray? = null

    private fun today() = df.format(Date())
    private fun monthStart(): String { val c = Calendar.getInstance(); c.set(Calendar.DAY_OF_MONTH, 1); return df.format(c.time) }
    private fun money(v: Double) = "₹" + String.format(Locale.US, "%,.0f", v)
    private fun days(v: Double) = if (v % 1.0 == 0.0) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun parseDate(s: String): Date = try { df.parse(s) ?: Date() } catch (_: Exception) { Date() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        db = DB(this)
        db.writableDatabase
        home()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val tag = (findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0)?.tag?.toString() ?: ""
        when {
            tag.startsWith("worker:") -> workers()
            tag.startsWith("field:") -> fields()
            tag.startsWith("report:") -> reports()
            tag == "workers" || tag == "fields" || tag == "reports" -> home()
            tag == "attendance" -> home()
            tag == "payments" -> home()
            tag == "backup" -> home()
            else -> super.onBackPressed()
        }
    }

    private fun bg(color: Int, radius: Int = 16, stroke: Int = 0, strokeColor: Int = C.BORDER) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke > 0) setStroke(dp(stroke), strokeColor)
    }

    private fun tv(text: String, size: Float = 15f, color: Int = C.TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; includeFontPadding = true
    }

    private fun label(text: String) = tv(text, 12f, C.MUTED, true).apply { setPadding(0, 0, 0, dp(5)) }

    private fun primary(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END; setTextColor(Color.WHITE); background = bg(C.GREEN, 13)
        minHeight = dp(48); stateListAnimator = null; setOnClickListener { action() }
    }

    private fun outline(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 13f; isAllCaps = false; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END; setTextColor(C.GREEN_DARK); background = bg(Color.WHITE, 12, 1)
        minHeight = dp(44); stateListAnimator = null; setOnClickListener { action() }
    }

    private fun input(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 14f; setTextColor(C.TEXT); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(13), 0, dp(13), 0); minHeight = dp(48); background = bg(Color.WHITE, 11, 1)
    }

    private fun section(text: String) = tv(text, 17f, C.TEXT, true).apply { setPadding(0, dp(2), 0, dp(8)) }

    private fun gap(h: Int = 10) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun page(title: String, subtitle: String = "", active: Int = 0, tagValue: String = title): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            tag = tagValue
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(12))
            background = bg(C.GREEN_DARK, 0)
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(com.majdoor.hisaab.R.drawable.majdoor_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        titleRow.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(tv(title, 20f, Color.WHITE, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        if (subtitle.isNotBlank()) titleBox.addView(tv(subtitle, 11.5f, 0xFFD8F1E0.toInt()).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0) })
        titleRow.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(tv("₹", 18f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = bg(C.GREEN, 50)
            setPadding(dp(9), dp(5), dp(9), dp(5))
        })
        header.addView(titleRow)
        root.addView(header)
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(92))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = ColorDrawable(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        val labels = listOf("⌂\nHome", "✓\nAttendance", "👷\nWorkers", "🌾\nFields", "▥\nReports")
        labels.forEachIndexed { i, text ->
            nav.addView(TextView(this).apply {
                this.text = text
                textSize = 10.5f
                maxLines = 2
                includeFontPadding = true
                gravity = Gravity.CENTER
                setTextColor(if (i == active) C.GREEN else C.MUTED)
                setTypeface(Typeface.DEFAULT, if (i == active) Typeface.BOLD else Typeface.NORMAL)
                setPadding(0, dp(4), 0, dp(4))
                setOnClickListener {
                    when (i) {
                        0 -> home()
                        1 -> attendance()
                        2 -> workers()
                        3 -> fields()
                        else -> reports()
                    }
                }
            }, LinearLayout.LayoutParams(0, dp(58), 1f))
        }
        root.addView(nav)
        return root
    }

    private fun stat(title: String, value: String, accent: Int, soft: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(11), dp(12), dp(11)); background = bg(soft, 15)
        addView(tv(title, 11f, C.MUTED).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }); addView(tv(value, 18f, accent, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun card(title: String, value: String, accent: Int = C.GREEN) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(Color.WHITE, 15, 1)
        addView(tv(title, 12f, C.MUTED).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }); addView(tv(value, 19f, accent, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun scalar(sql: String, args: Array<String> = emptyArray()): Double = db.readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else 0.0 }
    private fun count(table: String, where: String = "1=1"): Long = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table WHERE $where", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    private fun addRow(parent: LinearLayout, view: View, weight: Float = 1f, marginEnd: Int = 0) { parent.addView(view, LinearLayout.LayoutParams(0, -2, weight).apply { if (marginEnd > 0) this.marginEnd = dp(marginEnd) }) }

    private fun home() {
        setContentView(page("Majdoor Hisaab PRO","Farm labour • attendance • wages • payments",0,"home"))

        val hero=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            background=bg(Color.WHITE,18,1)
        }
        val heroLogo=ImageView(this).apply{
            setImageResource(com.majdoor.hisaab.R.drawable.majdoor_logo)
            scaleType=ImageView.ScaleType.CENTER_INSIDE
        }
        hero.addView(heroLogo,LinearLayout.LayoutParams(dp(62),dp(62)).apply{marginEnd=dp(12)})
        val heroText=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        heroText.addView(tv("Today",12f,C.MUTED,true))
        heroText.addView(tv(displayDf.format(parseDate(today())),20f,C.GREEN_DARK,true))
        heroText.addView(tv("Keep your labour records simple and accurate.",11.5f,C.MUTED).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        hero.addView(heroText,LinearLayout.LayoutParams(0,-2,1f))
        content.addView(hero); gap(12)

        val activeWorkers=count("workers","active=1")
        val activeFields=count("fields","active=1")
        val todayTeam=scalar("SELECT COUNT(DISTINCT worker_id) FROM team_members WHERE date=?",arrayOf(today()))
        val todayFull=scalar("SELECT COALESCE(SUM(CASE WHEN days=1 THEN 1 ELSE 0 END),0) FROM work_entries WHERE date=?",arrayOf(today()))
        val todayHalf=scalar("SELECT COALESCE(SUM(CASE WHEN days=0.5 THEN 1 ELSE 0 END),0) FROM work_entries WHERE date=?",arrayOf(today()))
        val todayWage=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date=?",arrayOf(today()))
        val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries")
        val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments")
        val balance=earned-paid

        val r1=LinearLayout(this)
        addRow(r1,stat("Today's Team",todayTeam.toInt().toString(),C.BLUE,C.BLUE_SOFT),1f,7)
        addRow(r1,stat("Full Days",todayFull.toInt().toString(),C.GREEN,C.GREEN_SOFT))
        content.addView(r1);gap(8)
        val r2=LinearLayout(this)
        addRow(r2,stat("Half Days",todayHalf.toInt().toString(),C.ORANGE,C.ORANGE_SOFT),1f,7)
        addRow(r2,stat("Today's Wages",money(todayWage),C.RED,C.RED_SOFT))
        content.addView(r2);gap(8)
        val r3=LinearLayout(this)
        addRow(r3,stat("Active Workers",activeWorkers.toString(),C.PURPLE,C.PURPLE_SOFT),1f,7)
        addRow(r3,stat("Active Fields",activeFields.toString(),C.GREEN,C.GREEN_SOFT))
        content.addView(r3);gap(8)
        content.addView(stat("Total Balance",money(balance),if(balance>0)C.RED else C.GREEN,if(balance>0)C.RED_SOFT else C.GREEN_SOFT))
        gap(14)

        content.addView(section("Quick Actions"))
        content.addView(tv("Fast entry for today's farm work",11.5f,C.MUTED).apply{setPadding(0,0,0,dp(7))})
        content.addView(primary("＋  Mark Today's Attendance"){attendance()},LinearLayout.LayoutParams(-1,dp(52)))
        gap(8)
        val q1=LinearLayout(this)
        addRow(q1,outline("＋ Payment"){payments()},1f,7)
        addRow(q1,outline("＋ Worker"){workerDialog(null)},1f)
        content.addView(q1);gap(8)
        val q2=LinearLayout(this)
        addRow(q2,outline("＋ Field / Crop"){fieldDialog(null)},1f,7)
        addRow(q2,outline("📊 Reports"){reports()},1f)
        content.addView(q2);gap(16)

        content.addView(section("Today's Work"))
        content.addView(tv("Tap a field to open today's team and attendance.",11.5f,C.MUTED).apply{setPadding(0,0,0,dp(8))})
        db.readableDatabase.rawQuery(
            "SELECT f.name,COUNT(DISTINCT tm.worker_id),COALESCE(SUM(w.days*w.rate),0) FROM team_members tm JOIN fields f ON f.id=tm.field_id LEFT JOIN work_entries w ON w.date=tm.date AND w.worker_id=tm.worker_id AND w.field_id=tm.field_id WHERE tm.date=? GROUP BY f.id,f.name ORDER BY f.name",
            arrayOf(today())
        ).use{c->
            if(!c.moveToFirst()){
                content.addView(tv("No attendance has been recorded today.\nTap “Mark Today's Attendance” to get started.",13f,C.MUTED).apply{
                    setPadding(dp(15),dp(20),dp(15),dp(20));background=bg(Color.WHITE,15,1)
                })
            }else do{
                val row=LinearLayout(this).apply{
                    orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
                    setPadding(dp(14),dp(12),dp(14),dp(12));background=bg(Color.WHITE,15,1)
                }
                row.addView(tv("🌾  ${c.getString(0)}\n${c.getInt(1)} workers in team",14f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
                row.addView(tv(money(c.getDouble(2))+"  ›",14f,C.GREEN,true))
                row.setOnClickListener{attendance(c.getString(0))}
                content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
            }while(c.moveToNext())
        }
    }

    private fun attendance(preselectField: String? = null) {
        setContentView(page("✓ Today's Attendance", "Today's team • Full / Half / None", 1, "attendance"))
        val dateButton = outline("📅  ${displayDf.format(parseDate(selectedDate))}") { pickDate(selectedDate) { selectedDate = it; attendance(preselectField) } }
        content.addView(dateButton, LinearLayout.LayoutParams(-1, dp(46))); gap(8)
        val fields = mutableListOf<Pair<Long,String>>(); db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name", null).use { c -> while(c.moveToNext()) fields.add(c.getLong(0) to c.getString(1)) }
        if (fields.isEmpty()) { content.addView(tv("Add a field or crop first.", 14f, C.MUTED).apply { setPadding(dp(12),dp(20),dp(12),dp(20)) }); return }
        content.addView(label("1. Select Field / Crop"))
        val spinner = Spinner(this); spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fields.map { it.second }); preselectField?.let { i -> fields.indexOfFirst { it.second == i }.takeIf { it >= 0 }?.let(spinner::setSelection) }; spinner.visibility = View.GONE
        val fieldStrip=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false}
        val fieldCards=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fields.forEachIndexed{index,f->
            val name=f.second
            val lower=name.lowercase(Locale.getDefault())
            val icon=when{ lower.contains("rice")||lower.contains("paddy") -> "🌾"; lower.contains("banana") -> "🍌"; lower.contains("sugar")||lower.contains("cane") -> "🌱"; else -> "🌿" }
            val card=TextView(this).apply{
                text="$icon\n$name";textSize=13f;gravity=Gravity.CENTER;maxLines=2;ellipsize=TextUtils.TruncateAt.END;setTextColor(C.TEXT);setPadding(dp(10),dp(10),dp(10),dp(10));minWidth=dp(92)
                background=bg(if(index==spinner.selectedItemPosition)C.GREEN_SOFT else Color.WHITE,14,1,if(index==spinner.selectedItemPosition)C.GREEN else C.BORDER)
                setOnClickListener{spinner.setSelection(index)}
            }
            fieldCards.addView(card,LinearLayout.LayoutParams(dp(110),dp(78)).apply{marginEnd=dp(7)})
        }
        fieldStrip.addView(fieldCards);content.addView(fieldStrip,LinearLayout.LayoutParams(-1,dp(82)));content.addView(spinner,LinearLayout.LayoutParams(1,1)); gap(8)
        content.addView(label("2. Today's Team"))
        val teamActions = LinearLayout(this); addRow(teamActions, primary("＋ Select Workers") { selectTeam(fields[spinner.selectedItemPosition].first, selectedDate) }, 1f, 7); addRow(teamActions, outline("↶ Previous Team") { loadPreviousTeam(spinner, fields) }); content.addView(teamActions); gap(8)
        val tools = LinearLayout(this); addRow(tools, outline("All Full") { setAllAttendance(1.0) }, 1f, 5); addRow(tools, outline("All Half") { setAllAttendance(0.5) }, 1f, 5); addRow(tools, outline("Clear All") { setAllAttendance(0.0) }); content.addView(tools); gap(10)
        val rowsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(rowsBox)
        fun render() {
            rowsBox.removeAllViews(); val fieldId = fields[spinner.selectedItemPosition].first
            val team = selectedWorkersFor(fieldId, selectedDate)
            if (team.isEmpty()) { rowsBox.addView(tv("Today's workers will appear here.\nTap “Select Workers” or “Previous Team”.", 13f, C.MUTED).apply { setPadding(dp(15),dp(22),dp(15),dp(22)); background=bg(Color.WHITE,14,1) }); return }
            team.forEach { w -> rowsBox.addView(attendanceRow(w.first,w.second,w.third,fieldId,selectedDate), LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)}) }
            val total = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date=? AND field_id=?", arrayOf(selectedDate,fieldId.toString()))
            rowsBox.addView(stat("Today's Total Wages", money(total), C.GREEN, C.GREEN_SOFT))
            rowsBox.addView(primary("✓  Done") { toast("Today's team and attendance are saved"); home() }, LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(10)})
        }
        fun reload() = render()
        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener { override fun onNothingSelected(p:AdapterView<*>?){}; override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){
            for(i in 0 until fieldCards.childCount){(fieldCards.getChildAt(i) as? TextView)?.background=bg(if(i==pos)C.GREEN_SOFT else Color.WHITE,14,1,if(i==pos)C.GREEN else C.BORDER)}
            render()
        } }
        render()
    }

    private fun selectedWorkersFor(fieldId: Long, date: String): List<Triple<Long,String,Double>> {
        val result = mutableListOf<Triple<Long,String,Double>>()
        db.readableDatabase.rawQuery("SELECT w.id,w.name,w.rate FROM team_members tm JOIN workers w ON w.id=tm.worker_id WHERE tm.field_id=? AND tm.date=? ORDER BY w.name", arrayOf(fieldId.toString(),date)).use { c -> while(c.moveToNext()) result.add(Triple(c.getLong(0),c.getString(1),c.getDouble(2))) }
        return result
    }

    private fun allActiveWorkers(): List<Triple<Long,String,Double>> {
        val r=mutableListOf<Triple<Long,String,Double>>(); db.readableDatabase.rawQuery("SELECT id,name,rate FROM workers WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())r.add(Triple(c.getLong(0),c.getString(1),c.getDouble(2)))}; return r
    }

    private fun attendanceRow(id:Long,name:String,rate:Double,fieldId:Long,date:String):LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=bg(Color.WHITE,14,1)}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; top.addView(tv(name,15f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f)); top.addView(tv(money(rate)+" / day",12f,C.MUTED)); root.addView(top); root.addView(tv("Attendance",11f,C.MUTED).apply{setPadding(0,dp(6),0,dp(5))})
        val buttons=LinearLayout(this); val state=currentDays(date,fieldId,id)
        val full=attendanceChoice("Full",C.GREEN,C.GREEN_SOFT,state==1.0){setAttendance(date,fieldId,id,1.0)}; val half=attendanceChoice("Half",C.ORANGE,C.ORANGE_SOFT,state==0.5){setAttendance(date,fieldId,id,0.5)}; val none=attendanceChoice("None",C.MUTED,0xFFF2F4F3.toInt(),state==0.0){setAttendance(date,fieldId,id,0.0)}
        buttons.addView(full,LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(5)});buttons.addView(half,LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(5)});buttons.addView(none,LinearLayout.LayoutParams(0,dp(44),1f));root.addView(buttons);return root
    }

    private fun attendanceChoice(text:String,color:Int,soft:Int,selected:Boolean,action:()->Unit)=TextView(this).apply{this.text=if(selected)"✓ $text" else text;textSize=13f;gravity=Gravity.CENTER;setTextColor(if(selected)color else C.TEXT);background = bg(if (selected) soft else Color.WHITE, 11, 1, color);setOnClickListener{action()}}

    private fun currentDays(date:String,fieldId:Long,workerId:Long):Double=scalar("SELECT COALESCE(MAX(days),0) FROM work_entries WHERE date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))

    private fun setAttendance(date:String,fieldId:Long,workerId:Long,value:Double){
        val d=db.writableDatabase
        d.beginTransaction()
        try{
            d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,workerId))
            d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))
            if(value>0){val rate=scalar("SELECT rate FROM workers WHERE id=?",arrayOf(workerId.toString()));d.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) VALUES(?,?,?,?,?)",arrayOf(date,workerId,fieldId,value,rate))}
            d.setTransactionSuccessful()
        }finally{d.endTransaction()}
        attendance(fieldName(fieldId))
    }

    private fun fieldName(fieldId:Long):String = db.readableDatabase.rawQuery("SELECT name FROM fields WHERE id=?",arrayOf(fieldId.toString())).use { if(it.moveToFirst()) it.getString(0) else "" }

    private fun setAllAttendance(value:Double){
        val root=(findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0) ?: return
        val scroll=root.findViewById<ScrollView>(android.R.id.content) ?: root
        // The active field is recovered from the visible Spinner.
        val spinner=findSpinner(root) ?: return
        val fields=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())fields.add(c.getLong(0) to c.getString(1))}
        if(fields.isEmpty())return
        val fieldId=fields[spinner.selectedItemPosition].first
        val team=selectedWorkersFor(fieldId,selectedDate)
        if(team.isEmpty()){toast("Select workers first");return}
        val d=db.writableDatabase;d.beginTransaction();try{team.forEach{setAttendanceDirect(d,selectedDate,fieldId,it.first,value,it.third)};d.setTransactionSuccessful()}finally{d.endTransaction()};attendance(fieldName(fieldId))
    }

    private fun findSpinner(v:View):Spinner?{if(v is Spinner)return v;if(v is ViewGroup)for(i in 0 until v.childCount)findSpinner(v.getChildAt(i))?.let{return it};return null}

    private fun setAttendanceDirect(d:SQLiteDatabase,date:String,fieldId:Long,workerId:Long,value:Double,rate:Double){
        d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,workerId))
        d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))
        if(value>0)d.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) VALUES(?,?,?,?,?)",arrayOf(date,workerId,fieldId,value,rate))
    }

    private fun selectTeam(fieldId:Long,date:String){
        val workers=allActiveWorkers()
        if(workers.isEmpty()){toast("Add a worker first");return}
        val selected=selectedWorkersFor(fieldId,date).map{it.first}.toMutableSet()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)}
        val search=input("Search worker name or ID")
        box.addView(search,LinearLayout.LayoutParams(-1,dp(48)))
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,dp(360)))
        fun render(q:String){
            list.removeAllViews()
            val query=q.trim().lowercase(Locale.getDefault())
            workers.forEach{w->
                val code=workerCode(w.first)
                if(query.isNotEmpty() && !w.second.lowercase(Locale.getDefault()).contains(query) && !code.lowercase(Locale.getDefault()).contains(query)) return@forEach
                val cb=CheckBox(this).apply{
                    text="${w.second}  •  ${money(w.third)}/day"
                    textSize=14f;setTextColor(C.TEXT);isChecked=selected.contains(w.first)
                    setPadding(dp(4),dp(4),dp(4),dp(4))
                    setOnCheckedChangeListener{_,checked->if(checked)selected.add(w.first)else selected.remove(w.first)}
                }
                list.addView(cb,LinearLayout.LayoutParams(-1,dp(52)))
            }
        }
        search.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}
            override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render(s?.toString()?:"")}
            override fun afterTextChanged(s:Editable?){}
        })
        render("")
        AlertDialog.Builder(this).setTitle("Select Today's Team").setView(box)
            .setPositiveButton("Save Team"){_,_->
                val d=db.writableDatabase;d.beginTransaction()
                try{
                    val previousIds = mutableListOf<Long>()
                    d.rawQuery("SELECT worker_id FROM team_members WHERE date=? AND field_id=?",arrayOf(date,fieldId.toString())).use { c ->
                        while(c.moveToNext()) previousIds.add(c.getLong(0))
                    }
                    previousIds.filterNot { selected.contains(it) }.forEach { wid ->
                        d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),wid.toString()))
                    }
                    d.delete("team_members","date=? AND field_id=?",arrayOf(date,fieldId.toString()))
                    selected.forEach{wid->d.execSQL("INSERT INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,wid))}
                    d.setTransactionSuccessful()
                }finally{d.endTransaction()}
                attendance(fieldName(fieldId))
            }.setNegativeButton("Cancel",null).show()
    }

    private fun workerCode(id:Long):String=
        db.readableDatabase.rawQuery("SELECT code FROM workers WHERE id=?",arrayOf(id.toString())).use{
            if(it.moveToFirst())it.getString(0) else ""
        }

    private fun loadPreviousTeam(spinner:Spinner,fields:List<Pair<Long,String>>){
        val fieldId=fields[spinner.selectedItemPosition].first
        val prev=db.readableDatabase.rawQuery("SELECT worker_id FROM team_members WHERE field_id=? AND date=(SELECT MAX(date) FROM team_members WHERE field_id=? AND date<?) GROUP BY worker_id",arrayOf(fieldId.toString(),fieldId.toString(),selectedDate))
        val ids=mutableListOf<Long>(); prev.use{c->while(c.moveToNext())ids.add(c.getLong(0))}
        if(ids.isEmpty()){toast("No previous team found");return}
        val d=db.writableDatabase; d.beginTransaction()
        try {
            d.delete("team_members","date=? AND field_id=?",arrayOf(selectedDate,fieldId.toString()))
            ids.forEach{wid->d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(selectedDate,fieldId,wid))}
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        attendance(fieldName(fieldId))
    }

    private fun workers(){
        setContentView(page("👷 Worker", "Workers, rates, earnings and balance", 2, "workers"))
        val add=LinearLayout(this);addRow(add,primary("＋ New Worker"){workerDialog(null)},1f,7);addRow(add,outline("💵 Payment"){payments()});content.addView(add);gap(9)
        val search=input("🔎 Search name or L-001");content.addView(search,LinearLayout.LayoutParams(-1,dp(48)));gap(9)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(list)
        fun render(q:String){list.removeAllViews();val like=q.trim().lowercase(Locale.getDefault());db.readableDatabase.rawQuery("SELECT id,code,name,rate,active FROM workers ORDER BY active DESC,name",null).use{c->var any=false;while(c.moveToNext()){val code=c.getString(1);val name=c.getString(2);if(like.isNotEmpty()&&!code.lowercase(Locale.getDefault()).contains(like)&&!name.lowercase(Locale.getDefault()).contains(like))continue;any=true;val id=c.getLong(0);val rate=c.getDouble(3);val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?",arrayOf(id.toString()));val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?",arrayOf(id.toString()));val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(12),dp(13),dp(11));background=bg(Color.WHITE,15,1)};val h=LinearLayout(this);h.addView(tv("$code  $name",16f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f));h.addView(tv(money(rate)+"/day",13f,C.GREEN,true));row.addView(h);row.addView(tv("Earned ${money(earned)}  •  Balance ${money(earned-paid)}",12f,if(earned-paid>0) C.RED else C.MUTED).apply{setPadding(0,dp(6),0,dp(8))});val a=LinearLayout(this);addRow(a,outline("View"){workerDetail(id)},1f,5);addRow(a,outline("Edit"){workerDialog(id)},1f,5);addRow(a,outline(if(c.getInt(4)==1) "Inactive" else "Active"){toggleWorker(id,c.getInt(4)==1)},1f);row.addView(a);list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})};if(!any)list.addView(tv("No workers found.",14f,C.MUTED).apply{setPadding(dp(14),dp(20),dp(14),dp(20))})}}
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render(s?.toString() ?: "")};override fun afterTextChanged(s:Editable?){}});render("")
    }

    private fun workerDialog(id:Long?){
        val old=if(id==null)null else db.readableDatabase.rawQuery("SELECT name,rate FROM workers WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())c.getString(0) to c.getDouble(1) else null};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(5),0,dp(5),0)};val name=input("Worker Name",old?.first ?: "");val rate=input("Daily Wage ₹",old?.second?.toString() ?: "");rate.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;box.addView(name,LinearLayout.LayoutParams(-1,dp(50)));box.addView(rate,LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(8)});AlertDialog.Builder(this).setTitle(if(id==null) "New Worker" else "Edit Worker").setView(box).setPositiveButton("Save"){_,_->val n=name.text.toString().trim();val r=rate.text.toString().replace(",",".").toDoubleOrNull();if(n.isBlank()||r==null||r<0){toast("Enter a name and valid daily wage");return@setPositiveButton};try{val d=db.writableDatabase;if(id==null){d.beginTransaction();try{val next=scalar("SELECT COALESCE(MAX(CAST(SUBSTR(code,3) AS INTEGER)),0)+1 FROM workers WHERE code LIKE 'L-%'").toInt();d.execSQL("INSERT INTO workers(code,name,rate,active) VALUES(?,?,?,1)",arrayOf("L-%03d".format(Locale.US,next),n,r));d.setTransactionSuccessful()}finally{d.endTransaction()}}else d.execSQL("UPDATE workers SET name=?,rate=? WHERE id=?",arrayOf(n,r,id));workers()}catch(e:Exception){toast("Could not save: ${e.message}")}}.setNegativeButton("Cancel",null).show()
    }

    private fun toggleWorker(id:Long,deactivate:Boolean){db.writableDatabase.execSQL("UPDATE workers SET active=? WHERE id=?",arrayOf(if(deactivate)0 else 1,id));workers()}

    private fun workerDetail(id:Long){
        val info = db.readableDatabase.rawQuery(
            "SELECT code,name,rate,active FROM workers WHERE id=?", arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) arrayOf(c.getString(0), c.getString(1), c.getDouble(2), c.getInt(3)) else null
        }
        if (info == null) { workers(); return }

        val code = info[0] as String
        val name = info[1] as String
        val rate = info[2] as Double
        setContentView(page("👷 $name", "$code  •  ${money(rate)}/day", 2, "worker:$id"))

        val earned = scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?", arrayOf(id.toString()))
        val paid = scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?", arrayOf(id.toString()))
        val totalDays = scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE worker_id=?", arrayOf(id.toString()))
        val r = LinearLayout(this)
        addRow(r, stat("Total Days", days(totalDays), C.GREEN, C.GREEN_SOFT), 1f, 6)
        addRow(r, stat("Total Earned", money(earned), C.BLUE, C.BLUE_SOFT), 1f, 6)
        addRow(r, stat("Balance", money(earned-paid), if (earned-paid > 0) C.RED else C.GREEN, if (earned-paid > 0) C.RED_SOFT else C.GREEN_SOFT))
        content.addView(r)
        gap(12)
        content.addView(primary("＋ Record Payment") { paymentDialog(null, id) })
        gap(13)
        content.addView(section("Work History"))

        db.readableDatabase.rawQuery(
            "SELECT w.date,f.name,w.days,w.rate FROM work_entries w JOIN fields f ON f.id=w.field_id WHERE w.worker_id=? ORDER BY w.date DESC,w.id DESC",
            arrayOf(id.toString())
        ).use { c ->
            if (!c.moveToFirst()) {
                content.addView(tv("No work entries yet.", 13f, C.MUTED))
            } else {
                do {
                    val status = if (c.getDouble(2) == 1.0) "Full Days" else "Half Days"
                    val text = "${displayDf.format(parseDate(c.getString(0)))}  •  ${c.getString(1)}\n$status  •  ${money(c.getDouble(2) * c.getDouble(3))}"
                    content.addView(tv(text, 13f, C.TEXT).apply {
                        setPadding(dp(13), dp(10), dp(13), dp(10))
                        background = bg(Color.WHITE, 12, 1)
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
                } while (c.moveToNext())
            }
        }

        gap(9)
        content.addView(section("Payment history"))
        db.readableDatabase.rawQuery(
            "SELECT date,amount,note FROM payments WHERE worker_id=? ORDER BY date DESC,id DESC", arrayOf(id.toString())
        ).use { c ->
            if (!c.moveToFirst()) {
                content.addView(tv("No payments yet.", 13f, C.MUTED))
            } else {
                do {
                    val text = "${displayDf.format(parseDate(c.getString(0)))}  •  ${money(c.getDouble(1))}\n${c.getString(2)}"
                    content.addView(tv(text, 13f, C.TEXT).apply {
                        setPadding(dp(13), dp(10), dp(13), dp(10))
                        background = bg(Color.WHITE, 12, 1)
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
                } while (c.moveToNext())
            }
        }
    }

    private fun fields(){
        setContentView(page("🌾 Fields / Crops","Track wages and work separately by field",3,"fields"));content.addView(primary("＋ New Field / Crop") {fieldDialog(null)},LinearLayout.LayoutParams(-1,dp(50)));gap(9);val search=input("🔎 Search fields / crops");content.addView(search,LinearLayout.LayoutParams(-1,dp(48)));gap(9);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(list)
        fun render(q:String){list.removeAllViews();val like=q.trim().lowercase(Locale.getDefault());db.readableDatabase.rawQuery("SELECT id,name,active FROM fields ORDER BY active DESC,name",null).use{c->var any=false;while(c.moveToNext()){if(like.isNotEmpty()&&!c.getString(1).lowercase(Locale.getDefault()).contains(like))continue;any=true;val id=c.getLong(0);val total=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(12),dp(13),dp(11));background=bg(Color.WHITE,15,1)};row.addView(tv("🌾 ${c.getString(1)}",16f,C.TEXT,true));row.addView(tv("Wages ${money(total)}",12f,C.MUTED).apply{setPadding(0,dp(5),0,dp(8))});val a=LinearLayout(this);addRow(a,outline("View"){fieldDetail(id)},1f,5);addRow(a,outline("Edit"){fieldDialog(id)},1f,5);addRow(a,outline(if(c.getInt(2)==1) "Inactive" else "Active"){toggleField(id,c.getInt(2)==1)},1f);row.addView(a);list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})};if(!any)list.addView(tv("No fields found.",14f,C.MUTED))}}
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render(s?.toString() ?: "")};override fun afterTextChanged(s:Editable?){}});render("")
    }

    private fun fieldDialog(id:Long?){val old=if(id==null)""else db.readableDatabase.rawQuery("SELECT name FROM fields WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())c.getString(0)else""};val e=input("Field / crop name",old);AlertDialog.Builder(this).setTitle(if(id==null) "New Field / Crop" else "Edit Field").setView(e).setPositiveButton("Save"){_,_->val n=e.text.toString().trim();if(n.isBlank()){toast("Enter a name");return@setPositiveButton};try{if(id==null)db.writableDatabase.execSQL("INSERT INTO fields(name,active) VALUES(?,1)",arrayOf(n))else db.writableDatabase.execSQL("UPDATE fields SET name=? WHERE id=?",arrayOf(n,id));fields()}catch(e:Exception){toast("Could not save: ${e.message}")}}.setNegativeButton("Cancel",null).show()}
    private fun toggleField(id:Long,deactivate:Boolean){db.writableDatabase.execSQL("UPDATE fields SET active=? WHERE id=?",arrayOf(if(deactivate)0 else 1,id));fields()}
    private fun fieldDetail(id:Long){val name=db.readableDatabase.rawQuery("SELECT name FROM fields WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())c.getString(0)else""};setContentView(page("🌾 $name","Complete field wage history",3,"field:$id"));val total=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val td=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val r=LinearLayout(this);addRow(r,stat("Total Days",days(td),C.GREEN,C.GREEN_SOFT),1f,6);addRow(r,stat("Total Cost",money(total),C.BLUE,C.BLUE_SOFT));content.addView(r);gap(12);content.addView(section("Work History"));db.readableDatabase.rawQuery("SELECT w.date,COUNT(DISTINCT w.worker_id),SUM(w.days*w.rate) FROM work_entries w WHERE w.field_id=? GROUP BY w.date ORDER BY w.date DESC",arrayOf(id.toString())).use{c->if(!c.moveToFirst())content.addView(tv("No work recorded yet.",13f,C.MUTED))else do{content.addView(tv("${displayDf.format(parseDate(c.getString(0)))}  •  ${c.getInt(1)} Worker\n${money(c.getDouble(2))}",13f,C.TEXT).apply{setPadding(dp(13),dp(10),dp(13),dp(10));background=bg(Color.WHITE,12,1)},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})}while(c.moveToNext())}}

    private fun payments(){
        setContentView(page("💵 Payments","Advances, wage payments and balance",0,"payments"));content.addView(primary("＋ Record Payment"){paymentDialog(null,null)},LinearLayout.LayoutParams(-1,dp(50)));gap(9);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(box);val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries");val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments");val r=LinearLayout(this);addRow(r,stat("Total Earned",money(earned),C.GREEN,C.GREEN_SOFT),1f,6);addRow(r,stat("Total Payments",money(paid),C.BLUE,C.BLUE_SOFT),1f,6);addRow(r,stat("Total Balance",money(earned-paid),C.RED,C.RED_SOFT));box.addView(r);gap(12);content.addView(section("Payment ledger"));db.readableDatabase.rawQuery("SELECT p.id,p.date,w.name,p.amount,p.note FROM payments p JOIN workers w ON w.id=p.worker_id ORDER BY p.date DESC,p.id DESC",null).use{c->if(!c.moveToFirst())content.addView(tv("No payments yet.",13f,C.MUTED))else do{val id=c.getLong(0);val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(10),dp(13),dp(10));background=bg(Color.WHITE,12,1)};val h=LinearLayout(this);h.addView(tv("${c.getString(2)}  •  ${displayDf.format(parseDate(c.getString(1)))}",14f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f));h.addView(tv(money(c.getDouble(3)),14f,C.GREEN,true));row.addView(h);if(c.getString(4).isNotBlank())row.addView(tv(c.getString(4),12f,C.MUTED).apply{setPadding(0,dp(5),0,0)});row.setOnLongClickListener{AlertDialog.Builder(this).setTitle("Payment").setItems(arrayOf("Edit","Delete")){_,which->if(which==0)paymentDialog(id,null)else confirmDeletePayment(id)}.show();true};content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})}while(c.moveToNext())}
    }

    private fun paymentDialog(editId:Long?, workerId:Long?){
        val workers=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM workers ORDER BY active DESC,name",null).use{c->while(c.moveToNext())workers.add(c.getLong(0) to c.getString(1))};if(workers.isEmpty()){toast("Add a worker first");return}
        var oldWorker=workerId;var oldDate=today();var oldAmount="";var oldNote="";if(editId!=null)db.readableDatabase.rawQuery("SELECT date,worker_id,amount,note FROM payments WHERE id=?",arrayOf(editId.toString())).use{c->if(c.moveToFirst()){oldDate=c.getString(0);oldWorker=c.getLong(1);oldAmount=c.getDouble(2).toString();oldNote=c.getString(3)}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(5),0,dp(5),0)};val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,workers.map{it.second});workers.indexOfFirst{it.first==oldWorker}.takeIf{it>=0}?.let(sp::setSelection);box.addView(label("Worker"));box.addView(sp,LinearLayout.LayoutParams(-1,dp(48)));var payDate=oldDate;var date: TextView?=null;date=outline("📅 ${displayDf.format(parseDate(payDate))}"){pickDate(payDate){payDate=it;date?.text="📅 ${displayDf.format(parseDate(payDate))}"}};box.addView(label("Date"));box.addView(date,LinearLayout.LayoutParams(-1,dp(44)));val amount=input("Amount ₹",oldAmount);amount.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;box.addView(label("Amount"));box.addView(amount,LinearLayout.LayoutParams(-1,dp(48)));val note=input("Note / Payment reason",oldNote);box.addView(label("Note"));box.addView(note,LinearLayout.LayoutParams(-1,dp(48)))
        AlertDialog.Builder(this).setTitle(if(editId==null) "Record Payment" else "Edit Payment").setView(box).setPositiveButton("Save"){_,_->val a=amount.text.toString().replace(",",".").toDoubleOrNull()?:0.0;if(a<=0){toast("Enter a valid amount");return@setPositiveButton};try{val wid=workers[sp.selectedItemPosition].first;if(editId==null)db.writableDatabase.execSQL("INSERT INTO payments(date,worker_id,amount,note) VALUES(?,?,?,?)",arrayOf(payDate,wid,a,note.text.toString().trim()))else db.writableDatabase.execSQL("UPDATE payments SET date=?,worker_id=?,amount=?,note=? WHERE id=?",arrayOf(payDate,wid,a,note.text.toString().trim(),editId));payments()}catch(e:Exception){toast("Could not save payment: ${e.message}")}}.setNegativeButton("Cancel",null).show()
    }
    private fun confirmDeletePayment(id:Long){AlertDialog.Builder(this).setTitle("Delete Payment?").setMessage("This payment record will be deleted.").setPositiveButton("Delete"){_,_->db.writableDatabase.execSQL("DELETE FROM payments WHERE id=?",arrayOf(id));payments()}.setNegativeButton("Cancel",null).show()}

    private fun reports(){
        setContentView(page("📊 Reports","Worker, Field, Date and Payment Reports",4,"reports"));val r=LinearLayout(this);addRow(r,primary("👷 Worker Reports"){workerReport()},1f,6);addRow(r,outline("🌾 Field Reports"){fieldReport()},1f);content.addView(r);gap(8);val r2=LinearLayout(this);addRow(r2,outline("💵 Payment Reports"){paymentReport()},1f,6);addRow(r2,outline("📅 Daily Report"){dailyReport()},1f);content.addView(r2);gap(14);content.addView(section("Date Range"));val dateRow=LinearLayout(this);addRow(dateRow,outline("${displayDf.format(parseDate(reportFrom))}"){pickDate(reportFrom){reportFrom=it;reports()}},1f,6);addRow(dateRow,outline("${displayDf.format(parseDate(reportTo))}"){pickDate(reportTo){reportTo=it;reports()}},1f);content.addView(dateRow);gap(10);val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo));val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo));val td=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo));val rr=LinearLayout(this);addRow(rr,stat("Total Days",days(td),C.GREEN,C.GREEN_SOFT),1f,6);addRow(rr,stat("Total Wages",money(earned),C.BLUE,C.BLUE_SOFT),1f,6);addRow(rr,stat("Total Payments",money(paid),C.PURPLE,C.PURPLE_SOFT));content.addView(rr);gap(8);content.addView(stat("Period Balance",money(earned-paid),if(earned-paid>0) C.RED else C.GREEN,if(earned-paid>0) C.RED_SOFT else C.GREEN_SOFT))
        gap(10); val ex=LinearLayout(this); addRow(ex,outline("📄 PDF Reports"){exportPdf()},1f,6); addRow(ex,outline("📤 Export CSV"){exportCsv()},1f); content.addView(ex); gap(8); val share=LinearLayout(this); addRow(share,outline("Share Summary"){shareReportSummary()},1f,6); addRow(share,outline("WhatsApp"){shareReportWhatsApp()},1f); content.addView(share)
    }

    private fun workerReport(){setContentView(page("👷 Worker Reports","${displayDf.format(parseDate(reportFrom))} — ${displayDf.format(parseDate(reportTo))}",4,"report:worker"));val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo));val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo));val rr=LinearLayout(this);addRow(rr,stat("Earned",money(earned),C.GREEN,C.GREEN_SOFT),1f,6);addRow(rr,stat("Total Payments",money(paid),C.BLUE,C.BLUE_SOFT),1f);content.addView(rr);gap(10);db.readableDatabase.rawQuery("SELECT id,code,name FROM workers ORDER BY name",null).use{c->if(!c.moveToFirst())content.addView(tv("No workers found.",13f,C.MUTED))else do{val id=c.getLong(0);val d=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE worker_id=? AND date BETWEEN ? AND ?",arrayOf(id.toString(),reportFrom,reportTo));val e=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=? AND date BETWEEN ? AND ?",arrayOf(id.toString(),reportFrom,reportTo));val p=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=? AND date BETWEEN ? AND ?",arrayOf(id.toString(),reportFrom,reportTo));val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(10),dp(13),dp(10));background=bg(Color.WHITE,13,1)};row.addView(tv("${c.getString(1)}  ${c.getString(2)}",15f,C.TEXT,true));row.addView(tv("${days(d)} Days  •  ${money(e)} Earned  •  ${money(p)} Payment  •  Balance ${money(e-p)}",12f,if(e-p>0) C.RED else C.GREEN));row.setOnClickListener{workerDetail(id)};content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})}while(c.moveToNext())}}

    private fun fieldReport(){setContentView(page("🌾 Field Reports","Wages by crop / field",4,"report:field"));db.readableDatabase.rawQuery("SELECT f.id,f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0),COUNT(DISTINCT w.worker_id) FROM fields f LEFT JOIN work_entries w ON w.field_id=f.id AND w.date BETWEEN ? AND ? GROUP BY f.id,f.name ORDER BY f.name",arrayOf(reportFrom,reportTo)).use{c->if(!c.moveToFirst())content.addView(tv("No field report available.",13f,C.MUTED))else do{val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(11),dp(13),dp(11));background=bg(Color.WHITE,14,1)};row.addView(tv("🌾 ${c.getString(1)}",15f,C.TEXT,true));row.addView(tv("${c.getInt(4)} ${if (c.getInt(4) == 1) "Worker" else "Workers"}  •  ${days(c.getDouble(2))} Days  •  ${money(c.getDouble(3))}",12f,C.MUTED));content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})}while(c.moveToNext())}}

    private fun paymentReport(){
        setContentView(page("💵 Payment Report","${displayDf.format(parseDate(reportFrom))} — ${displayDf.format(parseDate(reportTo))}",4,"report:payment"))
        val total=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        content.addView(stat("Total Payments",money(total),C.BLUE,C.BLUE_SOFT));gap(10)
        db.readableDatabase.rawQuery(
            "SELECT p.date,w.name,p.amount,p.note FROM payments p JOIN workers w ON w.id=p.worker_id WHERE p.date BETWEEN ? AND ? ORDER BY p.date DESC,p.id DESC",
            arrayOf(reportFrom,reportTo)
        ).use{c->
            if(!c.moveToFirst()){
                content.addView(tv("No payments found in this period.",13f,C.MUTED))
            }else do{
                val row=LinearLayout(this).apply{
                    orientation=LinearLayout.VERTICAL
                    setPadding(dp(13),dp(11),dp(13),dp(11))
                    background=bg(Color.WHITE,14,1)
                }
                val h=LinearLayout(this)
                h.addView(tv("${c.getString(1)}  •  ${displayDf.format(parseDate(c.getString(0)))}",14f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
                h.addView(tv(money(c.getDouble(2)),14f,C.GREEN,true))
                row.addView(h)
                if(c.getString(3).isNotBlank())row.addView(tv(c.getString(3),12f,C.MUTED).apply{setPadding(0,dp(5),0,0)})
                content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
            }while(c.moveToNext())
        }
    }

    private fun dailyReport(){setContentView(page("📅 Daily Report","Daily wages",4,"report:daily"));db.readableDatabase.rawQuery("SELECT date,COUNT(DISTINCT worker_id),SUM(days),SUM(days*rate) FROM work_entries WHERE date BETWEEN ? AND ? GROUP BY date ORDER BY date DESC",arrayOf(reportFrom,reportTo)).use{c->if(!c.moveToFirst())content.addView(tv("No work recorded in this period.",13f,C.MUTED))else do{content.addView(tv("${displayDf.format(parseDate(c.getString(0)))}\n${c.getInt(1)} ${if (c.getInt(1) == 1) "Worker" else "Workers"}  •  ${days(c.getDouble(2))} Days  •  ${money(c.getDouble(3))}",13f,C.TEXT).apply{setPadding(dp(13),dp(11),dp(13),dp(11));background=bg(Color.WHITE,13,1)},LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})}while(c.moveToNext())}}

    private fun exportCsv(){
        try{
            val sb=StringBuilder("Date,Worker,Field,Status,Rate,Wage\n")
            db.readableDatabase.rawQuery(
                """SELECT tm.date,wo.name,f.name,COALESCE(w.days,0),wo.rate,COALESCE(w.days*w.rate,0)
                   FROM team_members tm
                   JOIN workers wo ON wo.id=tm.worker_id
                   JOIN fields f ON f.id=tm.field_id
                   LEFT JOIN work_entries w ON w.date=tm.date AND w.worker_id=tm.worker_id AND w.field_id=tm.field_id
                   WHERE tm.date BETWEEN ? AND ? ORDER BY tm.date,wo.name""",
                arrayOf(reportFrom,reportTo)
            ).use{c->while(c.moveToNext()){
                val day=c.getDouble(3)
                val status=if(day==1.0)"Full" else if(day==0.5)"Half" else "None"
                sb.append(c.getString(0)).append(',').append(csv(c.getString(1))).append(',')
                    .append(csv(c.getString(2))).append(',').append(status).append(',')
                    .append(c.getDouble(4)).append(',').append(c.getDouble(5)).append('\n')
            }}
            pendingExport=sb.toString().toByteArray(Charsets.UTF_8)
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="text/csv";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_${reportFrom}_to_${reportTo}.csv");addCategory(Intent.CATEGORY_OPENABLE)}
            startActivityForResult(i,902)
        }catch(e:Exception){pendingExport=null;toast("CSV export failed: ${e.message}")}
    }
    private fun csv(v:String)="\""+v.replace("\"","\"\"")+"\""
    private fun exportPdf(){
        try{
            val pdf=android.graphics.pdf.PdfDocument()
            val bold=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.GREEN_DARK;textSize=18f;typeface=Typeface.DEFAULT_BOLD}
            val normal=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.TEXT;textSize=10.5f}
            val muted=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.MUTED;textSize=9.5f}
            val rows=mutableListOf<Array<String>>()
            db.readableDatabase.rawQuery(
                """SELECT tm.date,wo.name,f.name,COALESCE(w.days,0),COALESCE(w.days*w.rate,0)
                   FROM team_members tm JOIN workers wo ON wo.id=tm.worker_id JOIN fields f ON f.id=tm.field_id
                   LEFT JOIN work_entries w ON w.date=tm.date AND w.worker_id=tm.worker_id AND w.field_id=tm.field_id
                   WHERE tm.date BETWEEN ? AND ? ORDER BY tm.date,wo.name""",
                arrayOf(reportFrom,reportTo)
            ).use{c->while(c.moveToNext()){
                val day=c.getDouble(3)
                rows.add(arrayOf(c.getString(0),c.getString(1),c.getString(2),if(day==1.0)"Full" else if(day==0.5)"Half" else "None",money(c.getDouble(4))))
            }}
            var index=0;var pageNo=1
            while(index<rows.size || pageNo==1){
                val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create()
                val page=pdf.startPage(info);var y=42f
                page.canvas.drawText("Majdoor Hisaab PRO",30f,y,bold);y+=22f
                page.canvas.drawText("Labour Report  •  $reportFrom to $reportTo",30f,y,normal);y+=22f
                page.canvas.drawText("Date",30f,y,muted);page.canvas.drawText("Worker",95f,y,muted);page.canvas.drawText("Field",210f,y,muted)
                page.canvas.drawText("Status",390f,y,muted);page.canvas.drawText("Wage",465f,y,muted);y+=16f
                var countOnPage=0
                while(index<rows.size && countOnPage<36){
                    val r=rows[index]
                    page.canvas.drawText(r[0],30f,y,normal);page.canvas.drawText(r[1].take(18),95f,y,normal)
                    page.canvas.drawText(r[2].take(24),210f,y,normal);page.canvas.drawText(r[3],390f,y,normal);page.canvas.drawText(r[4],465f,y,normal)
                    y+=19f;index++;countOnPage++
                }
                if(rows.isEmpty())page.canvas.drawText("No records found for the selected period.",30f,y,normal)
                page.canvas.drawText("Page $pageNo",500f,820f,muted)
                pdf.finishPage(page);pageNo++
            }
            val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();pendingExport=out.toByteArray()
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/pdf";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_${reportFrom}_to_${reportTo}.pdf");addCategory(Intent.CATEGORY_OPENABLE)}
            startActivityForResult(i,902)
        }catch(e:Exception){pendingExport=null;toast("PDF export failed: ${e.message}")}
    }

    private fun shareReportSummary(){
        val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val td=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val text="""Majdoor Hisaab PRO
Labour Report
Period: $reportFrom to $reportTo
Total Days: ${days(td)}
Total Wages: ${money(earned)}
Total Paid: ${money(paid)}
Balance: ${money(earned-paid)}"""
        val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,"Majdoor Hisaab PRO Report");putExtra(Intent.EXTRA_TEXT,text)}
        startActivity(Intent.createChooser(i,"Share report"))
    }

    private fun shareReportWhatsApp(){
        val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val td=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        val text="""Majdoor Hisaab PRO
Labour Report
Period: $reportFrom to $reportTo
Total Days: ${days(td)}
Total Wages: ${money(earned)}
Total Paid: ${money(paid)}
Balance: ${money(earned-paid)}"""
        val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text);setPackage("com.whatsapp")}
        try{startActivity(i)}catch(_:Exception){toast("WhatsApp is not installed")}
    }

    private fun backup(){setContentView(page("💾 Backup / Restore","Local SQLite • Offline",0,"backup"));content.addView(card("Secure local data","Worker + Field + Attendance + Payment"));gap(10);content.addView(primary("⬇ Save Backup ZIP"){createBackup()},LinearLayout.LayoutParams(-1,dp(50)));gap(8);content.addView(outline("⬆ Restore from Backup ZIP"){pickRestore()},LinearLayout.LayoutParams(-1,dp(48)));gap(12);content.addView(tv("The backup contains your database and verification information. Restore validates integrity, app marker and schema before replacing current data.",13f,C.MUTED))}
    private fun createBackup(){try{val d=db.writableDatabase;d.execSQL("PRAGMA wal_checkpoint(TRUNCATE)");validateDatabase(d);val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/zip";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_Backup_${today()}.zip");addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,901)}catch(e:Exception){toast("Backup could not be created: ${e.message}")}}
    private fun pickRestore(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/zip","application/octet-stream"));addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,900)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;try{when(requestCode){901->{createZipBackup(data.data!!);toast("Backup ZIP saved successfully")}900->validateAndConfirmRestore(data.data!!);902->{pendingExport?.let{bytes->contentResolver.openOutputStream(data.data!!)?.use{it.write(bytes)}?:throw Exception("File could not be saved")};pendingExport=null;toast("Report saved successfully")} }}catch(e:Exception){pendingExport=null;toast("Export error: ${e.message}")}}
    private fun createZipBackup(uri:Uri){val f=getDatabasePath(DB_NAME);val d=db.writableDatabase;d.execSQL("PRAGMA wal_checkpoint(TRUNCATE)");validateDatabase(d);contentResolver.openOutputStream(uri)?.use{out->ZipOutputStream(out).use{z->z.putNextEntry(ZipEntry("majdoor_hisaab.db"));f.inputStream().use{it.copyTo(z)};z.closeEntry();z.putNextEntry(ZipEntry("backup_info.txt"));z.write(backupMetadata(d).toByteArray(Charsets.UTF_8));z.closeEntry()}}?:throw Exception("File could not be saved")}
    private fun backupMetadata(d:SQLiteDatabase):String{val integrity=d.rawQuery("PRAGMA integrity_check",null).use{if(it.moveToFirst())it.getString(0) else "unknown"};val foreignKeys=d.rawQuery("PRAGMA foreign_key_check",null).use{if(it.moveToFirst())"FAIL" else "PASS"};val marker=d.rawQuery("SELECT value FROM settings WHERE key='app_marker'",null).use{if(it.moveToFirst())it.getString(0) else ""};val schema=d.rawQuery("SELECT value FROM settings WHERE key='schema_version'",null).use{if(it.moveToFirst())it.getString(0) else ""};return "Majdoor Hisaab PRO\nApp Marker: $marker\nSchema Version: $schema\nSQLite user_version: ${d.version}\nIntegrity Check: $integrity\nForeign Key Check: $foreignKeys\nBackup Date: ${today()}\n"}
    private fun validateDatabase(d:SQLiteDatabase){d.rawQuery("PRAGMA integrity_check",null).use{if(!it.moveToFirst()||it.getString(0)!="ok")throw Exception("Database integrity check failed")};d.rawQuery("SELECT value FROM settings WHERE key='app_marker'",null).use{if(!it.moveToFirst()||it.getString(0)!=APP_MARKER)throw Exception("App database marker missing")};d.rawQuery("SELECT value FROM settings WHERE key='schema_version'",null).use{if(!it.moveToFirst()||it.getString(0).toIntOrNull()!=DB_VERSION)throw Exception("Database schema mismatch")};if(d.version!=DB_VERSION)throw Exception("SQLite user_version mismatch");d.rawQuery("PRAGMA foreign_key_check",null).use{if(it.moveToFirst())throw Exception("Foreign key error")}}
    private fun extractBackupDatabase(zipFile:File,destination:File){var found=false;zipFile.inputStream().use{inp->ZipInputStream(inp).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory&&e.name=="majdoor_hisaab.db"){destination.outputStream().use{out->z.copyTo(out)};found=true};z.closeEntry();e=z.nextEntry}}};if(!found||!destination.exists()||destination.length()==0L)throw Exception("Invalid backup")}
    private fun validateAndConfirmRestore(uri:Uri){val zip=File(cacheDir,"restore_check.zip");val tmp=File(cacheDir,"restore_check.db");try{contentResolver.openInputStream(uri)?.use{zip.outputStream().use{o->it.copyTo(o)}}?:throw Exception("Backup could not be read");extractBackupDatabase(zip,tmp);val t=SQLiteDatabase.openDatabase(tmp.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{validateDatabase(t)}finally{t.close()};AlertDialog.Builder(this).setTitle("Restore Backup?").setMessage("Backup is valid. Your current data will be replaced.").setPositiveButton("Restore"){_,_->restoreFrom(uri)}.setNegativeButton("Cancel",null).show()}catch(e:Exception){toast(e.message?:"Invalid backup")}finally{zip.delete();tmp.delete()}}
    private fun restoreFrom(uri:Uri){val zip=File(cacheDir,"restore_ready.zip");val tmp=File(cacheDir,"restore_ready.db");val target=getDatabasePath(DB_NAME);val old=File(target.absolutePath+".before_restore");try{contentResolver.openInputStream(uri)?.use{zip.outputStream().use{o->it.copyTo(o)}}?:throw Exception("Backup could not be read");extractBackupDatabase(zip,tmp);val t=SQLiteDatabase.openDatabase(tmp.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{validateDatabase(t)}finally{t.close()};db.close();if(target.exists())target.copyTo(old,true);tmp.copyTo(target,true);tmp.delete();zip.delete();db=DB(this);db.writableDatabase;validateDatabase(db.readableDatabase);old.delete();toast("Restore completed");home()}catch(e:Exception){tmp.delete();zip.delete();try{if(old.exists()){if(::db.isInitialized)db.close();old.copyTo(target,true);old.delete()}}catch(_:Exception){};db=DB(this);toast("Restore error: ${e.message}")}}

    private fun pickDate(current:String,done:(String)->Unit){val cal=Calendar.getInstance();try{cal.time=df.parse(current)?:Date()}catch(_:Exception){};DatePickerDialog(this,{_,y,m,d->val c=Calendar.getInstance();c.set(y,m,d);done(df.format(c.time))},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()}
