# मजदूर हिसाब v1.1
Offline Android labour accounting app.
Local SQLite; workers; fields; daily work; field-wise and worker-wise reports; payments; backup/restore; GitHub Actions release APK.
