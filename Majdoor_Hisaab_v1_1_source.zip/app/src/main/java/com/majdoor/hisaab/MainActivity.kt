package com.majdoor.hisaab

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.*
import android.net.Uri
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class DB(c:Context):SQLiteOpenHelper(c,"majdoor_hisaab.db",null,2){
 override fun onCreate(d:SQLiteDatabase){
  d.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,name TEXT,rate REAL,active INTEGER DEFAULT 1)")
  d.execSQL("CREATE TABLE fields(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,active INTEGER DEFAULT 1)")
  d.execSQL("CREATE TABLE work_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,worker_id INTEGER,field_id INTEGER,days REAL,rate REAL)")
  d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,worker_id INTEGER,amount REAL,note TEXT)")
  d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT)")
 }
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){}
}

class MainActivity:Activity(){
 lateinit var db:DB; lateinit var body:LinearLayout
 val today:String get()=SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
 fun root(title:String):LinearLayout{
  val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL
  val h=TextView(this);h.text=title;h.textSize=22f;h.setTextColor(0xffffffff.toInt());h.setPadding(20,25,10,25);h.setBackgroundColor(0xff2e7d32.toInt());r.addView(h)
  body=LinearLayout(this);body.orientation=LinearLayout.VERTICAL;body.setPadding(14,12,14,12);r.addView(body,LinearLayout.LayoutParams(-1,0,1f));return r
 }
 fun b(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
 fun onCreate(x:Bundle?){super.onCreate(x);db=DB(this);home()}
 fun home(){setContentView(root("मजदूर हिसाब"));body.addView(b("📅 आज का काम"){work()});body.addView(b("👷 मजदूर"){workers()});body.addView(b("🌾 खेत"){fields()});body.addView(b("📊 हिसाब"){reports()});body.addView(b("💵 भुगतान"){payments()});body.addView(b("💾 Backup / Restore"){backup()})}
 fun workers(){setContentView(root("👷 मजदूर"));body.addView(b("➕ मजदूर जोड़ें"){addWorker()})
  db.readableDatabase.rawQuery("SELECT id,code,name,rate FROM workers WHERE active=1 ORDER BY id",null).use{c->while(c.moveToNext()){
   val id=c.getLong(0);val tv=TextView(this);tv.text="${c.getString(1)}  ${c.getString(2)}  ₹${c.getDouble(3)}/दिन";tv.textSize=18f;tv.setPadding(5,10,5,10);body.addView(tv)
  }}
  body.addView(b("← वापस"){home()})
 }
 fun addWorker(){val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;val n=EditText(this);n.hint="नाम";val r=EditText(this);r.hint="दिहाड़ी ₹";r.inputType=2;l.addView(n);l.addView(r)
  AlertDialog.Builder(this).setTitle("मजदूर जोड़ें").setView(l).setPositiveButton("सेव"){_,_->val d=db.writableDatabase;val no=d.rawQuery("SELECT COUNT(*) FROM workers",null).use{it.moveToFirst();it.getInt(0)+1};d.execSQL("INSERT INTO workers(code,name,rate) VALUES(?,?,?)",arrayOf("L-%03d".format(no),n.text.toString(),r.text.toString().toDoubleOrNull()?:0.0));workers()}.setNegativeButton("रद्द",null).show()}
 fun fields(){setContentView(root("🌾 खेत"));body.addView(b("➕ खेत जोड़ें"){addField()});db.readableDatabase.rawQuery("SELECT name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())body.addView(TextView(this).apply{text="🌾 "+c.getString(0);textSize=18f;setPadding(5,10,5,10)})};body.addView(b("← वापस"){home()})}
 fun addField(){val e=EditText(this);e.hint="जैसे धान वाला खेत";AlertDialog.Builder(this).setTitle("खेत जोड़ें").setView(e).setPositiveButton("सेव"){_,_->db.writableDatabase.execSQL("INSERT OR IGNORE INTO fields(name) VALUES(?)",arrayOf(e.text.toString()));fields()}.setNegativeButton("रद्द",null).show()}
 fun work(){setContentView(root("📅 आज का काम  $today"))
  val f=Spinner(this);val fs=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())fs.add(c.getLong(0) to c.getString(1))}
  f.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,fs.map{it.second});body.addView(f)
  body.addView(b("✓ 全員 1 दिन"){ /* visual shortcut; individual values remain editable */ Toast.makeText(this,"नीचे सभी में 1 दिन भरें",Toast.LENGTH_SHORT).show()})
  db.readableDatabase.rawQuery("SELECT id,code,name,rate FROM workers WHERE active=1 ORDER BY id",null).use{c->while(c.moveToNext()){
   val id=c.getLong(0);val line=LinearLayout(this);line.orientation=LinearLayout.HORIZONTAL;val t=TextView(this);t.text="${c.getString(1)} ${c.getString(2)}";t.textSize=16f;line.addView(t,LinearLayout.LayoutParams(0,-2,1f))
   val d=EditText(this);d.hint="0/½/1";d.setText("1");d.inputType=2;line.addView(d,LinearLayout.LayoutParams(80,-2))
   line.addView(b("保存"){if(fs.isNotEmpty()){db.writableDatabase.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) VALUES(?,?,?,?,?)",arrayOf(today,id,fs[f.selectedItemPosition].first,d.text.toString().toDoubleOrNull()?:0.0,c.getDouble(3)));Toast.makeText(this,"सेव",Toast.LENGTH_SHORT).show()}})
   body.addView(line)
  }};body.addView(b("← वापस"){home()})
 }
 fun reports(){setContentView(root("📊 हिसाब"))
  body.addView(b("🌾 खेत के हिसाब"){fieldReport()});body.addView(b("👷 मजदूर के हिसाब"){workerReport()})
  val q=db.readableDatabase.rawQuery("SELECT f.name,SUM(w.days),SUM(w.days*w.rate) FROM work_entries w JOIN fields f ON f.id=w.field_id GROUP BY f.id ORDER BY f.name",null)
  while(q.moveToNext())body.addView(TextView(this).apply{text="${q.getString(0)} — ${q.getDouble(1)} दिहाड़ी — ₹${q.getDouble(2)}";textSize=17f;setPadding(5,9,5,9)});q.close()
  totalSummary();body.addView(b("← वापस"){home()})
 }
 fun totalSummary(){val q=db.readableDatabase.rawQuery("SELECT COALESCE(SUM(days*rate),0) FROM work_entries",null);q.moveToFirst();val earned=q.getDouble(0);q.close();val p=db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments",null);p.moveToFirst();val paid=p.getDouble(0);p.close();body.addView(TextView(this).apply{text="总工资 ₹$earned\n已支付 ₹$paid\n🔴 余额 ₹${earned-paid}";textSize=19f;setPadding(5,16,5,16)})}
 fun fieldReport(){setContentView(root("🌾 खेत का हिसाब"));val f=Spinner(this);val fs=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields ORDER BY name",null).use{c->while(c.moveToNext())fs.add(c.getLong(0) to c.getString(1))};f.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,fs.map{it.second});body.addView(f);body.addView(b("दिखाएं"){if(fs.isNotEmpty())showField(fs[f.selectedItemPosition].first,fs[f.selectedItemPosition].second)});body.addView(b("← वापस"){reports()})}
 fun showField(id:Long,name:String){val q=db.readableDatabase.rawQuery("SELECT w.date,wo.code,wo.name,w.days,w.rate FROM work_entries w JOIN workers wo ON wo.id=w.worker_id WHERE w.field_id=? ORDER BY w.date DESC",arrayOf(id.toString()));while(q.moveToNext())body.addView(TextView(this).apply{text="${q.getString(0)}  ${q.getString(1)} ${q.getString(2)} — ${q.getDouble(3)} दिन × ₹${q.getDouble(4)} = ₹${q.getDouble(3)*q.getDouble(4)}";textSize=16f;setPadding(4,7,4,7)});q.close()}
 fun workerReport(){setContentView(root("👷 मजदूर का हिसाब"));val q=db.readableDatabase.rawQuery("SELECT id,code,name FROM workers WHERE active=1 ORDER BY id",null);while(q.moveToNext()){val id=q.getLong(0);val x=db.readableDatabase.rawQuery("SELECT COALESCE(SUM(days),0),COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?",arrayOf(id.toString()));x.moveToFirst();val days=x.getDouble(0);val earned=x.getDouble(1);x.close();val p=db.readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?",arrayOf(id.toString()));p.moveToFirst();val paid=p.getDouble(0);p.close();body.addView(TextView(this).apply{text="${q.getString(1)} ${q.getString(2)}\n$days दिन | बने ₹$earned | दिए ₹$paid | 🔴 बाकी ₹${earned-paid}";textSize=17f;setPadding(5,10,5,10)})};q.close();body.addView(b("← वापस"){reports()})}
 fun payments(){setContentView(root("💵 भुगतान"));body.addView(b("➕ भुगतान दर्ज करें"){addPayment()});db.readableDatabase.rawQuery("SELECT p.date,w.code,w.name,p.amount FROM payments p JOIN workers w ON w.id=p.worker_id ORDER BY p.id DESC",null).use{c->while(c.moveToNext())body.addView(TextView(this).apply{text="${c.getString(0)}  ${c.getString(1)} ${c.getString(2)} — ₹${c.getDouble(3)}";textSize=17f;setPadding(5,8,5,8)})};body.addView(b("← वापस"){home()})}
 fun addPayment(){val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;val s=Spinner(this);val ids=mutableListOf<Long>();val names=mutableListOf<String>();db.readableDatabase.rawQuery("SELECT id,code,name FROM workers WHERE active=1",null).use{c->while(c.moveToNext()){ids.add(c.getLong(0));names.add("${c.getString(1)} ${c.getString(2)}")}};s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names);val a=EditText(this);a.hint="रकम ₹";a.inputType=2;l.addView(s);l.addView(a);AlertDialog.Builder(this).setTitle("नकद भुगतान").setView(l).setPositiveButton("सेव"){_,_->if(ids.isNotEmpty())db.writableDatabase.execSQL("INSERT INTO payments(date,worker_id,amount,note) VALUES(?,?,?,?)",arrayOf(today,ids[s.selectedItemPosition],a.text.toString().toDoubleOrNull()?:0.0,""))}.setNegativeButton("रद्द",null).show()}
 fun backup(){setContentView(root("💾 Backup / Restore"));body.addView(TextView(this).apply{text="डेटा फोन में SQLite में है। Backup से पूरा database सुरक्षित रहेगा.";textSize=17f})
  body.addView(b("💾 Backup बनाएं"){createBackup()});body.addView(b("♻️ Restore करें"){pickRestore()});body.addView(b("← वापस"){home()})}
 fun createBackup(){try{val src=getDatabasePath("majdoor_hisaab.db");val out=java.io.File(getExternalFilesDir(null),"Majdoor_Hisaab_Backup_${today}.db");src.inputStream().use{i->out.outputStream().use{o->i.copyTo(o)}};Toast.makeText(this,"Backup तैयार: ${out.name}",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"Backup error: ${e.message}",Toast.LENGTH_LONG).show()}}
 fun pickRestore(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT);i.type="application/octet-stream";i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,900)}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==900&&c==RESULT_OK&&d?.data!=null){try{db.close();contentResolver.openInputStream(d.data!!)?.use{inp->getDatabasePath("majdoor_hisaab.db").outputStream().use{out->inp.copyTo(out)}};db=DB(this);Toast.makeText(this,"Restore पूरा हुआ",Toast.LENGTH_LONG).show();home()}catch(e:Exception){Toast.makeText(this,"Restore error: ${e.message}",Toast.LENGTH_LONG).show()}}}
}