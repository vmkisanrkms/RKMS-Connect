package com.majdoor.hisaab

import android.app.*
import android.content.*
import android.database.sqlite.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.*
import android.text.InputType
import android.view.*
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private object C {
    const val GREEN = 0xFF087A3D.toInt()
    const val GREEN_DARK = 0xFF04572C.toInt()
    const val GREEN_SOFT = 0xFFE8F6EE.toInt()
    const val BLUE = 0xFF1677D2.toInt()
    const val BLUE_SOFT = 0xFFEAF3FF.toInt()
    const val ORANGE = 0xFFF59E0B.toInt()
    const val ORANGE_SOFT = 0xFFFFF5DB.toInt()
    const val RED = 0xFFDC3545.toInt()
    const val RED_SOFT = 0xFFFFECEE.toInt()
    const val PURPLE = 0xFF7C4DFF.toInt()
    const val PURPLE_SOFT = 0xFFF1ECFF.toInt()
    const val TEXT = 0xFF18231D.toInt()
    const val MUTED = 0xFF66736C.toInt()
    const val BG = 0xFFF4F7F5.toInt()
    const val WHITE = Color.WHITE
    const val BORDER = 0xFFE0E7E2.toInt()
}

private const val DB_VERSION = 9
private const val DB_NAME = "majdoor_hisaab.db"
private const val APP_MARKER = "MAJDOOR_HISAAB_LOCAL_SQLITE_V9"

class DB(c: Context) : SQLiteOpenHelper(c, DB_NAME, null, DB_VERSION) {
    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE workers(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE NOT NULL,name TEXT NOT NULL,rate REAL NOT NULL CHECK(rate>=0),active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),photo_uri TEXT NOT NULL DEFAULT '')")
        d.execSQL("CREATE TABLE fields(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,crop_type TEXT NOT NULL DEFAULT 'Paddy',active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),photo_uri TEXT NOT NULL DEFAULT '')")
        d.execSQL("CREATE TABLE work_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER REFERENCES fields(id) ON UPDATE CASCADE ON DELETE SET NULL,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
        d.execSQL("CREATE TABLE team_members(date TEXT NOT NULL,field_id INTEGER NOT NULL REFERENCES fields(id) ON DELETE CASCADE,worker_id INTEGER NOT NULL REFERENCES workers(id) ON DELETE RESTRICT,PRIMARY KEY(date,field_id,worker_id))")
        createIndexes(d)
        setMetadata(d)
    }

    private fun createIndexes(d: SQLiteDatabase) {
        d.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS ux_work_date_worker_field ON work_entries(date,worker_id,field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_worker ON work_entries(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_field ON work_entries(field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_work_date ON work_entries(date)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_worker ON payments(worker_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_date ON payments(date)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_team_date_field ON team_members(date,field_id)")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_team_worker ON team_members(worker_id)")
    }

    private fun setMetadata(d: SQLiteDatabase) {
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('app_marker',?)", arrayOf(APP_MARKER))
        d.execSQL("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version',?)", arrayOf(DB_VERSION.toString()))
        d.execSQL("PRAGMA user_version=$DB_VERSION")
    }

    override fun onUpgrade(d: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        d.beginTransaction()
        try {
            if (oldVersion < 3) d.execSQL("DELETE FROM work_entries WHERE id NOT IN (SELECT MAX(id) FROM work_entries GROUP BY date,worker_id,field_id)")
            if (oldVersion < 4) migrateToV4(d)
            if (oldVersion < 5) migrateToV5(d)
            if (oldVersion < 6) migrateToV6(d)
            if (oldVersion < 7) migrateToV7(d)
            if (oldVersion < 9) migrateToV9(d)
            createIndexes(d)
            setMetadata(d)
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
    }

    private fun migrateToV4(d: SQLiteDatabase) {
        d.execSQL("DROP INDEX IF EXISTS ux_work_date_worker_field")
        d.execSQL("CREATE TABLE work_entries_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,field_id INTEGER NOT NULL REFERENCES fields(id) ON UPDATE CASCADE ON DELETE RESTRICT,days REAL NOT NULL CHECK(days>=0 AND days<=1),rate REAL NOT NULL CHECK(rate>=0))")
        d.execSQL("INSERT INTO work_entries_v4(id,date,worker_id,field_id,days,rate) SELECT w.id,w.date,w.worker_id,w.field_id,w.days,w.rate FROM work_entries w INNER JOIN workers wo ON wo.id=w.worker_id INNER JOIN fields f ON f.id=w.field_id WHERE w.days>=0 AND w.days<=1 AND w.rate>=0")
        d.execSQL("DROP TABLE work_entries")
        d.execSQL("ALTER TABLE work_entries_v4 RENAME TO work_entries")
        d.execSQL("CREATE TABLE payments_v4(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,worker_id INTEGER NOT NULL REFERENCES workers(id) ON UPDATE CASCADE ON DELETE RESTRICT,amount REAL NOT NULL CHECK(amount>0),note TEXT NOT NULL DEFAULT '')")
        d.execSQL("INSERT INTO payments_v4(id,date,worker_id,amount,note) SELECT p.id,p.date,p.worker_id,p.amount,COALESCE(p.note,'') FROM payments p INNER JOIN workers w ON w.id=p.worker_id WHERE p.amount>0")
        d.execSQL("DROP TABLE payments")
        d.execSQL("ALTER TABLE payments_v4 RENAME TO payments")
    }
    private fun migrateToV9(d: SQLiteDatabase) {
        d.execSQL("ALTER TABLE payments ADD COLUMN field_id INTEGER REFERENCES fields(id) ON UPDATE CASCADE ON DELETE SET NULL")
        d.execSQL("CREATE INDEX IF NOT EXISTS ix_pay_field ON payments(field_id)")
    }
    private fun migrateToV7(d: SQLiteDatabase) {
        // Existing field names remain unique by design; users can create multiple plots by naming them distinctly (e.g. Paddy Plot 1, Paddy Plot 2).
        d.execSQL("ALTER TABLE fields ADD COLUMN crop_type TEXT NOT NULL DEFAULT 'Paddy'")
    }
    private fun migrateToV6(d: SQLiteDatabase) {
        d.execSQL("ALTER TABLE workers ADD COLUMN photo_uri TEXT NOT NULL DEFAULT ''")
        d.execSQL("ALTER TABLE fields ADD COLUMN photo_uri TEXT NOT NULL DEFAULT ''")
        // Keep existing workers/fields intact; identity uniqueness is enforced at save time.
    }
    private fun migrateToV5(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE IF NOT EXISTS team_members(date TEXT NOT NULL,field_id INTEGER NOT NULL REFERENCES fields(id) ON DELETE CASCADE,worker_id INTEGER NOT NULL REFERENCES workers(id) ON DELETE RESTRICT,PRIMARY KEY(date,field_id,worker_id))")
        d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) SELECT date,field_id,worker_id FROM work_entries")
    }
}

class MainActivity : Activity() {
    private lateinit var db: DB
    private lateinit var content: LinearLayout
    private val df = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDf = SimpleDateFormat("dd-MM-yyyy", Locale.US)
    private var selectedDate = today()
    private var reportFrom = monthStart()
    private var reportTo = today()
    private var pendingExport: ByteArray? = null
    private var selectedWorkerFilter = "All"
    private var selectedPaymentMethod = "Cash"
    private var darkMode = false
    private var reportWorkerQuery = ""
    private var reportFieldIds = mutableSetOf<Long>()
    private var photoTargetType = ""
    private var photoTargetId = -1L
    private var selectedAttendanceFieldId: Long? = null

    private fun today() = df.format(Date())
    private fun monthStart(): String { val c = Calendar.getInstance(); c.set(Calendar.DAY_OF_MONTH, 1); return df.format(c.time) }
    private fun currencySymbol(): String = getPreferences(0).getString("currency", "₹") ?: "₹"
    private fun money(v: Double) = currencySymbol() + String.format(Locale.US, "%,.0f", v)
    private fun days(v: Double) = if (v % 1.0 == 0.0) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun getColorCompat(id: Int): Int = if (Build.VERSION.SDK_INT >= 23) getColor(id) else resources.getColor(id)
    private fun parseDate(s: String): Date = try { df.parse(s) ?: Date() } catch (_: Exception) { Date() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        darkMode = getPreferences(0).getBoolean("dark_mode", false)
        db = DB(this)
        db.writableDatabase
        applyThemeBars()
        home()
    }

    private fun isHindi(): Boolean = getPreferences(0).getString("language", "Hindi") == "Hindi"
    private fun tr(en: String, hi: String): String = if (isHindi()) hi else en
    private fun lightSurfaceColor(): Int = getColorCompat(R.color.surface_light)
    private fun surfaceColor(): Int = if (darkMode) 0xFF1A231E.toInt() else lightSurfaceColor()
    private fun inputSurfaceColor(): Int = if (darkMode) 0xFF202A24.toInt() else lightSurfaceColor()
    private fun paymentMethodLabel(canonical: String): String = when (canonical.trim()) {
        "Cash" -> tr("Cash", "नकद")
        "Bank Transfer" -> tr("Bank Transfer", "बैंक ट्रांसफर")
        "UPI" -> tr("UPI", "यूपीआई")
        "Other" -> tr("Other", "अन्य")
        else -> canonical
    }
    private fun stripPaymentMethodPrefix(note: String): String {
        val lines = note.split("\n")
        if (lines.isNotEmpty() && (Regex("^Method:\\s*(Cash|Bank Transfer|UPI|Other)$").matches(lines[0].trim()) || Regex("^तरीका:\\s*(नकद|बैंक ट्रांसफर|यूपीआई|अन्य)$").matches(lines[0].trim()))) {
            return lines.drop(1).joinToString("\n").trimStart()
        }
        return note
    }
    private fun localizePaymentNote(note: String): String {
        if (note.isBlank()) return note
        val m = Regex("^Method:\\s*(Cash|Bank Transfer|UPI|Other)\\s*(?:\n|$)").find(note)
        if (m == null) return note
        val rest = note.substring(m.range.last + 1).trimStart('\n')
        val prefix = tr("Method", "तरीका") + ": " + paymentMethodLabel(m.groupValues[1])
        return if (rest.isBlank()) prefix else "$prefix\n$rest"
    }
    private fun applyThemeBars() {
        window.setBackgroundDrawable(ColorDrawable(if (darkMode) 0xFF101412.toInt() else lightSurfaceColor()))
        window.setStatusBarColor(if (darkMode) 0xFF0B3D25.toInt() else 0xFF1B5E20.toInt())
        window.setNavigationBarColor(if (darkMode) 0xFF101412.toInt() else lightSurfaceColor())
    }

    private fun dlg(): AlertDialog.Builder = AlertDialog.Builder(this, if (darkMode) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert)

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        resetSystemBars()
        val tag = (findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0)?.tag?.toString() ?: ""
        when {
            tag.startsWith("worker:") -> workers()
            tag.startsWith("field:") -> fields()
            tag.startsWith("report:") -> reports()
            tag == "workers" || tag == "fields" || tag == "reports" -> home()
            tag == "attendance" -> home()
            tag == "payments" -> home()
            tag == "backup" -> home()
            else -> super.onBackPressed()
        }
    }

    private fun themedColor(color: Int): Int = if (darkMode) when (color) {
        Color.WHITE -> 0xFF1A231E.toInt()
        C.TEXT -> 0xFFE8F0EB.toInt()
        C.MUTED -> 0xFFB6C4BC.toInt()
        C.BORDER -> 0xFF3A4A41.toInt()
        else -> color
    } else color

    private fun bg(color: Int, radius: Int = 16, stroke: Int = 0, strokeColor: Int = C.BORDER) = GradientDrawable().apply {
        setColor(themedColor(color)); cornerRadius = dp(radius).toFloat(); if (stroke > 0) setStroke(dp(stroke), strokeColor)
    }

    private fun tv(text: String, size: Float = 15f, color: Int = C.TEXT, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(themedColor(color)); if (bold) typeface = Typeface.DEFAULT_BOLD; includeFontPadding = true
    }

    private fun label(text: String) = tv(text, 12f, C.MUTED, true).apply { setPadding(0, 0, 0, dp(5)) }

    private fun primary(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END; setTextColor(Color.WHITE); background = bg(C.GREEN, 13)
        minHeight = dp(48); stateListAnimator = null; setOnClickListener { action() }
    }

    private fun outline(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 13f; isAllCaps = false; isSingleLine = true; ellipsize = TextUtils.TruncateAt.END; setTextColor(if (darkMode) 0xFF8FE0B0.toInt() else C.GREEN_DARK); background = bg(surfaceColor(), 12, 1)
        minHeight = dp(44); stateListAnimator = null; setOnClickListener { action() }
    }

    private fun input(hint: String, value: String = "") = EditText(this).apply {
        this.hint = hint; setText(value); textSize = 14f; setTextColor(themedColor(C.TEXT)); setHintTextColor(themedColor(C.MUTED)); maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(13), 0, dp(13), 0); minHeight = dp(48); background = bg(inputSurfaceColor(), 11, 1)
    }

    private fun section(text: String) = tv(text, 17f, C.TEXT, true).apply { setPadding(0, dp(2), 0, dp(8)) }

    private fun gap(h: Int = 10) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun assetImage(resId: Int, h: Int = 92, radius: Int = 14): ImageView = ImageView(this).apply {
        setImageResource(resId)
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = bg(surfaceColor(), radius, 1)
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(-1, dp(h))
    }

    private fun pill(text: String, selected: Boolean = false, action: () -> Unit = { toast(text) }) = TextView(this).apply {
        this.text = text
        textSize = 12.5f
        gravity = Gravity.CENTER
        setTypeface(Typeface.DEFAULT, if (selected) Typeface.BOLD else Typeface.NORMAL)
        setTextColor(if (selected) Color.WHITE else C.TEXT)
        background = bg(if (selected) C.GREEN else surfaceColor(), 18, 1, if (selected) C.GREEN else C.BORDER)
        setPadding(dp(14), dp(7), dp(14), dp(7))
        setOnClickListener { action() }
    }

    private fun page(title: String, subtitle: String = "", active: Int = 0, tagValue: String = title): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(if (darkMode) 0xFF101412.toInt() else lightSurfaceColor()); tag = tagValue }
        val isHome = tagValue == "home"
        val hideNav = tagValue.startsWith("worker:") || tagValue.startsWith("field:") || tagValue == "payments" || tagValue == "backup"
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(if (isHome) 10 else 8), dp(4), dp(10), dp(4))
            background = bg(C.GREEN_DARK, 0)
        }
        if (isHome) {
            val logo = ImageView(this).apply { setImageResource(R.drawable.majdoor_logo); scaleType = ImageView.ScaleType.CENTER_CROP }
            header.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
            val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            titleBox.addView(tv("Majdoor Hisaab PRO", 16f, Color.WHITE, true))
            titleBox.addView(tv("कृषि मजदूर प्रबंधन", 9.5f, 0xFFD8F1E0.toInt()))
            header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(tv("🔔", 19f, Color.WHITE, false).apply { gravity = Gravity.CENTER; setOnClickListener { backup() } })
        } else {
            header.addView(TextView(this).apply {
                text = "‹"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                setPadding(0, 0, dp(5), dp(4)); setOnClickListener { onBackPressed() }
            }, LinearLayout.LayoutParams(dp(42), dp(48)))
            val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            titleBox.addView(tv(title, 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            if (subtitle.isNotBlank()) titleBox.addView(tv(subtitle, 9.5f, 0xFFD8F1E0.toInt()).apply { gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
            header.addView(Space(this), LinearLayout.LayoutParams(dp(42), dp(48)))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(52)))
        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(if (hideNav) 14 else 72))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (!hideNav) {
            val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = ColorDrawable(if (darkMode) 0xFF151C18.toInt() else lightSurfaceColor()); elevation = dp(6).toFloat(); setPadding(dp(2), 0, dp(2), 0) }
            val labels = listOf("⌂\n${tr("Home","होम")}", "✓\n${tr("Attendance","उपस्थिति")}", "●\n${tr("Workers","मजदूर")}", "♧\n${tr("Fields","खेत")}", "▤\n${tr("Reports","रिपोर्ट")}")
            labels.forEachIndexed { i, text -> nav.addView(TextView(this).apply {
                this.text = text; textSize = 9.5f; gravity = Gravity.CENTER; setTextColor(if (i == active) C.GREEN else C.MUTED)
                typeface = if (i == active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setPadding(0, dp(3), 0, dp(3))
                setOnClickListener { when (i) { 0 -> home(); 1 -> attendance(); 2 -> workers(); 3 -> fields(); else -> reports() } }
            }, LinearLayout.LayoutParams(0, dp(50), 1f)) }
            root.addView(nav)
        }
        localizeTree(root)
        return root
    }
    private fun stat(title: String, value: String, accent: Int, soft: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(11), dp(12), dp(11)); background = bg(soft, 15)
        addView(tv(title, 11f, C.MUTED).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }); addView(tv(value, 18f, accent, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun card(title: String, value: String, accent: Int = C.GREEN) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = bg(if (darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(), 15, 1, if (darkMode) 0xFF3A4A41.toInt() else C.BORDER)
        addView(tv(title, 12f, C.MUTED).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }); addView(tv(value, 19f, accent, true).apply { setPadding(0, dp(5), 0, 0) })
    }

    private fun scalar(sql: String, args: Array<String> = emptyArray()): Double = db.readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst() && !it.isNull(0)) it.getDouble(0) else 0.0 }
    private fun scalarText(sql: String, args: Array<String> = emptyArray()): String? = db.readableDatabase.rawQuery(sql, args).use { if (it.moveToFirst() && !it.isNull(0)) it.getString(0) else null }
    private fun count(table: String, where: String = "1=1"): Long = db.readableDatabase.rawQuery("SELECT COUNT(*) FROM $table WHERE $where", null).use { if (it.moveToFirst()) it.getLong(0) else 0L }
    private fun addRow(parent: LinearLayout, view: View, weight: Float = 1f, marginEnd: Int = 0) { parent.addView(view, LinearLayout.LayoutParams(0, -2, weight).apply { if (marginEnd > 0) this.marginEnd = dp(marginEnd) }) }

    private fun localizeTree(v: View) {
        if (!isHindi()) return
        val map = mapOf(
            "Workers" to "मजदूर", "Fields" to "खेत", "Attendance" to "उपस्थिति", "Reports" to "रिपोर्ट",
            "Payment" to "भुगतान", "Make Payment" to "भुगतान करें", "Add Worker" to "मजदूर जोड़ें",
            "Add Field" to "खेत जोड़ें", "Search" to "खोजें", "Save" to "सहेजें", "Edit" to "संपादित करें",
            "Delete" to "हटाएँ", "Settings" to "सेटिंग्स", "Backup" to "बैकअप", "Restore Backup" to "बैकअप पुनर्स्थापित करें",
            "Create Backup" to "बैकअप बनाएँ", "Language" to "भाषा", "Theme" to "थीम", "Currency" to "मुद्रा",
            "Reset App Data" to "ऐप डेटा रीसेट करें", "Worker Reports" to "मजदूर रिपोर्ट", "Field Reports" to "खेत रिपोर्ट",
            "Payment Report" to "भुगतान रिपोर्ट", "Daily Report" to "दैनिक रिपोर्ट", "Work History" to "काम का इतिहास",
            "Payment History" to "भुगतान इतिहास", "Cost Summary" to "लागत सारांश", "View All" to "सभी देखें",
            "All Fields" to "सभी खेत", "Full" to "पूरा दिन", "Half" to "आधा दिन", "None" to "अनुपस्थित", "Cash" to "नकद", "Bank Transfer" to "बैंक ट्रांसफर", "Other" to "अन्य", "UPI" to "यूपीआई",
            "Type" to "प्रकार", "Field" to "खेत", "Fields" to "खेत", "Home" to "होम", "Search field..." to "खेत खोजें...", "Search worker..." to "मजदूर खोजें...", "Add Field" to "खेत जोड़ें", "Add Worker" to "मजदूर जोड़ें", "Paddy" to "धान", "Paddy (Dhaan)" to "धान", "Sugarcane" to "गन्ना", "Banana" to "केला", "Mustard" to "सरसों", "Workers" to "मजदूर", "Worker" to "मजदूर", "Days" to "दिन", "Day" to "दिन", "Full Day" to "पूरा दिन", "Half Day" to "आधा दिन", "Payment Date" to "भुगतान दिनांक", "Payment Method" to "भुगतान का तरीका", "Amount" to "राशि", "Method" to "तरीका", "Note" to "टिप्पणी", "Wages" to "मजदूरी", "English" to "अंग्रेज़ी", "Light" to "लाइट", "Dark" to "डार्क", "Delete data" to "डेटा हटाएँ", "From file" to "फाइल से", "Version" to "संस्करण", "Reports" to "रिपोर्ट", "Search field / crop" to "खेत / फसल खोजें", "Search worker..." to "मजदूर खोजें...",
            tr("Save Attendance","उपस्थिति सहेजें") to "उपस्थिति सहेजें", "Add Payment" to "भुगतान जोड़ें", "Total Days" to "कुल दिन",
            "Total Wages" to "कुल मजदूरी", "Total Paid" to "कुल भुगतान", "Remaining" to "बाकी",
            "Active" to "सक्रिय", "Inactive" to "निष्क्रिय", "All" to "सभी", "Select Field" to "खेत चुनें",
            "Select Team" to "टीम चुनें", "Apply Filter" to "फ़िल्टर लागू करें", "All Fields" to "सभी खेत",
            "Export PDF" to "PDF निर्यात", "Export CSV" to "CSV निर्यात", "Share" to "साझा करें",
            "Change Filters" to "फ़िल्टर बदलें", "No workers found." to "कोई मजदूर नहीं मिला।",
            "No field report available." to "कोई खेत रिपोर्ट उपलब्ध नहीं है।",
            "Cancel" to "रद्द करें", "Apply" to "लागू करें", "Reset" to "रीसेट करें",
            "New Worker" to "नया मजदूर", "Edit Worker" to "मजदूर संपादित करें", tr("New Field / Crop","नया खेत / फसल") to "नया खेत / फसल",
            tr("Edit Field / Crop","खेत / फसल संपादित करें") to "खेत / फसल संपादित करें", "Worker Name" to "मजदूर का नाम", "Daily Wage ₹" to "दैनिक मजदूरी ₹", "Worker" to "मजदूर", "Workers" to "मजदूर", '/day' to '/दिन', "Daily Wage" to "दैनिक मजदूरी",
            "Crop Type" to "फसल का प्रकार", "Plot / Field name" to "खेत / प्लॉट का नाम", "Search field / crop" to "खेत / फसल खोजें",
            "Search worker name or ID" to "मजदूर का नाम या आईडी खोजें", "Search Worker" to "मजदूर खोजें",
            "Search Field" to "खेत खोजें", "Change / Select Photo" to "फोटो बदलें / चुनें", "Remove Photo" to "फोटो हटाएँ",
            "Photo: selected" to "फोटो: चुनी गई", "Photo: default" to "फोटो: डिफ़ॉल्ट", "Worker Photo" to "मजदूर की फोटो",
            "Field Photo" to "खेत की फोटो", "Select fields / plots" to "खेत / प्लॉट चुनें", "All workers" to "सभी मजदूर",
            "No workers found" to "कोई मजदूर नहीं मिला", "No payments found" to "कोई भुगतान नहीं मिला",
            "Filtered Work" to "फ़िल्टर किया गया काम", "Selected fields" to "चयनित खेत", "Filter" to "फ़िल्टर",
            "Earned" to "कमाई", "Paid" to "भुगतान", "Balance" to "बाकी", "Search worker name or ID" to "मजदूर का नाम या आईडी खोजें",
            "Select fields / plots (leave all unchecked = all fields)" to "खेत / प्लॉट चुनें (कुछ न चुनें तो सभी खेत)",
            "Change Filters" to "फ़िल्टर बदलें", "Share Report" to "रिपोर्ट साझा करें", "Other apps" to "अन्य ऐप",
            "No team/attendance recorded" to "कोई टीम/उपस्थिति दर्ज नहीं है",
"No work history yet." to "अभी कोई काम का इतिहास नहीं है।", "No records found" to "कोई रिकॉर्ड नहीं मिला।",
            "Restore Backup?" to "बैकअप पुनर्स्थापित करें?", "Restore" to "पुनर्स्थापित करें",
            "Backup is valid. Your current data will be replaced." to "बैकअप सही है। आपका वर्तमान डेटा बदल दिया जाएगा।",
            "Restore completed" to "बैकअप पुनर्स्थापित हो गया", "Backup ZIP saved successfully" to "बैकअप ZIP सफलतापूर्वक सहेजा गया",
            "Backup could not be created" to "बैकअप नहीं बनाया जा सका", tr("Invalid backup","अमान्य बैकअप") to "अमान्य बैकअप",
            "Report saved successfully" to "रिपोर्ट सफलतापूर्वक सहेजी गई", "CSV export failed" to "CSV निर्यात विफल",
            "PDF export failed" to "PDF निर्यात विफल", "All Full saved" to "सभी पूरे दिन सहेजे गए",
            "All Half saved" to "सभी आधे दिन सहेजे गए", "Attendance cleared" to "उपस्थिति साफ की गई",
            "Full" to "पूरा दिन", "Half" to "आधा दिन", "None" to "अनुपस्थित", "Cash" to "नकद", "Bank Transfer" to "बैंक ट्रांसफर", "Other" to "अन्य", "UPI" to "यूपीआई",
            "Type" to "प्रकार", "Field" to "खेत", "Fields" to "खेत", "Home" to "होम", "Search field..." to "खेत खोजें...", "Search worker..." to "मजदूर खोजें...", "Add Field" to "खेत जोड़ें", "Add Worker" to "मजदूर जोड़ें", "Paddy" to "धान", "Paddy (Dhaan)" to "धान", "Sugarcane" to "गन्ना", "Banana" to "केला", "Mustard" to "सरसों", "Workers" to "मजदूर", "Worker" to "मजदूर", "Days" to "दिन", "Day" to "दिन", "Full Day" to "पूरा दिन", "Half Day" to "आधा दिन", "Payment Date" to "भुगतान दिनांक", "Payment Method" to "भुगतान का तरीका", "Amount" to "राशि", "Method" to "तरीका", "Note" to "टिप्पणी", "Wages" to "मजदूरी", "English" to "अंग्रेज़ी", "Light" to "लाइट", "Dark" to "डार्क", "Delete data" to "डेटा हटाएँ", "From file" to "फाइल से", "Version" to "संस्करण", "Reports" to "रिपोर्ट", "Search field / crop" to "खेत / फसल खोजें", "Search worker..." to "मजदूर खोजें..."
        )
        if (v is TextView) {
            val t=v.text?.toString() ?: ""
            map[t]?.let { v.text=it }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) localizeTree(v.getChildAt(i))
    }

    /** Reference-design skin: the supplied 10-screen artwork is the visual source of truth.
     * Transparent hit areas keep the visible design unchanged while routing taps to the real app actions. */
    private fun referenceScreen(resId:Int, tagValue:String, hotspots:List<Hotspot>): FrameLayout {
        // REAL NATIVE SCREEN: no screenshot/background artwork is used.
        // The original ZIP used full-screen PNG mockups with transparent hotspots.
        // This implementation renders actual Android Views instead.
        resetSystemBars()

        val root = FrameLayout(this).apply {
            tag = tagValue
            setBackgroundColor(if (darkMode) 0xFF101412.toInt() else lightSurfaceColor())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = bg(C.GREEN_DARK, 0)
        }

        val title = when {
            tagValue == "home" -> "Majdoor Hisaab PRO"
            tagValue == "attendance" -> tr("Attendance", "उपस्थिति")
            tagValue == "workers" -> tr("Workers", "मजदूर")
            tagValue == "fields" -> tr("Fields / Crops", "खेत / फसल")
            tagValue == "payments" -> tr("Payments", "भुगतान")
            tagValue == "reports" -> tr("Reports", "रिपोर्ट")
            tagValue == "report:daily" -> tr("Daily Report", "दैनिक रिपोर्ट")
            tagValue.startsWith("worker:") -> tr("Worker Profile", "मजदूर प्रोफाइल")
            tagValue.startsWith("field:") -> tr("Field Details", "खेत विवरण")
            else -> "Majdoor Hisaab PRO"
        }

        if (tagValue != "home") {
            header.addView(TextView(this).apply {
                text = "‹"
                textSize = 32f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setOnClickListener { onBackPressed() }
            }, LinearLayout.LayoutParams(dp(42), dp(48)))
        } else {
            header.addView(ImageView(this).apply {
                setImageResource(R.drawable.majdoor_logo)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        }

        header.addView(tv(title, 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))

        if (tagValue == "home") {
            header.addView(tv("⚙", 21f, Color.WHITE, true).apply {
                setPadding(dp(8), 0, dp(4), 0)
                setOnClickListener { backup() }
            })
        }

        root.addView(header, FrameLayout.LayoutParams(-1, dp(52)))

        // Native buttons replace transparent screenshot hotspots.
        hotspots.forEach { h ->
            val button = Button(this).apply {
                text = h.name
                textSize = when {
                    h.name.contains("Nav") -> 10f
                    h.name.length > 18 -> 11f
                    else -> 12f
                }
                isAllCaps = false
                setTextColor(if (darkMode) Color.WHITE else C.TEXT)
                background = bg(
                    if (darkMode) 0xFF1A231E.toInt() else Color.WHITE,
                    10,
                    1,
                    if (darkMode) 0xFF3A4A41.toInt() else C.BORDER
                )
                setPadding(dp(4), dp(2), dp(4), dp(2))
                minHeight = 0
                minimumHeight = 0
                setOnClickListener { h.action() }
                contentDescription = h.name
            }

            val lp = FrameLayout.LayoutParams(0, 0).apply {
                leftMargin = pxX(h.x)
                topMargin = dp(56) + pxY(h.y)
                width = pxX(h.w)
                height = pxY(h.h.coerceAtMost(8f))
            }

            // Bottom navigation is rendered as compact native controls.
            if (h.name.endsWith("Nav")) {
                lp.topMargin = resources.displayMetrics.heightPixels - dp(54)
                lp.height = dp(50)
                button.textSize = 9f
                button.setPadding(0, 0, 0, 0)
            }

            root.addView(button, lp)
        }

        setContentView(root)
        localizeTree(root)
        return root
    }

    private fun hindiResourceFor(resId:Int, dark:Boolean): Int = when(resId) {
        R.drawable.s_home -> if (dark) R.drawable.s_home_dark_hi else R.drawable.s_home_hi
        R.drawable.s_attendance -> if (dark) R.drawable.s_attendance_dark_hi else R.drawable.s_attendance_hi
        R.drawable.s_workers -> if (dark) R.drawable.s_workers_dark_hi else R.drawable.s_workers_hi
        R.drawable.s_worker_profile -> if (dark) R.drawable.s_worker_profile_dark_hi else R.drawable.s_worker_profile_hi
        R.drawable.s_payment -> if (dark) R.drawable.s_payment_dark_hi else R.drawable.s_payment_hi
        R.drawable.s_fields -> if (dark) R.drawable.s_fields_dark_hi else R.drawable.s_fields_hi
        R.drawable.s_field_details -> if (dark) R.drawable.s_field_details_dark_hi else R.drawable.s_field_details_hi
        R.drawable.s_reports -> if (dark) R.drawable.s_reports_dark_hi else R.drawable.s_reports_hi
        R.drawable.s_daily -> if (dark) R.drawable.s_daily_dark_hi else R.drawable.s_daily_hi
        R.drawable.s_settings -> if (dark) R.drawable.s_settings_dark_hi else R.drawable.s_settings_hi
        else -> resId
    }

    private fun darkResourceFor(resId:Int): Int = when(resId) {
        R.drawable.s_home -> R.drawable.s_home_dark
        R.drawable.s_attendance -> R.drawable.s_attendance_dark
        R.drawable.s_workers -> R.drawable.s_workers_dark
        R.drawable.s_worker_profile -> R.drawable.s_worker_profile_dark
        R.drawable.s_payment -> R.drawable.s_payment_dark
        R.drawable.s_fields -> R.drawable.s_fields_dark
        R.drawable.s_field_details -> R.drawable.s_field_details_dark
        R.drawable.s_reports -> R.drawable.s_reports_dark
        R.drawable.s_daily -> R.drawable.s_daily_dark
        R.drawable.s_settings -> R.drawable.s_settings_dark
        else -> resId
    }

    private fun addPhotoView(root:FrameLayout, uri:String, x:Float, y:Float, w:Float, h:Float, fallback:Int) {
        val iv=ImageView(this).apply {
            scaleType=ImageView.ScaleType.CENTER_CROP
            background=bg(if(darkMode) 0xFF26312B.toInt() else lightSurfaceColor(),10,1,if(darkMode) 0xFF4B5A52.toInt() else C.BORDER)
            clipToOutline=true
            if(uri.isNotBlank()) { try { setImageURI(Uri.parse(uri)) } catch(_:Exception) { setImageResource(fallback) } } else setImageResource(fallback)
            contentDescription=tr("Custom photo", "कस्टम फोटो")
        }
        root.addView(iv,FrameLayout.LayoutParams(pxX(w),pxY(h)).apply{leftMargin=pxX(x);topMargin=pxY(y)})
    }

    private fun addOverlay(root:FrameLayout, view:View, x:Float, y:Float, w:Float, h:Float) {
        root.addView(view, FrameLayout.LayoutParams(pxX(w), pxY(h)).apply { leftMargin=pxX(x); topMargin=pxY(y) })
    }
    private fun overlayPanel(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(dp(8),dp(8),dp(8),dp(8))
        background=bg(if(darkMode) 0xDD101412.toInt() else 0xEFFFFFFF.toInt(),14,1,if(darkMode) 0xFF4B5A52.toInt() else C.BORDER)
    }

    private fun addDynamicPhotoOverlays(root:FrameLayout, tagValue:String) {
        val d=db.readableDatabase
        when {
            tagValue=="home" -> {
                val crops=listOf(tr("Paddy","धान") to R.drawable.paddy,tr("Sugarcane","गन्ना") to R.drawable.sugarcane,tr("Banana","केला") to R.drawable.banana,tr("Mustard","सरसों") to R.drawable.mustard)
                crops.forEachIndexed { i,(crop,res) ->
                    val x=5f+i*23f
                    val uri=d.rawQuery("SELECT photo_uri FROM fields WHERE active=1 AND lower(crop_type) LIKE ? AND photo_uri<>'' ORDER BY id DESC LIMIT 1",arrayOf("%${crop.lowercase()}%" )).use{if(it.moveToFirst())it.getString(0) else ""}
                    if(uri.isNotBlank()) addPhotoView(root,uri,x+1,46f,20f,8f,res)
                }
            }
            tagValue=="workers" -> {
                d.rawQuery("SELECT photo_uri FROM workers WHERE active=1 ORDER BY name LIMIT 6",null).use{c->var i=0;while(c.moveToNext()){val u=c.getString(0);if(u.isNotBlank())addPhotoView(root,u,6f,32f+i*7.2f,14f,5.8f,R.drawable.avatar);i++}}
            }
            tagValue.startsWith("worker:") -> {
                val id=tagValue.substringAfter(":").toLongOrNull() ?: -1L
                val u=d.rawQuery("SELECT photo_uri FROM workers WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0) else ""}
                if(u.isNotBlank())addPhotoView(root,u,8f,15f,25f,18f,R.drawable.avatar)
            }
            tagValue=="fields" -> {
                val positions=listOf(5f to 27f,52f to 27f,5f to 47f,52f to 47f)
                d.rawQuery("SELECT photo_uri,crop_type FROM fields WHERE active=1 ORDER BY name LIMIT 4",null).use{c->var i=0;while(c.moveToNext()&&i<4){val u=c.getString(0);val ct=c.getString(1);val res=when{ct.contains("banana",true)->R.drawable.banana;ct.contains("mustard",true)->R.drawable.mustard;ct.contains("sugar",true)->R.drawable.sugarcane;else->R.drawable.paddy};if(u.isNotBlank())addPhotoView(root,u,positions[i].first+1,positions[i].second,40f,12f,res);i++}}
            }
            tagValue.startsWith("field:") -> {
                val id=tagValue.substringAfter(":").toLongOrNull() ?: -1L
                val row=d.rawQuery("SELECT photo_uri,crop_type FROM fields WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())it.getString(0)+"|"+it.getString(1) else ""}
                val parts=row.split("|")
                val u=parts.getOrNull(0).orEmpty();val ct=parts.getOrNull(1).orEmpty()
                if(u.isNotBlank()){val res=when{ct.contains("banana",true)->R.drawable.banana;ct.contains("mustard",true)->R.drawable.mustard;ct.contains("sugar",true)->R.drawable.sugarcane;else->R.drawable.paddy};addPhotoView(root,u,5f,16f,90f,13f,res)}
            }
        }
    }

    private data class Hotspot(val name:String,val x:Float,val y:Float,val w:Float,val h:Float,val action:()->Unit)
    private fun pxX(percent:Float):Int=(resources.displayMetrics.widthPixels*percent/100f).toInt()
    private fun pxY(percent:Float):Int=(resources.displayMetrics.heightPixels*percent/100f).toInt()
    private fun resetSystemBars(){
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        applyThemeBars()
    }

    private fun home() {
        val root=referenceScreen(R.drawable.s_home, "home", listOf(
            Hotspot("Workers",7,25,45,8){workers()}, Hotspot("Fields",50,25,44,8){fields()},
            Hotspot("Attendance",7,34,45,8){attendance()}, Hotspot("Payment",50,34,44,8){payments()},
            Hotspot("View All",83,43,14,5){fields()}, Hotspot("Paddy",5,45,22,10){attendance("Paddy (Dhaan)")},
            Hotspot("Sugarcane",28,45,22,10){attendance("Sugarcane")}, Hotspot("Banana",51,45,22,10){attendance("Banana")}, Hotspot("Mustard",74,45,22,10){attendance("Mustard")},
            Hotspot("Mark Attendance",8,55,84,7){attendance()}, Hotspot(tr("Add Worker","मजदूर जोड़ें"),5,62,29,6){workerDialog(null)}, Hotspot("Add Payment",35,62,29,6){payments()}, Hotspot(tr("Add Field","खेत जोड़ें"),66,62,29,6){fieldDialog(null)},
            Hotspot("Notifications",82,1,8,9){notificationsDialog()}, Hotspot("Settings",90,1,8,9){backup()}, Hotspot("Home Nav",0,91,20,9){home()}, Hotspot("Attendance Nav",20,91,20,9){attendance()}, Hotspot("Workers Nav",40,91,20,9){workers()}, Hotspot("Fields Nav",60,91,20,9){fields()}, Hotspot("Reports Nav",80,91,20,9){reports()}
        ))
        val panel=overlayPanel()
        val workers=count("workers","active=1")
        val todayAttendance=count("work_entries","date='${today()}' AND days>0")
        val wages=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries")
        val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments")
        val row1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        addRow(row1,stat(tr("Workers","मजदूर"),workers.toString(),C.GREEN,C.GREEN_SOFT),1f,5)
        addRow(row1,stat(tr("Today's Attendance","आज की उपस्थिति"),todayAttendance.toString(),C.BLUE,C.BLUE_SOFT),1f)
        panel.addView(row1,LinearLayout.LayoutParams(-1,dp(78)).apply{bottomMargin=dp(6)})
        val row2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        addRow(row2,stat(tr("Total Wages","कुल मजदूरी"),money(wages),C.ORANGE,C.ORANGE_SOFT),1f,5)
        addRow(row2,stat(tr("Pending / Balance","बाकी"),money(wages-paid),if(wages-paid>0)C.RED else C.GREEN, C.RED_SOFT),1f)
        panel.addView(row2,LinearLayout.LayoutParams(-1,dp(78)))
        addOverlay(root,panel,5f,12f,90f,20f)
    }

    private fun cropCard(name:String,res:Int,action:()->Unit)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(2),dp(2),dp(2),dp(3));background=bg(if(darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(),10,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER);setOnClickListener{action()};addView(ImageView(this@MainActivity).apply{setImageResource(res);scaleType=ImageView.ScaleType.CENTER_CROP},LinearLayout.LayoutParams(-1,dp(56)));addView(tv(name,8.8f,C.TEXT,true).apply{gravity=Gravity.CENTER;setPadding(0,dp(3),0,0);maxLines=1;ellipsize=TextUtils.TruncateAt.END})}
    private fun attendance(preselectField: String? = null) {
        referenceScreen(R.drawable.s_attendance, "attendance", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot("Date",15,5,70,9){pickDate(selectedDate){selectedDate=it;attendance(preselectField)}},
            Hotspot("Field",8,14,84,9){selectTeamForReference(preselectField)}, Hotspot("Team",8,22,84,9){selectTeamForReference(preselectField)}, Hotspot("Search",8,30,84,8){searchWorkerReference()},
            Hotspot("Worker 1",8,34,82,7){attendanceWorkerChoice(0)}, Hotspot("Worker 2",8,41,82,7){attendanceWorkerChoice(1)}, Hotspot("Worker 3",8,48,82,7){attendanceWorkerChoice(2)}, Hotspot("Worker 4",8,55,82,7){attendanceWorkerChoice(3)}, Hotspot("Worker 5",8,62,82,7){attendanceWorkerChoice(4)}, Hotspot("Worker 6",8,69,82,7){attendanceWorkerChoice(5)},
            Hotspot("Full",74,34,16,6){setAllAttendanceReference(1.0)}, Hotspot("Half",55,34,17,6){setAllAttendanceReference(.5)}, Hotspot("None",74,42,16,6){setAllAttendanceReference(0.0)},
            Hotspot("All Full",8,72,25,6){setAllAttendanceReference(1.0)}, Hotspot("All Half",34,72,25,6){setAllAttendanceReference(.5)}, Hotspot("Clear All",61,72,28,6){setAllAttendanceReference(0.0)},
            Hotspot(tr("Save Attendance","उपस्थिति सहेजें"),8,84,84,7){saveAttendanceReference()}
        ))
    }
    private fun selectTeamForReference(preselectField:String?){
        val f=preselectField ?: firstFieldName()
        if(f!=null){
            val fields=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())fields.add(c.getLong(0) to c.getString(1))}
            val id=fields.firstOrNull{it.second==f}?.first ?: fields.firstOrNull()?.first
            if(id!=null){selectedAttendanceFieldId=id;selectTeam(id,selectedDate)} else toast(tr("Add a field first","पहले एक खेत जोड़ें"))
        } else toast(tr("Add a field first","पहले एक खेत जोड़ें"))
    }
    private fun firstFieldName():String?=db.readableDatabase.rawQuery("SELECT name FROM fields WHERE active=1 ORDER BY name LIMIT 1",null).use{if(it.moveToFirst())it.getString(0) else null}

    private fun attendanceWorkerChoice(offset:Int){
        val field=selectedAttendanceFieldId ?: firstFieldId() ?: run{toast(tr("Add a field first","पहले एक खेत जोड़ें"));return}
        selectedAttendanceFieldId=field
        val workers=selectedWorkersFor(field,selectedDate)
        if(offset !in workers.indices){selectTeam(field,selectedDate);return}
        val w=workers[offset]
        dlg().setTitle("${w.second} • ${money(w.third)}/${tr("day","दिन")}").setItems(arrayOf(tr("Full","पूरा दिन"),tr("Half","आधा दिन"),tr("None","अनुपस्थित"))){_,which->
            setAttendance(selectedDate,field,w.first,if(which==0)1.0 else if(which==1)0.5 else 0.0)
        }.show()
    }
    private fun saveAttendanceReference(){
        val field=selectedAttendanceFieldId ?: firstFieldId() ?: run { toast(tr("Add a field first","पहले एक खेत जोड़ें")); return }
        selectedAttendanceFieldId=field
        val team=selectedWorkersFor(field,selectedDate)
        if(team.isEmpty()){ toast(tr("Select Team first","पहले टीम चुनें")); selectTeam(field,selectedDate); return }
        // Attendance choices are persisted immediately; this action validates the team/date
        // and returns to the dashboard only after a successful database transaction.
        db.writableDatabase.beginTransaction()
        try {
            team.forEach { w ->
                db.writableDatabase.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)", arrayOf(selectedDate,field,w.first))
            }
            db.writableDatabase.setTransactionSuccessful()
        } finally { db.writableDatabase.endTransaction() }
        toast(tr("Attendance saved","उपस्थिति सहेजी गई"))
        home()
    }

    private fun notificationsDialog(){
        val b=StringBuilder()
        db.readableDatabase.rawQuery("SELECT date,name,amount FROM (SELECT p.date,w.name,p.amount FROM payments p JOIN workers w ON w.id=p.worker_id ORDER BY p.id DESC LIMIT 5)",null).use { c ->
            while(c.moveToNext()) b.append(tr("Payment • ","भुगतान • ")).append(c.getString(1)).append(" • ").append(money(c.getDouble(2))).append(" • ").append(c.getString(0)).append("\n")
        }
        val text=if(b.isNotBlank()) b.toString().trim() else tr("No new notifications","कोई नई सूचना नहीं")
        dlg().setTitle(tr("Notifications","सूचनाएँ")).setMessage(text).setPositiveButton(tr("OK","ठीक है"),null).show()
    }

    private fun searchFieldReference(){
        val e=input(tr("Search field / crop","खेत / फसल खोजें"))
        dlg().setTitle(tr("Search Field","खेत खोजें")).setView(e).setPositiveButton(tr("Search","खोजें")){_,_->
            val q=e.text.toString().trim()
            if(q.isBlank()){ fields(); return@setPositiveButton }
            db.readableDatabase.rawQuery("SELECT id FROM fields WHERE lower(name) LIKE ? ORDER BY name LIMIT 1",arrayOf("%${q.lowercase(Locale.getDefault())}%")).use { c ->
                if(c.moveToFirst()) fieldDetail(c.getLong(0)) else toast(tr("Field not found","खेत नहीं मिला"))
            }
        }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun fieldHistoryDialog(id:Long){
        val b=StringBuilder()
        db.readableDatabase.rawQuery("SELECT w.date,wo.name,w.days,w.rate FROM work_entries w JOIN workers wo ON wo.id=w.worker_id WHERE w.field_id=? ORDER BY w.date DESC,w.id DESC",arrayOf(id.toString())).use { c ->
            while(c.moveToNext()) {
                val d=c.getDouble(2)
                b.append(c.getString(0)).append("  •  ").append(c.getString(1)).append("  •  ")
                    .append(if(d==1.0)tr("Full","पूरा दिन") else if(d==0.5)tr("Half","आधा दिन") else tr("None","अनुपस्थित")).append("  •  ").append(money(d*c.getDouble(3))).append("\n")
            }
        }
        dlg().setTitle(tr("Work History","काम का इतिहास")).setMessage(if(b.isBlank())tr("No work history yet.","अभी कोई काम का इतिहास नहीं है।") else b.toString().trim()).setPositiveButton(tr("OK","ठीक है"),null).show()
    }

    private fun fieldCostSummaryDialog(id:Long){
        val field=fieldName(id)
        val workers=scalar("SELECT COUNT(DISTINCT worker_id) FROM work_entries WHERE field_id=?",arrayOf(id.toString()))
        val totalDays=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()))
        val totalCost=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()))
        dlg().setTitle(tr("Cost Summary — $field","लागत सारांश — $field"))
            .setMessage(tr("Workers: ${workers.toInt()}\nTotal Days: ${days(totalDays)}\nTotal Cost: ${money(totalCost)}","मजदूर: ${workers.toInt()}\nकुल दिन: ${days(totalDays)}\nकुल लागत: ${money(totalCost)}"))
            .setPositiveButton(tr("OK","ठीक है"),null).show()
    }

    private fun dailyFieldDetail(fieldId:Long){
        val fieldName=scalarText("SELECT name FROM fields WHERE id=?",arrayOf(fieldId.toString())) ?: return
        val crop=scalarText("SELECT crop_type FROM fields WHERE id=?",arrayOf(fieldId.toString())) ?: ""
        val b=StringBuilder()
        val sql="""SELECT tm.date,wo.name,COALESCE(w.days,0),wo.rate
                   FROM team_members tm JOIN workers wo ON wo.id=tm.worker_id
                   LEFT JOIN work_entries w ON w.date=tm.date AND w.worker_id=tm.worker_id AND w.field_id=tm.field_id
                   WHERE tm.field_id=? AND tm.date=? ORDER BY wo.name"""
        db.readableDatabase.rawQuery(sql,arrayOf(fieldId.toString(),reportTo)).use { c ->
            while(c.moveToNext()){
                val d=c.getDouble(2); val status=if(d==1.0)tr("Full","पूरा दिन") else if(d==0.5)tr("Half","आधा दिन") else tr("None","अनुपस्थित")
                b.append(c.getString(1)).append("  •  ").append(status).append("  •  ").append(days(d)).append(" ").append(tr("day","दिन")).append("  •  ").append(money(d*c.getDouble(3))).append("\n")
            }
        }
        val cropLabel=when{crop.contains("paddy",true)||crop.contains("dhaan",true)->tr("Paddy","धान");crop.contains("sugar",true)->tr("Sugarcane","गन्ना");crop.contains("banana",true)->tr("Banana","केला");crop.contains("mustard",true)->tr("Mustard","सरसों");else->crop}; val title=if(crop.isBlank())fieldName else "$fieldName — $cropLabel"
        dlg().setTitle(tr("$title — Daily Details","$title — दैनिक विवरण")).setMessage(if(b.isBlank())tr("No team/attendance recorded for this field on $reportTo.","$reportTo को इस खेत के लिए कोई टीम/उपस्थिति दर्ज नहीं है।") else b.toString().trim()).setPositiveButton(tr("OK","ठीक है"),null).show()
    }

    private fun searchWorkerReference(){
        val e=input(tr("Search worker name or ID","मजदूर का नाम या आईडी खोजें"))
        dlg().setTitle(tr("Search Worker","मजदूर खोजें")).setView(e).setPositiveButton(tr("Search","खोजें")){_,_->
            val q=e.text.toString().trim(); if(q.isBlank()){selectTeamForReference(null);return@setPositiveButton}
            db.readableDatabase.rawQuery("SELECT id FROM workers WHERE lower(name) LIKE ? OR lower(code) LIKE ? ORDER BY name LIMIT 1",arrayOf("%${q.lowercase()}%","%${q.lowercase()}%")).use{c->if(c.moveToFirst())workerDetail(c.getLong(0)) else toast(tr("Worker not found","मजदूर नहीं मिला"))}
        }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun setAllAttendanceReference(value:Double){
        val field=selectedAttendanceFieldId ?: firstFieldId() ?: run { toast(tr("Add a field first","पहले एक खेत जोड़ें")); return }
        selectedAttendanceFieldId=field
        val team=selectedWorkersFor(field,selectedDate)
        if(team.isEmpty()){
            val workers=allActiveWorkers()
            if(workers.isEmpty()){toast(tr("Add a worker first","पहले मजदूर जोड़ें"));return}
            val d=db.writableDatabase; d.beginTransaction(); try {
                workers.forEach{w->setAttendanceDirect(d,selectedDate,field,w.first,value,w.third)}
                d.setTransactionSuccessful()
            } finally { d.endTransaction() }
        } else {
            val d=db.writableDatabase; d.beginTransaction(); try {
                team.forEach{w->setAttendanceDirect(d,selectedDate,field,w.first,value,w.third)}
                d.setTransactionSuccessful()
            } finally { d.endTransaction() }
        }
        toast(if(value==1.0)tr("All Full saved","सभी पूरे दिन सहेजे गए") else if(value==.5)tr("All Half saved","सभी आधे दिन सहेजे गए") else tr("Attendance cleared","उपस्थिति साफ की गई"))
    }
    private fun firstFieldId():Long?=db.readableDatabase.rawQuery("SELECT id FROM fields WHERE active=1 ORDER BY name LIMIT 1",null).use{if(it.moveToFirst())it.getLong(0) else null}

    private fun selectedWorkersFor(fieldId: Long, date: String): List<Triple<Long,String,Double>> {
        val result = mutableListOf<Triple<Long,String,Double>>()
        db.readableDatabase.rawQuery("SELECT w.id,w.name,w.rate FROM team_members tm JOIN workers w ON w.id=tm.worker_id WHERE tm.field_id=? AND tm.date=? ORDER BY w.name", arrayOf(fieldId.toString(),date)).use { c -> while(c.moveToNext()) result.add(Triple(c.getLong(0),c.getString(1),c.getDouble(2))) }
        return result
    }

    private fun allActiveWorkers(): List<Triple<Long,String,Double>> {
        val r=mutableListOf<Triple<Long,String,Double>>(); db.readableDatabase.rawQuery("SELECT id,name,rate FROM workers WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())r.add(Triple(c.getLong(0),c.getString(1),c.getDouble(2)))}; return r
    }

    private fun attendanceRow(id:Long,name:String,rate:Double,fieldId:Long,date:String):LinearLayout {
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(10));background=bg(surfaceColor(),14,1)}
        val top=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}; top.addView(tv(name,15f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f)); top.addView(tv(money(rate)+" / दिन",12f,C.MUTED)); root.addView(top); root.addView(tv(tr("Attendance","उपस्थिति"),11f,C.MUTED).apply{setPadding(0,dp(6),0,dp(5))})
        val buttons=LinearLayout(this); val state=currentDays(date,fieldId,id)
        val full=attendanceChoice(tr("Full","पूरा दिन"),C.GREEN,C.GREEN_SOFT,state==1.0){setAttendance(date,fieldId,id,1.0)}; val half=attendanceChoice(tr("Half","आधा दिन"),C.ORANGE,C.ORANGE_SOFT,state==0.5){setAttendance(date,fieldId,id,0.5)}; val none=attendanceChoice(tr("None","अनुपस्थित"),C.MUTED,0xFFF2F4F3.toInt(),state==0.0){setAttendance(date,fieldId,id,0.0)}
        buttons.addView(full,LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(5)});buttons.addView(half,LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(5)});buttons.addView(none,LinearLayout.LayoutParams(0,dp(44),1f));root.addView(buttons);return root
    }

    private fun attendanceChoice(text:String,color:Int,soft:Int,selected:Boolean,action:()->Unit)=TextView(this).apply{this.text=if(selected)"✓ $text" else text;textSize=13f;gravity=Gravity.CENTER;setTextColor(if(selected)color else C.TEXT);background = bg(if (selected) soft else surfaceColor(), 11, 1, color);setOnClickListener{action()}}

    private fun currentDays(date:String,fieldId:Long,workerId:Long):Double=scalar("SELECT COALESCE(MAX(days),0) FROM work_entries WHERE date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))

    private fun setAttendance(date:String,fieldId:Long,workerId:Long,value:Double){
        val d=db.writableDatabase
        d.beginTransaction()
        try{
            d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,workerId))
            d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))
            if(value>0){val rate=scalar("SELECT rate FROM workers WHERE id=?",arrayOf(workerId.toString()));d.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) VALUES(?,?,?,?,?)",arrayOf(date,workerId,fieldId,value,rate))}
            d.setTransactionSuccessful()
        }finally{d.endTransaction()}
        attendance(fieldName(fieldId))
    }

    private fun fieldName(fieldId:Long):String = db.readableDatabase.rawQuery("SELECT name FROM fields WHERE id=?",arrayOf(fieldId.toString())).use { if(it.moveToFirst()) it.getString(0) else "" }

    private fun setAllAttendance(value:Double){
        val root=(findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0) ?: return
        val scroll=root.findViewById<ScrollView>(android.R.id.content) ?: root
        // The active field is recovered from the visible Spinner.
        val spinner=findSpinner(root) ?: return
        val fields=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())fields.add(c.getLong(0) to c.getString(1))}
        if(fields.isEmpty())return
        val fieldId=fields[spinner.selectedItemPosition].first
        val team=selectedWorkersFor(fieldId,selectedDate)
        if(team.isEmpty()){toast(tr("Select workers first","पहले मजदूर चुनें"));return}
        val d=db.writableDatabase;d.beginTransaction();try{team.forEach{setAttendanceDirect(d,selectedDate,fieldId,it.first,value,it.third)};d.setTransactionSuccessful()}finally{d.endTransaction()};attendance(fieldName(fieldId))
    }

    private fun findSpinner(v:View):Spinner?{if(v is Spinner)return v;if(v is ViewGroup)for(i in 0 until v.childCount)findSpinner(v.getChildAt(i))?.let{return it};return null}

    private fun setAttendanceDirect(d:SQLiteDatabase,date:String,fieldId:Long,workerId:Long,value:Double,rate:Double){
        d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,workerId))
        d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),workerId.toString()))
        if(value>0)d.execSQL("INSERT INTO work_entries(date,worker_id,field_id,days,rate) VALUES(?,?,?,?,?)",arrayOf(date,workerId,fieldId,value,rate))
    }

    private fun selectTeam(fieldId:Long,date:String){
        val workers=allActiveWorkers()
        if(workers.isEmpty()){toast(tr("Add a worker first","पहले मजदूर जोड़ें"));return}
        val selected=selectedWorkersFor(fieldId,date).map{it.first}.toMutableSet()
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(4),dp(8),0)}
        val search=input(tr("Search worker name or ID","मजदूर का नाम या आईडी खोजें"))
        box.addView(search,LinearLayout.LayoutParams(-1,dp(48)))
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(ScrollView(this).apply{addView(list)},LinearLayout.LayoutParams(-1,dp(360)))
        fun render(q:String){
            list.removeAllViews()
            val query=q.trim().lowercase(Locale.getDefault())
            workers.forEach{w->
                val code=workerCode(w.first)
                if(query.isNotEmpty() && !w.second.lowercase(Locale.getDefault()).contains(query) && !code.lowercase(Locale.getDefault()).contains(query)) return@forEach
                val cb=CheckBox(this).apply{
                    text="${w.second}  •  ${money(w.third)}/${tr("day","दिन")}"
                    textSize=14f;setTextColor(C.TEXT);isChecked=selected.contains(w.first)
                    setPadding(dp(4),dp(4),dp(4),dp(4))
                    setOnCheckedChangeListener{_,checked->if(checked)selected.add(w.first)else selected.remove(w.first)}
                }
                list.addView(cb,LinearLayout.LayoutParams(-1,dp(52)))
            }
        }
        search.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}
            override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){render(s?.toString()?:"")}
            override fun afterTextChanged(s:Editable?){}
        })
        render("")
        dlg().setTitle(tr("Select Today's Team","आज की टीम चुनें")).setView(box)
            .setPositiveButton(tr("Save Team","टीम सहेजें")){_,_->
                val d=db.writableDatabase;d.beginTransaction()
                try{
                    val previousIds = mutableListOf<Long>()
                    d.rawQuery("SELECT worker_id FROM team_members WHERE date=? AND field_id=?",arrayOf(date,fieldId.toString())).use { c ->
                        while(c.moveToNext()) previousIds.add(c.getLong(0))
                    }
                    previousIds.filterNot { selected.contains(it) }.forEach { wid ->
                        d.delete("work_entries","date=? AND field_id=? AND worker_id=?",arrayOf(date,fieldId.toString(),wid.toString()))
                    }
                    d.delete("team_members","date=? AND field_id=?",arrayOf(date,fieldId.toString()))
                    selected.forEach{wid->d.execSQL("INSERT INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(date,fieldId,wid))}
                    d.setTransactionSuccessful()
                }finally{d.endTransaction()}
                attendance(fieldName(fieldId))
            }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun workerCode(id:Long):String=
        db.readableDatabase.rawQuery("SELECT code FROM workers WHERE id=?",arrayOf(id.toString())).use{
            if(it.moveToFirst())it.getString(0) else ""
        }

    private fun loadPreviousTeam(spinner:Spinner,fields:List<Pair<Long,String>>){
        val fieldId=fields[spinner.selectedItemPosition].first
        val prev=db.readableDatabase.rawQuery("SELECT worker_id FROM team_members WHERE field_id=? AND date=(SELECT MAX(date) FROM team_members WHERE field_id=? AND date<?) GROUP BY worker_id",arrayOf(fieldId.toString(),fieldId.toString(),selectedDate))
        val ids=mutableListOf<Long>(); prev.use{c->while(c.moveToNext())ids.add(c.getLong(0))}
        if(ids.isEmpty()){toast(tr("No previous team found","पिछली टीम नहीं मिली"));return}
        val d=db.writableDatabase; d.beginTransaction()
        try {
            d.delete("team_members","date=? AND field_id=?",arrayOf(selectedDate,fieldId.toString()))
            ids.forEach{wid->d.execSQL("INSERT OR IGNORE INTO team_members(date,field_id,worker_id) VALUES(?,?,?)",arrayOf(selectedDate,fieldId,wid))}
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        attendance(fieldName(fieldId))
    }

    private fun workers(){
        val root=referenceScreen(R.drawable.s_workers, "workers", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot(tr("Add Worker","मजदूर जोड़ें"),70,8,27,8){workerDialog(null)}, Hotspot("Search",5,17,90,8){searchWorkerReference()},
            Hotspot("All",5,24,27,7){selectedWorkerFilter="All";workers()}, Hotspot("Active",33,24,27,7){selectedWorkerFilter="Active";workers()}, Hotspot("Inactive",62,24,27,7){selectedWorkerFilter="Inactive";workers()},
            Hotspot("Home Nav",0,91,20,9){home()},Hotspot("Attendance Nav",20,91,20,9){attendance()},Hotspot("Workers Nav",40,91,20,9){workers()},Hotspot("Fields Nav",60,91,20,9){fields()},Hotspot("Reports Nav",80,91,20,9){reports()}
        ))
        val panel=overlayPanel(); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val sc=ScrollView(this).apply{addView(list);isFillViewport=true}; panel.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        renderWorkersList(list,"")
        addOverlay(root,panel,5f,31f,90f,57f)
    }

    private fun openFirstWorker(){openWorkerOffset(0)}
    private fun openWorkerOffset(offset:Int){db.readableDatabase.rawQuery("SELECT id FROM workers ORDER BY name LIMIT 1 OFFSET ?",arrayOf(offset.toString())).use{if(it.moveToFirst())workerDetail(it.getLong(0)) else workerDialog(null)}}

    private fun renderWorkers(q:String,tabs:LinearLayout){workers()}
    private fun renderWorkersList(list:LinearLayout,q:String){
        list.removeAllViews(); val like=q.trim().lowercase(Locale.getDefault()); val where=when(selectedWorkerFilter){"Active"->"active=1";"Inactive"->"active=0";else->"1=1"};
        db.readableDatabase.rawQuery("SELECT id,code,name,rate,active,photo_uri FROM workers WHERE $where ORDER BY active DESC,name",null).use{c->if(!c.moveToFirst()){list.addView(tv(tr("No workers found.","कोई मजदूर नहीं मिला।"),13f,C.MUTED));return@use};do{val id=c.getLong(0);val code=c.getString(1);val name=c.getString(2);if(like.isNotEmpty()&&!code.lowercase().contains(like)&&!name.lowercase().contains(like))continue;val rate=c.getDouble(3);val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),dp(9),dp(10),dp(9));background=bg(if(darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(),13,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER)};row.addView(ImageView(this).apply{
                val uri=c.getString(5)
                if(uri.isNotBlank()) try{setImageURI(Uri.parse(uri))}catch(_:Exception){setImageResource(R.drawable.avatar)} else setImageResource(R.drawable.avatar)
                scaleType=ImageView.ScaleType.CENTER_CROP
            },LinearLayout.LayoutParams(dp(48),dp(48)));val mid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(9),0,dp(5),0)};mid.addView(tv(name,14f,C.TEXT,true));mid.addView(tv("$code  •  ${money(rate)} ${tr("per day","प्रति दिन")}",11f,C.MUTED));mid.addView(tv(if(c.getInt(4)==1)tr("Active","सक्रिय") else tr("Inactive","निष्क्रिय"),10f,if(c.getInt(4)==1)C.GREEN else C.RED,true));row.addView(mid,LinearLayout.LayoutParams(0,-2,1f));row.addView(tv("›",25f,C.MUTED));row.setOnClickListener{workerDetail(id)};list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})}while(c.moveToNext())}
    }
    private fun workerDialog(id:Long?){
        val old=if(id==null)null else db.readableDatabase.rawQuery("SELECT name,rate,photo_uri FROM workers WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst()) Triple(c.getString(0),c.getDouble(1),c.getString(2)) else null}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(5),0,dp(5),0)}
        val name=input(tr("Worker Name","मजदूर का नाम"),old?.first ?: ""); val rate=input(tr("Daily Wage ₹","दैनिक मजदूरी ₹"),old?.second?.toString() ?: "")
        rate.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        box.addView(name,LinearLayout.LayoutParams(-1,dp(50)));box.addView(rate,LinearLayout.LayoutParams(-1,dp(50)).apply{topMargin=dp(8)})
        val photoStatus=tv(if(old?.third?.isNotBlank()==true) tr("Photo: selected", "फोटो: चुनी गई") else tr("Photo: default", "डिफ़ॉल्ट फोटो"),12f,C.MUTED)
        box.addView(photoStatus.apply{setPadding(dp(2),dp(8),0,0)})
        dlg().setTitle(if(id==null) tr("New Worker","नया मजदूर") else tr("Edit Worker","मजदूर संपादित करें")).setView(box)
            .setNeutralButton(tr("Photo","फोटो")){_,_-> if(id!=null) workerPhotoDialog(id) else toast(tr("Save the worker first, then add a photo","पहले मजदूर सहेजें, फिर फोटो जोड़ें"))}
            .setPositiveButton(tr("Save","सहेजें")){_,_->
                val n=name.text.toString().trim();val r=rate.text.toString().replace(",",".").toDoubleOrNull()
                if(n.isBlank()||r==null||r<0){toast(tr("Enter a name and valid daily wage","नाम और सही दैनिक मजदूरी दर्ज करें"));return@setPositiveButton}
                try{val d=db.writableDatabase
                    val duplicate=d.rawQuery("SELECT id FROM workers WHERE lower(trim(name))=lower(trim(?)) AND id<>? LIMIT 1",arrayOf(n,(id?:-1L).toString())).use{it.moveToFirst()}
                    if(duplicate){toast(tr("This worker already exists. Do not create a duplicate.","यह मजदूर पहले से मौजूद है। डुप्लीकेट मजदूर न बनाएँ।"));return@setPositiveButton}
                    if(id==null){d.beginTransaction();try{val next=scalar("SELECT COALESCE(MAX(CAST(SUBSTR(code,3) AS INTEGER)),0)+1 FROM workers WHERE code LIKE 'L-%'").toInt();d.execSQL("INSERT INTO workers(code,name,rate,active) VALUES(?,?,?,1)",arrayOf("L-%03d".format(Locale.US,next),n,r));d.setTransactionSuccessful()}finally{d.endTransaction()}}else d.execSQL("UPDATE workers SET name=?,rate=? WHERE id=?",arrayOf(n,r,id));workers()
                }catch(e:Exception){toast(tr("Could not save: ${e.message}","सहेजा नहीं जा सका: ${e.message}"))}
            }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun workerPhotoDialog(id:Long){
        dlg().setTitle(tr("Worker Photo","मजदूर की फोटो")).setItems(arrayOf(tr("Change / Select Photo","फोटो बदलें / चुनें"),tr("Remove Photo","फोटो हटाएँ"))){_,which->
            if(which==0){photoTargetType="worker";photoTargetId=id;val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(i,910)}
            else {db.writableDatabase.execSQL("UPDATE workers SET photo_uri='' WHERE id=?",arrayOf(id));toast(tr("Worker photo removed","मजदूर की फोटो हटा दी गई"));workers()}
        }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun toggleWorker(id:Long,deactivate:Boolean){db.writableDatabase.execSQL("UPDATE workers SET active=? WHERE id=?",arrayOf(if(deactivate)0 else 1,id));workers()}

    private fun workerDetail(id:Long){
        val row=db.readableDatabase.rawQuery("SELECT name,code,rate,active,photo_uri FROM workers WHERE id=?",arrayOf(id.toString()))
        var name="";var code="";var rate=0.0;var active=1
        row.use{if(it.moveToFirst()){name=it.getString(0);code=it.getString(1);rate=it.getDouble(2);active=it.getInt(3)}}
        val root=referenceScreen(R.drawable.s_worker_profile, "worker:$id", listOf(
            Hotspot("Back",0,0,12,10){workers()}, Hotspot("Edit",83,0,15,9){workerDialog(id)}, Hotspot(if(active==1) "Deactivate" else "Activate",66,0,17,9){toggleWorker(id,active==1)},
            Hotspot("Work History",5,43,45,8){showWorkerWorkHistory(id)}, Hotspot("Payment History",50,43,45,8){showWorkerPayments(id)},
            Hotspot("View All",83,69,15,7){showWorkerWorkHistory(id)}, Hotspot("Add Payment",5,79,90,8){payments(id)}
        ))
        row.use{if(it.moveToFirst()){name=it.getString(0);code=it.getString(1);rate=it.getDouble(2);active=it.getInt(3)}}
        val daysV=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE worker_id=?",arrayOf(id.toString()))
        val earned=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE worker_id=?",arrayOf(id.toString()))
        val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE worker_id=?",arrayOf(id.toString()))
        val panel=overlayPanel(); panel.addView(tv("$name  •  $code",16f,C.TEXT,true));panel.addView(tv("${tr("Daily Wage","दैनिक मजदूरी")}: ${money(rate)}  •  ${if(active==1)tr("Active","सक्रिय") else tr("Inactive","निष्क्रिय")}",12f,C.MUTED));gapIn(panel,5)
        val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};addRow(r,stat(tr("Total Days","कुल दिन"),days(daysV),C.BLUE,C.BLUE_SOFT),1f,4);addRow(r,stat(tr("Total Wages","कुल मजदूरी"),money(earned),C.ORANGE,C.ORANGE_SOFT),1f);panel.addView(r,LinearLayout.LayoutParams(-1,dp(70)).apply{bottomMargin=dp(5)})
        val r2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};addRow(r2,stat(tr("Paid","भुगतान"),money(paid),C.GREEN,C.GREEN_SOFT),1f,4);addRow(r2,stat(tr("Balance","बाकी"),money(earned-paid),if(earned-paid>0)C.RED else C.GREEN,C.RED_SOFT),1f);panel.addView(r2,LinearLayout.LayoutParams(-1,dp(70)))
        addOverlay(root,panel,5f,34f,90f,31f)
    }
    private fun gapIn(parent:LinearLayout,h:Int){parent.addView(Space(this),LinearLayout.LayoutParams(1,dp(h)))}

    private fun showWorkerWorkHistory(id:Long){
        dlg().setTitle(tr("Work History","काम का इतिहास")).setMessage(buildWorkerHistory(id)).setPositiveButton(tr("OK","ठीक है"),null).show()
    }
    private fun buildWorkerHistory(id:Long):String{val b=StringBuilder();db.readableDatabase.rawQuery("SELECT date,field_id,days,rate FROM work_entries WHERE worker_id=? ORDER BY date DESC",arrayOf(id.toString())).use{c->while(c.moveToNext())b.append(displayDf.format(parseDate(c.getString(0)))).append("  •  ").append(fieldName(c.getLong(1))).append("  •  ").append(if(c.getDouble(2)==1.0)tr("Full","पूरा दिन") else if(c.getDouble(2)==0.5)tr("Half","आधा दिन") else tr("None","अनुपस्थित")).append("  •  ").append(money(c.getDouble(3)*c.getDouble(2))).append("\n")};return if(b.isEmpty())tr("No work history yet.","अभी कोई काम का इतिहास नहीं है।") else b.toString().trim()}


    private fun showWorkerPayments(id:Long){dlg().setTitle(tr("Payment History","भुगतान इतिहास")).setMessage(buildPaymentHistory(id)).setPositiveButton(tr("OK","ठीक है"),null).show()}
    private fun buildPaymentHistory(id:Long):String{val b=StringBuilder();db.readableDatabase.rawQuery("SELECT date,amount,note FROM payments WHERE worker_id=? ORDER BY date DESC,id DESC",arrayOf(id.toString())).use{c->while(c.moveToNext())b.append(displayDf.format(parseDate(c.getString(0)))).append("  •  ").append(money(c.getDouble(1))).append("\n").append(c.getString(2)).append("\n\n")};return if(b.isEmpty())tr("No payments yet.","अभी कोई भुगतान नहीं है।") else b.toString().trim()}
    private fun fields(){
        val root=referenceScreen(R.drawable.s_fields, "fields", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot(tr("Add Field","खेत जोड़ें"),60,8,35,9){fieldDialog(null)}, Hotspot("Search",5,16,90,8){searchFieldReference()},
            Hotspot("Home Nav",0,91,20,9){home()},Hotspot("Attendance Nav",20,91,20,9){attendance()},Hotspot("Workers Nav",40,91,20,9){workers()},Hotspot("Fields Nav",60,91,20,9){fields()},Hotspot("Reports Nav",80,91,20,9){reports()}
        ))
        val panel=overlayPanel(); val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; val sc=ScrollView(this).apply{addView(grid);isFillViewport=true};panel.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        renderFieldGrid(grid,"")
        addOverlay(root,panel,5f,25f,90f,55f)
    }

    private fun openFieldByName(part:String){db.readableDatabase.rawQuery("SELECT id FROM fields WHERE lower(name) LIKE ? ORDER BY id LIMIT 1",arrayOf("%${part.lowercase()}%")).use{if(it.moveToFirst())fieldDetail(it.getLong(0)) else fieldDialog(null)}}
    private fun renderFieldGrid(grid:LinearLayout,q:String){grid.removeAllViews();val rows=LinearLayout(this);var col=0;val like=q.trim().lowercase();db.readableDatabase.rawQuery("SELECT id,name,active,crop_type,photo_uri FROM fields ORDER BY active DESC,name",null).use{c->while(c.moveToNext()){if(like.isNotEmpty()&&!c.getString(1).lowercase().contains(like))continue;val id=c.getLong(0);val name=c.getString(1);val cropType=c.getString(3);val photoUri=c.getString(4);val res=when{cropType.contains("banana",true)->R.drawable.banana;cropType.contains("mustard",true)->R.drawable.mustard;cropType.contains("sugar",true)->R.drawable.sugarcane;else->R.drawable.paddy};val daysV=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val cost=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=bg(if(darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(),12,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER);setPadding(dp(3),dp(3),dp(3),dp(7));setOnClickListener{fieldDetail(id)}};card.addView(ImageView(this).apply{if(photoUri.isNotBlank())try{setImageURI(Uri.parse(photoUri))}catch(_:Exception){setImageResource(res)}else setImageResource(res);scaleType=ImageView.ScaleType.CENTER_CROP},LinearLayout.LayoutParams(-1,dp(78)));card.addView(tv(name,12f,C.TEXT,true).apply{setPadding(dp(5),dp(5),dp(5),0)});card.addView(tv("${days(daysV)} ${tr("Days","दिन")}",10f,C.MUTED).apply{setPadding(dp(5),dp(2),dp(5),0)});card.addView(tv(tr("Total Cost: ${money(cost)}","कुल लागत: ${money(cost)}"),10f,C.MUTED).apply{setPadding(dp(5),dp(1),dp(5),0)});if(col==0){rows=LinearLayout(this);rows.orientation=LinearLayout.HORIZONTAL;grid.addView(rows,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)});rows.addView(card,LinearLayout.LayoutParams(0,dp(145),1f).apply{marginEnd=dp(4)});col=1}else{rows.addView(card,LinearLayout.LayoutParams(0,dp(145),1f));col=0}};if(col==1)rows.addView(Space(this),LinearLayout.LayoutParams(0,dp(145),1f))}}
    private fun fieldDialog(id:Long?){
        val old=if(id==null)Triple("","","") else db.readableDatabase.rawQuery("SELECT name,photo_uri,active,crop_type FROM fields WHERE id=?",arrayOf(id.toString())).use{c->if(c.moveToFirst())Triple(c.getString(0),c.getString(1),c.getString(3)) else Triple("","","")}
        val e=input(tr("Plot / Field name","खेत / प्लॉट का नाम"),old.first)
        val cropOptions=listOf("Paddy (Dhaan)" to "धान","Sugarcane" to "गन्ना","Banana" to "केला","Mustard" to "सरसों","Other" to "अन्य"); val crop=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,cropOptions.map{if(isHindi())it.second else it.first});setSelection(cropOptions.indexOfFirst{it.first.equals(old.third,true)}.coerceAtLeast(0))}
        val photo=tv(if(old.second.isNotBlank()) tr("Photo: custom selected","फोटो: कस्टम चुनी गई") else tr("Photo: default by crop type","फसल के अनुसार डिफ़ॉल्ट फोटो"),12f,C.MUTED).apply{setPadding(0,dp(8),0,0)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(e);addView(label(tr("Crop Type","फसल का प्रकार")));addView(crop,LinearLayout.LayoutParams(-1,dp(46)));addView(photo)}
        dlg().setTitle(if(id==null) tr("New Field / Crop","नया खेत / फसल") else tr("Edit Field / Crop","खेत / फसल संपादित करें")).setView(box)
            .setNeutralButton(tr("Photo","फोटो")){_,_->if(id!=null)fieldPhotoDialog(id) else toast(tr("Save the field first, then add a photo","पहले खेत सहेजें, फिर फोटो जोड़ें"))}
            .setPositiveButton(tr("Save","सहेजें")){_,_->val n=e.text.toString().trim();if(n.isBlank()){toast(tr("Enter a name","नाम दर्ज करें"));return@setPositiveButton};try{if(id==null)db.writableDatabase.execSQL("INSERT INTO fields(name,crop_type,active) VALUES(?,?,1)",arrayOf(n,cropOptions[crop.selectedItemPosition].first))else db.writableDatabase.execSQL("UPDATE fields SET name=?,crop_type=? WHERE id=?",arrayOf(n,cropOptions[crop.selectedItemPosition].first,id));fields()}catch(e:Exception){toast(tr("Could not save: ${e.message}","सहेजा नहीं जा सका: ${e.message}"))}}
            .setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun fieldPhotoDialog(id:Long){
        dlg().setTitle(tr("Field / Crop Photo","खेत / फसल की फोटो")).setItems(arrayOf(tr("Change / Select Photo","फोटो बदलें / चुनें"),tr("Remove Photo","फोटो हटाएँ"))){_,which->
            if(which==0){photoTargetType="field";photoTargetId=id;val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(i,911)}
            else {db.writableDatabase.execSQL("UPDATE fields SET photo_uri='' WHERE id=?",arrayOf(id));toast(tr("Field photo removed","खेत की फोटो हटा दी गई"));fields()}
        }.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun toggleField(id:Long,deactivate:Boolean){db.writableDatabase.execSQL("UPDATE fields SET active=? WHERE id=?",arrayOf(if(deactivate)0 else 1,id));fields()}
    private fun fieldDetail(id:Long){
        var name="";var crop="";var active=1
        db.readableDatabase.rawQuery("SELECT name,crop_type,active FROM fields WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst()){name=it.getString(0);crop=it.getString(1);active=it.getInt(2)}}
        val root=referenceScreen(R.drawable.s_field_details, "field:$id", listOf(
            Hotspot("Back",0,0,12,10){fields()}, Hotspot("Edit",80,0,18,10){fieldDialog(id)}, Hotspot(if(active==1) "Deactivate" else "Activate",60,0,18,10){toggleField(id,active==1)}, Hotspot("Work History",8,45,42,8){fieldHistoryDialog(id)}, Hotspot("Cost Summary",50,45,42,8){fieldCostSummaryDialog(id)}, Hotspot("View All",80,83,16,6){fieldHistoryDialog(id)}
        ))
        val workers=count("team_members","field_id=$id");val daysV=scalar("SELECT COALESCE(SUM(days),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val cost=scalar("SELECT COALESCE(SUM(days*rate),0) FROM work_entries WHERE field_id=?",arrayOf(id.toString()));val paid=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE field_id=?",arrayOf(id.toString()))
        val panel=overlayPanel();panel.addView(tv("🌾 $name",16f,C.TEXT,true));panel.addView(tv("${tr("Crop","फसल")}: ${cropLabel(crop)}  •  ${if(active==1)tr("Active","सक्रिय") else tr("Inactive","निष्क्रिय")}",12f,C.MUTED));gapIn(panel,5)
        val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};addRow(r,stat(tr("Workers","मजदूर"),workers.toString(),C.BLUE,C.BLUE_SOFT),1f,4);addRow(r,stat(tr("Total Days","कुल दिन"),days(daysV),C.GREEN,C.GREEN_SOFT),1f);panel.addView(r,LinearLayout.LayoutParams(-1,dp(70)).apply{bottomMargin=dp(5)})
        val r2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};addRow(r2,stat(tr("Total Cost","कुल लागत"),money(cost),C.ORANGE,C.ORANGE_SOFT),1f,4);addRow(r2,stat(tr("Field Balance","खेत बाकी"),money(cost-paid),if(cost-paid>0)C.RED else C.GREEN,C.RED_SOFT),1f);panel.addView(r2,LinearLayout.LayoutParams(-1,dp(70)))
        addOverlay(root,panel,5f,30f,90f,30f)
    }
    private fun cropLabel(c:String)=when(c.lowercase()){"paddy (dhaan)","paddy"->tr("Paddy","धान");"sugarcane"->tr("Sugarcane","गन्ना");"banana"->tr("Banana","केला");"mustard"->tr("Mustard","सरसों");else->c}

    private fun payments(preselectedWorkerId: Long? = null){
        val root=referenceScreen(R.drawable.s_payment, "payments", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot("Worker",10,13,84,8){paymentDialog(null,preselectedWorkerId)}, Hotspot("Date",10,24,84,8){paymentDialog(null,preselectedWorkerId)}, Hotspot("Amount",10,33,84,8){paymentDialog(null,preselectedWorkerId)}, Hotspot("Method",10,42,84,8){paymentDialog(null,preselectedWorkerId)}, Hotspot("Note",10,51,84,8){paymentDialog(null,preselectedWorkerId)}, Hotspot("Save Payment",8,66,84,8){paymentDialog(null,preselectedWorkerId)}
        ))
        val panel=overlayPanel();val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};db.readableDatabase.rawQuery("SELECT p.id,p.date,w.name,f.name,p.amount,p.note FROM payments p JOIN workers w ON w.id=p.worker_id LEFT JOIN fields f ON f.id=p.field_id ORDER BY p.date DESC,p.id DESC LIMIT 30",null).use{c->if(!c.moveToFirst())list.addView(tv(tr("No payments found","कोई भुगतान नहीं मिला"),12f,C.MUTED)) else do{val id=c.getLong(0);val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(6),dp(8),dp(6));background=bg(surfaceColor(),10,1);setOnClickListener{dlg().setItems(arrayOf(tr("Edit","संपादित करें"),tr("Delete","हटाएँ"))){_,w->if(w==0)paymentDialog(id,null)else confirmDeletePayment(id)}.show()}};row.addView(tv("${c.getString(2)} • ${c.getString(1)} • ${money(c.getDouble(4))}",12f,C.TEXT,true));row.addView(tv("${c.getString(3) ?: tr("General / Unassigned","सामान्य / बिना खेत")} • ${localizePaymentNote(c.getString(5))}",10f,C.MUTED));list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(4)})}while(c.moveToNext())};val sc=ScrollView(this).apply{addView(list)};panel.addView(sc,LinearLayout.LayoutParams(-1,0,1f));addOverlay(root,panel,5f,70f,90f,28f)
    }

    private fun paymentDialog(editId:Long?, workerId:Long?){
        val workers=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM workers ORDER BY active DESC,name",null).use{c->while(c.moveToNext())workers.add(c.getLong(0) to c.getString(1))};if(workers.isEmpty()){toast(tr("Add a worker first","पहले मजदूर जोड़ें"));return};val fields=mutableListOf<Pair<Long,String>>();db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext())fields.add(c.getLong(0) to c.getString(1))};var oldWorker=workerId?:workers.first().first;var oldField:Long?=null;var oldDate=today();var oldAmount="";var oldNote="";if(editId!=null)db.readableDatabase.rawQuery("SELECT date,worker_id,field_id,amount,note FROM payments WHERE id=?",arrayOf(editId.toString())).use{c->if(c.moveToFirst()){oldDate=c.getString(0);oldWorker=c.getLong(1);oldField=if(c.isNull(2))null else c.getLong(2);oldAmount=c.getDouble(3).toString();oldNote=c.getString(4)}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(4),0,dp(4),0)};val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,workers.map{it.second});workers.indexOfFirst{it.first==oldWorker}.takeIf{it>=0}?.let(sp::setSelection);box.addView(label(tr("Worker","मजदूर")));box.addView(sp,LinearLayout.LayoutParams(-1,dp(46)));val fieldSp=Spinner(this);fieldSp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(tr("Unassigned / General","सामान्य / खेत नहीं चुना"))+fields.map{it.second});val fieldIndex=oldField?.let{id->fields.indexOfFirst{it.first==id}.takeIf{it>=0}?.plus(1)}?:0;fieldSp.setSelection(fieldIndex);box.addView(label(tr("Payment Field / Plot","भुगतान का खेत / प्लॉट")));box.addView(fieldSp,LinearLayout.LayoutParams(-1,dp(46)));var payDate=oldDate;var date:TextView?=null;date=outline("▣  ${displayDf.format(parseDate(payDate))}"){pickDate(payDate){payDate=it;date?.text="▣  ${displayDf.format(parseDate(payDate))}"}};box.addView(label(tr("Payment Date","भुगतान दिनांक")));box.addView(date,LinearLayout.LayoutParams(-1,dp(44)));val amount=input(tr("Amount (₹)","राशि (₹)"),oldAmount);amount.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;box.addView(label(tr("Amount (₹)","राशि (₹)")));box.addView(amount,LinearLayout.LayoutParams(-1,dp(46)));val paymentMethods=listOf("Cash","Bank Transfer","UPI","Other"); val method=Spinner(this);method.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,paymentMethods.map{paymentMethodLabel(it)});val oldMethod=Regex("^Method:\\s*(Cash|Bank Transfer|UPI|Other)").find(oldNote)?.groupValues?.get(1);if(oldMethod!=null) method.setSelection(paymentMethods.indexOf(oldMethod).coerceAtLeast(0));box.addView(label(tr("Payment Method","भुगतान का तरीका")));box.addView(method,LinearLayout.LayoutParams(-1,dp(46)));val note=input(tr("Note (Optional)","टिप्पणी (वैकल्पिक)"),localizePaymentNote(oldNote));box.addView(label(tr("Note (Optional)","टिप्पणी (वैकल्पिक)")));box.addView(note,LinearLayout.LayoutParams(-1,dp(46)));
        dlg().setTitle(if(editId==null)tr("Make Payment","भुगतान करें") else tr("Edit Payment","भुगतान संपादित करें")).setView(box).setPositiveButton(tr("Save Payment","भुगतान सहेजें")){_,_->val a=amount.text.toString().replace(",",".").toDoubleOrNull()?:0.0;if(a<=0){toast(tr("Enter a valid amount","सही राशि दर्ज करें"));return@setPositiveButton};try{val wid=workers[sp.selectedItemPosition].first;val selectedFieldId=if(fieldSp.selectedItemPosition==0)null else fields[fieldSp.selectedItemPosition-1].first;val rawNote=stripPaymentMethodPrefix(note.text.toString());val n="Method: ${paymentMethods[method.selectedItemPosition]}\n$rawNote";if(editId==null)db.writableDatabase.execSQL("INSERT INTO payments(date,worker_id,field_id,amount,note) VALUES(?,?,?,?,?)",arrayOf(payDate,wid,selectedFieldId,a,n))else db.writableDatabase.execSQL("UPDATE payments SET date=?,worker_id=?,field_id=?,amount=?,note=? WHERE id=?",arrayOf(payDate,wid,selectedFieldId,a,n,editId));payments()}catch(e:Exception){toast(tr("Could not save payment: ${e.message}","भुगतान सहेजा नहीं जा सका: ${e.message}"))}}.setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }
    private fun confirmDeletePayment(id:Long){dlg().setTitle(tr("Delete Payment?","भुगतान हटाएँ?")).setMessage(tr("This payment record will be deleted.","यह भुगतान रिकॉर्ड हटा दिया जाएगा।")).setPositiveButton(tr("Delete","हटाएँ")){_,_->db.writableDatabase.execSQL("DELETE FROM payments WHERE id=?",arrayOf(id));payments()}.setNegativeButton(tr("Cancel","रद्द करें"),null).show()}

    private fun reports(){
        referenceScreen(R.drawable.s_reports, "reports", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot("Worker Wise",5,10,29,8){showWorkerReportFilter()}, Hotspot("Field Wise",35,10,29,8){fieldReport()}, Hotspot("Daily",66,10,29,8){dailyReport()},
            Hotspot("From",5,18,43,9){pickDate(reportFrom){reportFrom=it;reports()}}, Hotspot("To",52,18,43,9){pickDate(reportTo){reportTo=it;reports()}},
            Hotspot("Worker row",5,31,90,14){workerReport()}, Hotspot("Export PDF",5,82,28,8){exportPdf()}, Hotspot("Export CSV",34,82,28,8){exportCsv()}, Hotspot("Share",63,82,30,8){shareReportMenu()},
            Hotspot("Home Nav",0,91,20,9){home()},Hotspot("Attendance Nav",20,91,20,9){attendance()},Hotspot("Workers Nav",40,91,20,9){workers()},Hotspot("Fields Nav",60,91,20,9){fields()},Hotspot("Reports Nav",80,91,20,9){reports()}
        ))
    }
    private fun showWorkerReportFilter(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(5),0,dp(5),0)}
        val q=input(tr("Worker name or ID","मजदूर का नाम या आईडी"),reportWorkerQuery);box.addView(label(tr("Search worker","मजदूर खोजें")));box.addView(q,LinearLayout.LayoutParams(-1,dp(48)))
        box.addView(label(tr("Select fields / plots (leave all unchecked = all fields)","खेत / प्लॉट चुनें (कुछ न चुनें तो सभी खेत)")),LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val fieldRows=mutableListOf<Pair<Long,CheckBox>>()
        db.readableDatabase.rawQuery("SELECT id,name FROM fields WHERE active=1 ORDER BY name",null).use{c->while(c.moveToNext()){
            val id=c.getLong(0);val cb=CheckBox(this);cb.text=c.getString(1);cb.textSize=14f;cb.isChecked=reportFieldIds.contains(id);fieldRows.add(id to cb);list.addView(cb,LinearLayout.LayoutParams(-1,dp(46)))
        }}
        val sc=ScrollView(this).apply{addView(list)};box.addView(sc,LinearLayout.LayoutParams(-1,dp(210)))
        dlg().setTitle(tr("Final Worker Report Filters","मजदूर रिपोर्ट फ़िल्टर")).setView(box)
            .setPositiveButton(tr("Apply Filter","फ़िल्टर लगाएँ")){_,_->reportWorkerQuery=q.text.toString().trim();reportFieldIds=fieldRows.filter{it.second.isChecked}.map{it.first}.toMutableSet();workerReport()}
            .setNeutralButton(tr(tr("All Fields","सभी खेत"),"सभी खेत")){_,_->reportWorkerQuery=q.text.toString().trim();reportFieldIds.clear();workerReport()}
            .setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun workerReport(){
        setContentView(page("👷 ${tr("Worker Reports","मजदूर रिपोर्ट")}","${displayDf.format(parseDate(reportFrom))} — ${displayDf.format(parseDate(reportTo))}",4,"report:worker"))
        val filters=if(reportFieldIds.isEmpty())"" else " AND w.field_id IN (${reportFieldIds.joinToString(",")})"
        val q=reportWorkerQuery.lowercase(Locale.getDefault())
        val totalArgs = mutableListOf(reportFrom, reportTo)
        if (q.isNotBlank()) { val qq = "%$q%"; totalArgs.add(qq); totalArgs.add(qq) }
        val workerFilter = if (q.isBlank()) "" else " AND (lower(wo.name) LIKE ? OR lower(wo.code) LIKE ?)"
        val totalEarned=scalar("SELECT COALESCE(SUM(w.days*w.rate),0) FROM work_entries w JOIN workers wo ON wo.id=w.worker_id WHERE w.date BETWEEN ? AND ? $filters$workerFilter", totalArgs.toTypedArray())
        val rr=LinearLayout(this);addRow(rr,stat(tr("Filtered Work","फ़िल्टर किया गया काम"),money(totalEarned),C.GREEN,C.GREEN_SOFT),1f);content.addView(rr);gap(8)
        val filterText=if(reportFieldIds.isEmpty())tr("All fields","सभी खेत") else "${tr("Selected fields","चयनित खेत")}: ${reportFieldIds.size}"
        content.addView(tv("${tr("Filter","फ़िल्टर")}: ${if(q.isBlank())tr("All workers","सभी मजदूर") else reportWorkerQuery} • $filterText",12f,C.MUTED,true));gap(8)
        db.readableDatabase.rawQuery("SELECT id,code,name FROM workers WHERE (lower(name) LIKE ? OR lower(code) LIKE ?) ORDER BY name",arrayOf("%$q%","%$q%")).use{c->
            if(!c.moveToFirst())content.addView(tv(tr("No workers found.","कोई मजदूर नहीं मिला।"),13f,C.MUTED)) else do{
                val id=c.getLong(0)
                val args=mutableListOf(id.toString(),reportFrom,reportTo); if(reportFieldIds.isNotEmpty()) args.addAll(reportFieldIds.map{it.toString()})
                val d=scalar("SELECT COALESCE(SUM(w.days),0) FROM work_entries w WHERE w.worker_id=? AND w.date BETWEEN ? AND ? $filters",args.take(3+reportFieldIds.size).toTypedArray())
                val e=scalar("SELECT COALESCE(SUM(w.days*w.rate),0) FROM work_entries w WHERE w.worker_id=? AND w.date BETWEEN ? AND ? $filters",args.take(3+reportFieldIds.size).toTypedArray())
                val paidWhere=StringBuilder("worker_id=? AND date BETWEEN ? AND ?"); val paidArgs=mutableListOf(id.toString(),reportFrom,reportTo); if(reportFieldIds.isNotEmpty()){paidWhere.append(" AND field_id IN (${reportFieldIds.joinToString(",")})")}; val p=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE $paidWhere",paidArgs.toTypedArray())
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(10),dp(13),dp(10));background=bg(surfaceColor(),13,1)}
                row.addView(tv("${c.getString(1)}  ${c.getString(2)}",15f,C.TEXT,true))
                row.addView(tv("${days(d)} ${tr("Days","दिन")} • ${money(e)} ${tr("Earned","कमाई")} • ${money(p)} ${tr("Paid","भुगतान")} • ${tr("Balance","बाकी")} ${money(e-p)}",12f,if(e-p>0)C.RED else C.GREEN))
                db.readableDatabase.rawQuery("SELECT f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0) FROM work_entries w JOIN fields f ON f.id=w.field_id WHERE w.worker_id=? AND w.date BETWEEN ? AND ? $filters GROUP BY f.id,f.name ORDER BY f.name",args.take(3+reportFieldIds.size).toTypedArray()).use{fc->
                    while(fc.moveToNext()) row.addView(tv("  • ${fc.getString(0)}: ${days(fc.getDouble(1))} ${tr("Days","दिन")} • ${money(fc.getDouble(2))}",11.5f,C.MUTED).apply{setPadding(0,dp(5),0,0)})
                }
                row.setOnClickListener{workerDetail(id)};content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
            }while(c.moveToNext())
        }
        content.addView(primary(tr("Change Filters","फ़िल्टर बदलें")){showWorkerReportFilter()},LinearLayout.LayoutParams(-1,dp(48)))
    }

    private fun fieldReport(){
        setContentView(page("🌾 ${tr("Field Reports","खेत रिपोर्ट")}",tr("Wages, paid and balance by field","खेत के हिसाब से मजदूरी, भुगतान और बाकी"),4,"report:field"))
        val sql="""SELECT f.id,f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0),COUNT(DISTINCT w.worker_id),COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.field_id=f.id AND p.date BETWEEN ? AND ?),0) FROM fields f LEFT JOIN work_entries w ON w.field_id=f.id AND w.date BETWEEN ? AND ? GROUP BY f.id,f.name ORDER BY f.name"""
        db.readableDatabase.rawQuery(sql,arrayOf(reportFrom,reportTo,reportFrom,reportTo)).use{c->
            if(!c.moveToFirst()) content.addView(tv(tr("No field report available.","कोई खेत रिपोर्ट उपलब्ध नहीं है।"),13f,C.MUTED)) else do{
                val earned=c.getDouble(3);val paid=c.getDouble(5);val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(13),dp(11),dp(13),dp(11));background=bg(if(darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(),14,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER);setOnClickListener{fieldDetail(c.getLong(0))}}
                row.addView(tv("🌾 ${c.getString(1)}",15f,C.TEXT,true));row.addView(tv("${c.getInt(4)} ${if(c.getInt(4)==1)tr("Worker","मजदूर") else tr("Workers","मजदूर")} • ${days(c.getDouble(2))} ${tr("Days","दिन")} • ${tr("Wages","मजदूरी")}: ${money(earned)} • ${tr("Paid","भुगतान")}: ${money(paid)} • ${tr("Balance","बाकी")}: ${money(earned-paid)}",12f,if(earned-paid>0)C.RED else C.GREEN));content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
            }while(c.moveToNext())
        }
    }

    private fun paymentReport(){
        setContentView(page("💵 ${tr("Payment Report","भुगतान रिपोर्ट")}","${displayDf.format(parseDate(reportFrom))} — ${displayDf.format(parseDate(reportTo))}",4,"report:payment"))
        val total=scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date BETWEEN ? AND ?",arrayOf(reportFrom,reportTo))
        content.addView(stat(tr("Total Payments","कुल भुगतान"),money(total),C.BLUE,C.BLUE_SOFT));gap(10)
        db.readableDatabase.rawQuery(
            "SELECT p.date,w.name,p.amount,p.note FROM payments p JOIN workers w ON w.id=p.worker_id WHERE p.date BETWEEN ? AND ? ORDER BY p.date DESC,p.id DESC",
            arrayOf(reportFrom,reportTo)
        ).use{c->
            if(!c.moveToFirst()){
                content.addView(tv(tr("No payments found in this period.","इस अवधि में कोई भुगतान नहीं मिला।"),13f,C.MUTED))
            }else do{
                val row=LinearLayout(this).apply{
                    orientation=LinearLayout.VERTICAL
                    setPadding(dp(13),dp(11),dp(13),dp(11))
                    background=bg(surfaceColor(),14,1)
                }
                val h=LinearLayout(this)
                h.addView(tv("${c.getString(1)}  •  ${displayDf.format(parseDate(c.getString(0)))}",14f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
                h.addView(tv(money(c.getDouble(2)),14f,C.GREEN,true))
                row.addView(h)
                if(c.getString(3).isNotBlank())row.addView(tv(localizePaymentNote(c.getString(3)),12f,C.MUTED).apply{setPadding(0,dp(5),0,0)})
                content.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
            }while(c.moveToNext())
        }
    }

    private fun dailyShift(delta:Int, fieldFilter:String?){
        val cal=Calendar.getInstance().apply{time=parseDate(reportTo);add(Calendar.DAY_OF_MONTH,delta)}
        reportTo=df.format(cal.time)
        if(reportTo < reportFrom) reportFrom=reportTo
        dailyReport(fieldFilter)
    }

    private fun dailyReport(fieldFilter:String?=null){
        val root=referenceScreen(R.drawable.s_daily, "report:daily", listOf(
            Hotspot("Back",0,0,12,10){reports()}, Hotspot("Prev",5,8,25,8){dailyShift(-1,fieldFilter)}, Hotspot("Next",70,8,25,8){dailyShift(1,fieldFilter)},
            Hotspot(tr("All Fields","सभी खेत"),5,17,25,7){dailyReport()}, Hotspot("Paddy",32,17,20,7){dailyReport("Paddy")}, Hotspot("Sugarcane",54,17,22,7){dailyReport("Sugarcane")}, Hotspot("Banana",77,17,18,7){dailyReport("Banana")},
            Hotspot("Paddy row",5,30,90,12){dailyReport(fieldFilter)}, Hotspot("Sugarcane row",5,43,90,12){dailyReport(fieldFilter)}, Hotspot("Banana row",5,56,90,12){dailyReport(fieldFilter)}, Hotspot("Mustard row",5,69,90,12){dailyReport(fieldFilter)},
            Hotspot("Home Nav",0,91,20,9){home()},Hotspot("Attendance Nav",20,91,20,9){attendance()},Hotspot("Workers Nav",40,91,20,9){workers()},Hotspot("Fields Nav",60,91,20,9){fields()},Hotspot("Reports Nav",80,91,20,9){reports()}
        ))
        // Cover the static crop rows with a real, filter-aware report surface while preserving the reference frame/header.
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));background=bg(if(darkMode) 0xFF101412.toInt() else lightSurfaceColor(),12,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER)}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(tv(tr("Daily details","दैनिक विवरण"),14f,C.TEXT,true),LinearLayout.LayoutParams(0,-2,1f))
        top.addView(tv(displayDf.format(parseDate(reportTo)),12f,C.MUTED,true))
        panel.addView(top)
        val filters=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false}
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val crops=listOf(null,"Paddy","Sugarcane","Banana","Mustard")
        crops.forEach { crop ->
            val title=when(crop){null->tr(tr("All Fields","सभी खेत"),"सभी खेत");"Paddy"->tr("Paddy","धान");"Sugarcane"->tr("Sugarcane","गन्ना");"Banana"->tr("Banana","केला");else->tr("Mustard","सरसों")}
            row.addView(pill(title, crop==fieldFilter){dailyReport(crop) },LinearLayout.LayoutParams(-2,-2).apply{marginEnd=dp(6)})
        }
        filters.addView(row);panel.addView(filters)
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val args=mutableListOf(reportTo)
        val where=StringBuilder("w.date=?")
        if(fieldFilter!=null){if(fieldFilter=="Paddy") where.append(" AND lower(f.crop_type) IN (lower(?), lower(?) )").also{args.add("Paddy");args.add("Paddy (Dhaan)")} else {where.append(" AND lower(f.crop_type)=lower(?)");args.add(fieldFilter)}}
        val sql="""SELECT f.id,f.name,f.crop_type,COUNT(DISTINCT tm.worker_id),COALESCE(SUM(COALESCE(w.days,0)),0),COALESCE(SUM(COALESCE(w.days,0)*COALESCE(w.rate,tmRate.rate)),0)
                   FROM team_members tm JOIN fields f ON f.id=tm.field_id
                  
                   LEFT JOIN work_entries w ON w.date=tm.date AND w.worker_id=tm.worker_id AND w.field_id=tm.field_id
                   LEFT JOIN workers tmRate ON tmRate.id=tm.worker_id
                   WHERE tm.date=?${if(fieldFilter==null) "" else if(fieldFilter=="Paddy") " AND lower(f.crop_type) IN (lower(?), lower(?))" else " AND lower(f.crop_type)=lower(?)"}
                   GROUP BY f.id,f.name,f.crop_type ORDER BY f.name"""
        db.readableDatabase.rawQuery(sql,args.toTypedArray()).use { c ->
            if(!c.moveToFirst()) list.addView(tv(tr("No records found","कोई रिकॉर्ड नहीं मिला।"),13f,C.MUTED).apply{setPadding(0,dp(10),0,dp(10))})
            else do {
                val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(11),dp(8),dp(11),dp(8));background=bg(if(darkMode) 0xFF1A231E.toInt() else lightSurfaceColor(),11,1,if(darkMode) 0xFF3A4A41.toInt() else C.BORDER);setOnClickListener{dailyFieldDetail(c.getLong(0))}}
                val cropName=when(c.getString(2)){"Paddy (Dhaan)","Paddy"->tr("Paddy","धान");"Sugarcane"->tr("Sugarcane","गन्ना");"Banana"->tr("Banana","केला");"Mustard"->tr("Mustard","सरसों");else->c.getString(2)}
                card.addView(tv("🌾 $cropName",14f,C.TEXT,true))
                card.addView(tv("${c.getInt(3)} ${tr("Workers","मजदूर")}  •  ${days(c.getDouble(4))} ${tr("Days","दिन")}  •  ${money(c.getDouble(5))}",12f,C.MUTED))
                card.contentDescription=tr("${c.getString(1)} daily details","${c.getString(1)} का दैनिक विवरण")
                list.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})
            } while(c.moveToNext())
        }
        scroll.addView(list)
        panel.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val lp=FrameLayout.LayoutParams(-1,0).apply{height=pxY(61);leftMargin=pxX(3);topMargin=pxY(28)}
        root.addView(panel,lp)
        localizeTree(panel)
    }

    private fun exportCsv(){
        try{
            val sb=StringBuilder("\uFEFF${tr("Worker","मजदूर")},${tr("Worker ID","मजदूर आईडी")},${tr("Field","खेत")},${tr("Total Days","कुल दिन")},${tr("Wages","मजदूरी")},${tr("Paid","भुगतान")},${tr("Balance","बाकी")}\n")
            val fieldClause = if(reportFieldIds.isEmpty()) "" else " AND w.field_id IN (${reportFieldIds.joinToString(",")})"
            val workerClause = if(reportWorkerQuery.isBlank()) "" else " AND (lower(wo.name) LIKE ? OR lower(wo.code) LIKE ?)"
            val args = mutableListOf(reportFrom,reportTo)
            if(reportWorkerQuery.isNotBlank()){val qq="%${reportWorkerQuery.lowercase(Locale.getDefault())}%";args.add(qq);args.add(qq)}
            val sql="""SELECT wo.name,wo.code,f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0),
                COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.worker_id=w.worker_id AND p.field_id=w.field_id AND p.date BETWEEN ? AND ?),0)
                FROM work_entries w JOIN workers wo ON wo.id=w.worker_id JOIN fields f ON f.id=w.field_id
                WHERE w.date BETWEEN ? AND ? $fieldClause $workerClause
                GROUP BY w.worker_id,w.field_id,wo.name,wo.code,f.name ORDER BY wo.name,f.name"""
            val qArgs=mutableListOf(reportFrom,reportTo,reportFrom,reportTo);if(reportWorkerQuery.isNotBlank()){val qq="%${reportWorkerQuery.lowercase(Locale.getDefault())}%";qArgs.add(qq);qArgs.add(qq)}
            db.readableDatabase.rawQuery(sql,qArgs.toTypedArray()).use{c->while(c.moveToNext()){
                val earned=c.getDouble(4);val paid=c.getDouble(5)
                sb.append(csv(c.getString(0))).append(',').append(csv(c.getString(1))).append(',').append(csv(c.getString(2))).append(',')
                    .append(c.getDouble(3)).append(',').append(earned).append(',').append(paid).append(',').append(earned-paid).append('\n')
            }}
            pendingExport=sb.toString().toByteArray(Charsets.UTF_8)
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="text/csv";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_${reportFrom}_to_${reportTo}.csv");addCategory(Intent.CATEGORY_OPENABLE)}
            startActivityForResult(i,902)
        }catch(e:Exception){pendingExport=null;toast(tr("CSV export failed: ${e.message}","CSV निर्यात विफल: ${e.message}"))}
    }
    private fun csv(v:String)="\""+v.replace("\"","\"\"")+"\""
    private fun exportPdf(){
        try{
            val pdf=android.graphics.pdf.PdfDocument()
            val bold=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.GREEN_DARK;textSize=18f;typeface=Typeface.DEFAULT_BOLD}
            val normal=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.TEXT;textSize=10.5f}
            val muted=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=C.MUTED;textSize=9.5f}
            val rows=mutableListOf<Array<String>>()
            val fieldClause = if(reportFieldIds.isEmpty()) "" else " AND w.field_id IN (${reportFieldIds.joinToString(",")})"
            val workerClause = if(reportWorkerQuery.isBlank()) "" else " AND (lower(wo.name) LIKE ? OR lower(wo.code) LIKE ?)"
            val qArgs=mutableListOf(reportFrom,reportTo,reportFrom,reportTo)
            if(reportWorkerQuery.isNotBlank()){val qq="%${reportWorkerQuery.lowercase(Locale.getDefault())}%";qArgs.add(qq);qArgs.add(qq)}
            val sql="""SELECT wo.name,wo.code,f.name,COALESCE(SUM(w.days),0),COALESCE(SUM(w.days*w.rate),0),
                COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.worker_id=w.worker_id AND p.field_id=w.field_id AND p.date BETWEEN ? AND ?),0)
                FROM work_entries w JOIN workers wo ON wo.id=w.worker_id JOIN fields f ON f.id=w.field_id
                WHERE w.date BETWEEN ? AND ? $fieldClause $workerClause
                GROUP BY w.worker_id,w.field_id,wo.name,wo.code,f.name ORDER BY wo.name,f.name"""
            db.readableDatabase.rawQuery(sql,qArgs.toTypedArray()).use{c->while(c.moveToNext()){
                val earned=c.getDouble(4);val paid=c.getDouble(5)
                rows.add(arrayOf(c.getString(0),c.getString(1),c.getString(2),days(c.getDouble(3)),money(earned),money(paid),money(earned-paid)))
            }}
            var index=0;var pageNo=1
            while(index<rows.size || pageNo==1){
                val info=android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create()
                val page=pdf.startPage(info);var y=42f
                page.canvas.drawText("Majdoor Hisaab PRO",30f,y,bold);y+=22f
                page.canvas.drawText(tr("Worker / Field Report","मजदूर / खेत रिपोर्ट") + "  •  $reportFrom ${tr("to","से")} $reportTo",30f,y,normal);y+=22f
                page.canvas.drawText(tr("Worker","मजदूर"),30f,y,muted);page.canvas.drawText(tr("ID","आईडी"),145f,y,muted);page.canvas.drawText(tr("Field","खेत"),200f,y,muted);page.canvas.drawText(tr("Days","दिन"),340f,y,muted);page.canvas.drawText(tr("Wages","मजदूरी"),385f,y,muted);page.canvas.drawText(tr("Paid","भुगतान"),455f,y,muted);page.canvas.drawText(tr("Balance","बाकी"),510f,y,muted);y+=16f
                var countOnPage=0
                while(index<rows.size && countOnPage<36){
                    val r=rows[index]
                    page.canvas.drawText(r[0].take(17),30f,y,normal);page.canvas.drawText(r[1].take(8),145f,y,normal);page.canvas.drawText(r[2].take(20),200f,y,normal);page.canvas.drawText(r[3],340f,y,normal);page.canvas.drawText(r[4],385f,y,normal);page.canvas.drawText(r[5],455f,y,normal);page.canvas.drawText(r[6],510f,y,normal)
                    y+=19f;index++;countOnPage++
                }
                if(rows.isEmpty())page.canvas.drawText(tr("No records found for the selected period.","चयनित अवधि में कोई रिकॉर्ड नहीं मिला।"),30f,y,normal)
                page.canvas.drawText("${tr("Page","पृष्ठ")} $pageNo",500f,815f,muted);pdf.finishPage(page);pageNo++
            }
            val out=java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();pendingExport=out.toByteArray()
            val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/pdf";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_${reportFrom}_to_${reportTo}.pdf");addCategory(Intent.CATEGORY_OPENABLE)}
            startActivityForResult(i,902)
        }catch(e:Exception){pendingExport=null;toast(tr("PDF export failed: ${e.message}","PDF निर्यात विफल: ${e.message}"))}
    }

    private fun shareReportSummary(){
        val (workWhere, workArgs) = reportWorkerWhere("w")
        val earned=scalar("SELECT COALESCE(SUM(w.days*w.rate),0) FROM work_entries w WHERE $workWhere",workArgs.toTypedArray())
        val td=scalar("SELECT COALESCE(SUM(w.days),0) FROM work_entries w WHERE $workWhere",workArgs.toTypedArray())
        val payClauses = mutableListOf("p.date BETWEEN ? AND ?")
        val payArgs = mutableListOf(reportFrom, reportTo)
        if (reportWorkerQuery.isNotBlank()) {
            payClauses.add("p.worker_id IN (SELECT id FROM workers WHERE lower(name) LIKE ? OR lower(code) LIKE ?)")
            val qv = "%${reportWorkerQuery.lowercase(Locale.getDefault())}%"; payArgs.add(qv); payArgs.add(qv)
        }
        if (reportFieldIds.isNotEmpty()) payClauses.add("p.field_id IN (${reportFieldIds.joinToString(",")})")
        val paid=scalar("SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE ${payClauses.joinToString(" AND ")}",payArgs.toTypedArray())
        val scope = buildString {
            if (reportWorkerQuery.isNotBlank()) append(tr("Worker: $reportWorkerQuery; ", "मजदूर: $reportWorkerQuery; "))
            append(if (reportFieldIds.isEmpty()) tr("All fields","सभी खेत") else "${reportFieldIds.size} ${tr("selected fields","चयनित खेत")}")
        }
        val text="""Majdoor Hisaab PRO
${tr("Labour Report","मजदूर रिपोर्ट")}
${tr("Period","अवधि")}: $reportFrom ${tr("to","से")} $reportTo
${tr("Scope","दायरा")}: $scope
${tr("Total Days","कुल दिन")}: ${days(td)}
${tr("Total Wages","कुल मजदूरी")}: ${money(earned)}
${tr("Total Paid","कुल भुगतान")}: ${money(paid)}
${tr("Balance","बाकी")}: ${money(earned-paid)}

${tr("Note","नोट")}: ${tr("Selected-field reports count only payments linked to those selected fields; unassigned/general payments remain outside field-specific balance.","चयनित खेत की रिपोर्ट में केवल उसी खेत से जुड़े भुगतान शामिल होते हैं; सामान्य/बिना खेत वाले भुगतान खेत के हिसाब में शामिल नहीं होते।")}"""
        val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_SUBJECT,tr("Majdoor Hisaab PRO Report","मजदूर हिसाब रिपोर्ट"));putExtra(Intent.EXTRA_TEXT,text)}
        startActivity(Intent.createChooser(i,tr("Share report","रिपोर्ट साझा करें")))
    }

    private fun shareReportMenu(){
        dlg().setTitle(tr("Share Report","रिपोर्ट साझा करें"))
            .setItems(arrayOf(tr("WhatsApp","व्हाट्सऐप"),tr("Other apps","अन्य ऐप"))){_,which->if(which==0)shareReportWhatsApp() else shareReportSummary()}
            .setNegativeButton(tr("Cancel","रद्द करें"),null).show()
    }

    private fun shareReportWhatsApp(){
        val (workWhere, workArgs) = reportWorkerWhere("w")
        val earned=scalar("SELECT COALESCE(SUM(w.days*w.rate),0) FROM work_entries w WHERE $workWhere",workArgs.toTypedArray())
        val td=scalar("SELECT COALESCE(SUM(w.days),0) FROM work_entries w WHERE $workWhere",workArgs.toTypedArray())
        val payClauses = mutableListOf("p.date BETWEEN ? AND ?")
        val payArgs = mutableListOf(reportFrom, reportTo)
        if (reportWorkerQuery.isNotBlank()) {
            payClauses.add("p.worker_id IN (SELECT id FROM workers WHERE lower(name) LIKE ? OR lower(code) LIKE ?)")
            val qv = "%${reportWorkerQuery.lowercase(Locale.getDefault())}%"; payArgs.add(qv); payArgs.add(qv)
        }
        if (reportFieldIds.isNotEmpty()) payClauses.add("p.field_id IN (${reportFieldIds.joinToString(",")})")
        val paid=scalar("SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE ${payClauses.joinToString(" AND ")}",payArgs.toTypedArray())
        val text="""Majdoor Hisaab PRO
${tr("Labour Report","मजदूर रिपोर्ट")}
${tr("Period","अवधि")}: $reportFrom ${tr("to","से")} $reportTo
${tr("Scope","दायरा")}: ${if(reportWorkerQuery.isBlank()) tr("All workers","सभी मजदूर") else reportWorkerQuery} • ${if(reportFieldIds.isEmpty()) tr("All fields","सभी खेत") else "${reportFieldIds.size} ${tr("selected fields","चयनित खेत")}"}
${tr("Total Days","कुल दिन")}: ${days(td)}
${tr("Total Wages","कुल मजदूरी")}: ${money(earned)}
${tr("Total Paid","कुल भुगतान")}: ${money(paid)}
${tr("Balance","बाकी")}: ${money(earned-paid)}
${tr("Note","नोट")}: ${tr("Selected-field reports count only payments linked to those selected fields; unassigned/general payments remain outside field-specific balance.","चयनित खेत की रिपोर्ट में केवल उसी खेत से जुड़े भुगतान शामिल होते हैं; सामान्य/बिना खेत वाले भुगतान खेत के हिसाब में शामिल नहीं होते।")}"""
        val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text);setPackage("com.whatsapp")}
        try{startActivity(i)}catch(_:Exception){toast(tr("WhatsApp is not installed","WhatsApp इंस्टॉल नहीं है"))}
    }

    private fun backup(){
        referenceScreen(R.drawable.s_settings, "backup", listOf(
            Hotspot("Back",0,0,12,10){home()}, Hotspot("Create Backup",8,14,40,15){createBackup()}, Hotspot("Restore Backup",52,14,40,15){pickRestore()},
            Hotspot("Currency",8,48,84,8){currencyDialog()}, Hotspot("Language",8,57,84,8){languageDialog()}, Hotspot("Theme",8,66,84,8){themeDialog()}, Hotspot("Reset",8,74,84,8){confirmResetReference()}
        ))
    }
    private fun confirmResetReference(){dlg().setTitle(tr("Reset App Data?","ऐप का डेटा रीसेट करें?")).setMessage(tr("All workers, fields, attendance and payments will be deleted.","सभी मजदूर, खेत, उपस्थिति और भुगतान हटा दिए जाएंगे।")).setPositiveButton(tr("Reset","रीसेट करें")){_,_->db.writableDatabase.execSQL("DELETE FROM work_entries");db.writableDatabase.execSQL("DELETE FROM team_members");db.writableDatabase.execSQL("DELETE FROM payments");db.writableDatabase.execSQL("DELETE FROM workers");db.writableDatabase.execSQL("DELETE FROM fields");File(filesDir,"backup_photos").deleteRecursively();toast(tr("App data reset","ऐप डेटा रीसेट हो गया"));home()}.setNegativeButton(tr("Cancel","रद्द करें"),null).show()}
    private fun currencyDialog(){dlg().setTitle(tr("Currency","मुद्रा")).setItems(arrayOf("₹ रुपये","$ डॉलर","€ यूरो")){_,which->getPreferences(0).edit().putString("currency",arrayOf("₹","$","€")[which]).apply();toast(tr("Currency saved","मुद्रा सहेजी गई"))}.show()}
    private fun languageDialog(){
        dlg().setTitle(tr("Language","भाषा")).setItems(arrayOf("English","हिन्दी")){_,which->
            getPreferences(0).edit().putString("language",if(which==0)"English" else "Hindi").apply()
            toast(if(which==0)"English selected" else "हिन्दी चुनी गई")
            home()
        }.show()
    }
    private fun themeDialog(){
        dlg().setTitle(tr("Theme","थीम")).setItems(arrayOf(tr("Light","लाइट"),tr("Dark","डार्क"))){_,which->
            darkMode=which==1
            getPreferences(0).edit().putBoolean("dark_mode",darkMode).apply()
            applyThemeBars()
            toast(if(darkMode)tr("Dark theme enabled","डार्क थीम चालू") else tr("Light theme enabled","लाइट थीम चालू"))
            home()
        }.show()
    }
    private fun createBackup(){try{val d=db.writableDatabase;d.execSQL("PRAGMA wal_checkpoint(TRUNCATE)");validateDatabase(d);val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/zip";putExtra(Intent.EXTRA_TITLE,"Majdoor_Hisaab_Backup_${today()}.zip");addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,901)}catch(e:Exception){toast(tr("Backup could not be created: ${e.message}","बैकअप नहीं बनाया जा सका: ${e.message}"))}}
    private fun pickRestore(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/zip","application/octet-stream"));addCategory(Intent.CATEGORY_OPENABLE)};startActivityForResult(i,900)}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data?.data==null)return;try{when(requestCode){
                901->{createZipBackup(data.data!!);toast(tr("Backup ZIP saved successfully","बैकअप ZIP सफलतापूर्वक सहेजा गया"))}
                900->validateAndConfirmRestore(data.data!!)
                902->{pendingExport?.let{bytes->contentResolver.openOutputStream(data.data!!)?.use{it.write(bytes)}?:throw Exception(tr("File could not be saved","फ़ाइल सहेजी नहीं जा सकी"))};pendingExport=null;toast(tr("Report saved successfully","रिपोर्ट सफलतापूर्वक सहेजी गई"))}
                910->{contentResolver.takePersistableUriPermission(data.data!!,Intent.FLAG_GRANT_READ_URI_PERMISSION);db.writableDatabase.execSQL("UPDATE workers SET photo_uri=? WHERE id=?",arrayOf(data.data!!.toString(),photoTargetId));photoTargetType="";photoTargetId=-1;workers()}
                911->{contentResolver.takePersistableUriPermission(data.data!!,Intent.FLAG_GRANT_READ_URI_PERMISSION);db.writableDatabase.execSQL("UPDATE fields SET photo_uri=? WHERE id=?",arrayOf(data.data!!.toString(),photoTargetId));photoTargetType="";photoTargetId=-1;fields()}
            }}catch(e:Exception){pendingExport=null;toast(tr("Export error: ${e.message}","निर्यात में त्रुटि: ${e.message}"))}}
    private fun createZipBackup(uri:Uri){
        val f=getDatabasePath(DB_NAME);val d=db.writableDatabase;d.execSQL("PRAGMA wal_checkpoint(TRUNCATE)");validateDatabase(d)
        contentResolver.openOutputStream(uri)?.use{out->ZipOutputStream(out).use{z->
            z.putNextEntry(ZipEntry("majdoor_hisaab.db"));f.inputStream().use{it.copyTo(z)};z.closeEntry()
            db.readableDatabase.rawQuery("SELECT id,photo_uri FROM workers WHERE photo_uri<>''",null).use{c->while(c.moveToNext()){if(!backupPhotoEntry(z,"workers/${c.getLong(0)}",c.getString(1)))throw Exception(tr("A worker photo could not be backed up","एक मजदूर की फोटो का बैकअप नहीं बन सका"))}}
            db.readableDatabase.rawQuery("SELECT id,photo_uri FROM fields WHERE photo_uri<>''",null).use{c->while(c.moveToNext()){if(!backupPhotoEntry(z,"fields/${c.getLong(0)}",c.getString(1)))throw Exception(tr("A field photo could not be backed up","एक खेत की फोटो का बैकअप नहीं बन सका"))}}
            z.putNextEntry(ZipEntry("backup_info.txt"));z.write((backupMetadata(d)+"Photos: included when readable\n").toByteArray(Charsets.UTF_8));z.closeEntry()
        }}?:throw Exception(tr("File could not be saved","फ़ाइल सहेजी नहीं जा सकी"))
    }
    private fun backupPhotoEntry(z:ZipOutputStream,base:String,uriText:String):Boolean{try{val uri=Uri.parse(uriText);contentResolver.openInputStream(uri)?.use{input->z.putNextEntry(ZipEntry("photos/$base.jpg"));input.copyTo(z);z.closeEntry();return true}}catch(_:Exception){};return false}

    private fun backupMetadata(d:SQLiteDatabase):String{val integrity=d.rawQuery("PRAGMA integrity_check",null).use{if(it.moveToFirst())it.getString(0) else "unknown"};val foreignKeys=d.rawQuery("PRAGMA foreign_key_check",null).use{if(it.moveToFirst())"FAIL" else "PASS"};val marker=d.rawQuery("SELECT value FROM settings WHERE key='app_marker'",null).use{if(it.moveToFirst())it.getString(0) else ""};val schema=d.rawQuery("SELECT value FROM settings WHERE key='schema_version'",null).use{if(it.moveToFirst())it.getString(0) else ""};return "Majdoor Hisaab PRO\nApp Marker: $marker\nSchema Version: $schema\nSQLite user_version: ${d.version}\nIntegrity Check: $integrity\nForeign Key Check: $foreignKeys\nBackup Date: ${today()}\n"}
    private fun validateDatabase(d:SQLiteDatabase){d.rawQuery("PRAGMA integrity_check",null).use{if(!it.moveToFirst()||it.getString(0)!="ok")throw Exception("Database integrity check failed")};d.rawQuery("SELECT value FROM settings WHERE key='app_marker'",null).use{if(!it.moveToFirst()||it.getString(0)!=APP_MARKER)throw Exception("App database marker missing")};d.rawQuery("SELECT value FROM settings WHERE key='schema_version'",null).use{if(!it.moveToFirst()||it.getString(0).toIntOrNull()!=DB_VERSION)throw Exception("Database schema mismatch")};if(d.version!=DB_VERSION)throw Exception("SQLite user_version mismatch");d.rawQuery("PRAGMA foreign_key_check",null).use{if(it.moveToFirst())throw Exception("Foreign key error")}}
    private fun extractBackupDatabase(zipFile:File,destination:File){var found=false;zipFile.inputStream().use{inp->ZipInputStream(inp).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory&&e.name=="majdoor_hisaab.db"){destination.outputStream().use{out->z.copyTo(out)};found=true};z.closeEntry();e=z.nextEntry}}};if(!found||!destination.exists()||destination.length()==0L)throw Exception(tr("Invalid backup","अमान्य बैकअप"))}
    private fun validateAndConfirmRestore(uri:Uri){val zip=File(cacheDir,"restore_check.zip");val tmp=File(cacheDir,"restore_check.db");try{contentResolver.openInputStream(uri)?.use{zip.outputStream().use{o->it.copyTo(o)}}?:throw Exception(tr("Backup could not be read","बैकअप पढ़ा नहीं जा सका"));extractBackupDatabase(zip,tmp);val t=SQLiteDatabase.openDatabase(tmp.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{validateDatabase(t)}finally{t.close()};dlg().setTitle(tr("Restore Backup?","बैकअप पुनर्स्थापित करें?")).setMessage(tr("Backup is valid. Your current data will be replaced.","बैकअप सही है। आपका वर्तमान डेटा बदल दिया जाएगा।")).setPositiveButton(tr("Restore","पुनर्स्थापित करें")){_,_->restoreFrom(uri)}.setNegativeButton(tr("Cancel","रद्द करें"),null).show()}catch(e:Exception){toast(e.message?:tr("Invalid backup","अमान्य बैकअप"))}finally{zip.delete();tmp.delete()}}
    private fun restoreFrom(uri:Uri){val zip=File(cacheDir,"restore_ready.zip");val tmp=File(cacheDir,"restore_ready.db");val target=getDatabasePath(DB_NAME);val old=File(target.absolutePath+".before_restore");try{contentResolver.openInputStream(uri)?.use{zip.outputStream().use{o->it.copyTo(o)}}?:throw Exception(tr("Backup could not be read","बैकअप पढ़ा नहीं जा सका"));extractBackupDatabase(zip,tmp);val t=SQLiteDatabase.openDatabase(tmp.absolutePath,null,SQLiteDatabase.OPEN_READONLY);try{validateDatabase(t)}finally{t.close()};db.close();if(target.exists())target.copyTo(old,true);tmp.copyTo(target,true);tmp.delete();extractBackupPhotos(zip);zip.delete();db=DB(this);db.writableDatabase;restorePhotoUris();validateDatabase(db.readableDatabase);old.delete();toast(tr("Restore completed","बैकअप पुनर्स्थापित हो गया"));home()}catch(e:Exception){tmp.delete();zip.delete();try{if(old.exists()){if(::db.isInitialized)db.close();old.copyTo(target,true);old.delete()}}catch(_:Exception){};db=DB(this);toast(tr("Restore error: ${e.message}","बैकअप पुनर्स्थापित करने में त्रुटि: ${e.message}"))}}
    private fun extractBackupPhotos(zipFile:File){val dir=File(filesDir,"backup_photos");if(dir.exists())dir.deleteRecursively();dir.mkdirs();zipFile.inputStream().use{inp->ZipInputStream(inp).use{z->var e=z.nextEntry;while(e!=null){if(!e.isDirectory&&e.name.startsWith("photos/")){val safe=e.name.substringAfter("photos/").replace("/","_");File(dir,safe).outputStream().use{out->z.copyTo(out)}};z.closeEntry();e=z.nextEntry}}}}
    private fun restorePhotoUris(){val dir=File(filesDir,"backup_photos");val d=db.writableDatabase;d.execSQL("UPDATE workers SET photo_uri='' WHERE photo_uri<>''");d.execSQL("UPDATE fields SET photo_uri='' WHERE photo_uri<>''");d.rawQuery("SELECT id FROM workers",null).use{c->while(c.moveToNext()){val f=File(dir,"workers_${c.getLong(0)}.jpg");if(f.exists())d.execSQL("UPDATE workers SET photo_uri=? WHERE id=?",arrayOf(Uri.fromFile(f).toString(),c.getLong(0)))}};d.rawQuery("SELECT id FROM fields",null).use{c->while(c.moveToNext()){val f=File(dir,"fields_${c.getLong(0)}.jpg");if(f.exists())d.execSQL("UPDATE fields SET photo_uri=? WHERE id=?",arrayOf(Uri.fromFile(f).toString(),c.getLong(0)))}}}

    private fun pickDate(current:String,done:(String)->Unit){val cal=Calendar.getInstance();try{cal.time=df.parse(current)?:Date()}catch(_:Exception){};DatePickerDialog(this,{_,y,m,d->val c=Calendar.getInstance();c.set(y,m,d);done(df.format(c.time))},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()}

}
