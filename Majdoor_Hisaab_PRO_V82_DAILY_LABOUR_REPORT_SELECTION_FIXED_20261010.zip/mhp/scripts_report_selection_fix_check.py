#!/usr/bin/env python3
from pathlib import Path
import re, sys
p=Path(__file__).resolve().parents[0]/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'selected rows are derived from selected worker IDs': 'val selectedRows=rows.filter{it.labour.id in selectedWorkers}' in s,
 'PDF export receives only selected rows': 'exportAllWorkersLedgerPdf(context,"चुने_मजदूरों_का_हिसाब",selectedDateLabel,selectedFieldLabel,selectedRows,selectedWage,selectedPaid,background=true)' in s,
 'photo export receives only selected rows': 'selectedRows.map{"${it.labour.name} • काम ${money(it.workDays)} दिन • मजदूरी ₹${money(it.wage)} • भुगतान ₹${money(it.paid)} • बकाया ₹${money(it.wage-it.paid)}"}' in s,
 'selected totals are calculated from selected rows': 'val selectedWage = selectedRows.sumOf { it.wage }' in s and 'val selectedPaid = selectedRows.sumOf { it.paid }' in s,
 'empty selection is blocked for PDF/photo': s.count('if(selectedRows.isEmpty()) validation="पहले सूची में से मजदूर चुनें।"') >= 2,
 'selection controls appear before export controls': s.index('items(rows,key={it.labour.id})') < s.index('PDF / फोटो में केवल चुने हुए मजदूर'),
 'individual PDF omits zero-fraction attendance': 'attendanceRows.filter { it.fraction > 0.0 }' in s,
 'individual PDF has payment column and no note box': '"भुगतान (₹)"' in s and 'intentionally no note box' in s.lower(),
 'new-period worker detail excludes dates through closure': 'it.date>lastClosedThrough' in s,
 'attendance writes on closed dates are blocked': 'if(closedThrough.isNotBlank() && x.date<=closedThrough)' in s,
}
failed=[]
for name, ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} targeted checks passed')
sys.exit(1 if failed else 0)
