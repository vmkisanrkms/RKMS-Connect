# Majdoor Hisaab PRO — Payment & Wage History Fix Audit

## Fixed

### Payment field linking
- Payment records now store `fieldId` and optional `cropId`.
- When payment is opened from Attendance (`₹+`), the current field is locked and cannot be changed accidentally.
- The current crop is carried forward when known; with multiple crops it can be selected optionally.
- Payment cannot be saved from the Attendance flow without a valid field.
- Labour detail payment remains available as a general payment; field selection is optional there.
- Payment history displays field and crop (when available).
- Old payment JSON remains backward-compatible because missing `cropId` defaults to blank.

### Wage history
- Adding a labour with a non-zero daily rate creates an initial effective-date rate record for today.
- Editing a labour's daily rate creates/replaces today's effective rate record instead of silently changing historical rate history.
- Explicit `दिहाड़ी बदलें` entries remain date-effective and replace duplicates for the same labour/date.
- Attendance stores a rate snapshot, so old attendance amounts do not change when a new rate becomes effective.
- Labour list and labour detail use `rateFor(date)` to show the effective rate.
- Rate history is shown newest-first.
- Invalid calendar dates are rejected using strict `yyyy-MM-dd` validation.

## Accounting rule
Payment is settlement of labour owed; it is not added again as a separate expense. Labour cost comes from attendance snapshots.

## Multi-crop attendance
Attendance key remains `labour + field + crop + date`, preventing one crop's attendance from overwriting another crop's attendance.

## v4 Display + Date Validation Fix
- User-facing stored dates are displayed as DD/MM/YYYY while storage remains YYYY-MM-DD.
- Dashboard and Attendance headers now use DD/MM/YYYY display.
- Expense, Sale, Attendance, Payment and Wage History lists display DD/MM/YYYY.
- Date validation requires exact YYYY-MM-DD and strict calendar validity (e.g. 2026-02-29 is rejected).
- Invalid date inputs now show a Hindi validation message instead of silently doing nothing.
- Expense amount, Sale quantity/rate and Wage rate validation messages are shown to the user.
- Crop sowing-date validation shows a Hindi error when an invalid date is entered.

## V82 Final Fixes Applied
- Dashboard attendance buttons now open the dedicated attendance screen directly.
- Dashboard hero now uses the approved farm/oxen scenic artwork rather than the launcher logo.
- Release workflow now requires GitHub signing secrets, decodes the keystore, builds `app-release.apk`, verifies it with Android `apksigner`, and uploads `Majdoor-Hisaab-PRO-V82-Final-Signed.apk`.
- Release version updated to 1.82.0 / versionCode 82.
