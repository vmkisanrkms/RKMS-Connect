package com.majdoor.hisaabpro

import android.app.Activity
import android.graphics.BitmapFactory
import android.app.DatePickerDialog
import android.app.KeyguardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.content.ContentResolver
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID

private val Green = Color(0xFF0B6B4A)
private val GreenDark = Color(0xFF064C36)
private val Bg = Color(0xFFF6FAF8)
private val CardBg = Color.White

private data class Labour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
private data class Field(val id:String,val name:String,val address:String,val area:String,val photo:String)
private data class Crop(val id:String,val fieldId:String,val name:String,val variety:String,val sowingDate:String,val season:String)
private data class Expense(val id:String,val fieldId:String,val cropId:String,val type:String,val item:String,val qty:String,val unit:String,val amount:Double,val date:String)
private data class Sale(val id:String,val fieldId:String,val cropId:String,val qty:Double,val unit:String,val rate:Double,val total:Double,val buyer:String,val date:String)
private data class Attendance(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val fraction:Double,val rate:Double)
private data class Payment(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val amount:Double)
private data class WageRate(val id:String,val labourId:String,val effectiveDate:String,val rate:Double)

private sealed class Screen {
    data object Home:Screen()
    data object LabourList:Screen()
    data object FieldList:Screen()
    data class ExpenseList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class SaleList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class CropList(val fieldId:String?=null):Screen()
    data class LabourDetail(val id:String):Screen()
    data class FieldDetail(val id:String):Screen()
    data class CropDetail(val id:String):Screen()
    data class Attendance(val fieldId:String?=null):Screen()
}

private class Store(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
    var labours by mutableStateOf(loadLabours()); private set
    var fields by mutableStateOf(loadFields()); private set
    var crops by mutableStateOf(loadCrops()); private set
    var expenses by mutableStateOf(loadExpenses()); private set
    var sales by mutableStateOf(loadSales()); private set
    var attendances by mutableStateOf(loadAttendance()); private set
    var payments by mutableStateOf(loadPayments()); private set
    var rates by mutableStateOf(loadRates()); private set

    private fun read(key:String)=JSONArray(prefs.getString(key,"[]") ?: "[]")
    private fun str(o:JSONObject,k:String)=o.optString(k,"")
    private fun num(o:JSONObject,k:String)=o.optDouble(k,0.0)
    private fun save(key:String,a:JSONArray){prefs.edit().putString(key,a.toString()).apply()}
    private fun <T> JSONArray.mapList(mapper:(JSONObject)->T): List<T> = (0 until length()).map { mapper(getJSONObject(it)) }

    private fun loadLabours()=read("labour").mapList{Labour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFields()=read("field").mapList{Field(str(it,"id"),str(it,"name"),str(it,"address"),str(it,"area"),str(it,"photo"))}
    private fun loadCrops()=read("crop").mapList{Crop(str(it,"id"),str(it,"fieldId"),str(it,"name"),str(it,"variety"),str(it,"sowingDate"),str(it,"season"))}
    private fun loadExpenses()=read("expense").mapList{Expense(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),str(it,"type"),str(it,"item"),str(it,"qty"),str(it,"unit"),num(it,"amount"),str(it,"date"))}
    private fun loadSales()=read("sale").mapList{Sale(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),num(it,"qty"),str(it,"unit"),num(it,"rate"),num(it,"total"),str(it,"buyer"),str(it,"date"))}
    private fun loadAttendance():List<Attendance>{
        val raw=read("attendance").mapList{Attendance(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"fraction"),num(it,"rate"))}
        // Backward compatibility: an old attendance without cropId can be safely
        // attached to the only crop in that field. If multiple crops exist, keep
        // it field-level because assigning it to a crop would be guesswork.
        return raw.map{a->
            if(a.cropId.isBlank()){
                val matches=crops.filter{it.fieldId==a.fieldId}
                if(matches.size==1) a.copy(cropId=matches.first().id) else a
            } else a
        }
    }
    private fun loadPayments()=read("payment").mapList{Payment(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"amount"))}
    private fun loadRates()=read("rateHistory").mapList{WageRate(str(it,"id"),str(it,"labourId"),str(it,"effectiveDate"),num(it,"rate"))}

    private fun obj(x:Labour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:Field)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("area",x.area);put("photo",x.photo)}
    private fun obj(x:Crop)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("name",x.name);put("variety",x.variety);put("sowingDate",x.sowingDate);put("season",x.season)}
    private fun obj(x:Expense)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("type",x.type);put("item",x.item);put("qty",x.qty);put("unit",x.unit);put("amount",x.amount);put("date",x.date)}
    private fun obj(x:Sale)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("qty",x.qty);put("unit",x.unit);put("rate",x.rate);put("total",x.total);put("buyer",x.buyer);put("date",x.date)}
    private fun obj(x:Attendance)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("fraction",x.fraction);put("rate",x.rate)}
    private fun obj(x:Payment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("amount",x.amount)}
    private fun obj(x:WageRate)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun <T> write(key:String,list:List<T>,mapper:(T)->JSONObject){save(key,JSONArray(list.map(mapper)))}

    fun persistPhoto(uriString:String, owner:String):String {
        if(uriString.isBlank() || uriString.startsWith("file://")) return uriString
        return try {
            val uri=Uri.parse(uriString)
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return ""
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun addLabour(x:Labour){
        labours=labours+x
        write("labour",labours,::obj)
        if(x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
    }
    fun updateLabour(x:Labour){
        val old=labours.firstOrNull{it.id==x.id}
        labours=labours.map{if(it.id==x.id)x else it}
        write("labour",labours,::obj)
        if(old!=null && old.rate!=x.rate && x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
    }
    fun deleteLabour(id:String){labours=labours.filterNot{it.id==id};attendances=attendances.filterNot{it.labourId==id};payments=payments.filterNot{it.labourId==id};rates=rates.filterNot{it.labourId==id};write("labour",labours,::obj);write("attendance",attendances,::obj);write("payment",payments,::obj);write("rateHistory",rates,::obj)}

    fun addField(x:Field){fields=fields+x;write("field",fields,::obj)}
    fun updateField(x:Field){fields=fields.map{if(it.id==x.id)x else it};write("field",fields,::obj)}
    fun deleteField(id:String){fields=fields.filterNot{it.id==id};val cids=crops.filter{it.fieldId==id}.map{it.id}.toSet();crops=crops.filterNot{it.fieldId==id};expenses=expenses.filterNot{it.fieldId==id};sales=sales.filterNot{it.fieldId==id};attendances=attendances.filterNot{it.fieldId==id};payments=payments.filterNot{it.fieldId==id};write("field",fields,::obj);write("crop",crops,::obj);write("expense",expenses,::obj);write("sale",sales,::obj);write("attendance",attendances,::obj);write("payment",payments,::obj)}

    fun addCrop(x:Crop){crops=crops+x;write("crop",crops,::obj)}
    fun updateCrop(x:Crop){crops=crops.map{if(it.id==x.id)x else it};write("crop",crops,::obj)}
    fun deleteCrop(id:String){
        crops=crops.filterNot{it.id==id}
        expenses=expenses.filterNot{it.cropId==id}
        sales=sales.filterNot{it.cropId==id}
        attendances=attendances.filterNot{it.cropId==id}
        payments=payments.filterNot{it.cropId==id}
        write("crop",crops,::obj)
        write("expense",expenses,::obj)
        write("sale",sales,::obj)
        write("attendance",attendances,::obj)
        write("payment",payments,::obj)
    }

    fun addExpense(x:Expense){expenses=expenses+x;write("expense",expenses,::obj)}
    fun updateExpense(x:Expense){expenses=expenses.map{if(it.id==x.id)x else it};write("expense",expenses,::obj)}
    fun deleteExpense(id:String){expenses=expenses.filterNot{it.id==id};write("expense",expenses,::obj)}

    fun addSale(x:Sale){sales=sales+x;write("sale",sales,::obj)}
    fun updateSale(x:Sale){sales=sales.map{if(it.id==x.id)x else it};write("sale",sales,::obj)}
    fun deleteSale(id:String){sales=sales.filterNot{it.id==id};write("sale",sales,::obj)}

    fun addPayment(x:Payment){payments=payments+x;write("payment",payments,::obj)}
    fun deletePayment(id:String){payments=payments.filterNot{it.id==id};write("payment",payments,::obj)}
    fun setRate(x:WageRate){rates=rates.filterNot{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}+x;write("rateHistory",rates,::obj)}
    fun attendanceConflict(x:Attendance):String?{
        val existingSame=attendances.firstOrNull{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.cropId==x.cropId &&
            it.date==x.date
        }
        val otherTotal=attendances.filter{
            it.labourId==x.labourId &&
            it.date==x.date &&
            it.id!=existingSame?.id
        }.sumOf{it.fraction}
        if(otherTotal+x.fraction>1.0001){
            return if(otherTotal>=0.9999) "इस तारीख में इस मजदूर की पूरी 1 दिन की हाजिरी पहले से लगी है।" else "इस तारीख में इस मजदूर की ${if(otherTotal>=0.5) "Half" else "कुछ"} हाजिरी पहले से लगी है। बाकी जगह केवल बची हुई हाजिरी लग सकती है।"
        }
        return null
    }
    fun upsertAttendance(x:Attendance):String?{
        val conflict=attendanceConflict(x)
        if(conflict!=null) return conflict
        attendances=attendances.filterNot{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.cropId==x.cropId &&
            it.date==x.date
        }+x
        write("attendance",attendances,::obj)
        return null
    }
    fun deleteAttendance(id:String){attendances=attendances.filterNot{it.id==id};write("attendance",attendances,::obj)}
    fun rateFor(labourId:String,date:String):Double{
        val l=labours.firstOrNull{it.id==labourId}?:return 0.0
        val applicable=rates.filter{it.labourId==labourId && validDate(it.effectiveDate) && it.effectiveDate<=date}
        return applicable.maxByOrNull{it.effectiveDate}?.rate ?: l.rate
    }
    fun rateHistoryFor(labourId:String)=rates.filter{it.labourId==labourId}.sortedByDescending{it.effectiveDate}
}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{MajdoorApp()}}}

@Composable private fun MajdoorApp(){
    val context=LocalContext.current
    val store=remember{Store(context)}
    val stack=remember{mutableStateListOf<Screen>(Screen.Home)}
    val screen=stack.last()
    fun go(s:Screen){
        if(stack.lastOrNull()==s) return
        stack.add(s)
    }
    fun goRoot(s:Screen){
        stack.clear(); stack.add(s)
    }
    fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }
    val isRoot=screen is Screen.Home||screen is Screen.LabourList||screen is Screen.FieldList||screen is Screen.ExpenseList&&screen.fieldId==null&&screen.cropId==null||screen is Screen.SaleList&&screen.fieldId==null&&screen.cropId==null||(screen is Screen.CropList&&screen.fieldId==null)
    BackHandler(enabled=true){ if(stack.size>1) back() else if(screen !is Screen.Home) goRoot(Screen.Home) }
    Surface(Modifier.fillMaxSize(),color=Bg){Column(Modifier.fillMaxSize()){
        TopBar(title="MAJDOOR HISAAB PRO",subtitle="खेत • मजदूर • खर्च • बिक्री • फसल",canBack=!isRoot,onBack={if(isRoot) goRoot(Screen.Home) else back()})
        Box(Modifier.weight(1f).fillMaxWidth().imePadding()){when(val s=screen){
            Screen.Home->Dashboard(store){key->goRoot(when(key){"attendance"->Screen.Attendance();"labour"->Screen.LabourList;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();else->Screen.CropList()})}
            Screen.LabourList->LabourScreen(store,{go(Screen.LabourDetail(it))},{go(Screen.Attendance())})
            Screen.FieldList->FieldScreen(store){go(Screen.FieldDetail(it))}
            is Screen.ExpenseList->ExpenseScreen(store,s.fieldId,s.cropId){goRoot(Screen.ExpenseList(s.fieldId,s.cropId))}
            is Screen.SaleList->SaleScreen(store,s.fieldId,s.cropId)
            is Screen.CropList->CropScreen(store,s.fieldId){go(Screen.CropDetail(it))}
            is Screen.LabourDetail->LabourDetail(store,s.id,{back()})
            is Screen.FieldDetail->FieldDetail(store,s.id,{back()},{go(Screen.CropDetail(it))},{go(Screen.Attendance(s.id))},{go(Screen.ExpenseList(s.id,null))},{go(Screen.SaleList(s.id,null))},{go(Screen.CropList(s.id))})
            is Screen.CropDetail->CropDetail(store,s.id,{back()},{go(Screen.ExpenseList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))},{go(Screen.SaleList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))})
            is Screen.Attendance->AttendanceScreen(store,s.fieldId,{back()})
        }}
        if(isRoot) BottomBar(screen){key->goRoot(when(key){"home"->Screen.Home;"attendance"->Screen.Attendance();"labour"->Screen.LabourList;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();else->Screen.CropList()})}
    }}
}

@Composable private fun TopBar(title:String,subtitle:String?=null,canBack:Boolean=true,onBack:()->Unit){
    Surface(color=GreenDark,shadowElevation=4.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack,modifier=Modifier.size(44.dp)){Icon(imageVector=if(canBack) Icons.Default.ArrowBack else Icons.Default.Home,contentDescription=if(canBack) "Back" else "Home",tint=Color.White)}
            Image(painterResource(R.drawable.majdoor_logo_small),null,Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)),contentScale=ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)){
                Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1)
                if(!subtitle.isNullOrBlank()) Text(subtitle,color=Color.White.copy(alpha=.82f),fontSize=10.sp,maxLines=1)
            }
        }
    }
}

@Composable private fun BottomBar(screen:Screen,onTab:(String)->Unit){val current=when(screen){Screen.LabourList->"labour";Screen.FieldList->"field";is Screen.ExpenseList->"expense";is Screen.SaleList->"sale";is Screen.CropList->"crop";else->"home"};Surface(shadowElevation=8.dp){Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceAround){listOf("home" to Icons.Default.Home,"labour" to Icons.Default.Groups,"field" to Icons.Default.Landscape,"expense" to Icons.Default.Payments,"sale" to Icons.Default.ShoppingCart,"crop" to Icons.Default.Spa).forEach{(k,ic)->Column(Modifier.clickable{onTab(k)}.padding(horizontal=7.dp,vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(imageVector=ic,contentDescription=null,modifier=Modifier.size(22.dp),tint=if(current==k)Green else Color.Gray);Text(when(k){"home"->"Home";"labour"->"Labour";"field"->"Field";"expense"->"Kharch";"sale"->"Sale";else->"Crop"},fontSize=10.sp,color=if(current==k)Green else Color.Gray)}}}}}

@Composable
private fun Dashboard(store:Store,onGo:(String)->Unit){
    val today=today()
    val wage=store.attendances.filter{it.date==today}.sumOf{it.fraction*it.rate}
    val exp=store.expenses.filter{it.date==today}.sumOf{it.amount}
    val sale=store.sales.filter{it.date==today}.sumOf{it.total}
    val workerCount=store.attendances.count{it.date==today}
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){Box(Modifier.fillMaxWidth().height(185.dp)){Image(painterResource(R.drawable.dashboard_hero),null,Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,GreenDark.copy(alpha=.9f)))));Column(Modifier.align(Alignment.BottomStart).padding(18.dp)){Text("मेहनत का सही हिसाब",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text("किसान की सही ताकत",color=Color(0xFFD5F4E6),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("खेत का हर काम • हर खर्च • हर कमाई",color=Color.White.copy(alpha=.92f),fontSize=12.sp)}}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CalendarMonth,null,tint=Green,modifier=Modifier.size(27.dp));Spacer(Modifier.width(8.dp));Text("आज का हिसाब • ${displayDate(today)}",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f));AssistChip(onClick={onGo("expense")},label={Text("विवरण देखें")})};Spacer(Modifier.height(9.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){DashboardStat("👷","मजदूरी",wage,"$workerCount मजदूर",Color(0xFFE8F3FF),Modifier.weight(1f));DashboardStat("💰","खर्च",exp,"आज का खर्च",Color(0xFFFFF2DF),Modifier.weight(1f));DashboardStat("🧺","बिक्री",sale,"आज की बिक्री",Color(0xFFE8F7EA),Modifier.weight(1f))}}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.width(5.dp).height(58.dp).clip(RoundedCornerShape(5.dp)).background(Green));Spacer(Modifier.width(11.dp));Text("👷",fontSize=30.sp);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text("आज की हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Text("जल्दी से मजदूरों की हाजिरी लगाएँ",fontSize=12.sp,color=Color.Gray)};OutlinedButton(onClick={onGo("labour")}){Text("हाजिरी सूची  ›")}};Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){Button(onClick={onGo("attendance")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Fingerprint,null);Spacer(Modifier.width(6.dp));Column{Text("नई हाजिरी लगाएँ",fontWeight=FontWeight.Bold);Text("मजदूर चुनें और दर्ज करें",fontSize=9.sp)}};OutlinedButton(onClick={onGo("attendance")},modifier=Modifier.weight(.78f),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.List,null);Spacer(Modifier.width(5.dp));Column{Text("आज की हाजिरी",fontWeight=FontWeight.Bold);Text("देखें / संपादित करें",fontSize=9.sp)}}}}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("▦  मुख्य काम",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,modifier=Modifier.weight(1f));Text("सभी मॉड्यूल  ›",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("👷","Labour","मजदूर प्रबंधन","हाजिरी • मजदूरी • भुगतान",Color(0xFFDCEBFF),Modifier.weight(1f)){onGo("labour")};DashboardModule("🌾","Field","खेत प्रबंधन","खेत • काम • गतिविधि",Color(0xFFE0F3D9),Modifier.weight(1f)){onGo("field")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("💰","Kharch","खर्च प्रबंधन","बीज • खाद • दवा",Color(0xFFFFEBD4),Modifier.weight(1f)){onGo("expense")};DashboardModule("🧺","Sale","बिक्री प्रबंधन","फसल • उपज • बिक्री",Color(0xFFFFE3E1),Modifier.weight(1f)){onGo("sale")}}}
        item{DashboardModule("🌱","Crop","फसल प्रबंधन","फसल चक्र • बुवाई • कटाई",Color(0xFFEAE2FF),Modifier.fillMaxWidth()){onGo("crop")}}
    }
}


@Composable private fun DashboardStat(icon:String,label:String,value:Double,sub:String,bgColor:Color,modifier:Modifier=Modifier){Card(modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(icon,fontSize=21.sp);Text(label,fontSize=11.sp,color=GreenDark);Text("₹${money(value)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold);Text(sub,fontSize=9.sp,color=Color.Gray,maxLines=1)}}}

@Composable private fun DashboardModule(icon:String,title:String,subtitle:String,detail:String,bgColor:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.fillMaxWidth().padding(13.dp).heightIn(min=125.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.62f)),contentAlignment=Alignment.Center){Text(icon,fontSize=27.sp)};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=19.sp,fontWeight=FontWeight.ExtraBold);Text(subtitle,fontSize=10.sp,color=Color.DarkGray)};Icon(Icons.Default.ChevronRight,null,tint=GreenDark)};Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.72f)){Text(detail,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=9.sp,fontWeight=FontWeight.SemiBold,color=GreenDark,maxLines=1)}}}}

@Composable private fun Stat(label:String,value:Double){
    val icon=when(label){"मजदूरी","Labour"->"👷";"खर्च","लागत","खेती खर्च"->"💰";"बिक्री","Sale"->"🧺";"भुगतान"->"💵";"बाकी"->"📌";"लाभ"->"📈";else->"📊"}
    Card(Modifier.fillMaxWidth().heightIn(min=78.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=11.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=15.sp);Spacer(Modifier.width(5.dp));Text(label,fontSize=11.sp,color=Color.Gray,maxLines=1)}
            Text("₹${money(value)}",fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}
private fun money(v:Double)=String.format(Locale.US,"%.0f",v)
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
private fun validDate(v:String):Boolean{
    val value=v.trim()
    if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false
    return try{
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        f.isLenient=false
        val parsed=f.parse(value) ?: return false
        f.format(parsed)==value
    }catch(_:Exception){false}
}
private fun displayDate(v:String):String{
    val value=v.trim()
    if(!validDate(value)) return value
    return try{
        val input=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
        val output=SimpleDateFormat("dd/MM/yyyy",Locale.US)
        output.format(input.parse(value)!!)
    }catch(_:Exception){value}
}

@Composable
private fun PhotoThumb(path:String,modifier:Modifier=Modifier.size(52.dp)){
    val bitmap=remember(path){if(path.isNotBlank()) runCatching{BitmapFactory.decodeFile(path)?.asImageBitmap()}.getOrNull() else null}
    if(bitmap!=null){
        Image(bitmap=bitmap,contentDescription=null,modifier=modifier.clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)
    }else{
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=22.sp)}
    }
}

@Composable private fun LabourScreen(store:Store,onOpen:(String)->Unit,onAttendance:()->Unit){var edit by remember{mutableStateOf<Labour?>(null)};var delete by remember{mutableStateOf<Labour?>(null)};Column(Modifier.fillMaxSize().padding(16.dp)){SectionTitle("👷 Labour","मजदूरों की सूची") { edit=Labour("","","",0.0,"","") };Spacer(Modifier.height(10.dp));SmallAction("📅 हाजिरी / तारीख चुनें",onAttendance);Spacer(Modifier.height(10.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){this.items(store.labours,key={it.id}){l->Card(Modifier.fillMaxWidth().clickable{onOpen(l.id)},RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){PhotoThumb(l.photo);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold);Text("₹${money(store.rateFor(l.id,today()))}/दिन",fontSize=12.sp,color=Color.Gray)};IconButton(onClick={edit=l}){Icon(imageVector=Icons.Default.Edit,contentDescription=null,tint=Green)};IconButton(onClick={delete=l}){Icon(imageVector=Icons.Default.Delete,contentDescription=null,tint=Color(0xFFB3261E))}}}}};if(edit!=null)LabourDialog(store,edit!!.takeIf{it.id.isNotBlank()}, {edit=null});if(delete!=null)ConfirmDialog("मजदूर हटाएँ?","इस मजदूर का attendance, payment और rate history भी हटेगा।",{store.deleteLabour(delete!!.id);delete=null},{delete=null})}}

@Composable private fun LabourDialog(store:Store,existing:Labour?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var address by remember{mutableStateOf(existing?.address?:"")};var rate by remember{mutableStateOf(if(existing==null||existing.rate==0.0)"" else money(existing.rate))};var mobile by remember{mutableStateOf(existing?.mobile?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"मजदूर जोड़ें" else "मजदूर बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("नाम (Optional)")},singleLine=true);OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("रुपये/दिन (Optional)")},singleLine=true);OutlinedTextField(value=mobile,onValueChange={mobile=it},label={Text("मोबाइल (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")};Button(onClick={val x=Labour(ownerId,name,address,rate.toDoubleOrNull()?:0.0,mobile,photo);if(existing==null)store.addLabour(x) else store.updateLabour(x);onClose()},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable private fun FieldScreen(store:Store,onOpen:(String)->Unit){var add by remember{mutableStateOf(false)};var edit by remember{mutableStateOf<Field?>(null)};var del by remember{mutableStateOf<Field?>(null)};Column(Modifier.fillMaxSize().padding(16.dp)){SectionTitle("🌾 Field","खेतों की सूची") {add=true};LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){this.items(store.fields,key={it.id}){f->Card(Modifier.fillMaxWidth().clickable{onOpen(f.id)},RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){PhotoThumb(f.photo);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(f.name.ifBlank{"खेत का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=17.sp);Text(listOf(f.area.ifBlank{"रकबा नहीं दिया"},f.address).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)};IconButton(onClick={edit=f}){Icon(imageVector=Icons.Default.Edit,contentDescription=null,tint=Green)};IconButton(onClick={del=f}){Icon(imageVector=Icons.Default.Delete,contentDescription=null,tint=Color(0xFFB3261E))}}}}};if(add)FieldDialog(store,null){add=false};if(edit!=null)FieldDialog(store,edit!!){edit=null};if(del!=null)ConfirmDialog("खेत हटाएँ?","इस खेत से जुड़े crop, expense, sale, attendance और payment records हटेंगे।",{store.deleteField(del!!.id);del=null},{del=null})}}
@Composable private fun FieldDialog(store:Store,existing:Field?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var addr by remember{mutableStateOf(existing?.address?:"")};var area by remember{mutableStateOf(existing?.area?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"खेत जोड़ें" else "खेत बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("खेत का नाम (Optional)")},singleLine=true);OutlinedTextField(value=addr,onValueChange={addr=it},label={Text("पता/स्थान (Optional)")},singleLine=true);OutlinedTextField(value=area,onValueChange={area=it},label={Text("रकबा (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"खेत की फोटो (Optional)" else "✓ फोटो चुनी गई")};Button(onClick={val x=Field(ownerId,name,addr,area,photo);if(existing==null)store.addField(x) else store.updateField(x);onClose()},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable private fun CropScreen(store:Store,preField:String?,onOpen:(String)->Unit){var add by remember{mutableStateOf(false)};var edit by remember{mutableStateOf<Crop?>(null)};var del by remember{mutableStateOf<Crop?>(null)};Column(Modifier.fillMaxSize().padding(16.dp)){SectionTitle("🌱 Crop","फसल सूची"){add=true};LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){this.items(store.crops,key={it.id}){c->val f=store.fields.firstOrNull{it.id==c.fieldId};Card(Modifier.fillMaxWidth().clickable{onOpen(c.id)},RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(c.name.ifBlank{"फसल का नाम नहीं दिया"},fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत नहीं चुना"} • ${c.season}",fontSize=12.sp,color=Color.Gray)};IconButton(onClick={edit=c}){Icon(imageVector=Icons.Default.Edit,contentDescription=null,tint=Green)};IconButton(onClick={del=c}){Icon(imageVector=Icons.Default.Delete,contentDescription=null,tint=Color(0xFFB3261E))}}}}};if(add)CropDialog(store,null,preField){add=false};if(edit!=null)CropDialog(store,edit!!,null){edit=null};if(del!=null)ConfirmDialog("फसल हटाएँ?","इस crop के जुड़े expense, sale और attendance links हटेंगे।",{store.deleteCrop(del!!.id);del=null},{del=null})}}
@Composable private fun CropDialog(store:Store,existing:Crop?,preField:String?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var field by remember{mutableStateOf(existing?.fieldId?:preField?:store.fields.firstOrNull()?.id?:"")};var variety by remember{mutableStateOf(existing?.variety?:"")};var sow by remember{mutableStateOf(existing?.sowingDate?:"")};var season by remember{mutableStateOf(existing?.season?:SimpleDateFormat("yyyy",Locale.US).format(Date()))};var error by remember{mutableStateOf("")};SimpleDialog(if(existing==null)"फसल जोड़ें" else "फसल बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("फसल का नाम")},singleLine=true);ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it};OutlinedTextField(value=variety,onValueChange={variety=it},label={Text("किस्म (Optional)")},singleLine=true);OutlinedTextField(value=sow,onValueChange={sow=it},label={Text("बुवाई तारीख YYYY-MM-DD (Optional)")},singleLine=true);OutlinedTextField(value=season,onValueChange={season=it},label={Text("Season")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={when{ name.isBlank()->error="फसल का नाम डालें"; field.isBlank()->error="खेत चुनें"; !sow.isBlank()&&!validDate(sow)->error="सही बुवाई तारीख डालें: YYYY-MM-DD"; else->{error="";val x=Crop(existing?.id?:UUID.randomUUID().toString(),field,name,variety,sow,season);if(existing==null)store.addCrop(x) else store.updateCrop(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable private fun ExpenseScreen(store:Store,preField:String?,preCrop:String?,onSaved:()->Unit){var edit by remember{mutableStateOf<Expense?>(null)};var add by remember{mutableStateOf(false)};var del by remember{mutableStateOf<Expense?>(null)};val list=store.expenses.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date};Column(Modifier.fillMaxSize().padding(16.dp)){SectionTitle("💰 Kharch","खेती का खर्च"){add=true};if(preField==null&&preCrop==null)Text("सभी खर्च",fontWeight=FontWeight.Bold);LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){this.items(list,key={it.id}){e->val f=store.fields.firstOrNull{it.id==e.fieldId};Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(e.type+if(e.item.isNotBlank())" • ${e.item}" else "",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(e.date)}",fontSize=12.sp,color=Color.Gray);Text("₹${money(e.amount)}",fontWeight=FontWeight.Bold)};IconButton(onClick={edit=e}){Icon(imageVector=Icons.Default.Edit,contentDescription=null,tint=Green)};IconButton(onClick={del=e}){Icon(imageVector=Icons.Default.Delete,contentDescription=null,tint=Color(0xFFB3261E))}}}}};if(add)ExpenseDialog(store,edit?:Expense(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),"बीज","","","",0.0,today()),{add=false;edit=null},edit!=null);if(del!=null)ConfirmDialog("खर्च हटाएँ?","यह खर्च रिकॉर्ड हट जाएगा।",{store.deleteExpense(del!!.id);del=null},{del=null})}}

@Composable private fun ExpenseDialog(store:Store,existing:Expense,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var type by remember{mutableStateOf(existing.type)};var item by remember{mutableStateOf(existing.item)};var qty by remember{mutableStateOf(existing.qty)};var unit by remember{mutableStateOf(existing.unit)};var amount by remember{mutableStateOf(if(existing.amount==0.0)"" else money(existing.amount))};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"खर्च बदलें" else "खर्च जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};ChoiceField("खर्च का प्रकार",listOf("बीज" to "बीज","उर्वरक/खाद" to "उर्वरक/खाद","दवा/कीटनाशक" to "दवा/कीटनाशक","डीजल" to "डीजल","सिंचाई" to "सिंचाई","ट्रैक्टर/मशीन" to "ट्रैक्टर/मशीन","ढुलाई" to "ढुलाई","अन्य" to "अन्य"),type){type=it};OutlinedTextField(value=item,onValueChange={item=it},label={Text("नाम (Optional)")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value=qty,onValueChange={qty=it},modifier=Modifier.weight(1f),label={Text("मात्रा (Optional)")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},modifier=Modifier.weight(1f),label={Text("इकाई (Optional)")},singleLine=true)};OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("रकम")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=amount.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";n==null||n<=0||!n.isFinite()->error="सही रकम दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,type=type,item=item,qty=qty,unit=unit,amount=n,date=date.trim());if(isEdit)store.updateExpense(x) else store.addExpense(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable private fun SaleScreen(store:Store,preField:String?,preCrop:String?){var edit by remember{mutableStateOf<Sale?>(null)};var add by remember{mutableStateOf(false)};var del by remember{mutableStateOf<Sale?>(null)};val list=store.sales.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date};Column(Modifier.fillMaxSize().padding(16.dp)){SectionTitle("🧺 Sale","बिक्री"){add=true};LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){this.items(list,key={it.id}){s->val f=store.fields.firstOrNull{it.id==s.fieldId};Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("${s.qty} ${s.unit} × ₹${money(s.rate)}",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(s.date)}",fontSize=12.sp);Text("₹${money(s.total)}",fontWeight=FontWeight.Bold,color=Green)};IconButton(onClick={edit=s}){Icon(imageVector=Icons.Default.Edit,contentDescription=null,tint=Green)};IconButton(onClick={del=s}){Icon(imageVector=Icons.Default.Delete,contentDescription=null,tint=Color(0xFFB3261E))}}}}};if(add)SaleDialog(store,edit?:Sale(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),0.0,"क्विंटल",0.0,0.0,"",today()),{add=false;edit=null},edit!=null);if(del!=null)ConfirmDialog("बिक्री हटाएँ?","यह बिक्री रिकॉर्ड हट जाएगा।",{store.deleteSale(del!!.id);del=null},{del=null})}}

@Composable private fun SaleDialog(store:Store,existing:Sale,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var qty by remember{mutableStateOf(if(existing.qty==0.0)"" else existing.qty.toString())};var unit by remember{mutableStateOf(existing.unit)};var rate by remember{mutableStateOf(if(existing.rate==0.0)"" else existing.rate.toString())};var buyer by remember{mutableStateOf(existing.buyer)};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"बिक्री बदलें" else "बिक्री जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};OutlinedTextField(value=qty,onValueChange={qty=it},label={Text("मात्रा")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},label={Text("इकाई")},singleLine=true);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("दर")},singleLine=true);OutlinedTextField(value=buyer,onValueChange={buyer=it},label={Text("खरीदार (Optional)")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);val total=(qty.toDoubleOrNull()?:0.0)*(rate.toDoubleOrNull()?:0.0);Text("कुल रकम: ₹${money(total)}",fontWeight=FontWeight.Bold);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val q=qty.toDoubleOrNull();val r=rate.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";q==null||q<=0||!q.isFinite()->error="सही मात्रा दर्ज करें";r==null||r<=0||!r.isFinite()->error="सही दर दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,qty=q,unit=unit,rate=r,total=total,buyer=buyer,date=date.trim());if(isEdit)store.updateSale(x) else store.addSale(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun DeviceCredentialDeleteGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
){
    val context=LocalContext.current
    var noLock by remember{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        if(result.resultCode==Activity.RESULT_OK) onUnlocked() else onCancel()
    }
    LaunchedEffect(Unit){
        val km=context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(!km.isKeyguardSecure){
            noLock=true
        }else{
            val intent=km.createConfirmDeviceCredentialIntent(title,message)
            if(intent!=null) launcher.launch(intent) else onCancel()
        }
    }
    if(noLock){
        AlertDialog(
            onDismissRequest=onCancel,
            title={Text("Android Screen Lock जरूरी है")},
            text={Text("हाजिरी या payment delete करने के लिए फोन में PIN, Pattern या Password screen lock चालू होना चाहिए।")},
            confirmButton={Button(onClick=onCancel){Text("ठीक है")}}
        )
    }
}

private fun isNotFutureDate(value:String):Boolean{
    return validDate(value) && value<=today()
}

@Composable
private fun AttendanceDateButton(value:String,onDateSelected:(String)->Unit){
    val context=LocalContext.current
    val parsed=try{
        SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value)
    }catch(_:Exception){Date()}
    OutlinedButton(
        onClick={
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(
                context,
                {_,year,month,day->
                    val selected=Calendar.getInstance().apply{
                        set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                    }
                    val formatted=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time)
                    if(formatted<=today()) onDateSelected(formatted)
                },
                cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)
            ).apply{
                datePicker.maxDate=System.currentTimeMillis()
            }.show()
        },
        modifier=Modifier.fillMaxWidth()
    ){
        Icon(Icons.Default.CalendarMonth,null)
        Spacer(Modifier.width(7.dp))
        Text("हाजिरी तारीख: ${displayDate(value)}")
    }
}

@Composable
private fun AttendanceScreen(store:Store,preField:String?,onBack:()->Unit){
    var selectedDate by remember{mutableStateOf(today())}
    var activeField by remember{mutableStateOf(preField?:store.fields.firstOrNull()?.id?:"")}
    var activeCrop by remember{mutableStateOf("")}
    var attendanceError by remember{mutableStateOf("")}
    var deleteAttendance by remember{mutableStateOf<Attendance?>(null)}
    val field=store.fields.firstOrNull{it.id==activeField}
    val crops=store.crops.filter{it.fieldId==activeField}
    LaunchedEffect(activeField){activeCrop=if(crops.size==1)crops.first().id else ""}

    val credentialDelete=deleteAttendance

    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📅 हाजिरी • ${displayDate(selectedDate)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.item{
                Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(15.dp)){
                        Text("📅 तारीख के हिसाब से हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold)
                        Spacer(Modifier.height(8.dp))
                        AttendanceDateButton(selectedDate){selectedDate=it;attendanceError=""}
                        Spacer(Modifier.height(6.dp))
                        Text("आज या पिछली तारीख की हाजिरी लगाएँ। आगे की तारीख की हाजिरी नहीं लगेगी।",fontSize=11.sp,color=Color.Gray)
                    }
                }
            }
            this.item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(14.dp)){
                        Text("🌾 खेत चुनें",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            store.fields.forEach{f->
                                val fieldName=f.name.ifBlank { "खेत" }
                                FilterChip(
                                    selected=f.id==activeField,
                                    onClick={activeField=f.id;attendanceError=""},
                                    label={Text("🌾 $fieldName")}
                                )
                            }
                        }
                        if(field!=null&&crops.size>1){
                            Spacer(Modifier.height(8.dp))
                            ChoiceField("फसल",crops.map{it.id to it.name},activeCrop){activeCrop=it;attendanceError=""}
                        }
                    }
                }
            }
            if(attendanceError.isNotBlank()) this.item{
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE8E6)),shape=RoundedCornerShape(14.dp)){
                    Text("⚠ $attendanceError",Modifier.padding(12.dp),color=Color(0xFFB3261E),fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                }
            }
            if(field!=null){
                this.item{
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("मजदूरों की हाजिरी",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                        Text("${displayDate(selectedDate)}",fontSize=11.sp,color=Color.Gray)
                    }
                }
                this.items(store.labours,key={it.id}){l->
                    val a=store.attendances.firstOrNull{it.labourId==l.id&&it.fieldId==activeField&&it.cropId==activeCrop&&it.date==selectedDate}
                    val totalForLabour=store.attendances.filter{it.labourId==l.id&&it.date==selectedDate}.sumOf{it.fraction}
                    val remaining=(1.0-totalForLabour+(a?.fraction?:0.0)).coerceAtLeast(0.0)
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                        Column(Modifier.padding(13.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=24.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp)
                                    Text("दिहाड़ी ₹${money(store.rateFor(l.id,selectedDate))} • बाकी ${if(remaining>=.99)"Full" else if(remaining>=.49)"Half" else "0"}",fontSize=11.sp,color=Color.Gray)
                                }
                                if(a!=null) Text(if(a.fraction==1.0)"✓ Full" else "✓ Half",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.9999 || a?.fraction==1.0),
                                    onClick={
                                        val result=store.upsertAttendance(Attendance(a?.id?:UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,1.0,store.rateFor(l.id,selectedDate)))
                                        attendanceError=result?:""
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)
                                ){Text(if(a?.fraction==1.0)"✓ Full" else "Full")}
                                OutlinedButton(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.5 || a?.fraction==0.5),
                                    onClick={
                                        val result=store.upsertAttendance(Attendance(a?.id?:UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.5,store.rateFor(l.id,selectedDate)))
                                        attendanceError=result?:""
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp)
                                ){Text(if(a?.fraction==0.5)"✓ Half" else "Half")}
                                if(a!=null){
                                    IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                }
                            }
                        }
                    }
                }
            }
            if(store.fields.isEmpty()) this.item{Text("पहले Field में खेत जोड़ें।",color=Color.Gray)}
            if(store.labours.isEmpty()) this.item{Text("पहले Labour में मजदूर जोड़ें।",color=Color.Gray)}

            this.item{
                Text("इस तारीख की लगी हुई हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
            }
            this.items(store.attendances.filter{it.date==selectedDate}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}),key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"Full" else "Half"} • ₹${money(a.fraction*a.rate)}",fontSize=11.sp,color=Color.Gray)
                        }
                        IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }

        credentialDelete?.let{a->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                {store.deleteAttendance(a.id);deleteAttendance=null;attendanceError="हाजिरी सफलतापूर्वक हटाई गई।"},
                {deleteAttendance=null}
            )
        }
    }
}

@Composable private fun FieldDetail(store:Store,id:String,onBack:()->Unit,onCrop:(String)->Unit,onAttendance:(String)->Unit,onExpense:()->Unit,onSale:()->Unit,onAddCrop:()->Unit){val f=store.fields.firstOrNull{it.id==id}?:return;val crops=store.crops.filter{it.fieldId==id};val labourCost=store.attendances.filter{it.fieldId==id}.sumOf{it.fraction*it.rate};val exp=store.expenses.filter{it.fieldId==id}.sumOf{it.amount};val sale=store.sales.filter{it.fieldId==id}.sumOf{it.total};val total=labourCost+exp;Column(Modifier.fillMaxSize()){DetailTopBar("🌾 ${f.name.ifBlank{"खेत"}}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",total)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-total)}}};this.item{SmallAction("👷 Labour / हाजिरी",{onAttendance(id)})};this.item{SmallAction("💰 खेती का खर्च",onExpense)};this.item{SmallAction("🧺 Sale",onSale)};this.item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("🌱 फसल",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp);IconButton(onClick=onAddCrop){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}};this.items(crops,key={it.id}){c->Card(Modifier.fillMaxWidth().clickable{onCrop(c.id)},RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)}}};this.item{Text("कुल मजदूरी: ₹${money(labourCost)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल खेती खर्च: ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल लागत: ₹${money(total)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल बिक्री: ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{Text("लाभ: ₹${money(sale-total)}",fontWeight=FontWeight.Bold,color=Green)}}}}}

@Composable
private fun LabourDetail(
    store: Store,
    id: String,
    onBack: () -> Unit
) {
    val l = store.labours.firstOrNull { it.id == id } ?: return

    var edit by remember { mutableStateOf(false) }
    var payment by remember { mutableStateOf(false) }
    var rate by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var delAttendance by remember { mutableStateOf<Attendance?>(null) }

    val wage = store.attendances
        .filter { it.labourId == id }
        .sumOf { it.fraction * it.rate }

    val paid = store.payments
        .filter { it.labourId == id }
        .sumOf { it.amount }

    Column(Modifier.fillMaxSize()) {
        DetailTopBar(
            "👷 ${l.name.ifBlank { "मजदूर" }}",
            onBack
        )

        LazyColumn(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            this.item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(1f)) { Stat("मजदूरी", wage) }
                    Box(Modifier.weight(1f)) { Stat("भुगतान", paid) }
                    Box(Modifier.weight(1f)) { Stat("बाकी", wage - paid) }
                }
            }

            this.item {
                Button(
                    onClick = { payment = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("₹ Cash+ भुगतान जोड़ें")
                }
            }

            this.item {
                Button(
                    onClick = { rate = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
                ) {
                    Text("दिहाड़ी बदलें")
                }
            }

            this.item {
                Text(
                    "वर्तमान दिहाड़ी: ₹${money(store.rateFor(id, today()))}/दिन",
                    fontWeight = FontWeight.Bold,
                    color = Green
                )
            }

            this.item {
                Text(
                    "दिहाड़ी इतिहास",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(store.rateHistoryFor(id), key = { it.id }) { r ->
                Text(
                    "${displayDate(r.effectiveDate)} से ₹${money(r.rate)}/दिन",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            this.item {
                Text(
                    "हाजिरी",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                store.attendances
                    .filter { it.labourId == id }
                    .sortedByDescending { it.date },
                key = { it.id }
            ) { a ->
                val f = store.fields.firstOrNull { it.id == a.fieldId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(
                            "${displayDate(a.date)} • ${f?.name ?: "खेत"} • " +
                                "${store.crops.firstOrNull { it.id == a.cropId }?.name?.let { "$it • " } ?: ""}" +
                                "${if (a.fraction == 1.0) "Full" else "Half"} • " +
                                "₹${money(a.fraction * a.rate)}",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick={delAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }

            this.item {
                Text(
                    "भुगतान",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                store.payments
                    .filter { it.labourId == id }
                    .sortedByDescending { it.date },
                key = { it.id }
            ) { p ->
                val f = store.fields.firstOrNull { it.id == p.fieldId }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${displayDate(p.date)} • ${f?.name ?: "सामान्य"}" +
                            "${store.crops.firstOrNull { it.id == p.cropId }?.name?.let { " • $it" } ?: ""}" +
                            " • ₹${money(p.amount)}",
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { delPay = p }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = Color(0xFFB3261E)
                        )
                    }
                }
            }
        }

        if (edit) {
            LabourDialog(store, l) {
                edit = false
            }
        }

        if (payment) {
            PaymentDialog(store, id, null, "") {
                payment = false
            }
        }

        if (rate) {
            RateDialog(store, id) {
                rate = false
            }
        }

        delAttendance?.let { attendanceItem ->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                { store.deleteAttendance(attendanceItem.id); delAttendance = null },
                { delAttendance = null }
            )
        }

        delPay?.let { paymentItem ->
            DeviceCredentialDeleteGate(
                "भुगतान हटाएँ",
                "गलत payment entry हटाने के लिए Android screen lock से पुष्टि करें।",
                { store.deletePayment(paymentItem.id); delPay = null },
                { delPay = null }
            )
        }
        /*
        delPay?.let { paymentItem ->
            ConfirmDialog(
                "भुगतान हटाएँ?",
                "यह payment record हट जाएगा।",
                {
                    store.deletePayment(paymentItem.id)
                    delPay = null
                },
                {
                    delPay = null
                }
            )
        }
        */
    }
}

@Composable private fun PaymentDialog(store:Store,labourId:String,preField:String?,preCrop:String?,onClose:()->Unit){
    var field by remember{mutableStateOf(preField?:"")}
    var crop by remember{mutableStateOf(preCrop?:"")}
    var amount by remember{mutableStateOf("")}
    val lockedField=preField?.isNotBlank()==true
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){
        if(crop.isNotBlank() && crops.none{it.id==crop}) crop=""
        if(crop.isBlank() && crops.size==1) crop=crops.first().id
    }
    SimpleDialog("Cash Payment",onClose){
        if(lockedField){
            val name=store.fields.firstOrNull{it.id==field}?.name?:"खेत"
            Text("खेत: $name",fontWeight=FontWeight.Bold,color=Green)
        } else {
            ChoiceField("खेत (Optional)",listOf("" to "खेत नहीं चुनना")+store.fields.map{it.id to it.name},field){field=it}
        }
        if(field.isNotBlank() && crops.size>1){
            ChoiceField("फसल (Optional)",listOf("" to "फसल नहीं चुनना")+crops.map{it.id to it.name},crop){crop=it}
        }
        OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("आज कितना दिया?")},singleLine=true)
        Button(onClick={
            val n=amount.toDoubleOrNull()
            if(n==null||n<=0||!n.isFinite()) return@Button
            store.addPayment(Payment(UUID.randomUUID().toString(),labourId,field,crop,today(),n))
            onClose()
        },modifier=Modifier.fillMaxWidth()){Text("Save Payment")}
    }
}

@Composable private fun RateDialog(store:Store,labourId:String,onClose:()->Unit){var rate by remember{mutableStateOf("")};var date by remember{mutableStateOf(today())};var error by remember{mutableStateOf("")};val current=store.rateFor(labourId,today());SimpleDialog("दिहाड़ी बदलें",onClose){Text("अभी की प्रभावी दिहाड़ी: ₹${money(current)}/दिन",fontWeight=FontWeight.SemiBold,color=Green);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("नई दिहाड़ी")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=rate.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही दिहाड़ी दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";store.setRate(WageRate(UUID.randomUUID().toString(),labourId,date.trim(),n));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save नई दर")}}}

@Composable private fun CropDetail(store:Store,id:String,onBack:()->Unit,onExpense:()->Unit,onSale:()->Unit){val c=store.crops.firstOrNull{it.id==id}?:return;val f=store.fields.firstOrNull{it.id==c.fieldId};val exp=store.expenses.filter{it.cropId==id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==id}.sumOf{it.total};val wage=store.attendances.filter{it.cropId==id}.sumOf{it.fraction*it.rate};Column(Modifier.fillMaxSize()){DetailTopBar("🌱 ${c.name}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Text("खेत: ${f?.name?:"नहीं चुना"}",fontWeight=FontWeight.Bold)};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",exp+wage)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-exp-wage)}}};this.item{Text("मजदूरी ₹${money(wage)}",fontWeight=FontWeight.Bold)};this.item{Text("खेती खर्च ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("बिक्री ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{SmallAction("💰 इस फसल के खर्च",onExpense)};this.item{SmallAction("🧺 इस फसल की बिक्री",onSale)}}}}

@Composable private fun DetailTopBar(title:String,onBack:()->Unit){
    Surface(color=Green,tonalElevation=2.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}
            Text(title,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}

@Composable private fun SectionTitle(title:String,sub:String,onAdd:()->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);Text(sub,fontSize=12.sp,color=Color.Gray)};IconButton(onClick=onAdd){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}}
@Composable private fun SmallAction(text:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Text(text,Modifier.padding(16.dp),fontWeight=FontWeight.SemiBold)}}
@Composable private fun SimpleDialog(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){AlertDialog(onDismissRequest=onClose,title={Text(title,fontWeight=FontWeight.Bold)},text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)},confirmButton={},dismissButton={TextButton(onClick=onClose){Text("बंद")}})}
@Composable private fun ConfirmDialog(title:String,message:String,onYes:()->Unit,onNo:()->Unit){AlertDialog(onDismissRequest=onNo,title={Text(title)},text={Text(message)},confirmButton={Button(onClick=onYes){Text("हटाएँ")}},dismissButton={TextButton(onClick=onNo){Text("रद्द")}})}
@Composable
private fun ChoiceField(label:String,options:List<Pair<String,String>>,selected:String,onSelected:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    Column{
        Text(label,fontSize=12.sp,color=Color.Gray)
        Box{
            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){
                Text(options.firstOrNull{it.first==selected}?.second?.ifBlank{"नहीं चुना"} ?: "चुनें")
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                options.forEach{(id,name)->
                    DropdownMenuItem(text={Text(name.ifBlank{"नहीं चुना"})},onClick={onSelected(id);open=false})
                }
            }
        }
    }
}
