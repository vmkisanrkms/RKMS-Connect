#!/usr/bin/env python3
"""Static checks that empty Cane Parchi results cannot export misleading blank files."""
from pathlib import Path
import sys
s=(Path(__file__).resolve().parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
start=s.index('private fun CaneParchiDashboardScreen')
end=s.index('@Composable\nprivate fun CaneParchiFormScreen',start)
c=s[start:end]
checks={
 'CSV export is disabled for empty filtered rows':'exportCaneCsv(context, store, exportRows, if (season == "ALL") "ALL" else season)' in c and 'val exportRows = if (selectedParchiIds.isNotEmpty()) store.caneParchis.filter { it.id in selectedParchiIds } else rows' in c,
 'PDF export is disabled for empty filtered rows':'गन्ना_पर्ची_${safeFileName(season)}' in c and 'exportRows.map { p ->' in c and 'चुनी हुई पर्चियां' in c,
 'empty-state remains explicit':'इस सीजन में अभी कोई पर्ची नहीं है' in c,
 'filter drives both list and export':'val rows = allRows.filter' in c,
 'CSV injection sanitizer remains in export path':'joinToString(","){csvCell(it)}' in s and 'private fun exportCaneCsv' in s,
}
for n,ok in checks.items(): print(f"{'PASS' if ok else 'FAIL'}: {n}")
print(f"RESULT: {sum(checks.values())}/{len(checks)}")
if not all(checks.values()): sys.exit(1)
