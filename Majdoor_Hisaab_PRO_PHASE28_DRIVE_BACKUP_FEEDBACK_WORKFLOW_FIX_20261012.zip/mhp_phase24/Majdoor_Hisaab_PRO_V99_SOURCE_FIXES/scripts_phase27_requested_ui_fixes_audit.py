#!/usr/bin/env python3
from pathlib import Path
import sys
s=(Path(__file__).resolve().parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'cane peeling day cards are clickable':'Modifier.fillMaxWidth().clickable { detailDate=d }' in s,
 'day detail lists each worker row':'private fun CanePeelingDayDetail(store:Store,date:String,onClose:()->Unit)' in s and 'items(rows,key={it.id})' in s,
 'detail shows worker name, field, fandi, rate and amount':'worker?.name ?: "मजदूर रिकॉर्ड नहीं मिला"' in s and 'खेत: $field' in s and '₹${money(row.rate)}' in s and '₹${money(row.total)}' in s,
 'parchi model has backward-compatible optional field':'val season:String,val fieldId:String=""' in s,
 'old records load without field ID':'str(it,"season"),str(it,"fieldId")' in s,
 'new parchi persists field ID':'put("fieldId",x.fieldId)' in s,
 'parchi form field is optional':'ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},fieldId)' in s,
 'selected parchi IDs support multi-select':'selectedParchiIds' in s and 'Checkbox(checked=p.id in selectedParchiIds' in s,
 'selected export includes selected rows across current filters':'store.caneParchis.filter { it.id in selectedParchiIds } else rows' in s,
 'CSV export receives selected rows and store':'exportCaneCsv(context, store, exportRows' in s,
 'CSV includes field name and date':('सीजन,नाम,पिता का नाम,पर्ची कोड,दिनांक,खेत' in s or '"सीजन","नाम","पिता का नाम","पर्ची कोड","दिनांक","खेत"' in s),
 'PDF rows use selected export rows':'exportRows.map { p ->' in s,
 'dashboard shows five finance metrics':('DashboardStat("₹", "मजदूरी"' in s or 'DashboardStat("₹","मजदूरी"' in s) and ('DashboardStat("−", "खर्च"' in s or 'DashboardStat("−","खर्च"' in s) and ('DashboardStat("+", "बिक्री"' in s or 'DashboardStat("+","बिक्री"' in s) and 'भुगतान/अग्रिम' in s and 'कुल बाकी' in s,
 'dashboard has direct cane parchi shortcut':('Text("गन्ना पर्ची",maxLines=1)' in s or 'DashboardModule("🌾", "गन्ना पर्ची"' in s or 'DashboardModule("🌾","गन्ना पर्ची"' in s),
 'dashboard has direct cane peeling shortcut':('Text("गन्ना छिलाई",maxLines=1)' in s or 'DashboardModule("🌿", "गन्ना छिलाई"' in s or 'DashboardModule("🌿","गन्ना छिलाई"' in s),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS, {sum(not v for v in checks.values())} FAIL')
sys.exit(0 if all(checks.values()) else 1)
