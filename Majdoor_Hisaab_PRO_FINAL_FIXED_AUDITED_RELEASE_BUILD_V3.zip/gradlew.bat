@echo off
setlocal
set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"
set "WRAPPER_URL=https://raw.githubusercontent.com/gradle/gradle/v8.11.1/gradle/wrapper/gradle-wrapper.jar"
set "EXPECTED_SHA256=2db75c40782f5e8ba1fc278a5574bab070adccb2d21ca5a6e5ed840888448046"

if not exist "%WRAPPER_JAR%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%WRAPPER_JAR%.tmp'"
  if errorlevel 1 exit /b 1
  for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%WRAPPER_JAR%.tmp').Hash.ToLower()"') do set "ACTUAL_SHA256=%%H"
  if /I not "%ACTUAL_SHA256%"=="%EXPECTED_SHA256%" (
    del /q "%WRAPPER_JAR%.tmp" >nul 2>&1
    echo Gradle Wrapper JAR checksum mismatch; refusing to execute it.
    exit /b 1
  )
  move /Y "%WRAPPER_JAR%.tmp" "%WRAPPER_JAR%" >nul
)

java -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
endlocal
