# Majdoor Hisaab PRO v2.4

Final local SQLite release source for the Majdoor Hisaab PRO Android app.

- Version: 2.4
- Version code: 24
- Package: com.majdoor.hisaab
- Compile/target SDK: 35
- Gradle wrapper: 8.11.1
- Java/Kotlin: 17
- Storage: local SQLite, offline
