# Majdoor Hisaab PRO — Phase 8 Batch Fixes
Date: 2026-10-11

## Actual source changes
- Field form now requires a non-empty field name and blocks case-insensitive duplicate field names after whitespace normalization. Address, area, and photo remain optional.
- Crop form blocks duplicate crop names within the same field and trims saved crop fields; existing field and sowing-date validation remain.
- Expense search now matches crop name, ISO/display date, quantity/unit, item/type, field name, and formatted amount.
- Sale search now matches crop name, ISO/display date, buyer, unit, quantity, rate, field name, and formatted total.
- Cane Parchi form blocks duplicate parchi codes within the same season (code reuse in a different season is not blocked).
- Cane Parchi search now has a clear-search action and a query-specific no-result message.
- Cane Parchi PDF summary now totals the exact filtered rows included in the export rather than the entire season.
- Attendance history summary now includes half-day and absent counts; it still does not list absent workers' names.
- GitHub Actions updated to `android-actions/setup-android@v4`, requests `platform-tools`, does not cancel an in-progress release build, and runs Phase 2/4/5/6/7/8 static audits before build.

## Verification
- Phase 2 static audit: 20/20 PASS.
- Phase 4 UI audit: 17/17 PASS.
- Phase 5 attendance audit: 14/14 PASS.
- Phase 6 worker-ledger audit: 14/14 PASS.
- Phase 7 data-safety audit: 17/17 PASS.
- Phase 8 audit: run result recorded in `PHASE8_STATIC_AUDIT_RESULTS.txt`.
- Android compilation, signed APK build, installation, and device runtime are NOT TESTED in this environment. The Gradle wrapper JAR is absent in the source ZIP; workflow bootstraps it on GitHub Actions.
- No claim that all remaining 102 screen points are complete. The 135-point tracker remains authoritative and identifies each screen's actual status.

## Preservation
No Ganna Chhilayi or Ganna Parchi calculation/record model was replaced. Changes are limited to validation, search/empty-state behavior, filtered PDF summary correctness, history counts, and CI workflow setup.


Tracker after Phase 8: 30 design points IMPLEMENTED, 15 IN PROGRESS, 90 NOT STARTED; all 135 test statuses remain NOT TESTED until actual tests run.
