# Feature Preservation Matrix — Template

Populate this file only after inspecting the actual source code. Do not infer function names or test results.

| Feature ID | Existing screen/action | Existing handler/function | Data model/storage | Existing behavior/rule | New screen location | Change status | Regression test | Test result |
|---|---|---|---|---|---|---|---|---|
| FP-001 | To audit | To audit | To audit | To audit | To map | NOT STARTED | To define | NOT TESTED |

## Required mapping
- Every existing screen, button, menu, form, dialog, export, and navigation action.
- Every wage, attendance, payment, advance, locked-month, field/crop, expense, and sale calculation.
- Every backup/restore/import action and Google consent path.
- Every Ganna Chhilayi and Ganna Parchi workflow.
- Every setting, security, theme, and auto-lock behavior.

A feature is not PASS merely because its screen renders or code compiles. Test the real saved-data result and relevant edge cases.
