# Phase 25 — Gradle Wrapper JAR Bootstrap Fix

## Root cause

The Phase 24 archive contains `gradlew` and `gradle/wrapper/gradle-wrapper.properties` in both Android project trees, but it does not contain `gradle/wrapper/gradle-wrapper.jar`. The shell wrapper tries to download that JAR from `raw.githubusercontent.com`; that host failed DNS resolution in this environment. The canonical workflow already attempted to generate a missing JAR from Gradle 8.11.1, but did not use a shared script and did not verify the distribution checksum before extraction.

## Fix included in Phase 25

- Added `scripts/bootstrap-gradle-wrapper.sh` to both Android source trees.
- Uses Gradle 8.11.1 and the SHA-256 already pinned in `gradle-wrapper.properties`.
- Tries `services.gradle.org` then `downloads.gradle.org`.
- Verifies the distribution SHA-256 before extraction.
- Generates the official wrapper JAR using the downloaded Gradle distribution.
- Verifies the JAR contains `org/gradle/wrapper/GradleWrapperMain.class`.
- Re-pins `distributionUrl` and `distributionSha256Sum` after generation.
- Both GitHub Actions workflows invoke the same bootstrap before `./gradlew --version` and build tasks.
- Added a static audit for wrapper bootstrap logic.

## Honest limitation

The binary JAR is **not physically embedded in this ZIP**. The execution environment cannot resolve external download hosts, and no trusted local copy of the JAR was available. This Phase 25 ZIP makes the workflow bootstrap it safely at build time; the first download of the Gradle distribution still requires network access. Both workflow YAML files were parsed successfully, both bootstrap scripts pass `bash -n`, and the canonical project has 26/26 static audit/check scripts passing. A successful GitHub Actions build is not claimed until the workflow actually runs.
