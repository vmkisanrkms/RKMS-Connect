#!/usr/bin/env python3
"""Phase 11 static checks for A01/A03/A05/A06."""
from pathlib import Path
import csv, zipfile, sys
ROOT=Path(__file__).resolve().parent
MAIN=ROOT/"app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt"
TRACKER=ROOT.parent.parent/"SCREEN_PROGRESS_TRACKER.csv"
src=MAIN.read_text(encoding="utf-8")
checks={
 "A01 branded startup state": 'ऐप शुरू हो रहा है' in src and 'SharedStatePanel' in src and 'startupReady' in src,
 "A03 platform biometric prompt": 'PlatformBiometricPrompt.Builder' in src and 'onAuthenticationSucceeded' in src,
 "A03 device credential fallback": 'launchDeviceCredential()' in src and 'createConfirmDeviceCredentialIntent' in src,
 "A05 local initialization failure state": 'ऐप डेटा शुरू नहीं हो सका' in src and 'storageError' in src,
 "A05 retry action": 'दोबारा कोशिश करें' in src and 'recreate()' in src,
 "A05 offline-first messaging": 'यह ऐप ऑफलाइन काम करता है' in src,
 "A06 persisted theme preference": 'getSharedPreferences(APP_PREFS' in src and 'putString(THEME_KEY, mode)' in src,
 "A06 Light/Dark/System choices": all(x in src for x in ['"light" to "Light"', '"dark" to "Dark"', '"system" to "System"']),
 "A06 system theme follows Android": 'isSystemInDarkTheme()' in src,
 "A06 dark palette applied": 'darkColorScheme(' in src and 'DarkCardBg' in src,
 "Profile exposes theme setting": '🎨  थीम चुनें' in src,
 "Existing Android screen lock remains": 'Android Screen Lock जरूरी है' in src,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" | "+name)
try:
 with TRACKER.open(encoding="utf-8-sig",newline="") as f: rows=list(csv.DictReader(f))
 ids={r["ID"]:r for r in rows}
 for i in ("A01","A03","A05","A06"):
  ok=i in ids and ids[i]["Test_Status"]=="NOT TESTED" and ids[i]["Implementation_Status"] in ("IMPLEMENTED","IN PROGRESS")
  print(("PASS" if ok else "FAIL")+" | tracker "+i+" honest test status")
  checks["tracker "+i]=ok
except Exception as e:
 print("FAIL | tracker readable:",e); checks["tracker readable"]=False
sys.exit(0 if all(checks.values()) else 1)
