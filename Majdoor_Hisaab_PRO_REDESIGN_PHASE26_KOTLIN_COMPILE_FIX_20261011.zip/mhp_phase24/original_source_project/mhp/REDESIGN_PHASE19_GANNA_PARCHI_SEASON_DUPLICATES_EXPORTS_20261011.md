# Phase 19 — Ganna Parchi Season, Duplicate Prevention, PDF/CSV

Date: 2026-10-11

## Source changes
- Fixed the `ALL` season selection reset: `ALL` is no longer replaced with the newest concrete season during recomposition.
- Added synchronized Store-level add/update/delete validation for parchi records. Duplicate parchi codes are canonicalized to digits and blocked within the same cane season, excluding the current record on update. Missing IDs, invalid dates, future dates, invalid code lengths, non-positive/non-finite weights/rates, and non-finite totals are rejected.
- Season is derived from the ticket date; the business boundary remains April–March.
- When editing a ticket without changing its date, its stored historical rate remains unchanged. A changed date uses the rate effective for that date.
- CSV exports the exact filtered list, includes the season and ISO date per row, a filtered total row for weight and amount, UTF-8 BOM for Hindi/Excel compatibility, correct CSV quote/newline escaping, and formula-injection protection for user text. Empty filtered exports are blocked with a message.
- PDF details now show each ticket's season and the summary totals are calculated from the same filtered rows used in the PDF. Empty exports are blocked.
- `SCREEN_PROGRESS_TRACKER.csv` updated for M01–M06.

## Static verification
- Phase 19 focused source audit: 34/34 PASS, 0 FAIL.
- Selected cross-phase regression suite: 18/18 scripts passed, including Phase 2, 4–9, 11–19, Drive-consent and report-filter checks. Phase 8/9 assertions were updated to test the stronger Store-level duplicate guard.
- Three unrelated legacy audit scripts still contain stale assumptions or brittle selectors (Daily Labour workflow ZIP name, date/field report screen selectors, and report-selection string lookup); they were not changed as part of this Ganna Parchi task.
- Season boundary examples: 2026-03-31 => 2025-26; 2026-04-01 => 2026-27; 2027-01-01 => 2026-27.
- Android Kotlin compilation, APK build, device UI, real CSV opening in Excel/Sheets, PDF visual output, and real CRUD/runtime behavior are NOT TESTED in this environment.
