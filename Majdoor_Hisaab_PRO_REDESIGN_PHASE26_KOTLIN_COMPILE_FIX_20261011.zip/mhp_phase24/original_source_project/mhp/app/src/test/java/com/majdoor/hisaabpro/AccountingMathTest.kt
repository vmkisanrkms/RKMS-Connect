package com.majdoor.hisaabpro

import org.junit.Assert.assertEquals
import org.junit.Test

class AccountingMathTest {
    @Test fun fullHalfAndAbsentAttendanceWages() {
        assertEquals(500.0, attendanceWage(1.0, 500.0), 0.001)
        assertEquals(250.0, attendanceWage(0.5, 500.0), 0.001)
        assertEquals(0.0, attendanceWage(0.0, 500.0), 0.001)
        assertEquals(0.0, attendanceWage(Double.NaN, 500.0), 0.001)
    }

    @Test fun laterPaymentSettlesLockedOldDebtFirst() {
        val b = calculateAccountingBalance(0.0, 0.0, 1000.0, 0.0, 500.0, 600.0)
        assertEquals(400.0, b.oldDue, 0.001)
        assertEquals(500.0, b.currentDue, 0.001)
        assertEquals(0.0, b.advance, 0.001)
        assertEquals(900.0, b.totalOutstanding, 0.001)
    }

    @Test fun finalizedCreditOffsetsNewWagesAndKeepsExcessAsAdvance() {
        val b = calculateAccountingBalance(1000.0, 1300.0, 0.0, 0.0, 200.0, 0.0)
        assertEquals(0.0, b.totalOutstanding, 0.001)
        assertEquals(100.0, b.advance, 0.001)
    }

    @Test fun overpaymentIsAdvanceNotNegativeBalance() {
        val b = calculateAccountingBalance(0.0, 0.0, 0.0, 0.0, 500.0, 700.0)
        assertEquals(0.0, b.oldDue, 0.001)
        assertEquals(0.0, b.currentDue, 0.001)
        assertEquals(200.0, b.advance, 0.001)
    }

    @Test fun profitSubtractsExpensesAndWagesFromSales() {
        assertEquals(2500.0, fieldProfit(10000.0, 4500.0, 3000.0), 0.001)
        assertEquals(-500.0, fieldProfit(2000.0, 1500.0, 1000.0), 0.001)
    }
}
