# Phase 20 — Backup / Restore / Google Consent Audit

Base: Phase 19 source ZIP, 2026-10-11.

## Changes
- Backup ZIP is created in staging, validated, then installed while preserving a previous destination until verification succeeds.
- Google Drive restore now refuses to select arbitrary files when no `.mhbackup` archive exists.
- `NeedRemoteConsent` still launches the exact recoverable intent, retries once, and prevents duplicate/repeating consent actions.
- ZIP validation rejects empty archives, duplicate entries, traversal/absolute paths, oversized content, wrong app/schema, malformed arrays, and missing schema-v2 collections.
- Restore independently validates before mutation, stages photos, rewrites photo references before the single preferences commit, and retains previous photos until in-memory reload succeeds. Failure paths attempt preference/photo rollback and clearly warn the user not to clear app data.
- Manual export validates the source archive, checks copied byte count, reads the saved document back and validates it before reporting success. Restore selection is validated before the confirmation/device-lock gate.
- Recent local backup history records filename, size, destination and timestamp.

## Static checks
- Canonical backup/restore audit: **27/27 PASS**.
- Canonical regression scripts: **20/20 passed** after aligning stale report/phase-2 audit assertions to the current report UI.
- V99 backup/restore audit: **25/25 PASS**.
- V99 focused consent, restore atomicity, backup safety, persistence and CRUD audits also pass.

## Not verified
Android Kotlin compilation/APK build, device installation, live Google OAuth consent, live Drive upload/download, SAF provider round-trip and runtime fault-injection are **NOT TESTED**. Local records remain offline-first; Google Drive needs network connectivity and matching OAuth/signing configuration.
