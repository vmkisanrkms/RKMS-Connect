#!/usr/bin/env python3
"""Static source assertions for Phase 2 dashboard/navigation changes."""
from pathlib import Path
import csv
ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER = ROOT.parent.parent / 'SCREEN_PROGRESS_TRACKER.csv'
MATRIX = ROOT.parent.parent / 'FEATURE_PRESERVATION_MATRIX_PHASE1.csv'
s = SRC.read_text(encoding='utf-8')
checks = {
    'screen-specific header mapping exists': 'private fun screenHeader(screen: Screen)' in s,
    'global top bar uses screen mapping': 'TopBar(title=screenHeader(screen).first,subtitle=screenHeader(screen).second' in s,
    'outstanding uses shared old-balance allocation': 'fun balanceBreakdown(labourId:String):BalanceBreakdown' in s and 'store.balanceBreakdown(worker.id).totalOutstanding' in s,
    'current attendance wage total exists': 'currentWages=attendances.filter' in s,
    'current payment total exists': 'currentPayments=payments.filter' in s,
    'outstanding dashboard UI exists': 'मजदूरी का बाकी बकाया' in s,
    'recent attendance records exist': 'val recentAttendance = store.attendances.sortedByDescending { it.date }.take(3)' in s,
    'recent payment records exist': 'val recentPayments = store.payments.sortedByDescending { it.date }.take(3)' in s,
    'field count uses real store': 'DashboardCountStat("कुल खेत", store.fields.size' in s,
    'crop count uses real store': 'DashboardCountStat("कुल फसलें", store.crops.size' in s,
    'existing local store retained': 'private class Store(private val context:Context)' in s,
    'cane peeling screen retained': 'private fun CanePeelingScreen' in s,
    'cane parchi dashboard retained': 'private fun CaneParchiDashboardScreen' in s,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
if TRACKER.exists():
    with TRACKER.open(encoding='utf-8-sig', newline='') as f:
        rows = {r['ID']: r for r in csv.DictReader(f)}
    for ident in ('B04','B05','B07','P01'):
        ok = rows.get(ident, {}).get('Test_Status') == 'NOT TESTED' and rows.get(ident, {}).get('Implementation_Status') in ('IMPLEMENTED','IN PROGRESS','NOT TESTED')
        checks[f'tracker accurately marks {ident} unverified'] = ok
        print(('PASS' if ok else 'FAIL') + f' | tracker accurately marks {ident} unverified')
else:
    print('WARN | tracker path not found; checked source only')
if MATRIX.exists():
    m = MATRIX.read_text(encoding='utf-8-sig')
    for term in ('Outstanding wage balance summary','Recent attendance and payment','Field/crop summary'):
        ok = term in m
        checks[f'preservation matrix includes {term}'] = ok
        print(('PASS' if ok else 'FAIL') + ' | preservation matrix includes ' + term)
print(f'SUMMARY {sum(bool(v) for v in checks.values())}/{len(checks)} PASS')
raise SystemExit(0 if all(checks.values()) else 1)
