# Phase 18 — Ganna Chhilai: Fandi, Rate Persistence, Worker Ledger & Payments

Date: 2026-10-11

## Source changes

- Fandi rate now rejects invalid/non-positive values and commits to SharedPreferences before updating in-memory UI state; save failures are shown to the user.
- Existing Chhilai rows keep their stored historical rate; new rows use the current persisted Fandi rate.
- Fandi worker add/edit validates normalized duplicate names and duplicate phone numbers at the Store layer.
- Fandi worker deletion is refused when historical Chhilai or payment records exist; old accounts are not silently erased.
- Chhilai add/edit validates worker, optional field, date, positive quantity/rate, duplicate worker+field+date key, and recalculates total as quantity × the saved rate.
- Deleting a Chhilai earning row is blocked if that worker has payment history, avoiding silent changes to a paid ledger; the row can be corrected with Edit.
- Chhilai/payment Store CRUD operations are synchronized and return success/failure rather than silently pretending to save.
- Payment add/edit validates worker ID, date, amount and payment ID; invalid or missing records are rejected, and the payment dialog displays an error instead of closing.
- Worker ledger and payment summary show outstanding balance and advance/overpayment separately; outstanding is never shown as a negative number.
- Fandi workers, Chhilai rows, payments and rate remain included in backup keys.

## Static verification

- `scripts_redesign_phase18_ganna_chhilai_audit.py`: 22/22 PASS.
- Phase 2, 6, 7, 8, 12, 14, 15, 16 and 17 selected regression audits were rerun; all selected scripts completed successfully.
- `SCREEN_PROGRESS_TRACKER.csv` updated for L01–L12. Runtime status remains `NOT TESTED`.

## Not verified

No Android compile or device/runtime test is claimed. The ZIP lacks `gradle/wrapper/gradle-wrapper.jar`, and no installed `gradle` executable was found in this environment. Device restart rate persistence, double-tap testing, payment edit/delete, real PDF rendering and backup/restore must still be verified by an Android build/run.
