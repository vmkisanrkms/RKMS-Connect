# Phase 21 — Shared UI / Back Navigation / Search / Rotation

Date: 2026-10-11

## Changes

1. **Back navigation:** The screen stack is serialized with a typed Compose `listSaver`. Screen route names and their IDs/field/crop context are preserved across Activity recreation. Invalid or unknown restored routes fall back to Home. Existing root/back behavior is retained.
2. **Startup and lifecycle:** `startupReady` is ordinary remembered state, not separately restored. After recreation the in-memory Store is initialized again before showing the app. The app-lock gate remains non-saveable so Activity recreation requires re-authentication. Drive `busy` state is transient and is not restored as stuck `true`.
3. **Restore confirmation:** The temporary restore file path is saveable so a pending local/Drive restore confirmation can recover the staged file after configuration recreation. Restore still requires explicit device-credential confirmation.
4. **Dialogs:** Shared `SimpleDialog` closes on system Back. Shared `ConfirmDialog` explicitly routes system Back to its cancel action; destructive confirmation still requires tapping the destructive button.
5. **Search:** Added one locale-stable normalization function. It lowercases with `Locale.ROOT`, converts Devanagari digits to ASCII, and ignores punctuation/spacing. Wired into worker, field, crop, expense, sale, wage-rate, profitability, Fandi worker, Fandi payment, and cane-parchi searches.
6. **Form state:** Safe primitive/string form fields and toggles use `rememberSaveable` so entered values and filter selections can survive Activity recreation. Domain-object edit/delete selections remain ordinary remembered objects and may close/reopen via the parent screen flow; verify these on device before claiming full rotation support.
7. **Tracker:** P01, P04, P05, P09 and P10 updated. All 135 unique screen IDs remain.

## Verification

- Phase 21 focused static audit: **24/24 PASS**.
- Selected regression audit scripts: all **20/20 exited successfully** after updating two outdated source-pattern assertions to match current behavior.
- MainActivity raw delimiter totals are balanced: `{}` 3943/3943, `()` 8767/8767, `[]` 56/56. This is a structural scan, not a Kotlin compile.
- ZIP archive integrity checked after packaging.

## Not verified

- Kotlin/Android compilation and Release APK build.
- Physical-device Back-stack behavior, dialog priority, screen rotation, font scaling, keyboard behavior, and restore confirmation after rotation.
- Search interaction tests with real Hindi/English/mixed-script records.

The Android Gradle wrapper JAR is absent and no Gradle executable is installed in the current environment. Do not describe this source ZIP as a compiled or runtime-verified APK.
