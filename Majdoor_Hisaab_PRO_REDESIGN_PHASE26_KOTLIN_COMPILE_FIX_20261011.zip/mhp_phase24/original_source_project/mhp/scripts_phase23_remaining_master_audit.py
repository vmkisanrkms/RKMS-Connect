#!/usr/bin/env python3
from pathlib import Path
import csv, re, sys, zipfile
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER=ROOT.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
WORKFLOW=ROOT/'.github/workflows/majdoor-hisaab.yml'
s=SOURCE.read_text(encoding='utf-8')
w=WORKFLOW.read_text(encoding='utf-8')
rows=list(csv.DictReader(TRACKER.open(encoding='utf-8-sig',newline='')))
by={r['ID']:r for r in rows}
checks=[]
def check(label, ok): checks.append((label,bool(ok)))
check('135 unique tracker IDs preserved',len(rows)==135 and len(by)==135)
check('expense list computes field/crop scoped expense total', 'val scopeExpenses=all.sumOf{it.amount}' in s)
check('cost summary includes attendance-derived wages', 'val scopeWages=store.attendances.filter' in s and 'it.fraction*it.rate' in s)
check('cost summary includes real saved sales', 'val scopeRevenue=store.sales.filter' in s and 'sumOf{it.total}' in s)
check('cost summary computes revenue less all scoped costs', 'val scopeProfit=fieldProfit(scopeRevenue,scopeExpenses,scopeWages)' in s)
check('cost summary is independent of search text', 'यह सारांश चुने हुए खेत/फसल के सभी सेव रिकॉर्ड पर आधारित है; खोज टेक्स्ट इसे नहीं बदलता।' in s)
check('report summary preference wired to worker PDF', 'val showReportSummary = settingBool(context, "report_summary_enabled", true)' in s)
check('wage column preference wired to worker PDF', 'if (showReportWages && row.amount != null)' in s)
check('payment column preference wired to worker PDF', 'if (showReportPayments && pay != null)' in s)
check('summary preference hides lower worker ledger summary', 'if (showReportSummary) {' in s and 'if (y + 195f > 790f)' in s)
check('report preferences wired to all-worker PDF', s.count('val showReportSummary = settingBool(context, "report_summary_enabled", true)')>=2)
check('all-worker PDF wage and payment columns conditional', 'if(showReportWages) text("₹${money(r.wage)}"' in s and 'if(showReportPayments) text("₹${money(r.paid)}"' in s)
check('absence rows visible in selected-date calendar detail', 'selectedRows.count{it.fraction==0.0}' in s and 'labour?.name?:"मजदूर हटाया गया"' in s)
check('absence rows are not filtered from attendance history export input', 'exportAttendanceHistoryPdf(context,"हाजिरी_सूची_$month",month,dayGroups,store)' in s)
check('responsive root uses centered maximum content width', 'Box(Modifier.fillMaxSize(),contentAlignment=Alignment.TopCenter){Column(Modifier.widthIn(max=900.dp).fillMaxSize())' in s)
check('backup reminder uses saved backup history timestamp', 'mhpro_backup_history' in s and 'createdAt' in s and 'lastBackupAt' in s)
check('backup reminder triggers after seven days', '7L * 24L * 60L * 60L * 1000L' in s)
check('backup reminder preference can disable prompt', 'settingBool(context, "backup_reminder_enabled", true)' in s)
check('reminder dismiss snoozes for 24 hours', '24L * 60L * 60L * 1000L' in s and 'reminder_dismissed_at' in s)
check('reminder does not claim scheduled push notification', '7 दिन से बैकअप न हुआ हो तो Home खोलने पर याद दिलाएगा।' in s)
check('payment add protects locked and closed dates', 'isClosedDate(x.labourId,x.date) || isMonthLocked(x.date)' in s)
check('payment update protects original and target dates', 'isMonthLocked(old.date) || isMonthLocked(x.date)' in s)
check('field/crop scoped financial integrity checker remains', 'fun fieldCropIntegrityIssues' in s)
check('backup restore staging and rollback logic remains', 'photos_restore_' in s and 'पुराना data वापस रखा गया है' in s)
check('canonical workflow uses exact Phase 25 ZIP', 'Majdoor_Hisaab_PRO_REDESIGN_PHASE25_GRADLE_WRAPPER_BOOTSTRAP_FIX_20261011.zip' in w)
check('workflow selects canonical redesign source', '*/original_source_project/mhp/gradlew' in w)
check('workflow runs Phase 23 audit before build', 'python scripts_phase23_remaining_master_audit.py' in w)
check('workflow requires persistent signing secrets, no debug fallback', 'RELEASE_KEYSTORE_BASE64' in w and 'Required permanent signing secret is missing' in w)
check('P09 tracker keeps runtime tests pending', by.get('P09',{}).get('Test_Status')=='NOT TESTED')
check('Q09 not falsely marked implemented', by.get('Q09',{}).get('Implementation_Status')!='IMPLEMENTED')
check('pure accounting math is shared by Store and test suite', (ROOT/'app/src/main/java/com/majdoor/hisaabpro/AccountingMath.kt').exists() and 'calculateAccountingBalance(' in s and 'calculateAccountingBalance(' in (ROOT/'app/src/main/java/com/majdoor/hisaabpro/AccountingMath.kt').read_text())
check('JVM regression tests cover wage, old debt, advance, and profit', (ROOT/'app/src/test/java/com/majdoor/hisaabpro/AccountingMathTest.kt').exists() and all(x in (ROOT/'app/src/test/java/com/majdoor/hisaabpro/AccountingMathTest.kt').read_text() for x in ['fullHalfAndAbsentAttendanceWages','laterPaymentSettlesLockedOldDebtFirst','overpaymentIsAdvanceNotNegativeBalance','profitSubtractsExpensesAndWagesFromSales']))
check('CI runs accounting regression tests before release assembly', './gradlew :app:testReleaseUnitTest' in w)
for label,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY: {sum(ok for _,ok in checks)}/{len(checks)} PASS, {sum(not ok for _,ok in checks)} FAIL')
sys.exit(0 if all(ok for _,ok in checks) else 1)
