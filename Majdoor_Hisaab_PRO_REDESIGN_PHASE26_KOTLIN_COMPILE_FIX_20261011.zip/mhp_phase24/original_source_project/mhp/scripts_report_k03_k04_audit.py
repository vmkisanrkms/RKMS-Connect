#!/usr/bin/env python3
from pathlib import Path
import csv, sys
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'K03 start date control is visible':'AttendanceDateButton(startDate)' in src,
 'K03 end date control is visible':'AttendanceDateButton(endDate)' in src,
 'K03 inclusive ISO date range filters records':'date >= startDate && date <= endDate' in src,
 'K03 invalid or reversed range is guarded':'validDate(startDate) && validDate(endDate) && startDate <= endDate' in src and 'if(!rangeValid)' in src,
 'K04 worker multi-select exists':'selectedReportWorkers' in src and 'worker_filter_' in src,
 'K04 field multi-select exists':'selectedFields' in src and 'field_'+ '"+it.id' in src,
 'K04 crop multi-select exists':'selectedCrops' in src and 'crop_filter_' in src,
 'worker, field and crop filters all apply to attendance':'it.labourId in chosenWorkerIds && (allFields || it.fieldId in chosenFieldIds) && (allCrops || it.cropId in chosenCropIds)' in src,
 'worker, field and crop filters all apply to payments':'store.payments.filter{inRange(it.date) && it.labourId in chosenWorkerIds && (allFields || it.fieldId in chosenFieldIds) && (allCrops || it.cropId in chosenCropIds)}' in src,
 'empty worker selection is blocked':'if(!allWorkers && selectedReportWorkers.isEmpty())' in src,
 'empty field selection is blocked':'if(!allFields && selectedFields.isEmpty())' in src,
 'empty crop selection is blocked':'if(!allCrops && selectedCrops.isEmpty())' in src,
 'PDF metadata describes date and all selected dimensions':'तारीख: ${displayDate(startDate)} से ${displayDate(endDate)} • मजदूर:' in src and '• फसल:' in src,
 'report landing resets independent filters':'selectedReportWorkers.clear();allFields=true;allCrops=true;allWorkers=true' in src,
}
tracker=root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
with tracker.open(encoding='utf-8-sig',newline='') as f: rows={r['ID']:r for r in csv.DictReader(f)}
checks['K03 tracker reflects implemented source']=rows['K03']['Implementation_Status']=='IMPLEMENTED' and rows['K03']['Design_Status']=='IMPLEMENTED'
checks['K04 tracker reflects implemented source']=rows['K04']['Implementation_Status']=='IMPLEMENTED' and rows['K04']['Design_Status']=='IMPLEMENTED'
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
