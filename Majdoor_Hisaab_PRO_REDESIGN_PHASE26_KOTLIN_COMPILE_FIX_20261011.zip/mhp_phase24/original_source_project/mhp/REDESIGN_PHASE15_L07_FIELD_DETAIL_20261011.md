# Phase 15 — L07 Ganna Chhilai Field-wise Detail

Date: 2026-10-11

## Implemented
- Added a clear field-wise detail section to Ganna Chhilai Search / Filter. Every field card shows saved entry count, distinct workers, fandi total, and gross recorded wage; tapping a field opens its detail.
- Field detail now supports date-from/date-to and worker filters, filtered summary totals, an explicit empty-filter state, reset action, and PDF export of the currently filtered rows.
- Field-less entries are called out separately and are not incorrectly included in any field total.
- Existing per-worker and date-wise details remain. Saved per-entry rates are used for the amount calculation.

## Scope guard
Only the Ganna Chhilai field-detail route and its screen-progress row were changed. Ganna Parchi, general Labour, and the Home Dashboard were not intentionally modified.

## Verification
Static source audit: pending execution. Android Kotlin compile, APK build, device install, and real-device UI/PDF tests are not verified in this environment.
