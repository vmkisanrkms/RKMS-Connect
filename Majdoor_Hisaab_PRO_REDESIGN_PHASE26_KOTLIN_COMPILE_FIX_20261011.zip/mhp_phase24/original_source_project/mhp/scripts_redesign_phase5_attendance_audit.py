from pathlib import Path
import csv
project=Path(__file__).resolve().parent
root=project.parent.parent
kt=project/"app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt"
s=kt.read_text(encoding="utf-8")
checks={
"attendance date uses saveable state":"var selectedDate by rememberSaveable{mutableStateOf(today())}" in s,
"attendance field uses saveable state":"var activeField by rememberSaveable" in s,
"search state exists":"var attendanceQuery by rememberSaveable" in s,
"status filter state exists":"var attendanceFilter by rememberSaveable" in s,
"search matches name mobile address":"worker.mobile.contains(q) && worker.address.lowercase(Locale.ROOT).contains(q)" in s or ("worker.name.lowercase(Locale.ROOT).contains(q) || worker.mobile.contains(q) || worker.address.lowercase(Locale.ROOT).contains(q)") in s,
"status filter includes unmarked":"\"दर्ज नहीं\" -> record == null" in s,
"status filter includes full day":"\"पूरा दिन\" -> record?.fraction == 1.0" in s,
"status filter includes half day":"\"आधा दिन\" -> record?.fraction == 0.5" in s,
"status filter includes absent/bhanji":"\"भांजी/Absent\" -> record?.fraction == 0.0" in s,
"summary counts based on saved records":"val selectedFieldRows = store.attendances.filter { it.fieldId==activeField && it.date==selectedDate }" in s,
"search no-result empty state":"इस खोज या फ़िल्टर से कोई मजदूर नहीं मिला।" in s,
"protected edit gate retained":"DeviceCredentialGate(\n                \"हाजिरी बदलें\"" in s,
"protected delete gate retained":"DeviceCredentialDeleteGate(\n                \"हाजिरी हटाएँ\"" in s,
"135 unique screen ids retained":False,
}
tracker=root/"SCREEN_PROGRESS_TRACKER.csv"
if tracker.exists():
 rows=list(csv.DictReader(tracker.open(encoding="utf-8-sig",newline="")))
 checks["135 unique screen ids retained"]=len(rows)==135 and len({r["ID"] for r in rows})==135
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" | "+name)
print(f"SUMMARY {sum(checks.values())}/{len(checks)} PASS")
raise SystemExit(0 if all(checks.values()) else 1)
