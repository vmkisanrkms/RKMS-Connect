from pathlib import Path
import csv, sys
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
text=src.read_text(encoding='utf-8')
checks={
'F01 dashboard action routed to saved attendance field picker':'DashboardModule("🧾", "काम दर्ज करें"' in text and '"work_entry"->Screen.AttendanceFields' in text,
'F02 dedicated WorkList route':'data object WorkList:Screen()' in text and 'Screen.WorkList->WorkListScreen' in text,
'F02 reads real saved attendance rows':'val rows=store.attendances.sortedWith' in text,
'F02 displays absent attendance rows':'भांजी / अनुपस्थित' in text,
'F02 exposes worker ledger navigation':'मजदूर का पूरा लेजर देखें' in text,
'F03 dedicated rate history route':'Screen.WageRateHistory->WageRateHistoryScreen' in text,
'F03 reads stored rate history':'val rows=store.rates.sortedWith' in text,
'F03 rate history displays effective date and rate':'${displayDate(r.effectiveDate)} से लागू' in text and '₹${money(r.rate)}/दिन' in text,
'J04 dedicated profitability route':'Screen.Profitability->ProfitabilityScreen' in text,
'J04 revenue derives from saved sales':'val revenue=rows.sumOf{it.second}' in text and 'store.sales.filter{it.fieldId==f.id}.sumOf{it.total}' in text,
'J04 costs include saved attendance wages':'store.attendances.filter{it.fieldId==f.id}.sumOf{it.fraction*it.rate}' in text,
'J04 costs include saved field expenses':'store.expenses.filter{it.fieldId==f.id}.sumOf{it.amount}' in text,
'J04 profit is revenue less total cost':'profit=revenue-cost' in text,
'Existing backup keys retain work and wage data':'"attendance"' in text and '"rateHistory"' in text and '"sale"' in text and '"expense"' in text,
'Existing monthly lock guard remains in attendance delete':'if(isMonthLocked(row.date)) return false' in text,
'Ganna modules remain present':'Screen.CaneParchi->CaneParchiDashboardScreen(store)' in text and 'Screen.CanePeeling->CanePeelingScreen(store,{back()})' in text,
}
tracker=list(csv.DictReader((root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv').open(encoding='utf-8-sig',newline='')))
for i in ('F01','F02','F03','J04'):
    checks[f'{i} tracker updated']=any(r['ID']==i and r['Design_Status']=='IMPLEMENTED' and r['Test_Status']=='NOT TESTED' for r in tracker)
failed=[]
for name,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' | '+name)
    if not ok: failed.append(name)
print(f'SUMMARY: {len(checks)-len(failed)} PASS, {len(failed)} FAIL')
if failed: sys.exit(1)
