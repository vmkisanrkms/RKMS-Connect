from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
TRACKER = ROOT.parent.parent / 'SCREEN_PROGRESS_TRACKER.csv'
text = SOURCE.read_text(encoding='utf-8')
WORKFLOW = ROOT / '.github/workflows/majdoor-hisaab.yml'
workflow = WORKFLOW.read_text(encoding='utf-8') if WORKFLOW.exists() else ''
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

check('screen stack uses rememberSaveable with a typed saver', 'val stack = rememberSaveable(' in text and 'listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<Screen>, String>' in text)
check('screen stack serializer saves every route family', all(x in text for x in ['encodeScreenState(screen: Screen)', 'decodeScreenState(encoded: String)', '"labour_detail', '"field_detail', '"crop_detail', '"attendance_history', '"cane_parchi', '"cane_peeling']))
check('invalid saved route safely falls back to Home', 'saved.mapNotNull(::decodeScreenState).ifEmpty { listOf(Screen.Home) }' in text)
check('startup initialization is not restored as ready without Store', 'var startupReady by remember { mutableStateOf(false) }' in text)
check('app lock never restores unlocked state from saved state', 'var appUnlocked by remember{mutableStateOf(false)}' in text and 'var appUnlocked by rememberSaveable' not in text)
check('transient Drive busy flag is not restored after Activity recreation', 'var driveBusy by remember{mutableStateOf(false)}' in text)
check('restore temp-file path survives configuration recreation', 'var restoreFilePath by rememberSaveable{mutableStateOf("")}' in text and 'val restoreFile = restoreFilePath.takeIf{it.isNotBlank()}?.let(::File)' in text)
check('shared SimpleDialog handles system Back', 'private fun SimpleDialog' in text and 'BackHandler{onClose()};AlertDialog' in text)
check('shared ConfirmDialog handles system Back as cancel', 'private fun ConfirmDialog' in text and 'BackHandler(enabled=true){onNo()};AlertDialog' in text)
check('shared search normalizer is locale-stable', 'private fun normalizeSearch(value: String)' in text and 'value.lowercase(Locale.ROOT)' in text)
check('shared search normalizer converts Devanagari digits', "charArrayOf('०','१','२','३','४','५','६','७','८','९')" in text)
check('shared search ignores punctuation and spacing consistently', 'if (normalized.isLetterOrDigit()) append(normalized)' in text)
check('worker search uses shared normalizer', 'searchMatches(q, l.name, l.address, l.mobile)' in text)
check('field and crop searches use shared normalizer', 'searchMatches(query, f.name, f.address, f.area)' in text and 'searchMatches(query, c.name, c.variety, c.season, f?.name)' in text)
check('expense and sale searches use shared normalizer', 'searchMatches(query,e.type,e.item' in text and 'searchMatches(query,s.buyer' in text)
check('wage-rate and profitability searches use shared normalizer', 'searchMatches(query,name,r.effectiveDate' in text and 'searchMatches(query,f.name,f.address)' in text)
check('Fandi worker/payment searches use shared normalizer', 'searchMatches(query,it.name,it.mobile,it.address)' in text and 'searchMatches(query, labour?.name, payment.date)' in text)
check('cane-parchi search uses shared normalizer', 'searchMatches(query, it.name, it.fatherName, it.code, it.remark)' in text)
check('common form text and boolean state is saveable', 'var name by rememberSaveable{mutableStateOf(existing?.name?:"")}' in text and 'var add by rememberSaveable{mutableStateOf(false)}' in text)
check('Back stack navigation actions remain present', 'fun go(s:Screen)' in text and 'fun goRoot(s:Screen)' in text and 'fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }' in text)
check('all 135 tracker IDs remain unique', TRACKER.exists() and len(list(csv.DictReader(TRACKER.open(encoding='utf-8-sig', newline='')))) == 135)
check('tracker marks rotation as not runtime tested', any(r['ID']=='P10' and r['Test_Status']=='NOT TESTED' and 'Phase 21' in r['Notes'] for r in csv.DictReader(TRACKER.open(encoding='utf-8-sig', newline=''))))
check('GitHub workflow expects the exact current Phase 25 source ZIP', 'Majdoor_Hisaab_PRO_REDESIGN_PHASE25_GRADLE_WRAPPER_BOOTSTRAP_FIX_20261011.zip' in workflow)
check('GitHub workflow prioritizes canonical redesign project over legacy V99 copy', "*/original_source_project/mhp/gradlew" in workflow and 'scripts_redesign_phase21_shared_ui_audit.py' in workflow)

for label, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' | ' + label)
print(f'SUMMARY: {sum(ok for _,ok in checks)}/{len(checks)} PASS, {sum(not ok for _,ok in checks)} FAIL')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
