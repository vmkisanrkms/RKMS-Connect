from pathlib import Path
import csv, zipfile
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'expense list has live query state':'var query by rememberSaveable{mutableStateOf("")}' in src[src.index('private fun ExpenseScreen'):src.index('@Composable private fun ExpenseDialog')],
 'expense list filters saved records':'val list=all.filter{e->' in src[src.index('private fun ExpenseScreen'):src.index('@Composable private fun ExpenseDialog')],
 'expense visible subtotal uses saved amounts':'val visibleTotal=list.sumOf{it.amount}' in src,
 'expense empty/no-result state':'इस खोज से कोई खर्च नहीं मिला' in src,
 'expense edit gate retained':'DeviceCredentialGate("खर्च बदलें"' in src,
 'expense delete gate retained':'DeviceCredentialGate("खर्च हटाएँ"' in src,
 'sales list has live query state':'var query by rememberSaveable{mutableStateOf("")}' in src[src.index('private fun SaleScreen'):src.index('@Composable private fun SaleDialog')],
 'sales list filters saved records':'val list=all.filter{s->' in src[src.index('private fun SaleScreen'):src.index('@Composable private fun SaleDialog')],
 'sales subtotal uses saved totals':'val visibleTotal=list.sumOf{it.total}' in src,
 'sales empty/no-result state':'इस खोज से कोई बिक्री नहीं मिली' in src,
 'sale edit gate retained':'DeviceCredentialGate("बिक्री बदलें"' in src,
 'sale delete gate retained':'DeviceCredentialGate("बिक्री हटाएँ"' in src,
 'shared detail bar uses consistent dark green':'Surface(color=GreenDark,tonalElevation=0.dp)' in src,
 'shared section title has add action':'contentDescription="जोड़ें"' in src,
 'shared simple dialog has standard shape and spacing':'shape=RoundedCornerShape(24.dp),containerColor=CardBg' in src,
 'shared destructive confirmation remains wired':'confirmButton={Button(onClick=onYes,colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E)))' in src,
 'tracker still contains exactly 135 unique IDs':None,
}
tracker=root.parent.parent/'SCREEN_PROGRESS_TRACKER.csv'
with tracker.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
checks['tracker still contains exactly 135 unique IDs']=len(rows)==135 and len({r['ID'] for r in rows})==135
for name,ok in checks.items():
 if ok is None: ok=False
 print(('PASS' if ok else 'FAIL')+' | '+name)
if not all(checks.values()): raise SystemExit(1)
print(f'{len(checks)}/{len(checks)} PASS')
