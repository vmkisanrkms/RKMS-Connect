
## Phase 4 additions (2026-10-11)
- Expense and sales lists redesigned with live search, saved-record totals, improved cards and explicit empty/no-results states.
- Shared section headers, detail bars, action rows, dialogs and destructive confirmation styling standardized.
- Added `FEATURE_PRESERVATION_MATRIX_PHASE4.csv` and `scripts_redesign_phase4_ui_audit.py`.
- Tracker reports 16 design-implemented points out of 135. This remains a partial implementation; Android build and runtime testing are NOT TESTED.


## Phase 11 — Launch/Security
See `REDESIGN_PHASE11_LAUNCH_SECURITY_20261011.md`.
- A01 branded startup/loading state
- A03 platform biometric prompt with Android screen-lock fallback
- A05 local initialization error/retry state with offline-first guidance
- A06 persistent Light/Dark/System theme selector
- Static audit: `scripts_redesign_phase11_launch_security_audit.py`
- Android build/runtime and full visual verification remain NOT TESTED.


## Phase 12 — Attendance Bulk Actions & Calendar
See `REDESIGN_PHASE12_ATTENDANCE_BULK_CALENDAR_20261011.md`.
- E05: All Full / Clear All / Previous Team, with confirmation and device credential gate.
- E07: real saved-record attendance calendar, selectable dates and absent-record detail.
- Static audit: `scripts_redesign_phase12_attendance_bulk_calendar_audit.py`
- Android build/runtime tests remain NOT TESTED.


Phase 17: accounting integrity fixes and verification are documented in `REDESIGN_PHASE17_ACCOUNTING_INTEGRITY_20261011.md`. Android build/device verification remains pending.

## Phase 21 — Shared UI / Back Navigation / Search / Rotation (2026-10-11)
- Added a typed saveable navigation-stack serializer for all screen route families; unknown restored routes safely fall back to Home.
- Store startup is reinitialized after Activity recreation rather than restoring a stale ready flag; the app-lock gate and transient Drive busy flag are not restored.
- Pending restore temporary-file path, common string/boolean/number form fields, and search/filter state use saveable state where safe.
- Shared dialogs handle system Back consistently, with destructive confirmations cancelling rather than confirming.
- Shared search normalization is locale-stable, maps Devanagari digits to ASCII digits, and ignores punctuation/spacing for matching across key modules.
- Focused audit: 22/22 PASS; regression scripts results in `PHASE21_SHARED_UI_REGRESSION_AUDIT_RESULTS.txt`. Android compile/build/device rotation tests remain NOT TESTED.


Phase 23 note (2026-10-11): remaining master batch adds scoped cost/profit summary, connects report preferences to ledger PDF columns, adds a 7-day in-app backup reminder, centers wide layouts, and aligns CI workflow to the Phase 23 ZIP. Runtime tests remain NOT TESTED; see REDESIGN_PHASE23_REMAINING_MASTER_FIXES_20261011.md.
