# Majdoor Hisaab PRO — Phase 23 Remaining Master Audit

**Date:** 11 October 2026  
**Base:** Phase 22 ZIP  
**Canonical build source:** `original_source_project/mhp`  
**App ID:** `com.majdoor.hisaabpro` · **Version:** `1.82.0` / code `82`

## Executive result

- Requested checklist entries: **97**.
- Source implementation status: **92/97 marked IMPLEMENTED** after source recheck and focused fixes.
- Remaining implementation items: **5**.
- Test status for all 97 requested checklist entries remains **NOT TESTED** for Android runtime; static source checks are not a substitute for installing and exercising the APK.
- Static audit scripts: **23/23 exit successfully**.
- Assertions across those scripts: **489 PASS, 0 FAIL**.
- Phase 23 focused audit: **33/33 PASS**.
- Accounting-integrity source assertions: **24/24 PASS**; calculation scenarios: **7/7 PASS**.
- GitHub Actions YAML parse: **PASS**.
- ZIP integrity: verified after packaging.

## Fixes made in this batch

1. **Fields/Crops and profitability:** Expense screen now includes a field/crop-scoped summary of saved farming expenses, attendance-derived wage cost, saved sales revenue, total cost, and estimated profit/loss. The summary is independent of the text search.
2. **Report settings:** Summary, wage-column and payment-column preferences now control the worker-ledger and all-worker-ledger PDF summary blocks and columns. Worker identity remains visible if financial summary is switched off.
3. **Backup reminder:** If enabled, Home shows an in-app reminder when no verified backup exists or the latest backup is at least seven days old. Dismissal snoozes it for 24 hours. This is an in-app reminder, not a scheduled OS notification.
4. **Responsive root layout:** Main content is centered and capped at 900dp on wide screens while using available width on phones. Font scaling, keyboard and landscape behavior still require device tests.
5. **Attendance history:** Source review confirms selected-day details include absent workers and the attendance-history PDF receives all saved rows, including `fraction=0` absence records. Tracker note corrected.
6. **Accounting calculation:** Added shared pure Kotlin helpers for attendance wages, field profit and old-debt/credit/advance allocation. Five JUnit regression tests were added and CI now invokes `:app:testReleaseUnitTest` before signing/assembly. Those JUnit tests could not be run locally because Gradle bootstrap hit a DNS/network failure.
7. **CI/source consistency:** Workflow now expects the exact Phase 23 ZIP, explicitly selects `original_source_project/mhp`, runs the Phase 23 audit and Google Drive consent audit, and validates permanent signing secrets only after compile/unit-test steps.
8. **Tracker:** All 135 IDs remain unique; 97 requested IDs are tracked with honest implementation/test statuses.

## Remaining implementation items

| ID | Item | Why still open |
|---|---|---|
| A02 | PIN / Device Lock | Android device-credential/biometric gate exists, but the original blueprint's separate custom in-app PIN is not implemented.
| P03 | Reusable forms | App-wide reusable form-field standardization is not complete. Existing shared dialog/search controls remain.
| P06 | Loading/empty/error/success | Many screens have individual states, but a consistent app-wide shared feedback-state component and exhaustive state audit remain incomplete.
| Q01 | Feature preservation matrix | Matrix/tracker covers all 135 screens and selected safety scenarios, but the full action-by-action preservation matrix is not complete.
| Q09 | Signed Release APK | No signed APK is attached. It requires a successful GitHub Actions run and the repository's permanent `RELEASE_*` signing secrets.

## Important caveats

- O06 notification preferences are present, but this build does not include a push/scheduled notification delivery service.
- O08 is an in-app Home reminder; it is not an Android scheduled notification.
- The ZIP contains the historical V99 source snapshot as reference, but CI selects the canonical redesign source under `original_source_project/mhp`.
- Current canonical app ID is `com.majdoor.hisaabpro`, version `1.82.0` / code `82`. Confirm this package identity before publishing if the intended production package is different.
- The local Gradle compile attempt could not proceed: `gradlew` tried to fetch its missing wrapper bootstrap from `raw.githubusercontent.com`, but DNS resolution failed. No APK compile, signed build, installation, rotation, font-scaling, PDF visual, offline, or end-to-end backup/restore test is claimed.

## Requested point status

| Module | Requested IDs | Implementation summary | Runtime test |
|---|---|---|---|
| Launch/Security | A01–A06 | 5 implemented; A02 in progress | NOT TESTED |
| Dashboard | B01–B07 | 7 implemented | NOT TESTED |
| Workers/Ledger | C01, C05, C06, C08, C09 | 5 implemented | NOT TESTED |
| Daily Labour | D01, D05–D08 | 5 implemented | NOT TESTED |
| Attendance | E01–E05, E08–E10 | 8 implemented | NOT TESTED |
| Work/Wages/Payments | F01–F08 | 8 implemented | NOT TESTED |
| Fields | G01, G02, G04, G05 | 4 implemented | NOT TESTED |
| Crops | H01 | 1 implemented | NOT TESTED |
| Expenses | I01–I05 | 5 implemented | NOT TESTED |
| Sales/Income | J01–J03 | 3 implemented | NOT TESTED |
| Reports/PDF/CSV | K06, K07, K10, K11 | 4 implemented | NOT TESTED |
| Ganna Chhilayi | L01–L12 | 12 implemented | NOT TESTED |
| Ganna Parchi | M01–M06 | 6 implemented | NOT TESTED |
| Settings/Security | O06–O08 | 3 implemented at settings/in-app level; notification delivery service absent | NOT TESTED |
| Shared UI | P01–P10 | 8 implemented; P03/P06 in progress | NOT TESTED |
| Regression/Release | Q01–Q10 | 8 implemented; Q01 in progress; Q09 not started | NOT TESTED |

## Files in this Phase 23 ZIP

- `SCREEN_PROGRESS_TRACKER.csv` — current 135-point tracker
- `PHASE23_FULL_135_POINT_TRACKER.csv` — copy for audit/export
- `FEATURE_PRESERVATION_MATRIX_PHASE23.csv` — targeted regression matrix and test status
- `PHASE23_STATIC_AUDIT_RESULTS.txt` — 23-script audit results
- `PHASE23_REGRESSION_AUDIT_RESULTS.txt` — accounting and preservation regression status
- `REDESIGN_PHASE23_REMAINING_MASTER_FIXES_20261011.md` — source-change notes
