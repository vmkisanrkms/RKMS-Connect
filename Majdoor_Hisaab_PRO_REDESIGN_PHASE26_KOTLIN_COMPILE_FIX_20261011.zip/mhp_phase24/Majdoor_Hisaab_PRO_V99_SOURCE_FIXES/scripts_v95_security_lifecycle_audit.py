#!/usr/bin/env python3
"""Security lifecycle audit: unlocked state must never be restored from saved state."""
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
workflow=(root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
checks={
    'unlocked state is non-saveable and starts locked': 'var appUnlocked by remember{mutableStateOf(false)}' in source and 'var appUnlocked by rememberSaveable{mutableStateOf(false)}' not in source,
    'credential gate precedes accounting UI composition': source.index('if(!appUnlocked)') < source.index('Screen.Home->Dashboard(store)'),
    'activity recreation lock-gate runtime test exists': 'activityRecreationKeepsDeviceLockGateVisible' in (root/'app/src/androidTest/java/com/majdoor/hisaabpro/AppLaunchRuntimeSmokeTest.kt').read_text(encoding='utf-8'),
    'CI runs security lifecycle audit': 'python3 scripts_v95_security_lifecycle_audit.py' in workflow,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} security lifecycle checks passed')
if not all(checks.values()): raise SystemExit(1)
