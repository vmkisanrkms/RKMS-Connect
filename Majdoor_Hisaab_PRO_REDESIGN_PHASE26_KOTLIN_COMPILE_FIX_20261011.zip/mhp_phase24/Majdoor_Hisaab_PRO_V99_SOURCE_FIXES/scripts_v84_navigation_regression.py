#!/usr/bin/env python3
"""Static regression checks for V84 navigation wiring; not a substitute for Android runtime tests."""
from pathlib import Path
import sys
root=Path(__file__).parent
s=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
  'dashboard daily attendance action reaches Daily Labour home': '\"daily_labour\"->Screen.DailyLabourHome' in s,
  'dashboard worker module opens worker list': '\"labour\"->Screen.LabourList' in s,
  'dashboard crop module opens crop list': '\"crop\"->Screen.CropList()' in s,
  'unknown dashboard action no longer defaults to crop list': 'else->Screen.More' in s,
  'monthly account field report action opens report centre': 'onFieldReport={go(Screen.AllLabourReport)}' in s,
  'More menu includes monthly accounts shortcut': 'MoreMenuItem(\"accounts\"' in s and '\"accounts\"->Screen.DailyLabourAccounts' in s,
  'More menu includes date and field report shortcut': 'MoreMenuItem(\"field_report\"' in s and '\"field_report\"->Screen.AllLabourReport' in s,
  'More menu exposes worker list': 'MoreMenuItem(\"workers\"' in s and '\"workers\"->Screen.LabourList' in s,
  'four bottom navigation tabs remain': 'Triple(\"home\"' in s and 'Triple(\"labour\"' in s and 'Triple(\"field\"' in s and 'Triple(\"more\"' in s,
  'Ganna modules still route to existing screens': '\"cane\"->Screen.CaneParchi' in s and '\"cane_peeling\"->Screen.CanePeeling' in s,
}
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} V84 navigation regression checks passed')
sys.exit(1 if failed else 0)
