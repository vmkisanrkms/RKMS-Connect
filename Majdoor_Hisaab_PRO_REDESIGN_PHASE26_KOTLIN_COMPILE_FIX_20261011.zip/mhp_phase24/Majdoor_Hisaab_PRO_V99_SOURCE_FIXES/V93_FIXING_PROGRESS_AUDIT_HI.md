# Majdoor Hisaab PRO — V93 Re-check / Fixing Progress

**स्थिति: अभी FINAL READY नहीं।**

- 96/96 बिंदुओं के लिए source trace मिला; यह runtime proof नहीं है।
- इस 96-point checklist में 50 बिंदुओं पर source fix दर्ज है; इनकी भी Android runtime verification बाकी है।
- Fully fixed + Android runtime verified: 0 (कोई runtime gate अभी पूरा प्रमाणित नहीं)।

## V93 में वास्तविक सुधार

1. Locked month में backdated payment add करने पर रोक।
2. Locked month के payment को edit/delete करके finalized accounting बदलने पर रोक।
3. पुराने outstanding balance का settlement unlocked बाद की तारीख पर स्वीकार होता है।
4. Runtime regression harness में locked-month add/edit/delete और later settlement scenarios जोड़े।
5. Fandi worker add/update अब explicit Boolean save result लौटाते हैं; duplicate mobile/name पर form गलत तरीके से बंद नहीं होता।
6. Dark theme में cane module cards और settings चयन के contrast को theme-aware किया।
7. बिना खेत वाली हाजिरी/खर्च/बिक्री रिपोर्ट में “खेत नहीं चुना” दिखेगा, “खेत हटाया गया” नहीं।
8. Attendance में खेत चुने बिना हाजिरी का विकल्प जोड़ा; expense और sale forms में भी खेत/फसल optional विकल्प दिए और blank-field saves के regression checks जोड़े।
9. Persisted month-lock loader अब `2026-00` / `2026-13` जैसी malformed lock values को ignore करता है।
10. Runtime harness में मिले stale attendance-count assertions ठीक किए; अब Store recreation और backup round-trip में दोनों expected attendance IDs जाँचे जाते हैं।
11. Later payment regression अब केवल save success नहीं, actual outstanding balance reduction भी जाँचती है।
12. फसल से खर्च/बिक्री/हाजिरी/भुगतान जुड़ा होने पर उसका खेत बदलना रोक दिया, ताकि पुराने financial references टूटें नहीं। Regression assertion जोड़ा।
13. ALL season चुनने पर गन्ना पर्ची dashboard अब उसे वापस current season में reset नहीं करेगा; सभी seasons और single season के filter के regression cases जोड़े।
14. गन्ना छिलाई CSV में worker/field नामों के quotes और commas को सही escape किया, UTF-8 BOM जोड़ा, और regression assertion बनाया।
15. Backup/Restore validation में schema-2 के record dates और locked-month keys की semantic जाँच जोड़ी; invalid-date backup live data बदले बिना reject होता है।
16. मजदूर को निष्क्रिय/फिर सक्रिय करने का persisted विकल्प जोड़ा। निष्क्रिय मजदूर की पुरानी हाजिरी/भुगतान/बकाया सुरक्षित रहते हैं, नई हाजिरी रोकी जाती है; बिना accounting history वाला unused worker delete करने पर उसकी rate metadata भी साफ होती है।
17. Dashboard के “सभी देखें” payment action को searchable global payment history से जोड़ा; row tap पर संबंधित worker ledger खुलता है और route serialization test जोड़ा।
18. Emulator smoke test को target Android API 36 पर चलाने के लिए workflow update किया।
19. Payment और अग्रिम को अलग `kind` के साथ सहेजना, validate करना और history/CSV/PDF में दिखाना जोड़ा; पुराने records को default “भुगतान” मिलता है। Regression test जोड़ा।
20. Android instrumentation में Activity recreate करके device-lock gate बने रहने का test जोड़ा; emulator run अभी pending है।
21. Version `1.93.0`, versionCode `93`, workflow audit step और APK artifact name एक जैसे किए।

## Re-check परिणाम

- Daily Labour audit: 30/30 PASS
- Date/field report audit: 11/11 PASS
- Google Drive consent audit: 11 PASS (script output confirms all checks)
- Report selection audit: 16/16 PASS
- Navigation regression audit: 10/10 PASS
- Data integrity source audit: 62/62 PASS
- Restore atomicity audit: 23/23 PASS
- CRUD feedback audit: 14/14 PASS
- V92 source assertions retained: 73/73 PASS
- V93 locked-month payment audit: 40/40 PASS
- 96-point source trace: 96/96 source patterns found (not runtime proof)
- Workflow YAML and Android XML parse: PASS
- Python audit scripts compile: PASS

**कुल targeted static/source assertions: 290 PASS।** ये source/static checks हैं। Android instrumentation tests अभी execute नहीं हुए।

## बाकी अनिवार्य gates

- Gradle Release compile/assemble (local attempt blocked: missing `gradle-wrapper.jar`; wrapper download failed because DNS/network could not resolve `raw.githubusercontent.com`)
- Emulator instrumentation test execution
- असली फोन पर theme, app lock/biometric, auto-lock, notification/reboot, PDF layout, navigation और responsive font scaling
- Google Drive account के साथ backup → restore round-trip
- Ganna Chhilayi और Ganna Parchi के वास्तविक end-to-end regressions
- Signed APK signature/alignment/package verification
- 96-point सूची के प्रत्येक बिंदु की runtime evidence सहित final sign-off

**निर्णय:** payment lock bug का source fix और regression assertions जोड़े गए हैं। पूर्ण fixing और runtime verification का दावा नहीं किया जा सकता; कोई final ZIP/APK इस चरण में नहीं बनाई गई।
