#!/usr/bin/env bash
# Build a verified Gradle 8.11.1 Wrapper JAR when a source ZIP omits it.
# The distribution is SHA-256 pinned in gradle-wrapper.properties.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
cd "$ROOT"
PROPERTIES="gradle/wrapper/gradle-wrapper.properties"
WRAPPER_JAR="gradle/wrapper/gradle-wrapper.jar"
EXPECTED_VERSION="8.11.1"
EXPECTED_DIST_SHA="$(sed -n 's/^distributionSha256Sum=//p' "$PROPERTIES" | head -n 1)"
EXPECTED_DIST_SHA="${EXPECTED_DIST_SHA//$'\r'/}"
if [[ ! "$EXPECTED_DIST_SHA" =~ ^[a-f0-9]{64}$ ]]; then
  echo "::error::gradle-wrapper.properties must contain a valid pinned distributionSha256Sum." >&2
  exit 1
fi
if ! grep -Fq "gradle-${EXPECTED_VERSION}-bin.zip" "$PROPERTIES"; then
  echo "::error::Expected pinned Gradle ${EXPECTED_VERSION} binary distribution." >&2
  exit 1
fi

# If a valid wrapper already exists, preserve it. If it is corrupt, regenerate it.
if [[ -s "$WRAPPER_JAR" ]] && jar tf "$WRAPPER_JAR" 2>/dev/null | grep -qx 'org/gradle/wrapper/GradleWrapperMain.class'; then
  echo "Gradle Wrapper JAR already exists and contains GradleWrapperMain."
else
  rm -f "$WRAPPER_JAR"
  DIST_ZIP="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/gradle-${EXPECTED_VERSION}-bin.zip"
  DIST_DIR="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/gradle-${EXPECTED_VERSION}"
  rm -f "$DIST_ZIP"
  rm -rf "$DIST_DIR"
  downloaded=0
  for url in \
    "https://services.gradle.org/distributions/gradle-${EXPECTED_VERSION}-bin.zip" \
    "https://downloads.gradle.org/distributions/gradle-${EXPECTED_VERSION}-bin.zip"; do
    echo "Downloading pinned Gradle distribution from ${url}"
    if curl --fail --location --show-error --retry 2 --retry-all-errors \
      --connect-timeout 20 --max-time 600 "$url" --output "$DIST_ZIP"; then
      downloaded=1
      break
    fi
    rm -f "$DIST_ZIP"
  done
  if [[ "$downloaded" != 1 || ! -s "$DIST_ZIP" ]]; then
    echo "::error::Could not download Gradle ${EXPECTED_VERSION}. Check GitHub Actions DNS/network access." >&2
    exit 1
  fi
  printf '%s  %s\n' "$EXPECTED_DIST_SHA" "$DIST_ZIP" | sha256sum --check --strict
  mkdir -p "$DIST_DIR"
  unzip -q "$DIST_ZIP" -d "$DIST_DIR"
  DIST_GRADLE="$DIST_DIR/gradle-${EXPECTED_VERSION}/bin/gradle"
  test -x "$DIST_GRADLE"
  "$DIST_GRADLE" wrapper --gradle-version "$EXPECTED_VERSION" --distribution-type bin
fi

# Re-pin the generated properties, as Gradle may rewrite them while generating the wrapper.
EXPECTED_URL="distributionUrl=https\\://services.gradle.org/distributions/gradle-${EXPECTED_VERSION}-bin.zip"
if grep -q '^distributionUrl=' "$PROPERTIES"; then
  sed -i "s#^distributionUrl=.*#$EXPECTED_URL#" "$PROPERTIES"
else
  echo "$EXPECTED_URL" >> "$PROPERTIES"
fi
if grep -q '^distributionSha256Sum=' "$PROPERTIES"; then
  sed -i "s/^distributionSha256Sum=.*/distributionSha256Sum=$EXPECTED_DIST_SHA/" "$PROPERTIES"
else
  sed -i "/^distributionUrl=/a distributionSha256Sum=$EXPECTED_DIST_SHA" "$PROPERTIES"
fi

test -s "$WRAPPER_JAR"
jar tf "$WRAPPER_JAR" | grep -qx 'org/gradle/wrapper/GradleWrapperMain.class'
grep -Fqx "$EXPECTED_URL" "$PROPERTIES"
grep -Fqx "distributionSha256Sum=$EXPECTED_DIST_SHA" "$PROPERTIES"
chmod +x ./gradlew
sha256sum "$WRAPPER_JAR"
echo "PASS: Gradle ${EXPECTED_VERSION} wrapper JAR exists, is readable, and distribution checksum is pinned."
