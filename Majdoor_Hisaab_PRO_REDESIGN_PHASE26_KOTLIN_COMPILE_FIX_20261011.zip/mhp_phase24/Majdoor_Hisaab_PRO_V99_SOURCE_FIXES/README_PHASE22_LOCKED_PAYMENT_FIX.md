# Phase 22 — Locked Month Payment Fix

This phase hardens the Daily Labour payment-lock behavior only. Locked-month payments cannot be added, edited, moved to a later date, or deleted. Payments made on later unlocked dates remain allowed for settling old outstanding balances. The source includes regression assertions and an audit script. Android runtime testing is still required.
