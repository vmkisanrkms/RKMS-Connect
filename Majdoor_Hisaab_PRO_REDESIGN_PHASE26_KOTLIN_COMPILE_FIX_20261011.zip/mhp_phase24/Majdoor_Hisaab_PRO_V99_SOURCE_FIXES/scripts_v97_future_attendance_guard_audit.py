#!/usr/bin/env python3
"""Regression audit for future-date attendance rejection at the Store boundary."""
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
workflow=(root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
checks={
    'Store validates attendance date before mutation':'if(!validDate(x.date) || !x.fraction.isFinite()' in src,
    'Store rejects future attendance date':'if(x.date>today()) return "भविष्य की तारीख की हाजिरी दर्ज नहीं हो सकती।"' in src,
    'regression test exercises far-future date':'date="9999-12-31"' in src,
    'regression test verifies no attendance was mutated':'?.contains("भविष्य") == true && store.attendances.isEmpty()' in src,
    'CI runs the future attendance guard audit':'python3 scripts_v97_future_attendance_guard_audit.py' in workflow,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+label)
print(f'{sum(checks.values())}/{len(checks)} future attendance guard checks passed')
if not all(checks.values()): raise SystemExit(1)
