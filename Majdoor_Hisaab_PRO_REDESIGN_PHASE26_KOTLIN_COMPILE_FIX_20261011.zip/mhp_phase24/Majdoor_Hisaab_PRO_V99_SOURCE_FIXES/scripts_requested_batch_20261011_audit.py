#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'Expense deletion synchronized and reports success': '@Synchronized fun deleteExpense(id:String):Boolean' in s,
 'Expense deletion validates ID before mutation': 'if(id.isBlank() || expenses.none{it.id==id}) return false' in s,
 'Expense deletion commits before changing memory': 'if(!prefs.edit().putString("expense",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false' in s,
 'Sale deletion synchronized and reports success': '@Synchronized fun deleteSale(id:String):Boolean' in s,
 'Sale deletion validates ID before mutation': 'if(id.isBlank() || sales.none{it.id==id}) return false' in s,
 'Sale deletion commits before changing memory': 'if(!prefs.edit().putString("sale",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false' in s,
 'Parchi deletion synchronized and validates ID': '@Synchronized fun deleteCaneParchi(id:String):Boolean' in s and 'caneParchis.none{it.id==id}' in s,
 'Chhilayi entry deletion synchronized': '@Synchronized fun deleteCanePeeling(id:String):Boolean' in s,
 'Chhilayi payment deletion synchronized': '@Synchronized fun deleteCanePeelingPayment(id:String):Boolean' in s,
 'Expense delete persistence regression added': 'expense delete is idempotent, synchronized and persisted only for an existing row' in s,
 'Sale delete persistence regression added': 'sale delete is idempotent, synchronized and persisted only for an existing row' in s,
 'Parchi delete persistence regression added': 'parchi delete requires an existing ID and persists atomically' in s,
 'Existing month-lock protection retained': 'locked month blocks attendance changes' in s and 'locked-month payment cannot be edited into or deleted from finalized month' in s,
 'Existing Fandi duplicate protection retained': 'duplicate cane peeling worker-field-date is rejected' in s,
 'Existing restore rollback checks retained': 'restore failure rolls back existing records, field order and locked months' in s,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+label)
print(f'{sum(checks.values())}/{len(checks)} targeted source checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
