# Majdoor Hisaab PRO — V94 Working Source (NOT FINAL)

यह folder fixing work के लिए है। इसे final-ready ZIP/APK न समझें और अभी install करने के लिए कोई APK शामिल नहीं है।

- Package: `com.majdoor.hisaabpro`
- Version: `1.94.0` / versionCode `94`
- Release workflow artifact target: `Majdoor-Hisaab-PRO-V94-FINAL.apk`
- Full checklist: `V94_REQUESTED_96_POINT_FIX_CHECKLIST.csv`
- New source-hardening rows (runtime pending): `V94_REQUESTED_96_POINT_FIX_CHECKLIST.csv`
- Rows without new source hardening in this pass: `V94_RECHECK_PROGRESS_HI.md`
- Current audit: `V91_PROGRESS_AUDIT_HI.md`

## Status

Static source checks pass, but Android Gradle compile, signed Release APK, emulator instrumentation, physical-device verification, Google Drive account flow, PDF visual review, and restart/offline regression have not yet been proven in this environment. Do not mark the app ready until these checks pass and every checklist item has evidence.

The previous `Majdoor_Hisaab_PRO_V88_122_ITEM_FIX_BATCH.zip` is an incomplete historical batch, not the final deliverable. No new ZIP is being packaged during this continued fixing pass.


## V90 अतिरिक्त सुधार
- Google Drive/local ZIP restore को transactional बनाया: restore fail होने पर managed preferences और पुरानी photos वापस restore करने का rollback path।
- Restore writes अब synchronous success-check के साथ हैं; restored photo byte-length verify होती है।
- Regression harness में field/crop history delete protection, finalized closure date guard, ZIP path-traversal, missing mapped photo और restore-failure rollback checks जोड़े।
- Static audit: restore atomicity 11/11 PASS; main data-integrity audit 62/62 PASS। Android build/emulator runtime अभी pending है; यह FINAL READY package नहीं है।


- V91 की नई fixing सूची: `V91_NEW_FIXES_RUNTIME_PENDING.csv`

## V91 अतिरिक्त सुधार
- Android 11+ पर biometric + device credential gate जोड़ा; पुराने Android पर सुरक्षित device-credential fallback रखा।
- Schema-1 legacy backup में गायब module arrays, खेत क्रम और Fandi rate को खाली/default से overwrite करने के बजाय मौजूदा values सुरक्षित रखने का सुधार; पुरानी ZIP में photos न हों तो existing photos भी delete नहीं होंगी।
- Regression harness में partial schema-1 restore preservation assertion जोड़ा।
- Release version/workflow artifact V91 पर sync किया।
- Runtime/build verification अभी pending है; यह FINAL READY package नहीं है।


## V94 recheck status (2026-10-11)

12 source audit scripts pass, the 96-point source trace passes, Python scripts compile, and Android XML resources parse. This is still NOT FINAL: all 96 Android runtime verification ticks remain unchecked; local Gradle could not run because the wrapper JAR and Android SDK are absent and network access is unavailable. See `V94_RECHECK_PROGRESS_HI.md`.
## V95 security lifecycle hardening (2026-10-11)
- The app-unlocked flag is now non-saveable and starts locked, preventing a saved Activity state from restoring an unlocked accounting session.
- Static audit `scripts_v95_security_lifecycle_audit.py`: 4/4 PASS.
- This is source/static evidence only; Gradle, emulator, physical-device, Google Drive, PDF visual and signed-release gates remain pending. See `V95_SECURITY_LIFECYCLE_FIX_AUDIT_HI.md`.
