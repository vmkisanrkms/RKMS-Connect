package com.majdoor.hisaabpro

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.assertExists
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Real Android emulator smoke test. It verifies the app launches and does not bypass
 * the Android-device-lock requirement when the emulator has no secure lock configured.
 * Full account/Drive flows still require an explicitly configured test account.
 */
@RunWith(AndroidJUnit4::class)
class AppLaunchRuntimeSmokeTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun launchShowsDeviceLockRequirementOnUnsecuredEmulator() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Android Screen Lock जरूरी है", substring = true).assertExists()
        composeRule.onNodeWithText("PIN, Pattern या Password", substring = true).assertExists()
    }

    @Test
    fun activityRecreationKeepsDeviceLockGateVisible() {
        composeRule.waitForIdle()
        composeRule.activityRule.scenario.recreate()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Android Screen Lock जरूरी है", substring = true).assertExists()
        composeRule.onNodeWithText("PIN, Pattern या Password", substring = true).assertExists()
    }

    @Test
    fun coreLocalAccountingAndBackupRegressionChecksPass() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val results = runCoreStoreRuntimeRegression(context)
        results.forEach { (scenario, passed) -> assertTrue("Runtime regression failed: $scenario", passed) }
    }
}
