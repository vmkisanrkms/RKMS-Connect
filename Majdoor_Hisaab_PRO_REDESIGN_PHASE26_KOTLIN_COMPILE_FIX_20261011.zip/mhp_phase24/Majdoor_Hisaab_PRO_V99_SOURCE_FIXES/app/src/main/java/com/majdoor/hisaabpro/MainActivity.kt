package com.majdoor.hisaabpro

import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.Manifest
import android.content.pm.PackageManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Build
import android.content.ContentResolver
import android.accounts.Account
import java.io.File
import java.io.FileOutputStream
import java.io.ByteArrayOutputStream
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.concurrent.Executors
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private data class AppPalette(
    val green: Color, val greenDark: Color, val background: Color, val card: Color,
    val text: Color, val muted: Color, val accentText: Color
)
private val LightPalette = AppPalette(Color(0xFF0B6B4A), Color(0xFF064C36), Color(0xFFF6FAF8), Color.White, Color(0xFF202824), Color(0xFF66736C), Color(0xFF064C36))
private val DarkPalette = AppPalette(Color(0xFF2F9D76), Color(0xFF0B3326), Color(0xFF101815), Color(0xFF1B2621), Color(0xFFE7F0EB), Color(0xFFB2C0B8), Color(0xFFB6F1D6))
private val LocalAppPalette = staticCompositionLocalOf { LightPalette }
private val Green: Color @Composable get() = LocalAppPalette.current.green
private val GreenDark: Color @Composable get() = LocalAppPalette.current.greenDark
private val Bg: Color @Composable get() = LocalAppPalette.current.background
private val CardBg: Color @Composable get() = LocalAppPalette.current.card
private val AppText: Color @Composable get() = LocalAppPalette.current.text
private val AppMuted: Color @Composable get() = LocalAppPalette.current.muted
private val AppAccentText: Color @Composable get() = LocalAppPalette.current.accentText
private val AppPanelBg: Color @Composable get() = if(LocalAppPalette.current.background==DarkPalette.background) LocalAppPalette.current.card else Color(0xFFEAF8F1)

private data class Labour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String,val active:Boolean=true)
private data class FandiLabour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
private data class Field(val id:String,val name:String,val address:String,val area:String,val photo:String)
private data class Crop(val id:String,val fieldId:String,val name:String,val variety:String,val sowingDate:String,val season:String)
private data class Expense(val id:String,val fieldId:String,val cropId:String,val type:String,val item:String,val qty:String,val unit:String,val amount:Double,val date:String)
private data class Sale(val id:String,val fieldId:String,val cropId:String,val qty:Double,val unit:String,val rate:Double,val total:Double,val buyer:String,val date:String)
private data class Attendance(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val fraction:Double,val rate:Double)
private data class Payment(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val amount:Double,val kind:String="payment")
private data class LabourClosure(val id:String,val labourId:String,val throughDate:String,val wage:Double,val paid:Double,val closedAt:Long)
private data class WageRate(val id:String,val labourId:String,val effectiveDate:String,val rate:Double)
private data class CanePrice(val id:String,val season:String,val effectiveDate:String,val rate:Double)
private data class CaneParchi(val id:String,val name:String,val fatherName:String,val code:String,val date:String,val weight:Double,val rate:Double,val photo:String,val remark:String,val season:String)
private data class CanePeeling(val id:String,val labourId:String,val fieldId:String,val date:String,val fandi:Double,val rate:Double,val total:Double)
private data class CanePeelingPayment(val id:String,val labourId:String,val date:String,val amount:Double,val method:String,val note:String)

private data class MoreMenuItem(val key:String,val title:String,val subtitle:String,val icon:androidx.compose.ui.graphics.vector.ImageVector)

private sealed class Screen {
    data object Home:Screen()
    data object LabourList:Screen()
    data object PaymentHistory:Screen()
    data object DailyLabourHome:Screen()
    data object DailyLabourAccounts:Screen()
    data object AllLabourReport:Screen()
    data object AttendanceFields:Screen()
    data object FieldList:Screen()
    data class ExpenseList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class SaleList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class CropList(val fieldId:String?=null):Screen()
    data class LabourDetail(val id:String):Screen()
    data class FieldDetail(val id:String):Screen()
    data class CropDetail(val id:String):Screen()
    data class Attendance(val fieldId:String?=null):Screen()
    data object AttendanceHistory:Screen()
    data object TodayAttendance:Screen()
    data object Backup:Screen()
    data object Profile:Screen()
    data object More:Screen()
    data object CaneParchi:Screen()
    data object CanePeeling:Screen()
}

private fun encodeScreen(screen:Screen):String = when(screen){
    Screen.Home -> "home"
    Screen.LabourList -> "labour-list"
    Screen.PaymentHistory -> "payment-history"
    Screen.DailyLabourHome -> "daily-home"
    Screen.DailyLabourAccounts -> "daily-accounts"
    Screen.AllLabourReport -> "all-report"
    Screen.AttendanceFields -> "attendance-fields"
    Screen.FieldList -> "field-list"
    is Screen.ExpenseList -> "expense:${screen.fieldId.orEmpty()}:${screen.cropId.orEmpty()}"
    is Screen.SaleList -> "sale:${screen.fieldId.orEmpty()}:${screen.cropId.orEmpty()}"
    is Screen.CropList -> "crop-list:${screen.fieldId.orEmpty()}"
    is Screen.LabourDetail -> "labour-detail:${screen.id}"
    is Screen.FieldDetail -> "field-detail:${screen.id}"
    is Screen.CropDetail -> "crop-detail:${screen.id}"
    is Screen.Attendance -> "attendance:${screen.fieldId.orEmpty()}"
    Screen.AttendanceHistory -> "attendance-history"
    Screen.TodayAttendance -> "today-attendance"
    Screen.Backup -> "backup"
    Screen.Profile -> "profile"
    Screen.More -> "more"
    Screen.CaneParchi -> "cane-parchi"
    Screen.CanePeeling -> "cane-peeling"
}

private fun decodeScreen(value:String):Screen?{
    val parts=value.split(":",limit=3)
    return when(parts.firstOrNull()){
        "home"->Screen.Home;"labour-list"->Screen.LabourList;"payment-history"->Screen.PaymentHistory;"daily-home"->Screen.DailyLabourHome;
        "daily-accounts"->Screen.DailyLabourAccounts;"all-report"->Screen.AllLabourReport;
        "attendance-fields"->Screen.AttendanceFields;"field-list"->Screen.FieldList;
        "expense"->Screen.ExpenseList(parts.getOrNull(1)?.ifBlank{null},parts.getOrNull(2)?.ifBlank{null});
        "sale"->Screen.SaleList(parts.getOrNull(1)?.ifBlank{null},parts.getOrNull(2)?.ifBlank{null});
        "crop-list"->Screen.CropList(parts.getOrNull(1)?.ifBlank{null});
        "labour-detail"->parts.getOrNull(1)?.takeIf{it.isNotBlank()}?.let{Screen.LabourDetail(it)};
        "field-detail"->parts.getOrNull(1)?.takeIf{it.isNotBlank()}?.let{Screen.FieldDetail(it)};
        "crop-detail"->parts.getOrNull(1)?.takeIf{it.isNotBlank()}?.let{Screen.CropDetail(it)};
        "attendance"->Screen.Attendance(parts.getOrNull(1)?.ifBlank{null});
        "attendance-history"->Screen.AttendanceHistory;"today-attendance"->Screen.TodayAttendance;
        "backup"->Screen.Backup;"profile"->Screen.Profile;"more"->Screen.More;
        "cane-parchi"->Screen.CaneParchi;"cane-peeling"->Screen.CanePeeling;else->null
    }
}


private const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
private const val DRIVE_FOLDER_NAME = "Majdoor Hisaab PRO"

private class NeedRemoteConsent(val consentIntent: Intent, message: String) : IllegalStateException(message)

private class GoogleDriveDirect(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_drive",Context.MODE_PRIVATE)
    private fun signInOptions():GoogleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestScopes(Scope(DRIVE_FILE_SCOPE))
        .build()
    fun signInIntent():Intent = GoogleSignIn.getClient(context,signInOptions()).signInIntent
    fun prepareFreshSignIn(onReady:()->Unit){
        prefs.edit().remove("email").apply()
        GoogleSignIn.getClient(context,signInOptions()).signOut().addOnCompleteListener { onReady() }
    }
    fun lastAccount():GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)
    fun saveAccount(account:GoogleSignInAccount){ prefs.edit().putString("email",account.email.orEmpty()).apply() }
    fun accountLabel():String = lastAccount()?.email ?: prefs.getString("email",null) ?: "Google Account नहीं जुड़ा"

    private fun token(account:GoogleSignInAccount):String{
        val acc:Account=account.account ?: throw IllegalStateException("Google Account उपलब्ध नहीं है।")
        return try {
            GoogleAuthUtil.getToken(context,acc,"oauth2:$DRIVE_FILE_SCOPE")
        } catch (consent:UserRecoverableAuthException) {
            // Do not launch UI from this IO-thread token request. Return the SDK-provided
            // consent intent to the Compose Activity Result handler, which owns retry policy.
            val consentIntent = consent.intent
            if (consentIntent != null) {
                throw NeedRemoteConsent(
                    consentIntent,
                    "Google Drive की अतिरिक्त अनुमति आवश्यक है। अनुमति स्क्रीन खोलें और फिर कार्रवाई जारी रखें।"
                )
            } else {
                throw IllegalStateException(
                    "Google Drive consent Intent उपलब्ध नहीं है। कृपया Backup/Restore दोबारा शुरू करें।"
                )
            }
        }
    }
    private fun request(method:String,url:String,token:String,body:ByteArray?=null,contentType:String?=null):ByteArray{
        val c=(URL(url).openConnection() as HttpURLConnection).apply{
            requestMethod=method
            setRequestProperty("Authorization","Bearer $token")
            connectTimeout=30000; readTimeout=60000
            if(body!=null){doOutput=true; setRequestProperty("Content-Type",contentType ?: "application/octet-stream")}
        }
        if(body!=null) c.outputStream.use{it.write(body)}
        val code=c.responseCode
        val stream=if(code in 200..299)c.inputStream else (c.errorStream ?: c.inputStream)
        val bytes=stream.use{it.readBytes()}
        if(code !in 200..299) throw IllegalStateException("Google Drive error $code: ${bytes.toString(Charsets.UTF_8).take(300)}")
        return bytes
    }
    private fun requestMultipartFile(url:String,token:String,file:File,contentType:String,head:ByteArray,tail:ByteArray):ByteArray{
        val maxBytes=100L*1024L*1024L
        if(!file.isFile || file.length()<=0L) throw IllegalArgumentException("Backup file खाली या उपलब्ध नहीं है।")
        if(file.length()>maxBytes) throw IllegalArgumentException("Backup 100 MB से बड़ा है। पहले फोटो/डेटा का आकार कम करें।")
        val contentLength=head.size.toLong()+file.length()+tail.size.toLong()
        val c=(URL(url).openConnection() as HttpURLConnection).apply{
            requestMethod="POST";setRequestProperty("Authorization","Bearer $token");setRequestProperty("Content-Type",contentType)
            connectTimeout=30000;readTimeout=120000;doOutput=true;setFixedLengthStreamingMode(contentLength)
        }
        c.outputStream.use{output->
            output.write(head)
            file.inputStream().buffered().use{input->input.copyTo(output,64*1024)}
            output.write(tail)
        }
        val code=c.responseCode
        val stream=if(code in 200..299)c.inputStream else (c.errorStream ?: c.inputStream)
        val bytes=stream.use{it.readBytes()}
        if(code !in 200..299) throw IllegalStateException("Google Drive error $code: ${bytes.toString(Charsets.UTF_8).take(300)}")
        return bytes
    }
    private fun downloadToFile(url:String,token:String,out:File,maxBytes:Long=100L*1024L*1024L):Long{
        val c=(URL(url).openConnection() as HttpURLConnection).apply{requestMethod="GET";setRequestProperty("Authorization","Bearer $token");connectTimeout=30000;readTimeout=120000}
        val code=c.responseCode
        if(code !in 200..299){val error=(c.errorStream ?: c.inputStream).use{it.readBytes()};throw IllegalStateException("Google Drive error $code: ${error.toString(Charsets.UTF_8).take(300)}")}
        val declaredLength=c.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
        if(declaredLength>maxBytes){c.disconnect();throw IllegalArgumentException("Drive backup 100 MB से बड़ा है।") }
        out.parentFile?.mkdirs()
        var total=0L
        try{
            c.inputStream.buffered().use{input->out.outputStream().buffered().use{output->
                val buffer=ByteArray(64*1024)
                while(true){val read=input.read(buffer);if(read<0)break;total+=read;if(total>maxBytes)throw IllegalArgumentException("Drive backup 100 MB से बड़ा है।");output.write(buffer,0,read)}
            }}
        }catch(error:Throwable){out.delete();throw error}finally{c.disconnect()}
        if(total<=0L){out.delete();throw IllegalStateException("Google Drive से खाली backup मिला।")}
        return total
    }
    private fun jsonGet(url:String,token:String):JSONObject=JSONObject(request("GET",url,token).toString(Charsets.UTF_8))

    private fun ensureFolder(token:String):String{
        val q=URLEncoder.encode("name='$DRIVE_FOLDER_NAME' and mimeType='application/vnd.google-apps.folder' and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&pageSize=10&fields=files(id,name)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files!=null && files.length()>0) return files.getJSONObject(0).getString("id")
        val meta=JSONObject().apply{put("name",DRIVE_FOLDER_NAME);put("mimeType","application/vnd.google-apps.folder")}
        return JSONObject(request("POST","https://www.googleapis.com/drive/v3/files?fields=id",token,meta.toString().toByteArray(Charsets.UTF_8),"application/json").toString(Charsets.UTF_8)).getString("id")
    }
    fun upload(account:GoogleSignInAccount,zip:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val boundary="mhpro_${System.currentTimeMillis()}"
        val meta=JSONObject().apply{
            put("name",zip.name)
            put("mimeType","application/octet-stream")
            put("parents",org.json.JSONArray().put(folder))
        }.toString()
        val head=("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n").toByteArray()
        val tail="\r\n--$boundary--\r\n".toByteArray()
        val result=requestMultipartFile("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name",token,zip,"multipart/related; boundary=$boundary",head,tail)
        return JSONObject(result.toString(Charsets.UTF_8)).optString("name",zip.name)
    }
    fun downloadLatest(account:GoogleSignInAccount,out:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val q=URLEncoder.encode("'$folder' in parents and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&orderBy=createdTime desc&pageSize=20&fields=files(id,name,createdTime,mimeType)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files==null || files.length()==0) throw IllegalStateException("Google Drive में कोई backup नहीं मिला।")
        var chosen:JSONObject?=null
        for(i in 0 until files.length()){
            val f=files.getJSONObject(i)
            if(f.optString("name").endsWith(".mhbackup",true)){chosen=f;break}
        }
        val file=chosen ?: throw IllegalStateException("Google Drive folder में कोई वैध .mhbackup फ़ाइल नहीं मिली। कोई दूसरी फ़ाइल restore नहीं की गई।")
        val id=file.getString("id")
        downloadToFile("https://www.googleapis.com/drive/v3/files/$id?alt=media",token,out)
        return file.optString("name","backup.mhbackup")
    }
}

private fun recordBackupHistory(context:Context,action:String,detail:String){
    val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
    val old=runCatching{JSONArray(prefs.getString("backupHistory","[]") ?: "[]")}.getOrElse{JSONArray()}
    val rows=(0 until old.length()).mapNotNull{old.optJSONObject(it)}.toMutableList()
    rows.add(JSONObject().put("at",System.currentTimeMillis()).put("action",action.take(80)).put("detail",detail.take(200)))
    val updated=JSONArray()
    rows.takeLast(20).forEach{updated.put(it)}
    prefs.edit().putString("backupHistory",updated.toString()).apply()
}

private class Store(private val context:Context, preferenceName:String="mhpro_store"){
    private val prefs=context.getSharedPreferences(preferenceName,Context.MODE_PRIVATE)
    var dataWarning by mutableStateOf(""); private set
    var labours by mutableStateOf(loadLabours()); private set
    var fandiLabours by mutableStateOf(loadFandiLabours()); private set
    var fields by mutableStateOf(loadFields()); private set
    var crops by mutableStateOf(loadCrops()); private set
    var expenses by mutableStateOf(loadExpenses()); private set
    var sales by mutableStateOf(loadSales()); private set
    var attendances by mutableStateOf(loadAttendance()); private set
    var payments by mutableStateOf(loadPayments()); private set
    var labourClosures by mutableStateOf(loadLabourClosures()); private set
    var lockedLabourMonths by mutableStateOf(loadLockedLabourMonths()); private set
    var rates by mutableStateOf(loadRates()); private set
    var fandiRate by mutableStateOf(prefs.getString("fandiRate","5")?.toDoubleOrNull() ?: 5.0); private set
    var canePrices by mutableStateOf(loadCanePrices()); private set
    var caneParchis by mutableStateOf(loadCaneParchis()); private set
    var canePeelings by mutableStateOf(loadCanePeelings()); private set
    var canePeelingPayments by mutableStateOf(loadCanePeelingPayments()); private set

    init {
        // One-time compatibility migration: only workers already referenced by old
        // Fandi records are copied into the new independent Fandi labour list.
        // Daily labour records are never copied wholesale.
        if(fandiLabours.isEmpty() && canePeelings.isNotEmpty()){
            val ids=canePeelings.map{it.labourId}.distinct()
            val migrated=ids.mapNotNull{id->labours.firstOrNull{it.id==id}?.let{l->FandiLabour(l.id,l.name,l.address,l.rate,l.mobile,l.photo)}}
            if(migrated.isNotEmpty()){
                fandiLabours=migrated.distinctBy{it.id}
                write("fandiLabour",fandiLabours,::obj)
            }
        }
        normalizeFandiData()
    }

    private fun normalizeFandiData(){
        fun nameKey(v:String)=v.trim().lowercase(Locale.ROOT).replace(Regex("\\s+")," ")
        fun phoneKey(v:String)=v.filter{it.isDigit()}
        val canonical=mutableListOf<FandiLabour>()
        val idMap=mutableMapOf<String,String>()
        fandiLabours.forEach{worker->
            val nk=nameKey(worker.name)
            val ph=phoneKey(worker.mobile)
            // Product rule: a normalized worker name must be unique. For legacy data,
            // map same-name profiles to the first profile and preserve their linked history.
            // A matching valid phone also identifies the same profile even if the name changed.
            val prior=canonical.firstOrNull{old->
                (nk.isNotBlank() && nameKey(old.name)==nk) || (ph.length>=7 && phoneKey(old.mobile).length>=7 && ph==phoneKey(old.mobile))
            }
            if(prior==null){canonical.add(worker);idMap[worker.id]=worker.id}
            else{
                idMap[worker.id]=prior.id
                val merged=prior.copy(
                    address=prior.address.ifBlank{worker.address},
                    mobile=prior.mobile.ifBlank{worker.mobile},
                    photo=prior.photo.ifBlank{worker.photo}
                )
                canonical[canonical.indexOfFirst{it.id==prior.id}]=merged
            }
        }
        val mappedRows=canePeelings.map{row->row.copy(labourId=idMap[row.labourId]?:row.labourId)}
        // Consolidate legacy duplicate rows by ADDING their quantities, never replacing 10 with 15.
        val uniqueRows=linkedMapOf<String,CanePeeling>()
        mappedRows.forEach{row->
            val key="${row.labourId}|${row.fieldId}|${row.date}"
            val old=uniqueRows[key]
            uniqueRows[key]=if(old==null) row else {
                val f=old.fandi+row.fandi
                val amount=old.total+row.total
                old.copy(fandi=f,total=amount,rate=if(f>0) amount/f else old.rate)
            }
        }
        val cleanRows=uniqueRows.values.toList()
        val cleanPayments=canePeelingPayments.map{payment->payment.copy(labourId=idMap[payment.labourId]?:payment.labourId)}
        if(canonical!=fandiLabours){fandiLabours=canonical;write("fandiLabour",fandiLabours,::obj)}
        if(cleanRows!=canePeelings){canePeelings=cleanRows;write("canePeeling",canePeelings,::obj)}
        if(cleanPayments!=canePeelingPayments){canePeelingPayments=cleanPayments;write("canePeelingPayment",canePeelingPayments,::obj)}
    }

    private fun preserveRawForRecovery(key:String,raw:String){
        val recoveryKey="recovery_raw_$key"
        if(!prefs.contains(recoveryKey)) prefs.edit().putString(recoveryKey,raw).apply()
        dataWarning="कुछ पुराने रिकॉर्ड पढ़ने में समस्या मिली। ऐप को बंद होने से बचाने के लिए मूल डेटा की एक सुरक्षित recovery copy रखी गई है। Backup बनाकर सहायता लें; ऐप ने मूल raw डेटा overwrite नहीं किया है।"
    }
    private fun read(key:String):JSONArray{
        val raw=prefs.getString(key,"[]") ?: "[]"
        val parsed=runCatching{JSONArray(raw)}.getOrElse{
            preserveRawForRecovery(key,raw)
            return JSONArray()
        }
        val badRows=(0 until parsed.length()).any{i->runCatching{parsed.getJSONObject(i)}.isFailure}
        if(!badRows) return parsed
        preserveRawForRecovery(key,raw)
        return JSONArray().apply{for(i in 0 until parsed.length()) runCatching{parsed.getJSONObject(i)}.getOrNull()?.let{put(it)}}
    }
    private fun str(o:JSONObject,k:String)=o.optString(k,"")
    private fun num(o:JSONObject,k:String)=o.optDouble(k,0.0)
    private fun save(key:String,a:JSONArray){prefs.edit().putString(key,a.toString()).apply()}
    private fun <T> JSONArray.mapList(mapper:(JSONObject)->T): List<T> = (0 until length()).mapNotNull { index ->
        runCatching { mapper(getJSONObject(index)) }.onFailure {
            dataWarning="कुछ रिकॉर्ड का प्रारूप अमान्य है। ऐप ने पढ़े जा सकने वाले रिकॉर्ड दिखाए हैं; मूल डेटा की recovery copy सुरक्षित रखें।"
        }.getOrNull()
    }

    private fun loadLabours()=read("labour").mapList{Labour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"),it.optBoolean("active",true))}
    private fun loadFandiLabours()=read("fandiLabour").mapList{FandiLabour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFields():List<Field>{
        val raw=read("field").mapList{Field(str(it,"id"),str(it,"name"),str(it,"address"),str(it,"area"),str(it,"photo"))}
        val order=prefs.getString("fieldOrder","").orEmpty().split('|').filter{it.isNotBlank()}
        if(order.isEmpty()) return raw
        val byId=raw.associateBy{it.id}
        return order.mapNotNull{byId[it]} + raw.filter{it.id !in order}
    }
    private fun loadCrops()=read("crop").mapList{Crop(str(it,"id"),str(it,"fieldId"),str(it,"name"),str(it,"variety"),str(it,"sowingDate"),str(it,"season"))}
    private fun loadExpenses()=read("expense").mapList{Expense(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),str(it,"type"),str(it,"item"),str(it,"qty"),str(it,"unit"),num(it,"amount"),str(it,"date"))}
    private fun loadSales()=read("sale").mapList{Sale(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),num(it,"qty"),str(it,"unit"),num(it,"rate"),num(it,"total"),str(it,"buyer"),str(it,"date"))}
    private fun loadAttendance():List<Attendance>{
        val raw=read("attendance").mapList{Attendance(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"fraction"),num(it,"rate"))}
        // Backward compatibility: an old attendance without cropId can be safely
        // attached to the only crop in that field. If multiple crops exist, keep
        // it field-level because assigning it to a crop would be guesswork.
        return raw.map{a->
            if(a.cropId.isBlank()){
                val matches=crops.filter{it.fieldId==a.fieldId}
                if(matches.size==1) a.copy(cropId=matches.first().id) else a
            } else a
        }
    }
    private fun loadPayments()=read("payment").mapList{Payment(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"amount"),it.optString("kind","payment").takeIf{kind->kind=="payment"||kind=="advance"} ?: "payment")}
    private fun loadLabourClosures()=read("labourClosure").mapList{LabourClosure(str(it,"id"),str(it,"labourId"),str(it,"throughDate"),num(it,"wage"),num(it,"paid"),it.optLong("closedAt",0L))}
    private fun loadLockedLabourMonths():List<String> = read("lockedLabourMonths").mapList{str(it,"month")}.filter{validMonthKey(it)}.distinct().sortedDescending()
    private fun loadRates()=read("rateHistory").mapList{WageRate(str(it,"id"),str(it,"labourId"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCanePrices()=read("canePriceHistory").mapList{CanePrice(str(it,"id"),str(it,"season"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCaneParchis()=read("caneParchi").mapList{CaneParchi(str(it,"id"),str(it,"name"),str(it,"fatherName"),str(it,"code"),str(it,"date"),num(it,"weight"),num(it,"rate"),str(it,"photo"),str(it,"remark"),str(it,"season"))}
    private fun loadCanePeelings()=read("canePeeling").mapList{CanePeeling(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"date"),num(it,"fandi"),num(it,"rate"),num(it,"total"))}
    private fun loadCanePeelingPayments()=read("canePeelingPayment").mapList{CanePeelingPayment(str(it,"id"),str(it,"labourId"),str(it,"date"),num(it,"amount"),str(it,"method"),str(it,"note"))}

    private fun obj(x:Labour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo);put("active",x.active)}
    private fun obj(x:FandiLabour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:Field)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("area",x.area);put("photo",x.photo)}
    private fun obj(x:Crop)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("name",x.name);put("variety",x.variety);put("sowingDate",x.sowingDate);put("season",x.season)}
    private fun obj(x:Expense)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("type",x.type);put("item",x.item);put("qty",x.qty);put("unit",x.unit);put("amount",x.amount);put("date",x.date)}
    private fun obj(x:Sale)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("qty",x.qty);put("unit",x.unit);put("rate",x.rate);put("total",x.total);put("buyer",x.buyer);put("date",x.date)}
    private fun obj(x:Attendance)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("fraction",x.fraction);put("rate",x.rate)}
    private fun obj(x:Payment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("amount",x.amount);put("kind",x.kind)}
    private fun obj(x:LabourClosure)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("throughDate",x.throughDate);put("wage",x.wage);put("paid",x.paid);put("closedAt",x.closedAt)}
    private fun obj(x:WageRate)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CanePrice)=JSONObject().apply{put("id",x.id);put("season",x.season);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CaneParchi)=JSONObject().apply{put("id",x.id);put("name",x.name);put("fatherName",x.fatherName);put("code",x.code);put("date",x.date);put("weight",x.weight);put("rate",x.rate);put("photo",x.photo);put("remark",x.remark);put("season",x.season)}
    private fun obj(x:CanePeeling)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("date",x.date);put("fandi",x.fandi);put("rate",x.rate);put("total",x.total)}
    private fun obj(x:CanePeelingPayment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("date",x.date);put("amount",x.amount);put("method",x.method);put("note",x.note)}
    private fun <T> persistList(key:String,list:List<T>,mapper:(T)->JSONObject):Boolean =
        prefs.edit().putString(key,JSONArray(list.map(mapper)).toString()).commit()
    private fun <T> write(key:String,list:List<T>,mapper:(T)->JSONObject){save(key,JSONArray(list.map(mapper)))}

    private val backupKeys = listOf("labour","fandiLabour","field","crop","expense","sale","attendance","payment","labourClosure","lockedLabourMonths","rateHistory","canePriceHistory","caneParchi","canePeeling","canePeelingPayment")

    @Synchronized fun createBackupZip(output:File){
        val parent=output.absoluteFile.parentFile ?: throw IllegalStateException("Backup folder उपलब्ध नहीं है।")
        if(!parent.exists() && !parent.mkdirs()) throw IllegalStateException("Backup folder नहीं बन सका।")
        val staging=File(parent,output.name+".staging-"+UUID.randomUUID())
        val previous=File(parent,output.name+".previous-"+UUID.randomUUID())
        var previousMoved=false
        try{
            val root=JSONObject().apply{
                put("schemaVersion",2)
                put("app","Majdoor Hisaab PRO")
                put("appVersion",BuildConfig.VERSION_NAME)
                put("createdAt",System.currentTimeMillis())
                put("backupHistory",runCatching{JSONArray(prefs.getString("backupHistory","[]") ?: "[]")}.getOrElse{JSONArray()})
                put("fandiRate",fandiRate)
                put("fieldOrder",prefs.getString("fieldOrder","").orEmpty())
                backupKeys.forEach{put(it,read(it))}
                put("recoveryData",JSONObject().apply{
                    prefs.all.keys.filter{it.startsWith("recovery_raw_")}.sorted().forEach{key->
                        prefs.getString(key,null)?.let{put(key.removePrefix("recovery_raw_"),it)}
                    }
                })
            }
            val photoPaths=(labours.map{it.photo}+fandiLabours.map{it.photo}+fields.map{it.photo}+caneParchis.map{it.photo}).filter{it.isNotBlank()}
                .map{File(it)}.filter{it.isFile}.distinctBy{it.absolutePath}
            val photoMap=JSONObject()
            photoPaths.forEachIndexed{index,file->
                val safeBase=file.name.replace(Regex("[^A-Za-z0-9._-]"),"_")
                photoMap.put(file.absolutePath,"${index}_${safeBase}")
            }
            root.put("photoMap",photoMap)
            ZipOutputStream(FileOutputStream(staging)).use{zos->
                zos.putNextEntry(ZipEntry("backup.json"))
                zos.write(root.toString().toByteArray(Charsets.UTF_8))
                zos.closeEntry()
                photoPaths.forEach{file->
                    val safe=photoMap.optString(file.absolutePath)
                    if(safe.isBlank()) return@forEach
                    zos.putNextEntry(ZipEntry("photos/$safe"))
                    file.inputStream().use{it.copyTo(zos)}
                    zos.closeEntry()
                }
            }
            if(!staging.isFile || staging.length()<=0L) throw IllegalStateException("Backup खाली बना है।")
            validateBackupZip(staging)
            if(output.exists()){
                if(!output.renameTo(previous)) throw IllegalStateException("पुराना backup सुरक्षित नहीं रखा जा सका; नया backup नहीं लिखा गया।")
                previousMoved=true
            }
            if(!staging.renameTo(output)) throw IllegalStateException("सत्यापित backup अंतिम जगह पर सेव नहीं हो सका।")
            validateBackupZip(output)
            previous.delete()
        }catch(error:Throwable){
            if(output.exists() && previousMoved) output.delete()
            if(previousMoved && previous.exists()) previous.renameTo(output)
            throw error
        }finally{
            staging.delete()
            if(!previousMoved) previous.delete()
        }
    }

    private fun readZipEntryLimited(zis:ZipInputStream, remainingBytes:Long):ByteArray{
        val out=ByteArrayOutputStream()
        val buffer=ByteArray(8192)
        var written=0L
        while(true){
            val count=zis.read(buffer)
            if(count<0) break
            written+=count
            if(written>remainingBytes) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
            out.write(buffer,0,count)
        }
        return out.toByteArray()
    }

    fun validateBackupZip(input:File){
        if(!input.isFile || input.length()<=0L) throw IllegalArgumentException("Backup file खाली या उपलब्ध नहीं है।")
        var backupJson:String?=null
        var total=0L
        val names=mutableSetOf<String>()
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry ?: break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                val name=entry.name.replace('\\','/')
                if(name.isBlank() || name.contains("..") || name.startsWith("/") || name.startsWith("~") || Regex("^[A-Za-z]:").containsMatchIn(name)) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(!names.add(name)) throw IllegalArgumentException("Backup में duplicate file entry मिली: $name")
                if(!entry.isDirectory){
                    val bytes=readZipEntryLimited(zis,100L*1024L*1024L-total)
                    total+=bytes.size
                    if(name=="backup.json") backupJson=bytes.toString(Charsets.UTF_8)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson ?: throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Backup app match नहीं करता।")
        val schema=root.optInt("schemaVersion",0)
        if(schema !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        // A partial/corrupt JSON must never be accepted as a full replacement backup;
        // absent arrays would otherwise be interpreted as empty and erase local records.
        val dateFields=mapOf(
            "expense" to "date", "sale" to "date", "attendance" to "date", "payment" to "date",
            "labourClosure" to "throughDate", "rateHistory" to "effectiveDate", "canePriceHistory" to "effectiveDate",
            "caneParchi" to "date", "canePeeling" to "date", "canePeelingPayment" to "date"
        )
        backupKeys.forEach{key->
            val raw=root.opt(key)
            val array=when{
                raw is JSONArray -> raw
                raw==null && schema==1 -> JSONArray() // legacy schema may not include newer modules
                else -> throw IllegalArgumentException("Backup में '$key' डेटा गलत या गायब है। पुराना डेटा सुरक्षित रखा गया है।")
            }
            for(index in 0 until array.length()){
                val row=array.optJSONObject(index) ?: throw IllegalArgumentException("Backup का '$key' रिकॉर्ड ${index+1} गलत है।")
                val dateField=dateFields[key]
                if(dateField!=null){
                    val dateValue=row.optString(dateField,"")
                    if((schema>=2 || dateValue.isNotBlank()) && !validDate(dateValue)) throw IllegalArgumentException("Backup के '$key' रिकॉर्ड ${index+1} की तारीख गलत है। पुराना डेटा सुरक्षित रखा गया है।")
                }
                if(key=="lockedLabourMonths"){
                    val month=row.optString("month","")
                    val validMonth=validMonthKey(month)
                    if((schema>=2 || month.isNotBlank()) && !validMonth) throw IllegalArgumentException("Backup में लॉक महीने का मान गलत है। पुराना डेटा सुरक्षित रखा गया है।")
                }
            }
        }
        val photoMap=root.optJSONObject("photoMap")
        if(schema>=2 && photoMap==null) throw IllegalArgumentException("Backup का photoMap गलत या गायब है।")
        if(root.has("recoveryData") && root.optJSONObject("recoveryData")==null) throw IllegalArgumentException("Backup की recoveryData metadata गलत है।")
        photoMap?.keys()?.forEach{key->
            val value=photoMap.optString(key,"")
            if(value.isBlank() || value.contains("..") || value.contains('/') || value.contains('\\')) throw IllegalArgumentException("Backup में photo path सुरक्षित नहीं है।")
            if(schema>=2 && "photos/$value" !in names) throw IllegalArgumentException("Backup में फोटो '$value' गायब है। पुराना डेटा सुरक्षित रखा गया है।")
        }
    }

    fun restoreBackupZip(input:File):String = restoreBackupZipImpl(input) {}

    /** Test-only failure injection proves rollback after preferences and photos have started changing. */
    internal fun restoreBackupZipWithInjectedFailureForTest(input:File):String =
        restoreBackupZipImpl(input) { throw java.io.IOException("Injected restore failure for rollback regression test") }

    private fun restoreBackupZipImpl(input:File, afterPhotoRestore:()->Unit):String{
        // Complete validation happens before any preference/photo mutation.
        validateBackupZip(input)
        var backupJson:String?=null
        val photoEntries=mutableListOf<Pair<String,ByteArray>>()
        var total=0L
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry?:break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                if(entry.isDirectory){zis.closeEntry();continue}
                val name=entry.name.replace('\\','/')
                if(name.contains("..") || name.startsWith("/")) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(name.startsWith("photos/") && name.removePrefix("photos/").isBlank()) throw IllegalArgumentException("Backup photo entry गलत है।")
                val bytes=readZipEntryLimited(zis,100L*1024L*1024L-total)
                total+=bytes.size
                when{
                    name=="backup.json" -> backupJson=bytes.toString(Charsets.UTF_8)
                    name.startsWith("photos/") -> photoEntries.add(name.removePrefix("photos/") to bytes)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson?:throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO")
            throw IllegalArgumentException("Backup app match नहीं करता।")
        val schema=root.optInt("schemaVersion",0)
        if(schema !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        val photoMap=root.optJSONObject("photoMap") ?: JSONObject()
        val restoredPhotoNames=mutableMapOf<String,String>()
        val photoDir=File(context.filesDir,"photos")
        fun restoredPath(original:String):String{
            if(original.isBlank()) return ""
            val backupName=photoMap.optString(original,"")
            if(backupName.isNotBlank()) restoredPhotoNames[File(backupName).name]?.let{return it}
            // Backward compatibility for schema v1 backups: match by original basename.
            val legacy=File(original).name
            val candidate=photoEntries.firstOrNull{File(it.first).name.endsWith("_$legacy") || File(it.first).name==legacy}
            candidate?.let{restoredPhotoNames[File(it.first).name]?.let{return it}}
            // Old backups sometimes have no photo archive at all. Keep an already-local
            // photo (or a still-valid legacy absolute path) instead of erasing its reference.
            if(schema==1){
                val existingLocal=File(photoDir,legacy)
                if(existingLocal.isFile) return existingLocal.absolutePath
                val originalFile=File(original)
                if(originalFile.isFile) return originalFile.absolutePath
            }
            return ""
        }
        // Restore is transactional at the app-data level: keep a rollback snapshot of all
        // managed preference keys and the existing photo directory until every write and
        // record reload has succeeded. A failed photo write must not leave half-restored data.
        val recoveryData=root.optJSONObject("recoveryData")
        val existingRecoveryKeys=prefs.all.keys.filter{it.startsWith("recovery_raw_")}
        val backupRecoveryKeys=recoveryData?.keys()?.asSequence()?.map{"recovery_raw_$it"}?.toList().orEmpty()
        val managedKeys=(backupKeys + listOf("fieldOrder","fandiRate","backupHistory") + existingRecoveryKeys + backupRecoveryKeys).distinct()
        val preferenceSnapshot=managedKeys.associateWith{key->prefs.getString(key,null)}
        val rollbackDir=File(context.cacheDir,"mhpro-restore-rollback-${UUID.randomUUID()}")
        val rollbackPhotos=File(rollbackDir,"photos")
        fun copyDirectory(source:File,destination:File){
            if(!source.exists()) return
            if(source.isDirectory){
                if(!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Rollback folder create नहीं हो सका।")
                source.listFiles()?.forEach{child->copyDirectory(child,File(destination,child.name))}
            }else{
                destination.parentFile?.mkdirs()
                source.inputStream().use{input->FileOutputStream(destination).use{output->input.copyTo(output)}}
            }
        }
        val hadPhotoDir=photoDir.exists()
        try{
            if(hadPhotoDir) copyDirectory(photoDir,rollbackPhotos)
            backupKeys.forEach{key->
                // Schema-1 backups predate several newer modules. A missing legacy key means
                // "not represented in this backup", not an empty collection: preserve current
                // records for that module instead of silently erasing them during migration.
                if(schema==1 && !root.has(key)) return@forEach
                val arr=root.optJSONArray(key) ?: JSONArray()
                if(!prefs.edit().putString(key,arr.toString()).commit()) throw IllegalStateException("'$key' डेटा सेव नहीं हो सका।")
            }
            // Preserve newer metadata when restoring an older schema that never stored it.
            if(root.has("fieldOrder")){
                if(!prefs.edit().putString("fieldOrder",root.optString("fieldOrder","")).commit()) throw IllegalStateException("खेतों का क्रम सेव नहीं हो सका।")
            }
            if(root.has("backupHistory")){
                if(!prefs.edit().putString("backupHistory",root.getJSONArray("backupHistory").toString()).commit()) throw IllegalStateException("Backup history सेव नहीं हुई।")
            }
            if(recoveryData!=null){
                val recoveryEditor=prefs.edit()
                existingRecoveryKeys.forEach{if(!recoveryData.has(it.removePrefix("recovery_raw_"))) recoveryEditor.remove(it)}
                recoveryData.keys().forEach{key->recoveryEditor.putString("recovery_raw_$key",recoveryData.optString(key,""))}
                if(!recoveryEditor.commit()) throw IllegalStateException("डेटा recovery copy restore नहीं हुई।")
            }
            val currentFandiRate=prefs.getString("fandiRate","5")?.toDoubleOrNull() ?: 5.0
            val requestedFandiRate=if(root.has("fandiRate")) root.optDouble("fandiRate",currentFandiRate) else currentFandiRate
            val restoredFandiRate=requestedFandiRate.takeIf{it.isFinite() && it>0} ?: 5.0
            if(root.has("fandiRate") && !prefs.edit().putString("fandiRate",restoredFandiRate.toString()).commit()) throw IllegalStateException("फांदी रेट सेव नहीं हो सका।")
            fandiRate=restoredFandiRate
            // Schema 2 is a complete photo snapshot, so replace the photo directory.
            // Schema 1 may not contain photo entries at all; merge its available photos into
            // the existing directory to avoid deleting photos absent from an older archive.
            if(schema>=2 && photoDir.exists() && !photoDir.deleteRecursively()) throw IllegalStateException("पुरानी फोटो फाइलें हटाई नहीं जा सकीं।")
            if(!photoDir.mkdirs() && !photoDir.isDirectory) throw IllegalStateException("फोटो फोल्डर तैयार नहीं हो सका।")
            photoEntries.forEach{(name,bytes)->
                if(name.isBlank()) return@forEach
                val safe=File(name).name
                val target=File(photoDir,safe)
                target.outputStream().use{it.write(bytes)}
                if(!target.isFile || target.length().toLong()!=bytes.size.toLong()) throw IllegalStateException("फोटो '$safe' पूरी तरह restore नहीं हुई।")
                restoredPhotoNames[safe]=target.absolutePath
            }
            afterPhotoRestore()
            labours=loadLabours().map{l->if(l.photo.isBlank()) l else l.copy(photo=restoredPath(l.photo))}
            fandiLabours=loadFandiLabours().map{l->if(l.photo.isBlank()) l else l.copy(photo=restoredPath(l.photo))}
            fields=loadFields().map{f->if(f.photo.isBlank()) f else f.copy(photo=restoredPath(f.photo))}
            // Persist restored photo paths so the restored database remains portable on this device.
            write("labour",labours,::obj); write("fandiLabour",fandiLabours,::obj); write("field",fields,::obj)
            crops=loadCrops(); expenses=loadExpenses()
            sales=loadSales(); attendances=loadAttendance(); payments=loadPayments(); labourClosures=loadLabourClosures(); lockedLabourMonths=loadLockedLabourMonths(); rates=loadRates(); canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()
            caneParchis=caneParchis.map{x->if(x.photo.isBlank()) x else x.copy(photo=restoredPath(x.photo))}
            write("caneParchi",caneParchis,::obj)
            dataWarning=if(recoveryData!=null && recoveryData.length()>0) "Backup में कुछ पुराने रिकॉर्ड की recovery copy मौजूद है। मुख्य रिकॉर्ड की जाँच करें; मूल raw डेटा recovery_raw_* में सुरक्षित रखा गया है।" else ""
            // Verify persisted JSON before discarding the rollback snapshot.
            backupKeys.forEach{key->JSONArray(prefs.getString(key,"[]") ?: "[]")}
            rollbackDir.deleteRecursively()
            return root.optString("createdAt","")
        }catch(error:Throwable){
            try{
                val editor=prefs.edit()
                managedKeys.forEach{key->
                    val value=preferenceSnapshot[key]
                    if(value==null) editor.remove(key) else editor.putString(key,value)
                }
                if(!editor.commit()) throw IllegalStateException("पुरानी preferences वापस सेव नहीं हुईं।")
                if(photoDir.exists() && !photoDir.deleteRecursively()) throw IllegalStateException("नई फोटो rollback में हटाई नहीं जा सकीं।")
                if(hadPhotoDir) copyDirectory(rollbackPhotos,photoDir)
                labours=loadLabours(); fandiLabours=loadFandiLabours(); fields=loadFields(); crops=loadCrops()
                expenses=loadExpenses(); sales=loadSales(); attendances=loadAttendance(); payments=loadPayments()
                labourClosures=loadLabourClosures(); lockedLabourMonths=loadLockedLabourMonths(); rates=loadRates()
                fandiRate=prefs.getString("fandiRate","5")?.toDoubleOrNull()?.takeIf{it.isFinite()&&it>0} ?: 5.0
                canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()
            }catch(rollbackError:Throwable){error.addSuppressed(rollbackError)}
            throw IllegalStateException("Backup restore पूरा नहीं हो सका। पुराने डेटा को वापस रखने की कोशिश की गई है: ${error.message ?: "अज्ञात त्रुटि"}",error)
        }finally{
            rollbackDir.deleteRecursively()
        }
    }

    @Synchronized fun addCanePrice(x:CanePrice){
        val season=x.season.trim()
        if(x.id.isBlank() || season.isBlank() || !validDate(x.effectiveDate) || x.rate<=0 || !x.rate.isFinite()) return
        val sameEffective=canePrices.firstOrNull{it.season==season && it.effectiveDate==x.effectiveDate}
        if(canePrices.any{it.id==x.id && it.id!=sameEffective?.id}) return
        canePrices=canePrices.filterNot{it.season==season && it.effectiveDate==x.effectiveDate}+x.copy(season=season)
        write("canePriceHistory",canePrices,::obj)
    }
    fun caneRateFor(season:String,date:String):Double=
        canePrices.filter{it.season==season && validDate(it.effectiveDate) && it.effectiveDate<=date}
            .maxByOrNull{it.effectiveDate}?.rate ?: 400.0
    fun canePricesFor(season:String)=canePrices.filter{it.season==season}.sortedByDescending{it.effectiveDate}.distinctBy{it.effectiveDate}
    private fun validCaneParchi(x:CaneParchi,excludeId:String?=null):Boolean =
        x.id.isNotBlank() && x.name.isNotBlank() && Regex("\\d{6,7}").matches(x.code.trim()) && x.season.isNotBlank() && validDate(x.date) &&
        x.weight>0 && x.weight.isFinite() && x.rate>0 && x.rate.isFinite() &&
        caneParchis.none{it.id!=excludeId && (it.id==x.id || (it.code.trim().equals(x.code.trim(),ignoreCase=true) && it.season.trim()==x.season.trim()))}
    fun addCaneParchi(x:CaneParchi):Boolean{
        if(!validCaneParchi(x)) return false
        caneParchis=caneParchis+x.copy(name=x.name.trim(),code=x.code.trim());write("caneParchi",caneParchis,::obj);return true
    }
    fun updateCaneParchi(x:CaneParchi):Boolean{
        if(caneParchis.none{it.id==x.id} || !validCaneParchi(x,x.id)) return false
        caneParchis=caneParchis.map{if(it.id==x.id)x.copy(name=x.name.trim(),code=x.code.trim()) else it};write("caneParchi",caneParchis,::obj);return true
    }
    @Synchronized fun deleteCaneParchi(id:String):Boolean{
        if(id.isBlank() || caneParchis.none{it.id==id}) return false
        val next=caneParchis.filterNot{it.id==id}
        if(!prefs.edit().putString("caneParchi",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false
        caneParchis=next
        return true
    }
    fun addCanePeeling(x:CanePeeling):Boolean{
        // Validate at the storage layer as well as the UI; never persist malformed totals.
        if(x.id.isBlank() || x.labourId.isBlank() || fandiLabours.none{it.id==x.labourId} || (x.fieldId.isNotBlank() && fields.none{it.id==x.fieldId}) || !validDate(x.date) || x.fandi<=0 || !x.fandi.isFinite() || x.rate<=0 || !x.rate.isFinite() || x.total<=0 || !x.total.isFinite() || kotlin.math.abs(x.total-(x.fandi*x.rate))>0.02) return false
        // Never silently overwrite/accumulate an existing worker + date + field entry.
        // Return the result so callers can keep the form open and explain a duplicate.
        val duplicate=canePeelings.any{it.labourId==x.labourId&&it.fieldId==x.fieldId&&it.date==x.date}
        if(duplicate || canePeelings.any{it.id==x.id}) return false
        canePeelings=canePeelings+x
        write("canePeeling",canePeelings,::obj)
        return true
    }
    @Synchronized fun updateCanePeeling(x:CanePeeling):Boolean{
        if(canePeelings.none{it.id==x.id} || x.labourId.isBlank() || fandiLabours.none{it.id==x.labourId}) return false
        // The same worker can have only one entry for a field and date. Validate at
        // the storage layer too, not only in the form, to prevent accidental overwrites.
        if(canePeelings.any{it.id!=x.id && it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date}) return false
        if(x.fieldId.isNotBlank() && fields.none{it.id==x.fieldId}) return false
        if(x.fandi<=0 || !x.fandi.isFinite() || x.rate<=0 || !x.rate.isFinite() || x.total<=0 || !x.total.isFinite() || kotlin.math.abs(x.total-(x.fandi*x.rate))>0.02 || !validDate(x.date)) return false
        canePeelings=canePeelings.map{if(it.id==x.id)x else it};write("canePeeling",canePeelings,::obj);return true
    }
    @Synchronized fun deleteCanePeeling(id:String):Boolean{
        if(id.isBlank() || canePeelings.none{it.id==id}) return false
        val next=canePeelings.filterNot{it.id==id}
        if(!prefs.edit().putString("canePeeling",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false
        canePeelings=next
        return true
    }
    @Synchronized fun addCanePeelingPayment(x:CanePeelingPayment):Boolean{
        if(x.id.isBlank() || canePeelingPayments.any{it.id==x.id} || x.labourId.isBlank() || fandiLabours.none{it.id==x.labourId} || !validDate(x.date) || x.amount<=0 || !x.amount.isFinite()) return false
        canePeelingPayments=canePeelingPayments+x;write("canePeelingPayment",canePeelingPayments,::obj);return true
    }
    @Synchronized fun updateCanePeelingPayment(x:CanePeelingPayment):Boolean{
        if(canePeelingPayments.none{it.id==x.id} || x.labourId.isBlank() || fandiLabours.none{it.id==x.labourId} || !validDate(x.date) || x.amount<=0 || !x.amount.isFinite()) return false
        canePeelingPayments=canePeelingPayments.map{if(it.id==x.id)x else it};write("canePeelingPayment",canePeelingPayments,::obj);return true
    }
    @Synchronized fun deleteCanePeelingPayment(id:String):Boolean{
        if(id.isBlank() || canePeelingPayments.none{it.id==id}) return false
        val next=canePeelingPayments.filterNot{it.id==id}
        if(!prefs.edit().putString("canePeelingPayment",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false
        canePeelingPayments=next
        return true
    }

    fun persistPhoto(uriString:String, owner:String):String {
        if(uriString.isBlank() || uriString.startsWith("file://")) return uriString
        return try {
            val uri=Uri.parse(uriString)
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return ""
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun persistBitmapPhoto(bitmap:Bitmap, owner:String):String {
        return try {
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG,90,out) }
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    private fun normalizedLabourName(value:String)=value.trim().replace(Regex("\\s+")," ").lowercase(java.util.Locale.ROOT)
    fun labourNameExists(name:String,excludeId:String?=null):Boolean{
        val normalized=normalizedLabourName(name)
        return normalized.isNotBlank() && labours.any{it.id!=excludeId && normalizedLabourName(it.name)==normalized}
    }
    @Synchronized fun addLabour(x:Labour):Boolean{
        if(x.id.isBlank() || x.name.isBlank() || !x.rate.isFinite() || x.rate<0 || labours.any{it.id==x.id} || labourNameExists(x.name)) return false
        val normalized=x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        val nextLabours=labours+normalized
        val nextRates=if(x.rate>0) rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate) else rates
        val editor=prefs.edit().putString("labour",JSONArray(nextLabours.map(::obj)).toString())
        if(x.rate>0) editor.putString("rateHistory",JSONArray(nextRates.map(::obj)).toString())
        if(!editor.commit()) return false
        labours=nextLabours
        if(x.rate>0) rates=nextRates
        return true
    }
    @Synchronized fun updateLabour(x:Labour):Boolean{
        if(labours.none{it.id==x.id} || x.name.isBlank() || !x.rate.isFinite() || x.rate<0 || labourNameExists(x.name,x.id)) return false
        val normalized=x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        val old=labours.firstOrNull{it.id==x.id}
        val nextLabours=labours.map{if(it.id==x.id)normalized else it}
        val rateChanged=old!=null && old.rate!=x.rate && x.rate>0
        val nextRates=if(rateChanged) rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate) else rates
        val editor=prefs.edit().putString("labour",JSONArray(nextLabours.map(::obj)).toString())
        if(rateChanged) editor.putString("rateHistory",JSONArray(nextRates.map(::obj)).toString())
        if(!editor.commit()) return false
        labours=nextLabours
        if(rateChanged) rates=nextRates
        return true
    }
    @Synchronized fun setLabourActive(id:String,active:Boolean):Boolean{
        if(labours.none{it.id==id}) return false
        val next=labours.map{if(it.id==id)it.copy(active=active) else it}
        if(!persistList("labour",next,::obj)) return false
        labours=next
        return true
    }
    @Synchronized fun deleteLabour(id:String):Boolean{
        // Keep every accounting record for workers with history; allow hard-delete only
        // when there is no attendance/payment/closure/cane history. Rate metadata is
        // removed with an otherwise-unused profile so a new worker can be deleted safely.
        val hasAccountingHistory=attendances.any{it.labourId==id} || payments.any{it.labourId==id} || labourClosures.any{it.labourId==id} || canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}
        if(hasAccountingHistory || labours.none{it.id==id}) return false
        val nextLabours=labours.filterNot{it.id==id}
        val nextRates=rates.filterNot{it.labourId==id}
        val committed=prefs.edit()
            .putString("labour",JSONArray().apply{nextLabours.forEach{put(obj(it))}}.toString())
            .putString("rateHistory",JSONArray().apply{nextRates.forEach{put(obj(it))}}.toString())
            .commit()
        if(!committed) return false
        labours=nextLabours;rates=nextRates
        return true
    }

    @Synchronized fun updateFandiRate(value:Double):Boolean {
        if(!value.isFinite() || value<=0.0) return false
        // Persist first: do not let the UI show a new rate that disappears after restart.
        if(!prefs.edit().putString("fandiRate",value.toString()).commit()) return false
        fandiRate=value
        return true
    }
    private fun normalizedFandiName(value:String)=value.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
    @Synchronized fun addFandiLabour(x:FandiLabour):Boolean{
        if(x.id.isBlank() || x.name.isBlank() || !x.rate.isFinite() || x.rate<0 || fandiLabours.any{it.id==x.id || normalizedFandiName(it.name)==normalizedFandiName(x.name)}) return false
        val phone=x.mobile.filter{it.isDigit()}
        if(phone.length>=7 && fandiLabours.any{val other=it.mobile.filter{c->c.isDigit()};other.length>=7&&other==phone}) return false
        val next=fandiLabours+x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        if(!persistList("fandiLabour",next,::obj)) return false
        fandiLabours=next
        return true
    }
    @Synchronized fun updateFandiLabour(x:FandiLabour):Boolean{
        if(fandiLabours.none{it.id==x.id} || x.name.isBlank() || !x.rate.isFinite() || x.rate<0 || fandiLabours.any{it.id!=x.id && normalizedFandiName(it.name)==normalizedFandiName(x.name)}) return false
        val phone=x.mobile.filter{it.isDigit()}
        if(phone.length>=7 && fandiLabours.any{it.id!=x.id && run{val other=it.mobile.filter{c->c.isDigit()};other.length>=7&&other==phone}}) return false
        val next=fandiLabours.map{if(it.id==x.id)x.copy(name=x.name.trim().replace(Regex("\\s+")," ")) else it}
        if(!persistList("fandiLabour",next,::obj)) return false
        fandiLabours=next
        return true
    }
    @Synchronized fun deleteFandiLabour(id:String):Boolean{
        // Never delete historical work or payment rows as a side effect of removing a profile.
        if(canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}) return false
        if(fandiLabours.none{it.id==id}) return false
        val next=fandiLabours.filterNot{it.id==id}
        if(!persistList("fandiLabour",next,::obj)) return false
        fandiLabours=next
        return true
    }

    private fun persistFieldOrder(order:List<Field> = fields):Boolean =
        prefs.edit().putString("fieldOrder",order.joinToString("|"){it.id}).commit()
    @Synchronized fun moveField(id:String,delta:Int):Boolean {
        val from=fields.indexOfFirst{it.id==id}; val to=from+delta
        if(from<0 || to !in fields.indices) return false
        val reordered=fields.toMutableList(); val item=reordered.removeAt(from); reordered.add(to,item)
        // Commit the proposed order before publishing it in memory.
        if(!persistFieldOrder(reordered)) return false
        fields=reordered
        return true
    }
    @Synchronized fun addField(x:Field):Boolean{
        val name=x.name.trim().replace(Regex("\\s+")," ")
        if(x.id.isBlank() || name.isBlank() || fields.any{it.id==x.id || it.name.trim().replace(Regex("\\s+")," ").equals(name,ignoreCase=true)}) return false
        val next=fields+x.copy(name=name)
        // Field data and its display order are one logical operation: commit both
        // together so a failed save cannot leave a field with stale ordering metadata.
        val editor=prefs.edit()
            .putString("field",JSONArray(next.map(::obj)).toString())
            .putString("fieldOrder",next.joinToString("|"){it.id})
        if(!editor.commit()) return false
        fields=next
        return true
    }
    @Synchronized fun updateField(x:Field):Boolean{
        val name=x.name.trim().replace(Regex("\\s+")," ")
        if(fields.none{it.id==x.id} || name.isBlank() || fields.any{it.id!=x.id && it.name.trim().replace(Regex("\\s+")," ").equals(name,ignoreCase=true)}) return false
        val next=fields.map{if(it.id==x.id)x.copy(name=name) else it}
        if(!persistList("field",next,::obj)) return false
        fields=next
        return true
    }
    @Synchronized fun deleteField(id:String):Boolean{
        // Preserve field-linked financial and crop history.
        val cropIds=crops.filter{it.fieldId==id}.map{it.id}.toSet()
        val hasHistory=expenses.any{it.fieldId==id || it.cropId in cropIds} || sales.any{it.fieldId==id || it.cropId in cropIds} || attendances.any{it.fieldId==id || it.cropId in cropIds} || payments.any{it.fieldId==id || it.cropId in cropIds} || canePeelings.any{it.fieldId==id}
        if(hasHistory) return false
        fields=fields.filterNot{it.id==id};persistFieldOrder();crops=crops.filterNot{it.fieldId==id};write("field",fields,::obj);write("crop",crops,::obj);return true
    }

    @Synchronized fun addCrop(x:Crop):Boolean{
        val name=x.name.trim().replace(Regex("\\s+")," ")
        if(x.id.isBlank() || name.isBlank() || x.season.isBlank() || fields.none{it.id==x.fieldId} || crops.any{it.id==x.id || (it.fieldId==x.fieldId && it.name.trim().replace(Regex("\\s+")," ").equals(name,ignoreCase=true) && it.season==x.season)}) return false
        if(x.sowingDate.isNotBlank() && !validDate(x.sowingDate)) return false
        val next=crops+x.copy(name=name,season=x.season.trim())
        if(!persistList("crop",next,::obj)) return false
        crops=next
        return true
    }
    @Synchronized fun updateCrop(x:Crop):Boolean{
        val name=x.name.trim().replace(Regex("\\s+")," ")
        val existing=crops.firstOrNull{it.id==x.id} ?: return false
        if(name.isBlank() || x.season.isBlank() || fields.none{it.id==x.fieldId} || crops.any{it.id!=x.id && it.fieldId==x.fieldId && it.name.trim().replace(Regex("\\s+")," ").equals(name,ignoreCase=true) && it.season==x.season}) return false
        if(existing.fieldId!=x.fieldId && (expenses.any{it.cropId==x.id} || sales.any{it.cropId==x.id} || attendances.any{it.cropId==x.id} || payments.any{it.cropId==x.id})) return false
        if(x.sowingDate.isNotBlank() && !validDate(x.sowingDate)) return false
        val next=crops.map{if(it.id==x.id)x.copy(name=name,season=x.season.trim()) else it}
        if(!persistList("crop",next,::obj)) return false
        crops=next
        return true
    }
    @Synchronized fun deleteCrop(id:String):Boolean{
        // Do not silently erase expenses, sales, wages or payments linked to a crop.
        val hasHistory=expenses.any{it.cropId==id} || sales.any{it.cropId==id} || attendances.any{it.cropId==id} || payments.any{it.cropId==id}
        if(hasHistory) return false
        val next=crops.filterNot{it.id==id}
        if(!persistList("crop",next,::obj)) return false
        crops=next
        return true
    }

    private fun validExpense(x:Expense):Boolean = x.id.isNotBlank() && validDate(x.date) && x.amount>0 && x.amount.isFinite() &&
        (x.fieldId.isBlank() || fields.any{it.id==x.fieldId}) &&
        (x.cropId.isBlank() || crops.any{it.id==x.cropId && (x.fieldId.isBlank() || it.fieldId==x.fieldId)})
    @Synchronized fun addExpense(x:Expense):Boolean{
        if(!validExpense(x) || expenses.any{it.id==x.id}) return false
        val next=expenses+x
        if(!persistList("expense",next,::obj)) return false
        expenses=next
        return true
    }
    @Synchronized fun updateExpense(x:Expense):Boolean{
        if(expenses.none{it.id==x.id} || !validExpense(x)) return false
        val next=expenses.map{if(it.id==x.id)x else it}
        if(!persistList("expense",next,::obj)) return false
        expenses=next
        return true
    }
    @Synchronized fun deleteExpense(id:String):Boolean{
        if(id.isBlank() || expenses.none{it.id==id}) return false
        val next=expenses.filterNot{it.id==id}
        if(!prefs.edit().putString("expense",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false
        expenses=next
        return true
    }

    private fun validSale(x:Sale):Boolean = x.id.isNotBlank() && validDate(x.date) && x.qty>0 && x.qty.isFinite() && x.rate>0 && x.rate.isFinite() && x.total>0 && x.total.isFinite() &&
        kotlin.math.abs(x.total-(x.qty*x.rate))<=0.02 && (x.fieldId.isBlank() || fields.any{it.id==x.fieldId}) &&
        (x.cropId.isBlank() || crops.any{it.id==x.cropId && (x.fieldId.isBlank() || it.fieldId==x.fieldId)})
    @Synchronized fun addSale(x:Sale):Boolean{
        if(!validSale(x) || sales.any{it.id==x.id}) return false
        val next=sales+x
        if(!persistList("sale",next,::obj)) return false
        sales=next
        return true
    }
    @Synchronized fun updateSale(x:Sale):Boolean{
        if(sales.none{it.id==x.id} || !validSale(x)) return false
        val next=sales.map{if(it.id==x.id)x else it}
        if(!persistList("sale",next,::obj)) return false
        sales=next
        return true
    }
    @Synchronized fun deleteSale(id:String):Boolean{
        if(id.isBlank() || sales.none{it.id==id}) return false
        val next=sales.filterNot{it.id==id}
        if(!prefs.edit().putString("sale",JSONArray().apply{next.forEach{put(obj(it))}}.toString()).commit()) return false
        sales=next
        return true
    }

    fun isClosedDate(labourId:String,date:String)=latestClosure(labourId)?.throughDate?.let{date<=it}?:false
    fun isMonthLocked(date:String):Boolean = date.length>=7 && date.substring(0,7) in lockedLabourMonths
    @Synchronized fun setLabourMonthLocked(month:String,locked:Boolean):Boolean {
        if(!validMonthKey(month)) return false
        val next=(if(locked) (lockedLabourMonths+month) else lockedLabourMonths.filterNot{it==month}).distinct().sortedDescending()
        // Month finalization is accounting-critical: persist atomically before changing
        // the in-memory state or reporting success to the caller.
        val payload=JSONArray().apply{next.forEach{put(JSONObject().put("month",it))}}.toString()
        if(!prefs.edit().putString("lockedLabourMonths",payload).commit()) return false
        lockedLabourMonths=next
        return true
    }
    private fun validPayment(x:Payment):Boolean = x.id.isNotBlank() && x.labourId.isNotBlank() &&
        labours.any{it.id==x.labourId} && validDate(x.date) && x.amount>0 && x.amount.isFinite() && (x.kind=="payment" || x.kind=="advance") &&
        (x.fieldId.isBlank() || fields.any{it.id==x.fieldId}) &&
        (x.cropId.isBlank() || crops.any{it.id==x.cropId && (x.fieldId.isBlank() || it.fieldId==x.fieldId)})
    @Synchronized fun addPayment(x:Payment):Boolean{
        // A finalized month is immutable: settlement of its outstanding balance must
        // be recorded on a later, unlocked date, not backdated into the locked month.
        if(!validPayment(x) || payments.any{it.id==x.id} || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)) return false
        val next=payments+x
        if(!persistList("payment",next,::obj)) return false
        payments=next
        return true
    }
    @Synchronized fun updatePayment(x:Payment):Boolean{
        // Protect both the stored row and the proposed row. Checking only x.date would
        // let an old locked/closed payment be moved forward into an unlocked date.
        val existing=payments.firstOrNull{it.id==x.id} ?: return false
        // A locked/finalized historical payment is immutable, even if the editor
        // tries to move it to a later open date. A payment can never change owners.
        if(isMonthLocked(existing.date) || isClosedDate(existing.labourId,existing.date)) return false
        if(x.labourId!=existing.labourId || !validPayment(x) || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)) return false
        val next=payments.map{if(it.id==x.id)x else it}
        if(!persistList("payment",next,::obj)) return false
        payments=next
        return true
    }
    @Synchronized fun deletePayment(id:String):Boolean{
        val row=payments.firstOrNull{it.id==id}?:return false
        if(isMonthLocked(row.date) || isClosedDate(row.labourId,row.date)) return false
        val next=payments.filterNot{it.id==id}
        if(!persistList("payment",next,::obj)) return false
        payments=next
        return true
    }
    fun latestClosure(labourId:String):LabourClosure? = labourClosures.filter{it.labourId==labourId}.maxByOrNull{it.throughDate}
    fun outstandingBalance(labourId:String):Double{
        val closure=latestClosure(labourId)
        val through=closure?.throughDate.orEmpty()
        val carriedBalance=closure?.let{it.wage-it.paid} ?: 0.0
        val currentWage=attendances.filter{it.labourId==labourId && it.date>through}.sumOf{it.fraction*it.rate}
        val currentPaid=payments.filter{it.labourId==labourId && it.date>through}.sumOf{it.amount}
        return carriedBalance+currentWage-currentPaid
    }
    fun closeLabourAccount(labourId:String,throughDate:String,wage:Double,paid:Double):Boolean {
        if(labourId.isBlank() || labours.none{it.id==labourId} || !validDate(throughDate) || wage<0 || paid<0 || !wage.isFinite() || !paid.isFinite()) return false
        val old=latestClosure(labourId)
        if(old!=null && throughDate<=old.throughDate) return false
        val closure=LabourClosure(UUID.randomUUID().toString(),labourId,throughDate,wage,paid,System.currentTimeMillis())
        labourClosures=labourClosures+closure
        write("labourClosure",labourClosures,::obj)
        return true
    }
    fun closureHistory(labourId:String?=null)=labourClosures.filter{labourId==null||it.labourId==labourId}.sortedByDescending{it.throughDate}
    @Synchronized fun setRate(x:WageRate){
        if(x.id.isBlank() || labours.none{it.id==x.labourId} || !validDate(x.effectiveDate) || x.rate<=0 || !x.rate.isFinite()) return
        val sameEffective=rates.firstOrNull{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}
        if(rates.any{it.id==x.id && it.id!=sameEffective?.id}) return
        rates=rates.filterNot{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}+x;write("rateHistory",rates,::obj)
    }
    fun attendanceConflict(x:Attendance):String?{
        val existingSame=attendances.firstOrNull{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.date==x.date
        }
        val otherRows=attendances.filter{
            it.labourId==x.labourId &&
            it.date==x.date &&
            it.id!=existingSame?.id
        }
        if(x.fraction==0.0 && otherRows.any{it.fraction>0.0}) return "इस मजदूर की इस तारीख में दूसरे खेत पर हाजिरी लगी है; अनुपस्थित दर्ज नहीं कर सकते।"
        val otherTotal=otherRows.sumOf{it.fraction}
        if(otherTotal+x.fraction>1.0001){
            return if(otherTotal>=0.9999) "इस तारीख में इस मजदूर की पूरी 1 दिन की हाजिरी पहले से लगी है।" else "इस तारीख में इस मजदूर की ${if(otherTotal>=0.5) "आधी" else "कुछ"} हाजिरी पहले से लगी है। बाकी जगह केवल बची हुई हाजिरी लग सकती है।"
        }
        return null
    }
    @Synchronized fun upsertAttendance(x:Attendance):String?{
        // Validate every record before checking or mutating existing attendance.
        // A blank field remains supported by design; a supplied field/crop must exist.
        if(x.id.isBlank() || x.labourId.isBlank() || labours.none{it.id==x.labourId}) return "मजदूर का विवरण सही नहीं है। सूची से मजदूर चुनें।"
        if(labours.firstOrNull{it.id==x.labourId}?.active!=true) return "यह मजदूर निष्क्रिय है। नई हाजिरी के लिए पहले उसे फिर सक्रिय करें।"
        if(!validDate(x.date) || !x.fraction.isFinite() || x.fraction<0 || x.fraction>1.0 || !x.rate.isFinite() || x.rate<0) return "तारीख, हाजिरी या दिहाड़ी की राशि सही नहीं है।"
        // Enforce the same no-future-date rule in the data layer as the UI; imported,
        // replayed, or direct Store writes must not bypass the attendance screen guard.
        if(x.date>today()) return "भविष्य की तारीख की हाजिरी दर्ज नहीं हो सकती।"
        if(x.fieldId.isNotBlank() && fields.none{it.id==x.fieldId}) return "चुना गया खेत उपलब्ध नहीं है।"
        if(x.cropId.isNotBlank() && crops.none{it.id==x.cropId && (x.fieldId.isBlank() || it.fieldId==x.fieldId)}) return "चुनी गई फसल इस खेत से मेल नहीं खाती।"
        if(isMonthLocked(x.date)) return "${monthTitle(x.date.take(7))} का हिसाब लॉक है। पुरानी हाजिरी सुरक्षित है; नई हाजिरी चालू महीने में दर्ज करें।"
        val closedThrough=latestClosure(x.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && x.date<=closedThrough) return "इस मजदूर का ${closedThrough} तक का हिसाब फाइनल है। पुरानी तारीख में बदलाव नहीं हो सकता।"
        val conflict=attendanceConflict(x)
        if(conflict!=null) return conflict
        val existing=attendances.firstOrNull{it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date}
        val safeRow=if(existing!=null) x.copy(id=existing.id) else x
        attendances=attendances.filterNot{
            (it.labourId==safeRow.labourId && it.fieldId==safeRow.fieldId && it.date==safeRow.date) ||
                (it.labourId==safeRow.labourId && it.date==safeRow.date && it.fraction==0.0)
        }+safeRow
        write("attendance",attendances,::obj)
        return null
    }
    fun deleteAttendance(id:String):Boolean{
        val row=attendances.firstOrNull{it.id==id}?:return false
        if(isMonthLocked(row.date)) return false
        val closedThrough=latestClosure(row.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && row.date<=closedThrough) return false
        attendances=attendances.filterNot{it.id==id};write("attendance",attendances,::obj);return true
    }
    fun rateFor(labourId:String,date:String):Double{
        val l=labours.firstOrNull{it.id==labourId}?:return 0.0
        val applicable=rates.filter{it.labourId==labourId && validDate(it.effectiveDate) && it.effectiveDate<=date}
        return applicable.maxByOrNull{it.effectiveDate}?.rate ?: l.rate
    }
    fun rateHistoryFor(labourId:String)=rates.filter{it.labourId==labourId}.sortedByDescending{it.effectiveDate}
}

/** Instrumentation-only regression harness. It uses an isolated preference namespace and
 * always clears it, so tests never mutate the user's real app records.
 */
internal fun runCoreStoreRuntimeRegression(context:Context):Map<String,Boolean>{
    // Device-protected storage gives the harness its own preferences and photo directory;
    // restoring a test backup must never touch normal app data/photos.
    if(android.os.Build.VERSION.SDK_INT<24) return mapOf("isolated test storage requires Android API 24+" to false)
    val isolatedContext=context.createDeviceProtectedStorageContext()
    val prefsName="mhpro_runtime_regression"
    val testPrefs=isolatedContext.getSharedPreferences(prefsName,Context.MODE_PRIVATE)
    testPrefs.edit().clear().commit()
    val results=linkedMapOf<String,Boolean>()
    val routeSamples=listOf<Screen>(Screen.Home,Screen.LabourList,Screen.PaymentHistory,Screen.DailyLabourAccounts,Screen.ExpenseList("field-1","crop-1"),Screen.SaleList("field-2",null),Screen.CropList("field-3"),Screen.LabourDetail("worker-1"),Screen.FieldDetail("field-4"),Screen.CropDetail("crop-2"),Screen.Attendance("field-5"),Screen.Backup,Screen.Profile,Screen.CaneParchi,Screen.CanePeeling)
    results["navigation routes survive save/restore serialization"] = routeSamples.all{decodeScreen(encodeScreen(it))==it}
    val octoberCalendar=attendanceCalendarCells(2026,9)
    val leapFebruaryCalendar=attendanceCalendarCells(2024,1)
    results["attendance calendar is Monday-first, leap-year aware and has stable six-week grid"] =
        octoberCalendar.size==42 && octoberCalendar.take(3).all{it==null} && octoberCalendar[3]=="2026-10-01" &&
        octoberCalendar.filterNotNull().first()=="2026-10-01" && octoberCalendar.filterNotNull().last()=="2026-10-31" &&
        leapFebruaryCalendar.filterNotNull().size==29 && leapFebruaryCalendar.filterNotNull().last()=="2024-02-29" &&
        attendanceCalendarCells(2026,12).isEmpty()
    val seasonSamples=listOf(
        CaneParchi("rt-season-a","Season A","","123456","2026-10-01",1.0,100.0,"","","2025-26"),
        CaneParchi("rt-season-b","Season B","","123457","2026-10-02",2.0,110.0,"","","2026-27")
    )
    results["ALL cane parchi season includes every season and specific season filters"] = filterCaneParchiSeason(seasonSamples,"ALL").size==2 && filterCaneParchiSeason(seasonSamples,"2025-26").map{it.id}==listOf("rt-season-a")
    val backup=File(isolatedContext.cacheDir,"mhpro_runtime_regression.mhbackup")
    try{
        testPrefs.edit().putString("fandiRate","17.5").putString("expense","{bad-json").putString("backupHistory",JSONArray().put(JSONObject().put("at",1L).put("action","Runtime test").put("detail","History row")).toString()).commit()
        val store=Store(isolatedContext,prefsName)
        results["corrupt local JSON does not crash initialization and raw data is preserved"] = store.expenses.isEmpty() && testPrefs.getString("recovery_raw_expense",null)=="{bad-json" && store.dataWarning.isNotBlank()
        val worker=Labour("rt-worker-1","Runtime Worker","",500.0,"","")
        results["worker can be added"]=store.addLabour(worker)
        results["blank/duplicate worker IDs and invalid worker rates are rejected"]=!store.addLabour(worker.copy(id="",name="No ID")) && !store.addLabour(worker.copy(id="rt-worker-1",name="Another Name")) && !store.addLabour(worker.copy(id="rt-worker-bad-rate",name="Bad Rate",rate=Double.NaN))
        results["duplicate normalized worker name is rejected"]=!store.addLabour(worker.copy(id="rt-worker-2",name=" runtime   worker "))
        results["Fandi rate loads from local preferences"]=store.fandiRate==17.5
        val originalFandiRate=store.fandiRate
        results["invalid Fandi rate cannot replace persisted setting"]=!store.updateFandiRate(Double.NaN) && !store.updateFandiRate(0.0) && store.fandiRate==originalFandiRate && testPrefs.getString("fandiRate",null)==originalFandiRate.toString()
        results["valid Fandi rate persists before publishing new state"]=store.updateFandiRate(19.5) && store.fandiRate==19.5 && Store(isolatedContext,prefsName).fandiRate==19.5
        store.updateFandiRate(originalFandiRate)
        val firstFieldSaved=store.addField(Field("rt-field-1","Runtime Field","","1 acre",""))
        val duplicateFieldNameSaved=store.addField(Field("rt-field-duplicate-id"," runtime   field ","","1 acre",""))
        val duplicateFieldIdSaved=store.addField(Field("rt-field-1","Second field ID collision","","1 acre",""))
        results["field persists and duplicate field names/IDs return failure"]=firstFieldSaved && !duplicateFieldNameSaved && !duplicateFieldIdSaved && Store(isolatedContext,prefsName).fields.count{it.name.equals("Runtime Field",true)}==1 && store.fields.none{it.id=="rt-field-duplicate-id"} && store.fields.none{it.name=="Second field ID collision"}
        store.addField(Field("rt-field-2","Runtime Field 2","","2 acres",""))
        val firstCropSaved=store.addCrop(Crop("rt-crop-1","rt-field-1","गेहूँ","HD-2967","2026-11-12","2026-27"))
        val invalidFieldCropSaved=store.addCrop(Crop("rt-crop-2","missing-field","धान","","2026-06-01","2026-26"))
        val duplicateCropSaved=store.addCrop(Crop("rt-crop-3","rt-field-1"," गेहूँ ","Other","2026-11-12","2026-27"))
        results["crop requires valid field and duplicate save returns failure"]=firstCropSaved && !invalidFieldCropSaved && !duplicateCropSaved && store.crops.count{it.id=="rt-crop-1"}==1 && store.crops.none{it.id=="rt-crop-2"||it.id=="rt-crop-3"}
        val first=Attendance("rt-att-1",worker.id,"rt-field-1","","2026-10-05",1.0,500.0)
        results["invalid attendance date, fraction and worker are rejected"]=store.upsertAttendance(first.copy(date="bad-date"))!=null && store.upsertAttendance(first.copy(fraction=1.5))!=null && store.upsertAttendance(first.copy(labourId="missing-worker"))!=null && store.attendances.isEmpty()
        results["future attendance date is rejected in the Store layer"]=store.upsertAttendance(first.copy(id="rt-att-future",date="9999-12-31"))?.contains("भविष्य") == true && store.attendances.isEmpty()
        results["attendance saves"]=store.upsertAttendance(first)==null
        val edited=store.upsertAttendance(first.copy(id="rt-att-2",fraction=0.5))
        results["same worker-field-date attendance updates instead of duplicating"]=edited==null && store.attendances.count{it.labourId==worker.id&&it.fieldId=="rt-field-1"&&it.date=="2026-10-05"}==1 && store.attendances.first{it.labourId==worker.id}.id=="rt-att-1"
        results["absence marker saves at zero wage and is excluded from worked-attendance list"]=store.upsertAttendance(Attendance("rt-absence-marker",worker.id,"rt-field-1","","2026-10-07",0.0,500.0))==null && store.attendances.any{it.id=="rt-absence-marker"&&it.fraction==0.0} && store.attendances.filter{it.date=="2026-10-07"&&it.fraction>0.0}.none{it.labourId==worker.id}
        results["absence marker survives local Store recreation"]=Store(isolatedContext,prefsName).attendances.any{it.id=="rt-absence-marker"&&it.fraction==0.0}
        results["positive attendance clears stale absence marker"]=store.upsertAttendance(Attendance("rt-present-after-absence",worker.id,"rt-field-2","","2026-10-07",1.0,500.0))==null && store.attendances.none{it.id=="rt-absence-marker"}
        val csvWorker=Labour("rt-csv-worker","CSV, \"Quoted\" Worker","",400.0,"","")
        store.addLabour(csvWorker)
        val csvText=buildDateFieldReportCsv(listOf(Attendance("rt-csv-att",csvWorker.id,"rt-field-1","","2026-10-08",1.0,400.0),Attendance("rt-csv-no-field",csvWorker.id,"","","2026-10-08",1.0,400.0)),listOf(Payment("rt-csv-pay",csvWorker.id,"","","2026-10-09",123.45),Payment("rt-csv-advance",csvWorker.id,"","","2026-10-10",50.0,"advance")),store)
        results["general CSV escapes worker names, includes payment amount and omits rate column"]=csvText.startsWith("तारीख,प्रकार,मजदूर,खेत,हाजिरी,मजदूरी,भुगतान/अग्रिम") && csvText.contains("\"CSV, \"\"Quoted\"\" Worker\"") && csvText.contains("123.45") && csvText.contains("अग्रिम") && !csvText.lines().first().contains("रेट")
        results["blank-field report rows say no field instead of field deleted"]=csvText.contains("खेत नहीं चुना") && !csvText.contains("खेत हटाया गया")
        val offlineWorker=Labour("rt-offline-worker","Offline Local Worker","",300.0,"","")
        val offlineAdded=store.addLabour(offlineWorker)
        results["offline local worker record survives Store recreation without Drive call"]=offlineAdded && Store(isolatedContext,prefsName).labours.any{it.id==offlineWorker.id}
        results["month lock rejects impossible month values"]=!store.setLabourMonthLocked("2026-00",true) && !store.setLabourMonthLocked("2026-13",true) && !store.setLabourMonthLocked("0000-01",true) && !store.setLabourMonthLocked("26-10",true) && store.lockedLabourMonths.isEmpty()
        results["month lock commits before reporting success and survives Store recreation"]=store.setLabourMonthLocked("2026-08",true) && Store(isolatedContext,prefsName).lockedLabourMonths.contains("2026-08") && store.setLabourMonthLocked("2026-08",false) && Store(isolatedContext,prefsName).lockedLabourMonths.none{it=="2026-08"}
        val lockedEditWorker=Labour("rt-worker-locked-edit","Locked Edit Worker","",500.0,"","")
        store.addLabour(lockedEditWorker)
        val historicalLockedPayment=Payment("rt-payment-old-locked",lockedEditWorker.id,"","","2026-10-05",20.0)
        val historicalPaymentAdded=store.addPayment(historicalLockedPayment)
        val closedEditWorker=Labour("rt-worker-closed-edit","Closed Edit Worker","",500.0,"","")
        store.addLabour(closedEditWorker)
        val historicalClosedPayment=Payment("rt-payment-old-closed",closedEditWorker.id,"","","2026-09-04",30.0)
        val historicalClosedPaymentAdded=store.addPayment(historicalClosedPayment)
        val closedEditAccountCreated=store.closeLabourAccount(closedEditWorker.id,"2026-09-05",500.0,30.0)
        store.setLabourMonthLocked("2026-10",true)
        results["locked month payment cannot be edited or deleted even when later date is open"] = historicalPaymentAdded && !store.updatePayment(historicalLockedPayment.copy(amount=19.0,date="2026-11-08")) && !store.deletePayment(historicalLockedPayment.id) && store.payments.any{it.id==historicalLockedPayment.id && it.date=="2026-10-05" && it.amount==20.0}
        results["locked payment cannot be moved to an unlocked month"]=historicalPaymentAdded && !store.updatePayment(historicalLockedPayment.copy(date="2026-11-08")) && store.payments.any{it.id==historicalLockedPayment.id && it.date=="2026-10-05"}
        results["closed-period payment cannot be moved beyond closure date"]=historicalClosedPaymentAdded && closedEditAccountCreated && !store.updatePayment(historicalClosedPayment.copy(date="2026-11-08")) && store.payments.any{it.id==historicalClosedPayment.id && it.date=="2026-09-04"}
        val attendanceCountBeforeLockedWrite=store.attendances.size
        results["locked month blocks attendance changes"]=store.upsertAttendance(first.copy(id="rt-att-3",date="2026-10-06"))!=null && store.attendances.size==attendanceCountBeforeLockedWrite
        val backdatedLockedPayment=Payment("rt-payment-backdated",worker.id,"rt-field-1","","2026-10-06",100.0)
        results["locked month rejects backdated payment changes"]=!store.addPayment(backdatedLockedPayment)
        val payment=Payment("rt-payment-1",worker.id,"rt-field-1","","2026-11-06",100.0)
        results["later unlocked payment can settle locked month's outstanding balance"]=store.addPayment(payment) && kotlin.math.abs(store.outstandingBalance(worker.id)-650.0)<0.01
        results["duplicate payment id is rejected"]=!store.addPayment(payment)
        val lockCheckAdded=store.addPayment(payment.copy(id="rt-payment-lock-check",date="2026-11-07"))
        val novemberLocked=store.setLabourMonthLocked("2026-11",true)
        val lockedPaymentMutationRejected= !store.updatePayment(payment.copy(id="rt-payment-lock-check",amount=90.0)) && !store.deletePayment("rt-payment-lock-check")
        store.setLabourMonthLocked("2026-11",false)
        store.deletePayment("rt-payment-lock-check")
        results["locked-month payment cannot be edited into or deleted from finalized month"]=!store.updatePayment(payment.copy(date="2026-10-10")) && lockCheckAdded && novemberLocked && lockedPaymentMutationRejected && store.payments.none{it.id=="rt-payment-lock-check"}
        results["payment edit cannot transfer an existing payment to another worker"] = !store.updatePayment(payment.copy(labourId=closedEditWorker.id)) && store.payments.firstOrNull{it.id==payment.id}?.labourId==worker.id
        results["negative/invalid payments and bad field/crop references are rejected"]=!store.addPayment(payment.copy(id="rt-payment-negative",amount=-1.0)) && !store.addPayment(payment.copy(id="rt-payment-invalid-date",date="not-a-date")) && !store.addPayment(payment.copy(id="",amount=50.0)) && !store.addPayment(payment.copy(id="rt-payment-bad-field",fieldId="missing-field")) && !store.addPayment(payment.copy(id="rt-payment-bad-crop",cropId="missing-crop")) && !store.addPayment(payment.copy(id="rt-payment-field-crop-mismatch",fieldId="rt-field-2",cropId="rt-crop-1")) && store.payments.count{it.id==payment.id}==1
        results["invalid expense and duplicate expense saves return failure"]=run { val invalid=!store.addExpense(Expense("rt-exp-invalid","rt-field-1","","बीज","बीज","1","kg",-2.0,"2026-10-05")); val valid=store.addExpense(Expense("rt-exp-1","rt-field-1","","बीज","बीज","1","kg",100.0,"2026-10-05")); val duplicate=!store.addExpense(Expense("rt-exp-1","rt-field-1","","बीज","बीज","1","kg",100.0,"2026-10-05")); invalid && valid && duplicate && store.expenses.count{it.id=="rt-exp-1"}==1 }
        results["invalid sale and duplicate sale saves return failure"]=run { val invalid=!store.addSale(Sale("rt-sale-invalid","rt-field-1","",2.0,"kg",10.0,19.0,"Buyer","2026-10-05")); val valid=store.addSale(Sale("rt-sale-1","rt-field-1","",2.0,"kg",10.0,20.0,"Buyer","2026-10-05")); val duplicate=!store.addSale(Sale("rt-sale-1","rt-field-1","",2.0,"kg",10.0,20.0,"Buyer","2026-10-05")); invalid && valid && duplicate && store.sales.count{it.id=="rt-sale-1"}==1 }
        results["expense delete is idempotent, synchronized and persisted only for an existing row"]=run { val first=store.deleteExpense("rt-exp-1"); val duplicate=!store.deleteExpense("rt-exp-1"); val reload=Store(isolatedContext,prefsName); first && duplicate && reload.expenses.none{it.id=="rt-exp-1"} }
        results["sale delete is idempotent, synchronized and persisted only for an existing row"]=run { val first=store.deleteSale("rt-sale-1"); val duplicate=!store.deleteSale("rt-sale-1"); val reload=Store(isolatedContext,prefsName); first && duplicate && reload.sales.none{it.id=="rt-sale-1"} }
        results["field deletion preserves linked financial history"]=!store.deleteField("rt-field-1") && store.fields.any{it.id=="rt-field-1"}
        store.addExpense(Expense("rt-exp-crop-1","rt-field-1","rt-crop-1","बीज","गेहूँ बीज","1","kg",50.0,"2026-10-05"))
        val cropFieldChangeBlocked=!store.updateCrop(store.crops.first{it.id=="rt-crop-1"}.copy(fieldId="rt-field-2")) && store.crops.first{it.id=="rt-crop-1"}.fieldId=="rt-field-1"
        results["crop field cannot change while financial history is linked"]=cropFieldChangeBlocked
        results["crop deletion preserves linked expense history"]=!store.deleteCrop("rt-crop-1") && store.crops.any{it.id=="rt-crop-1"}
        val unusedWorker=Labour("rt-unused-worker","Unused Worker","",250.0,"","")
        val unusedWorkerAdded=store.addLabour(unusedWorker)
        val unusedRateExists=store.rates.any{it.labourId==unusedWorker.id}
        val unusedWorkerDeleted=store.deleteLabour(unusedWorker.id)
        results["unused worker can be deleted together with rate metadata"]=unusedWorkerAdded && unusedRateExists && unusedWorkerDeleted && store.labours.none{it.id==unusedWorker.id} && store.rates.none{it.labourId==unusedWorker.id}
        val closureWorker=Labour("rt-closure-worker","Closure Worker","",300.0,"","")
        results["closure worker can be added and finalized once"]=store.addLabour(closureWorker) && store.closeLabourAccount(closureWorker.id,"2026-09-30",900.0,500.0) && !store.closeLabourAccount(closureWorker.id,"2026-09-30",900.0,500.0)
        store.upsertAttendance(Attendance("rt-att-closure-after",closureWorker.id,"","","2026-11-01",1.0,200.0))
        store.addPayment(Payment("rt-pay-closure-after",closureWorker.id,"","","2026-11-02",100.0))
        results["outstanding balance carries closed balance and subtracts later payment"]=kotlin.math.abs(store.outstandingBalance(closureWorker.id)-500.0)<0.01
        results["worker with finalized closure history cannot be hard-deleted"]=!store.deleteLabour(closureWorker.id) && store.labours.any{it.id==closureWorker.id}
        results["finalized closure blocks retroactive attendance and payment"]=store.upsertAttendance(Attendance("rt-closed-attendance",closureWorker.id,"","","2026-09-29",1.0,300.0))!=null && !store.addPayment(Payment("rt-closed-payment",closureWorker.id,"","","2026-09-29",10.0))
        results["invalid closure and wage rate are rejected"]=!store.closeLabourAccount(worker.id,"2026-10-05",-1.0,0.0) && run { store.setRate(WageRate("rt-rate-invalid",worker.id,"not-a-date",-5.0)); store.rates.none{it.id=="rt-rate-invalid"} }
        store.addFandiLabour(FandiLabour(worker.id,worker.name,"",500.0,"",""))
        val csvFandi=FandiLabour("rt-csv-fandi","Fandi, \"Quoted\" Worker","",100.0,"","")
        val csvFandiAdded=store.addFandiLabour(csvFandi)
        val caneCsv=buildCanePeelingCsv(listOf(CanePeeling("rt-csv-cane",csvFandi.id,"","2026-10-09",1.0,100.0,100.0)),store)
        results["cane peeling CSV safely escapes quoted names and labels optional field"]=csvFandiAdded && caneCsv.startsWith("तारीख,मजदूर,खेत,फांदी,रेट,राशि") && caneCsv.contains("\"Fandi, \"\"Quoted\"\" Worker\"") && caneCsv.contains("खेत नहीं चुना")
        results["CSV cells neutralize spreadsheet formula injection and preserve normal values"] = csvCell("=HYPERLINK(\"https://example.invalid\")").startsWith("\"'=HYPERLINK") && csvCell("  +SUM(1,2)").startsWith("\"'  +SUM") && csvCell("@cmd").startsWith("\"'@cmd\"") && csvCell("\uFEFF=1+1").startsWith("\"'\uFEFF=1+1\"") && csvCell("\u200B@cmd").startsWith("\"'\u200B@cmd\"") && csvCell("\n=1+1").startsWith("\"'\n=1+1\"") && csvCell("Ram,\"Singh\"")=="\"Ram,\"\"Singh\"\"\"" && csvCell("125.50")=="\"125.50\""
        results["invalid cane quantities, worker references and mismatched totals are rejected"]=!store.addCanePeeling(CanePeeling("rt-cane-invalid",worker.id,"rt-field-1","2026-10-05",-1.0,25.0,-25.0)) && !store.addCanePeeling(CanePeeling("rt-cane-mismatch",worker.id,"rt-field-1","2026-10-05",2.0,25.0,90.0)) && !store.addCanePeeling(CanePeeling("rt-cane-no-worker","missing-worker","rt-field-1","2026-10-05",2.0,25.0,50.0))
        val peeling=CanePeeling("rt-cane-1",worker.id,"rt-field-1","2026-10-05",10.0,25.0,250.0)
        results["cane peeling entry saves"]=store.addCanePeeling(peeling)
        results["duplicate cane peeling worker-field-date is rejected"]=!store.addCanePeeling(peeling.copy(id="rt-cane-2",fandi=15.0,total=375.0)) && store.canePeelings.size==1
        val duplicateFandiNameAccepted=store.addFandiLabour(FandiLabour("rt-fandi-duplicate"," runtime worker ","",100.0,"",""))
        val invalidFandiRateAccepted=store.addFandiLabour(FandiLabour("rt-fandi-invalid-rate","Invalid Fandi Rate","",Double.NaN,"",""))
        results["duplicate normalized Fandi worker name and invalid Fandi rate are rejected"]=!duplicateFandiNameAccepted && !invalidFandiRateAccepted && store.fandiLabours.count{it.name.trim().lowercase(Locale.ROOT)=="runtime worker"}==1 && store.fandiLabours.none{it.id=="rt-fandi-invalid-rate"}
        val phoneWorker=FandiLabour("rt-fandi-phone","Phone Worker","",100.0,"9876543210","")
        val phoneWorkerSaved=store.addFandiLabour(phoneWorker)
        val duplicatePhoneUpdate=store.updateFandiLabour(FandiLabour(worker.id,worker.name,"",500.0,"9876543210",""))
        results["Fandi update rejects duplicate mobile without overwriting existing profile"]=phoneWorkerSaved && !duplicatePhoneUpdate && store.fandiLabours.firstOrNull{it.id==worker.id}?.mobile!="9876543210" && store.fandiLabours.firstOrNull{it.id==phoneWorker.id}?.mobile=="9876543210"
        results["Fandi worker with history cannot be deleted"]=!store.deleteFandiLabour(worker.id) && store.canePeelings.any{it.labourId==worker.id}
        store.addCanePeeling(CanePeeling("rt-cane-3",worker.id,"rt-field-2","2026-10-05",3.0,17.5,52.5))
        results["editing cane entry cannot create duplicate worker-field-date"]=!store.updateCanePeeling(peeling.copy(fieldId="rt-field-2")) && store.canePeelings.size==2
        val canePay=CanePeelingPayment("rt-cane-pay-1",worker.id,"2026-10-06",50.0,"नकद","")
        results["Fandi payment validates worker and duplicate id"]=store.addCanePeelingPayment(canePay) && !store.addCanePeelingPayment(canePay) && !store.addCanePeelingPayment(canePay.copy(id="rt-cane-pay-missing-worker",labourId="missing-worker")) && store.canePeelingPayments.size==1
        results["updating nonexistent payment is rejected"]=!store.updateCanePeelingPayment(canePay.copy(id="missing"))
        results["updating nonexistent labour payment is rejected"]=!store.updatePayment(payment.copy(id="missing"))
        val parchi=CaneParchi("rt-parchi-1","Runtime Farmer","","123456","2026-10-05",10.0,400.0,"","","2026-27")
        store.addCaneParchi(parchi)
        store.addCaneParchi(parchi.copy(id="rt-parchi-2",code="123456"))
        results["duplicate parchi code and ID are rejected"]=!store.addCaneParchi(parchi.copy(id="rt-parchi-2",code="123456")) && !store.addCaneParchi(parchi.copy(id="rt-parchi-3",code="123456")) && !store.addCaneParchi(parchi.copy(id="rt-parchi-invalid",code="ABC123")) && store.caneParchis.count{it.season=="2026-27"&&it.code=="123456"}==1
        results["parchi edit rejects duplicate season/code and preserves original row"]=!store.updateCaneParchi(parchi.copy(name="Changed",code="ABC123")) && store.caneParchis.firstOrNull{it.id==parchi.id}?.name==parchi.name
        results["parchi delete requires an existing ID and persists atomically"]=run { val deleted=store.deleteCaneParchi(parchi.id); val repeated=!store.deleteCaneParchi(parchi.id); deleted && repeated && Store(isolatedContext,prefsName).caneParchis.none{it.id==parchi.id} }
        store.addField(Field("rt-field-2","Runtime Field 2","","2 acres",""))
        store.moveField("rt-field-2",-1)
        val reloaded=Store(isolatedContext,prefsName)
        results["worker, attendance and payment survive Store reinitialization"]=reloaded.labours.any{it.id==worker.id} && reloaded.attendances.size==2 && reloaded.attendances.any{it.id=="rt-att-1"} && reloaded.attendances.any{it.id=="rt-present-after-absence"} && reloaded.payments.size==1
        results["Fandi rate survives Store reinitialization"]=reloaded.fandiRate==17.5
        results["locked month and field order survive Store reinitialization"]=reloaded.lockedLabourMonths.contains("2026-10") && reloaded.fields.firstOrNull()?.id=="rt-field-2"
        store.createBackupZip(backup)
        store.validateBackupZip(backup)
        results["local backup ZIP is created and validated"]=backup.isFile && backup.length()>0
        val backupRecoveryData=runCatching{ZipInputStream(backup.inputStream().buffered()).use{zis->
            var json:JSONObject?=null
            while(true){val entry=zis.nextEntry?:break;if(entry.name=="backup.json") json=JSONObject(zis.readBytes().toString(Charsets.UTF_8));zis.closeEntry()}
            json?.optJSONObject("recoveryData")?.optString("expense","")
        }}.getOrNull()
        results["backup includes preserved raw data-recovery copy"]=backupRecoveryData=="{bad-json"
        val backupHistoryCount=runCatching{ZipInputStream(backup.inputStream().buffered()).use{zis->var root:JSONObject?=null;while(true){val entry=zis.nextEntry?:break;if(entry.name=="backup.json")root=JSONObject(zis.readBytes().toString(Charsets.UTF_8));zis.closeEntry()};root?.optJSONArray("backupHistory")?.length()?:0}}.getOrDefault(0)
        results["backup includes backup/restore history metadata"]=backupHistoryCount==1
        testPrefs.edit().remove("recovery_raw_expense").remove("backupHistory").commit()
        store.restoreBackupZip(backup)
        results["restore restores preserved raw data-recovery copy"]=testPrefs.getString("recovery_raw_expense",null)=="{bad-json"
        results["restore restores backup history metadata"]=runCatching{JSONArray(testPrefs.getString("backupHistory","[]")?:"[]").length()==1}.getOrDefault(false)
        // A malformed/incomplete backup must fail validation before it can clear live records.
        val incomplete=File(isolatedContext.cacheDir,"mhpro_runtime_incomplete.mhbackup")
        try{
            ZipOutputStream(FileOutputStream(incomplete)).use{zos->
                zos.putNextEntry(ZipEntry("backup.json"))
                zos.write(JSONObject().put("app","Majdoor Hisaab PRO").put("schemaVersion",2).toString().toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            val beforeCount=store.labours.size
            val rejected=runCatching{store.restoreBackupZip(incomplete)}.isFailure
            results["incomplete backup is rejected before changing records"]=rejected && store.labours.size==beforeCount && store.labours.any{it.id==worker.id}
        }finally{incomplete.delete()}
        val invalidDateBackup=File(isolatedContext.cacheDir,"mhpro_runtime_invalid_date.mhbackup")
        try{
            val validRoot=ZipInputStream(backup.inputStream().buffered()).use{zis->var parsed:JSONObject?=null;while(true){val entry=zis.nextEntry?:break;if(entry.name=="backup.json")parsed=JSONObject(zis.readBytes().toString(Charsets.UTF_8));zis.closeEntry()};parsed ?: JSONObject()}
            val attendanceArray=validRoot.optJSONArray("attendance") ?: JSONArray()
            if(attendanceArray.length()>0) attendanceArray.getJSONObject(0).put("date","2026-99-99")
            ZipOutputStream(FileOutputStream(invalidDateBackup)).use{zos->zos.putNextEntry(ZipEntry("backup.json"));zos.write(validRoot.toString().toByteArray(Charsets.UTF_8));zos.closeEntry()}
            val beforeIds=store.labours.map{it.id}.toSet()
            val rejected=runCatching{store.restoreBackupZip(invalidDateBackup)}.isFailure
            results["backup with impossible record date is rejected before mutation"]=rejected && store.labours.map{it.id}.toSet()==beforeIds
        }finally{invalidDateBackup.delete()}
        val traversal=File(isolatedContext.cacheDir,"mhpro_runtime_traversal.mhbackup")
        try{
            ZipOutputStream(FileOutputStream(traversal)).use{zos->
                zos.putNextEntry(ZipEntry("../outside.json"));zos.write("{}".toByteArray(Charsets.UTF_8));zos.closeEntry()
                zos.putNextEntry(ZipEntry("backup.json"));zos.write(JSONObject().put("app","Majdoor Hisaab PRO").put("schemaVersion",2).toString().toByteArray(Charsets.UTF_8));zos.closeEntry()
            }
            val beforeIds=store.labours.map{it.id}.toSet()
            val rejected=runCatching{store.restoreBackupZip(traversal)}.isFailure
            results["path-traversal backup is rejected without data mutation"]=rejected && store.labours.map{it.id}.toSet()==beforeIds
        }finally{traversal.delete()}
        val missingPhoto=File(isolatedContext.cacheDir,"mhpro_runtime_missing_photo.mhbackup")
        try{
            val missingPhotoRoot=JSONObject().put("app","Majdoor Hisaab PRO").put("schemaVersion",2).put("photoMap",JSONObject().put("/old/device/worker.jpg","missing-worker.jpg"))
            listOf("labour","fandiLabour","field","crop","expense","sale","attendance","payment","labourClosure","lockedLabourMonths","rateHistory","canePriceHistory","caneParchi","canePeeling","canePeelingPayment").forEach{missingPhotoRoot.put(it,JSONArray())}
            ZipOutputStream(FileOutputStream(missingPhoto)).use{zos->zos.putNextEntry(ZipEntry("backup.json"));zos.write(missingPhotoRoot.toString().toByteArray(Charsets.UTF_8));zos.closeEntry()}
            val beforeIds=store.labours.map{it.id}.toSet()
            val rejected=runCatching{store.restoreBackupZip(missingPhoto)}.isFailure
            results["backup with missing mapped photo is rejected before mutation"]=rejected && store.labours.map{it.id}.toSet()==beforeIds
        }finally{missingPhoto.delete()}
        // Restore must replace data from the snapshot and retain the configured Fandi rate.
        store.addLabour(Labour("rt-temporary-worker","Temporary Worker","",100.0,"",""))
        store.setLabourMonthLocked("2026-10",false)
        store.moveField("rt-field-1",-1)
        val preFailureIds=store.labours.map{it.id}.toSet()
        val preFailureFields=store.fields.map{it.id}
        val preFailureLockedMonths=store.lockedLabourMonths.toSet()
        val injectedFailure=runCatching{store.restoreBackupZipWithInjectedFailureForTest(backup)}.isFailure
        val afterFailure=Store(isolatedContext,prefsName)
        results["restore failure rolls back existing records, field order and locked months"]=injectedFailure && afterFailure.labours.map{it.id}.toSet()==preFailureIds && afterFailure.fields.map{it.id}==preFailureFields && afterFailure.lockedLabourMonths.toSet()==preFailureLockedMonths && afterFailure.labours.any{it.id=="rt-temporary-worker"}
        store.restoreBackupZip(backup)
        val restored=Store(isolatedContext,prefsName)
        results["backup restore removes records created after backup"]=restored.labours.none{it.id=="rt-temporary-worker"}
        results["backup restore recovers original worker and attendance"]=restored.labours.any{it.id==worker.id} && restored.attendances.size==2 && restored.attendances.any{it.id=="rt-att-1"} && restored.attendances.any{it.id=="rt-present-after-absence"} && restored.attendances.none{it.id=="rt-absence-marker"}
        results["backup restore preserves Fandi rate"]=restored.fandiRate==17.5
        results["backup restore recovers monthly lock and field order"]=restored.lockedLabourMonths.contains("2026-10") && restored.fields.firstOrNull()?.id=="rt-field-2"
        // Schema-1 backups can omit newer modules and metadata. Restoring one must not
        // erase current Fandi workers/records, field ordering or the configured Fandi rate.
        val legacy=File(isolatedContext.cacheDir,"mhpro_runtime_legacy_partial.mhbackup")
        try{
            store.updateFandiRate(17.5)
            store.moveField("rt-field-1",-1)
            val legacyPhotoDir=File(isolatedContext.filesDir,"photos")
            legacyPhotoDir.mkdirs()
            val legacyPhoto=File(legacyPhotoDir,"legacy-photo.jpg")
            legacyPhoto.writeBytes(byteArrayOf(1,2,3,4))
            val legacyRoot=JSONObject().put("app","Majdoor Hisaab PRO").put("schemaVersion",1)
                .put("labour",JSONArray().put(JSONObject().put("id",worker.id).put("name",worker.name).put("address",worker.address).put("rate",worker.rate).put("mobile",worker.mobile).put("photo",legacyPhoto.absolutePath)))
            ZipOutputStream(FileOutputStream(legacy)).use{zos->
                zos.putNextEntry(ZipEntry("backup.json"));zos.write(legacyRoot.toString().toByteArray(Charsets.UTF_8));zos.closeEntry()
            }
            store.restoreBackupZip(legacy)
            val afterLegacy=Store(isolatedContext,prefsName)
            results["schema-1 partial restore preserves newer modules and settings"]=afterLegacy.fandiLabours.any{it.id==worker.id} && afterLegacy.canePeelings.isNotEmpty() && afterLegacy.fandiRate==17.5 && afterLegacy.fields.firstOrNull()?.id=="rt-field-1"
            results["schema-1 restore without photo entries preserves existing photo file and path"]=legacyPhoto.isFile && afterLegacy.labours.firstOrNull{it.id==worker.id}?.photo==legacyPhoto.absolutePath
        }finally{legacy.delete()}
        testPrefs.edit().putString("lockedLabourMonths",JSONArray().put(JSONObject().put("month","2026-00")).put(JSONObject().put("month","2026-13")).put(JSONObject().put("month","0000-01")).put(JSONObject().put("month","2026-10")).toString()).commit()
        results["malformed stored lock months are ignored while valid month remains"]=Store(isolatedContext,prefsName).lockedLabourMonths==listOf("2026-10")
        val optionalFieldPrefs=isolatedContext.getSharedPreferences("mhpro_optional_field_test",Context.MODE_PRIVATE)
        optionalFieldPrefs.edit().clear().commit()
        val optionalFieldStore=Store(isolatedContext,"mhpro_optional_field_test")
        val optionalFieldWorker=Labour("rt-optional-field-worker","Optional Field Worker","",250.0,"","")
        val optionalWorkerAdded=optionalFieldStore.addLabour(optionalFieldWorker)
        val optionalAttendanceSaved=optionalFieldStore.upsertAttendance(Attendance("rt-optional-field-attendance",optionalFieldWorker.id,"","","2026-10-08",1.0,250.0))==null
        val optionalFieldExpenseSaved=optionalFieldStore.addExpense(Expense("rt-optional-field-expense","","","बीज","बीज","","",50.0,"2026-10-08"))
        val optionalFieldSaleSaved=optionalFieldStore.addSale(Sale("rt-optional-field-sale","","",2.0,"क्विंटल",100.0,200.0,"Buyer","2026-10-08"))
        results["attendance, expense and sale can be saved without selecting a field"]=optionalWorkerAdded && optionalAttendanceSaved && optionalFieldStore.attendances.any{it.id=="rt-optional-field-attendance"&&it.fieldId.isBlank()} && optionalFieldExpenseSaved && optionalFieldStore.expenses.any{it.id=="rt-optional-field-expense"&&it.fieldId.isBlank()} && optionalFieldSaleSaved && optionalFieldStore.sales.any{it.id=="rt-optional-field-sale"&&it.fieldId.isBlank()}
        val activeTestStore=Store(isolatedContext,prefsName)
        val advancePrefs=isolatedContext.getSharedPreferences("mhpro_advance_test",Context.MODE_PRIVATE)
        advancePrefs.edit().clear().commit()
        val advanceStore=Store(isolatedContext,"mhpro_advance_test")
        val advanceWorker=Labour("rt-advance-worker","Advance Worker","",200.0,"","")
        val advanceWorkerAdded=advanceStore.addLabour(advanceWorker)
        val advanceEntry=Payment("rt-advance-payment",advanceWorker.id,"","","2026-10-11",75.0,"advance")
        val advanceSaved=advanceStore.addPayment(advanceEntry)
        val invalidKindRejected=!advanceStore.addPayment(advanceEntry.copy(id="rt-invalid-payment-kind",kind="unknown"))
        val advanceReload=Store(isolatedContext,"mhpro_advance_test")
        results["payment and advance type persist across Store reload; invalid type rejected"]=advanceWorkerAdded && advanceSaved && invalidKindRejected && advanceReload.payments.firstOrNull{it.id==advanceEntry.id}?.kind=="advance"
        advancePrefs.edit().clear().commit()
        val balanceBeforeDeactivation=activeTestStore.outstandingBalance(worker.id)
        val deactivated=activeTestStore.setLabourActive(worker.id,false)
        val inactiveReload=Store(isolatedContext,prefsName)
        val inactiveAttendanceRejected=inactiveReload.upsertAttendance(Attendance("rt-inactive-attendance",worker.id,"","","2026-11-15",1.0,500.0))!=null
        val historyStillExists=inactiveReload.attendances.any{it.labourId==worker.id} && inactiveReload.outstandingBalance(worker.id)==balanceBeforeDeactivation
        val reactivated=inactiveReload.setLabourActive(worker.id,true)
        results["worker can be deactivated without losing history and reactivated after reload"]=deactivated && inactiveReload.labours.firstOrNull{it.id==worker.id}?.active==false && inactiveAttendanceRejected && historyStillExists && reactivated && Store(isolatedContext,prefsName).labours.firstOrNull{it.id==worker.id}?.active==true
        optionalFieldPrefs.edit().clear().commit()
    }catch(_:Throwable){
        results["runtime harness completed without exception"]=false
    }finally{
        backup.delete()
        File(isolatedContext.cacheDir,"mhpro_runtime_incomplete.mhbackup").delete()
        File(isolatedContext.cacheDir,"mhpro_runtime_invalid_date.mhbackup").delete()
        isolatedContext.getSharedPreferences("mhpro_advance_test",Context.MODE_PRIVATE).edit().clear().commit()
        testPrefs.edit().clear().commit()
        // The isolated test context owns this folder; no production photos are touched.
        File(isolatedContext.filesDir,"photos").deleteRecursively()
    }
    return results
}
private const val DAILY_REMINDER_CHANNEL = "mhpro_daily_attendance_reminder"
private const val DAILY_REMINDER_REQUEST_CODE = 9207

private fun dailyReminderPendingIntent(context:Context):PendingIntent = PendingIntent.getBroadcast(
    context, DAILY_REMINDER_REQUEST_CODE,
    Intent(context,DailyAttendanceReminderReceiver::class.java).setAction("com.majdoor.hisaabpro.DAILY_ATTENDANCE_REMINDER"),
    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
)

private fun scheduleDailyAttendanceReminder(context:Context,hour:Int,minute:Int){
    val calendar=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,hour.coerceIn(0,23));set(Calendar.MINUTE,minute.coerceIn(0,59));set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)}
    val alarm=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,calendar.timeInMillis,AlarmManager.INTERVAL_DAY,dailyReminderPendingIntent(context))
}

private fun cancelDailyAttendanceReminder(context:Context){
    (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(dailyReminderPendingIntent(context))
}

class DailyAttendanceReminderBootReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent?){
        if(intent?.action!=Intent.ACTION_BOOT_COMPLETED && intent?.action!="android.intent.action.MY_PACKAGE_REPLACED") return
        val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
        if(prefs.getBoolean("dailyAttendanceReminderEnabled",false)){
            val hour=prefs.getInt("dailyAttendanceReminderHour",7).coerceIn(0,23)
            val minute=prefs.getInt("dailyAttendanceReminderMinute",0).coerceIn(0,59)
            scheduleDailyAttendanceReminder(context,hour,minute)
        }
    }
}

class DailyAttendanceReminderReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent?){
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(DAILY_REMINDER_CHANNEL,"दैनिक हाजिरी रिमाइंडर",NotificationManager.IMPORTANCE_DEFAULT))
        val openApp=PendingIntent.getActivity(context,DAILY_REMINDER_REQUEST_CODE,Intent(context,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification=NotificationCompat.Builder(context,DAILY_REMINDER_CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("आज की हाजिरी")
            .setContentText("Majdoor Hisaab PRO खोलकर आज की मजदूर हाजिरी दर्ज करें।")
            .setContentIntent(openApp).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(context).notify(DAILY_REMINDER_REQUEST_CODE,notification)
    }
}

class MainActivity:FragmentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent{MajdoorApp()}
    }

}

private fun driveErrorMessage(action:String,error:Throwable):String{
    val causes=generateSequence(error){it.cause}.toList()
    val root=causes.lastOrNull() ?: error
    val detail=(causes.mapNotNull{it.message}.joinToString(" | ").ifBlank{"Unknown error"}).take(500)
    val developerError=causes.any{(it as? ApiException)?.statusCode==10} || detail.contains("DEVELOPER_ERROR",ignoreCase=true) || detail.contains("status=10",ignoreCase=true)
    return when {
        developerError ->
            "$action असफल: Google OAuth configuration गलत है (status 10)। Package com.majdoor.hisaabpro और इसी Release APK की signing SHA-1 वाला Android OAuth client बनाएं/जाँचें, Google Drive API enable करें, फिर उसी stable keystore से APK rebuild करें।"
        detail.contains("PERMISSION_DENIED",ignoreCase=true) || detail.contains("insufficient",ignoreCase=true) ->
            "$action असफल: Google Drive permission नहीं मिली। Account दोबारा चुनें और Drive file access अनुमति दें। विवरण: $detail"
        else -> "$action असफल: $detail"
    }
}

@Composable private fun MajdoorApp(){
    val context=LocalContext.current
    val activity=context as? Activity
    val themePrefs=remember(context){context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)}
    var themeChoice by rememberSaveable{mutableStateOf(themePrefs.getString("themeChoice","system")?.takeIf{it in setOf("light","dark","system")} ?: "system")}
    val systemDark=isSystemInDarkTheme()
    val useDark=when(themeChoice){"dark"->true;"light"->false;else->systemDark}
    val palette=if(useDark) DarkPalette else LightPalette
    val store=remember{Store(context)}
    val drive=remember{GoogleDriveDirect(context)}
    val scope=rememberCoroutineScope()
    var driveAccount by remember{mutableStateOf(drive.lastAccount())}
    var driveBusy by remember{mutableStateOf(false)}
    var pendingDriveAction by rememberSaveable{mutableStateOf("")}
    var consentRetryInProgress by rememberSaveable{mutableStateOf(false)}
    val screenStackSaver = remember { listSaver<SnapshotStateList<Screen>,String>(
        save={state->state.map(::encodeScreen)},
        restore={saved->mutableStateListOf<Screen>().apply{addAll(saved.mapNotNull(::decodeScreen));if(isEmpty())add(Screen.Home)}}
    ) }
    val stack=rememberSaveable(saver=screenStackSaver){mutableStateListOf<Screen>(Screen.Home)}
    val screen=stack.last()
    // Never persist the unlocked security state through savedInstanceState. A recreated
    // Activity/process must re-check device credentials before exposing accounting data.
    var appUnlocked by remember{mutableStateOf(false)}
    val lifecycleOwner=LocalLifecycleOwner.current
    val securityPrefs=remember(context){context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)}
    DisposableEffect(lifecycleOwner,securityPrefs){
        val observer=LifecycleEventObserver{_,event->
            when(event){
                Lifecycle.Event.ON_STOP -> securityPrefs.edit().putLong("appBackgroundAt",System.currentTimeMillis()).apply()
                Lifecycle.Event.ON_START -> {
                    val stoppedAt=securityPrefs.getLong("appBackgroundAt",0L)
                    val timeoutMinutes=securityPrefs.getInt("autoLockMinutes",5).coerceIn(1,30)
                    if(stoppedAt>0L && System.currentTimeMillis()-stoppedAt >= timeoutMinutes*60_000L) appUnlocked=false
                    securityPrefs.edit().remove("appBackgroundAt").apply()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose{lifecycleOwner.lifecycle.removeObserver(observer)}
    }
    var backupStatus by remember{mutableStateOf("")}
    var restorePending by remember{mutableStateOf(false)}
    var restoreFile by remember{mutableStateOf<File?>(null)}
    val driveSignInLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        // Google Sign-In may return useful Status data even when resultCode is not RESULT_OK.
        // Always inspect the returned intent so OAuth/configuration failures are not hidden as cancellation.
        val returnedIntent=result.data
        if(returnedIntent==null){
            driveAccount=null
            backupStatus="Google Sign-In पूरा नहीं हुआ (resultCode=${result.resultCode}, data=null). दोबारा कोशिश करें; अगर बार-बार हो तो Release SHA-1/OAuth configuration जाँचें।"
        } else {
            runCatching{GoogleSignIn.getSignedInAccountFromIntent(returnedIntent).getResult(ApiException::class.java)}
                .onSuccess{account->
                    driveAccount=account
                    drive.saveAccount(account)
                    backupStatus="Google Account जुड़ गया: ${account.email ?: ""}"
                }
                .onFailure{error->
                    driveAccount=null
                    val code=(error as? ApiException)?.statusCode
                    val codeText=code?.let { "$it (${CommonStatusCodes.getStatusCodeString(it)})" } ?: "unknown"
                    val resultText=if(result.resultCode==Activity.RESULT_OK) "OK" else "${result.resultCode}"
                    backupStatus=if(code==10) "Google Sign-In failed: status=10 (DEVELOPER_ERROR). यह आम तौर पर Google Cloud OAuth configuration mismatch है। Android OAuth client में package com.majdoor.hisaabpro और इसी Release keystore का SHA-1 दर्ज करें; Google Drive API enable करें। फिर नया APK बनाकर दोबारा कोशिश करें।" else "Google Sign-In failed: status=$codeText, resultCode=$resultText. ${error.message ?: "Google account/Drive permission पूरी नहीं हुई"}"
                }
        }
    }
    var startDriveAction: (String, Boolean) -> Unit = { _, _ -> }
    val driveConsentLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        val action=pendingDriveAction
        pendingDriveAction="" // consume before any retry; duplicate results cannot repeat the operation
        if(action.isBlank()) return@rememberLauncherForActivityResult
        if(result.resultCode==Activity.RESULT_OK){
            consentRetryInProgress=true
            driveBusy=false
            startDriveAction(action, true)
        }else{
            consentRetryInProgress=false
            driveBusy=false
            backupStatus=if(action=="backup") "Google Drive Backup रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Backup दबाएँ।" else "Google Drive Restore रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Restore दबाएँ।"
        }
    }
    val createBackupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->
        if(uri==null){
            backupStatus="Backup save नहीं किया गया। Google Drive चुनकर फिर Backup बनाएं।"
        } else {
            val temp=File(context.cacheDir,"mhpro_backup_${System.currentTimeMillis()}.zip")
            runCatching{
                store.createBackupZip(temp)
                store.validateBackupZip(temp)
                val expectedBytes=temp.length()
                val copied=context.contentResolver.openOutputStream(uri)?.use{out->
                    temp.inputStream().use{input->val count=input.copyTo(out);out.flush();count}
                } ?: throw IllegalStateException("Backup location open नहीं हुई।")
                if(copied!=expectedBytes) throw IllegalStateException("Backup पूरा save नहीं हुआ; bytes का मिलान नहीं हुआ।")
                val verify=File(context.cacheDir,"mhpro_backup_verify_${System.currentTimeMillis()}.mhbackup")
                try{
                    context.contentResolver.openInputStream(uri)?.use{input->verify.outputStream().use{input.copyTo(it)}}
                        ?: throw IllegalStateException("सेव हुए backup को दोबारा पढ़कर जाँचा नहीं जा सका।")
                    store.validateBackupZip(verify)
                }finally{verify.delete()}
                recordBackupHistory(context,"Local Backup",uri.lastPathSegment ?: temp.name)
                backupStatus="Backup सेव और सत्यापित हो गया। (${SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date())})"
            }.onFailure{
                backupStatus="Backup सेव/सत्यापित नहीं हो सका। मौजूदा app data सुरक्षित है। कारण: ${it.message ?: "Unknown error"}"
            }
            temp.delete()
        }
    }
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            var temp:File?=null
            runCatching{
                temp=File(context.cacheDir,"mhpro_restore_${System.currentTimeMillis()}.mhbackup")
                context.contentResolver.openInputStream(uri)?.use{input->temp!!.outputStream().use{input.copyTo(it)}}
                    ?: throw IllegalStateException("Backup file open नहीं हुई।")
                if(temp!!.length()<=0L) throw IllegalStateException("चुनी गई backup file खाली है।")
                store.validateBackupZip(temp!!)
                restoreFile=temp
                restorePending=true
                backupStatus="Backup file सत्यापित है। Restore से पहले पुष्टि और screen-lock जाँच होगी।"
            }.onFailure{temp?.delete();backupStatus="Restore शुरू नहीं किया गया। चुनी गई file गलत/अधूरी है; मौजूदा data में कोई बदलाव नहीं हुआ। कारण: ${it.message ?: "Unknown error"}"}
        }else backupStatus="Restore रद्द किया गया। मौजूदा data में कोई बदलाव नहीं हुआ।"
    }
    startDriveAction = start@{ action, isConsentRetry ->
        // A fresh user action starts a new one-shot consent cycle; the automatic retry does not.
        if(driveBusy || pendingDriveAction.isNotBlank()) return@start
        if(!isConsentRetry) consentRetryInProgress=false
        val account=driveAccount
        if(account==null){
            driveSignInLauncher.launch(drive.signInIntent())
            return@start
        }
        driveBusy=true
        scope.launch{
            val result=runCatching{withContext(Dispatchers.IO){
                if(action=="backup"){
                    val temp=File(context.cacheDir,"mhpro_drive_upload_${System.currentTimeMillis()}.mhbackup")
                    try{
                        store.createBackupZip(temp)
                        store.validateBackupZip(temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Backup खाली बना है; Drive पर upload नहीं किया गया।")
                        drive.upload(account,temp)
                    }finally{temp.delete()}
                }else{
                    val temp=File(context.cacheDir,"mhpro_drive_restore_${System.currentTimeMillis()}.mhbackup")
                    try{
                        val name=drive.downloadLatest(account,temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Drive से खाली backup मिला।")
                        store.validateBackupZip(temp)
                        name to temp
                    }catch(e:Throwable){temp.delete();throw e}
                }
            }}
            result.onSuccess{value->
                if(action=="backup") { recordBackupHistory(context,"Google Drive Backup",value.toString()); backupStatus="Google Drive पर backup upload हो गया: $value (${SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date())})" }
                else {
                    @Suppress("UNCHECKED_CAST")
                    val pair=value as Pair<String,File>
                    restoreFile=pair.second
                    restorePending=true
                    backupStatus="Drive backup '${pair.first}' सत्यापित है। Restore दबाकर पुष्टि करें।"
                }
                consentRetryInProgress=false
                driveBusy=false
            }.onFailure{error->
                if(error is NeedRemoteConsent && !consentRetryInProgress){
                    pendingDriveAction=action
                    // Launch the exact recoverable consent intent once, on the foreground UI.
                    runCatching{driveConsentLauncher.launch(error.consentIntent)}.onFailure{launchError->
                        pendingDriveAction=""
                        backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",launchError)
                        driveBusy=false
                    }
                }else{
                    consentRetryInProgress=false
                    pendingDriveAction=""
                    backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",error)
                    driveBusy=false
                }
            }
        }
    }
    if(!appUnlocked){
        MaterialTheme(colorScheme=if(useDark) darkColorScheme(primary=palette.green,secondary=palette.greenDark,background=palette.background,surface=palette.card,onBackground=palette.text,onSurface=palette.text) else lightColorScheme(primary=palette.green,secondary=palette.greenDark,background=palette.background,surface=palette.card,onBackground=palette.text,onSurface=palette.text)) {
        CompositionLocalProvider(LocalAppPalette provides palette) {
        DeviceCredentialGate("Majdoor Hisaab PRO खोलें","App का data देखने के लिए Android screen lock से पुष्टि करें।",{appUnlocked=true},{activity?.finish()})
        Box(Modifier.fillMaxSize().background(Bg).testTag("app_lock_gate"),contentAlignment=Alignment.Center){
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Text("🔐",fontSize=42.sp); Text("Majdoor Hisaab PRO",fontWeight=FontWeight.ExtraBold,fontSize=22.sp); Text("App खोलने के लिए phone screen lock जरूरी है।",color=AppMuted)
                }
            }
        }
        }
        }
        return
    }
    fun go(s:Screen){
        if(stack.lastOrNull()==s) return
        stack.add(s)
    }
    fun goRoot(s:Screen){
        stack.clear(); stack.add(s)
    }
    fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }
    val isRoot=screen is Screen.Home||screen is Screen.More||screen is Screen.LabourList||screen is Screen.FieldList||screen is Screen.ExpenseList&&screen.fieldId==null&&screen.cropId==null||screen is Screen.SaleList&&screen.fieldId==null&&screen.cropId==null||(screen is Screen.CropList&&screen.fieldId==null)
    restoreFile?.let{file->
        DeviceCredentialGate("Backup Restore करें","Backup data से app का मौजूदा data replace होगा। Android screen lock से पुष्टि करें।",{
            val safetyFile=File(context.filesDir,"mhpro_pre_restore_safety.zip")
            val restoringSafety=runCatching{file.canonicalFile==safetyFile.canonicalFile}.getOrDefault(false)
            var safeToRestore=true
            if(!restoringSafety && context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE).getBoolean("backupBeforeRestore",true)){
                val tempSafety=File(context.filesDir,"mhpro_pre_restore_safety.tmp.zip")
                val previousSafety=File(context.filesDir,"mhpro_pre_restore_safety.previous.zip")
                runCatching{
                    tempSafety.delete()
                    store.createBackupZip(tempSafety)
                    if(!tempSafety.isFile || tempSafety.length()<=0L) throw IllegalStateException("Safety backup खाली बना है।")
                    store.validateBackupZip(tempSafety)
                    previousSafety.delete()
                    if(safetyFile.exists() && !safetyFile.renameTo(previousSafety)) throw IllegalStateException("पुरानी safety copy सुरक्षित नहीं की जा सकी।")
                    if(!tempSafety.renameTo(safetyFile)){
                        if(previousSafety.exists()) previousSafety.renameTo(safetyFile)
                        throw IllegalStateException("नई safety copy सुरक्षित नहीं की जा सकी।")
                    }
                    previousSafety.delete()
                    recordBackupHistory(context,"Pre-restore safety copy",safetyFile.name)
                }.onFailure{error->
                    safeToRestore=false
                    tempSafety.delete()
                    if(!safetyFile.exists() && previousSafety.exists()) previousSafety.renameTo(safetyFile)
                    backupStatus="Restore रोक दिया गया: safety backup नहीं बन पाया। मौजूदा data नहीं बदला। ${error.message ?: ""}"
                }
            }
            if(safeToRestore){
                runCatching{store.restoreBackupZip(file);recordBackupHistory(context,"Restore",file.name);backupStatus="Backup सफलतापूर्वक restore हुआ। (${SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date())})"}.onFailure{backupStatus="Restore failed: ${it.message ?: "Unknown error"}"}
            }
            if(!restoringSafety) file.delete()
            restoreFile=null;restorePending=false
        },{val safetyFile=File(context.filesDir,"mhpro_pre_restore_safety.zip");if(runCatching{file.canonicalFile!=safetyFile.canonicalFile}.getOrDefault(true))file.delete();restoreFile=null;restorePending=false})
    }
    BackHandler(enabled=true){
        when {
            stack.size > 1 -> back()
            screen !is Screen.Home -> goRoot(Screen.Home)
            else -> (context as? Activity)?.finish()
        }
    }
    MaterialTheme(colorScheme=if(useDark) darkColorScheme(primary=palette.green,secondary=palette.greenDark,background=palette.background,surface=palette.card,onBackground=palette.text,onSurface=palette.text) else lightColorScheme(primary=palette.green,secondary=palette.greenDark,background=palette.background,surface=palette.card,onBackground=palette.text,onSurface=palette.text)) {
    CompositionLocalProvider(LocalAppPalette provides palette) {
    Surface(Modifier.fillMaxSize(),color=Bg){Column(Modifier.fillMaxSize()){
        TopBar(
            title=screenTitle(screen),
            subtitle=screenSubtitle(screen),
            canBack=!isRoot,
            onBack={if(isRoot) goRoot(Screen.Home) else back()},
            onProfile={goRoot(Screen.Profile)}
        )
        Box(Modifier.weight(1f).fillMaxWidth().imePadding()){when(val s=screen){
            Screen.Home->Dashboard(store){key->goRoot(when(key){
                "attendance","daily_labour"->Screen.DailyLabourHome
                "attendance_history"->Screen.AttendanceHistory
                "today_attendance"->Screen.TodayAttendance
                "backup"->Screen.Backup
                "labour"->Screen.LabourList
                "payments"->Screen.PaymentHistory
                "field"->Screen.FieldList
                "expense"->Screen.ExpenseList()
                "sale"->Screen.SaleList()
                "crop"->Screen.CropList()
                "cane"->Screen.CaneParchi
                "cane_peeling"->Screen.CanePeeling
                else->Screen.More
            })}
            Screen.DailyLabourHome->DailyLabourHomeScreen(onAttendance={go(Screen.AttendanceFields)},onAccounts={go(Screen.DailyLabourAccounts)})
            Screen.DailyLabourAccounts->DailyLabourAccountsScreen(store,onWorkers={go(Screen.LabourList)},onFieldReport={go(Screen.AllLabourReport)},onAttendanceHistory={go(Screen.AttendanceHistory)},onToday={go(Screen.TodayAttendance)},onAllReport={go(Screen.AllLabourReport)},onPayments={go(Screen.LabourList)},onBack={back()})
            Screen.AllLabourReport->AllLabourReportScreen(store,onBack={back()},onWorker={go(Screen.LabourDetail(it))},onAttendance={go(Screen.AttendanceFields)})
            Screen.AttendanceFields->AttendanceFieldPickerScreen(store,onSelect={go(Screen.Attendance(it))},onBack={back()})
            Screen.LabourList->LabourScreen(store,{go(Screen.LabourDetail(it))},{go(Screen.AttendanceFields)})
            Screen.PaymentHistory->PaymentHistoryScreen(store,{go(Screen.LabourDetail(it))})
            Screen.FieldList->FieldScreen(store){go(Screen.FieldDetail(it))}
            is Screen.ExpenseList->ExpenseScreen(store,s.fieldId,s.cropId){goRoot(Screen.ExpenseList(s.fieldId,s.cropId))}
            is Screen.SaleList->SaleScreen(store,s.fieldId,s.cropId)
            is Screen.CropList->CropScreen(store,s.fieldId){go(Screen.CropDetail(it))}
            is Screen.LabourDetail->LabourDetail(store,s.id,{back()})
            is Screen.FieldDetail->FieldDetail(store,s.id,{back()},{go(Screen.CropDetail(it))},{go(Screen.Attendance(s.id))},{go(Screen.ExpenseList(s.id,null))},{go(Screen.SaleList(s.id,null))},{go(Screen.CropList(s.id))})
            is Screen.CropDetail->CropDetail(store,s.id,{back()},{go(Screen.ExpenseList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))},{go(Screen.SaleList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))})
            is Screen.Attendance->AttendanceScreen(store,s.fieldId,{back()})
            Screen.AttendanceHistory->AttendanceHistoryScreen(store,{back()})
            Screen.TodayAttendance->TodayAttendanceScreen(store,{back()})
            Screen.Backup->BackupScreen(store,backupStatus,{msg->backupStatus=msg},{createBackupLauncher.launch("Majdoor_Hisaab_PRO_Backup_${today()}.mhbackup")},{restoreLauncher.launch(arrayOf("application/zip","application/octet-stream"))},{
                val safety=File(context.filesDir,"mhpro_pre_restore_safety.zip")
                if(safety.isFile && safety.length()>0L){restoreFile=safety;restorePending=true;backupStatus="Safety backup चुना गया है। Restore से पहले screen lock से पुष्टि करें।"}
                else backupStatus="अभी कोई safety backup नहीं है। Restore से पहले safety backup setting चालू रखें।"
            },driveAccount?.email ?: "Google Account नहीं जुड़ा",driveBusy || pendingDriveAction.isNotBlank(),{driveAccount=null;drive.prepareFreshSignIn{driveSignInLauncher.launch(drive.signInIntent())}},{startDriveAction("backup", false)},{startDriveAction("restore", false)})
            Screen.Profile->ProfileScreen(themeChoice=themeChoice,onThemeChanged={choice->themeChoice=choice;themePrefs.edit().putString("themeChoice",choice).apply()},onBackup={goRoot(Screen.Backup)})
            Screen.More->MoreScreen { key -> goRoot(when(key){
                "attendance","daily_labour"->Screen.DailyLabourHome
                "accounts"->Screen.DailyLabourAccounts
                "workers"->Screen.LabourList
                "payments"->Screen.PaymentHistory
                "attendance_history"->Screen.AttendanceHistory
                "today_attendance"->Screen.TodayAttendance
                "backup"->Screen.Backup
                "expense"->Screen.ExpenseList()
                "sale"->Screen.SaleList()
                "crop"->Screen.CropList()
                "field"->Screen.FieldList
                "cane"->Screen.CaneParchi
                "cane_peeling"->Screen.CanePeeling
                "reports","field_report"->Screen.AllLabourReport
                "settings"->Screen.Profile
                else->Screen.More
            }) }
            Screen.CaneParchi->CaneParchiDashboardScreen(store)
            Screen.CanePeeling->CanePeelingScreen(store,{back()})
        }}
        if(isRoot) BottomBar(screen){key->goRoot(when(key){"home"->Screen.Home;"labour"->Screen.LabourList;"field"->Screen.FieldList;else->Screen.More})}
    }}
    }
    }
}

private fun screenTitle(screen: Screen): String = when (screen) {
    Screen.Home -> "Majdoor Hisaab PRO"
    Screen.LabourList -> "मजदूर सूची"
    Screen.PaymentHistory -> "सभी भुगतान"
    Screen.DailyLabourHome -> "दिहाड़ी मजदूर"
    Screen.DailyLabourAccounts -> "दिहाड़ी हिसाब"
    Screen.AllLabourReport -> "मजदूरी रिपोर्ट"
    Screen.AttendanceFields -> "हाजिरी के लिए खेत चुनें"
    Screen.FieldList -> "खेत प्रबंधन"
    is Screen.ExpenseList -> "खर्च का हिसाब"
    is Screen.SaleList -> "फसल बिक्री"
    is Screen.CropList -> "फसल प्रबंधन"
    is Screen.LabourDetail -> "मजदूर का पूरा हिसाब"
    is Screen.FieldDetail -> "खेत का विवरण"
    is Screen.CropDetail -> "फसल का विवरण"
    is Screen.Attendance -> "मजदूरों की हाजिरी"
    Screen.AttendanceHistory -> "हाजिरी इतिहास"
    Screen.TodayAttendance -> "आज की हाजिरी"
    Screen.Backup -> "Backup और Restore"
    Screen.Profile -> "प्रोफाइल और सेटिंग्स"
    Screen.More -> "सभी सुविधाएँ"
    Screen.CaneParchi -> "गन्ना पर्ची"
    Screen.CanePeeling -> "गन्ना छिलाई"
}

private fun screenSubtitle(screen: Screen): String? = when (screen) {
    Screen.Home -> "खेत • मजदूर • खर्च • बिक्री • फसल"
    Screen.LabourList, is Screen.LabourDetail -> "मजदूर, भुगतान और बकाया"
    Screen.PaymentHistory -> "सभी मजदूरों की भुगतान हिस्ट्री"
    Screen.DailyLabourHome, Screen.DailyLabourAccounts, Screen.AllLabourReport -> "हाजिरी • मजदूरी • भुगतान • रिपोर्ट"
    Screen.AttendanceFields, is Screen.Attendance, Screen.AttendanceHistory, Screen.TodayAttendance -> "तारीख के अनुसार सुरक्षित रिकॉर्ड"
    Screen.FieldList, is Screen.FieldDetail -> "खेत और उनसे जुड़े रिकॉर्ड"
    is Screen.CropList, is Screen.CropDetail -> "फसल, लागत और बिक्री"
    is Screen.ExpenseList -> "खेती के खर्च और उनकी तारीखें"
    is Screen.SaleList -> "उपज, दर और बिक्री का रिकॉर्ड"
    Screen.Backup -> "स्थानीय बैकअप और Google Drive"
    Screen.Profile -> "ऐप और सुरक्षा विकल्प"
    Screen.More -> "रिपोर्ट • गन्ना • Backup • Settings"
    Screen.CaneParchi -> "पर्ची • वजन • भाव • विवरण"
    Screen.CanePeeling -> "फांदी • दर • भुगतान • बाकी"
}

@Composable private fun TopBar(title:String,subtitle:String?=null,canBack:Boolean=true,onBack:()->Unit,onProfile:(()->Unit)?=null){
    Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(GreenDark,Green))).shadow(4.dp)){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack,modifier=Modifier.size(44.dp)){Icon(imageVector=if(canBack) Icons.Default.ArrowBack else Icons.Default.Home,contentDescription=if(canBack) "Back" else "Home",tint=Color.White)}
            Image(painterResource(R.drawable.majdoor_logo_small),null,Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
                Text(title,color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=16.sp,maxLines=1)
                if(!subtitle.isNullOrBlank()) Text(subtitle,color=Color.White.copy(alpha=.88f),fontSize=10.sp,maxLines=1)
            }
            if(onProfile!=null){
                IconButton(onClick=onProfile,modifier=Modifier.size(44.dp)){
                    Icon(Icons.Default.AccountCircle,contentDescription="Profile",tint=Color.White,modifier=Modifier.size(29.dp))
                }
            }
        }
    }
}

@Composable private fun BottomBar(screen:Screen,onTab:(String)->Unit){
    val current=when(screen){Screen.Home->"home";Screen.LabourList,Screen.DailyLabourHome,Screen.DailyLabourAccounts,Screen.AllLabourReport,Screen.AttendanceFields,Screen.AttendanceHistory,Screen.TodayAttendance,is Screen.Attendance->"labour";Screen.FieldList,is Screen.FieldDetail,is Screen.CropList,is Screen.CropDetail->"field";else->"more"}
    Surface(color=CardBg,shadowElevation=5.dp){
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal=8.dp,vertical=5.dp),horizontalArrangement=Arrangement.SpaceAround){
            listOf(Triple("home",Icons.Default.Home,"होम"),Triple("labour",Icons.Default.Groups,"मजदूर"),Triple("field",Icons.Default.Landscape,"खेत"),Triple("more",Icons.Default.Menu,"अन्य")).forEach{(key,icon,label)->
                val selected=current==key
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                        .background(if(selected) Color(0xFFE4F3EA) else Color.Transparent)
                        .clickable{onTab(key)}.padding(vertical=8.dp),
                    horizontalAlignment=Alignment.CenterHorizontally,
                    verticalArrangement=Arrangement.spacedBy(4.dp)
                ){
                    Icon(imageVector=icon,contentDescription=label,modifier=Modifier.size(22.dp),tint=if(selected)Green else Color(0xFF68756E))
                    Text(label,fontSize=11.sp,fontWeight=if(selected)FontWeight.Bold else FontWeight.Medium,color=if(selected)GreenDark else Color(0xFF68756E))
                }
            }
        }
    }
}

@Composable private fun MoreScreen(onGo:(String)->Unit){
    val sections=listOf(
        "मजदूरी और हिसाब" to listOf(
            MoreMenuItem("workers","मजदूर सूची","मजदूर जोड़ें, खोजें और पूरा हिसाब देखें",Icons.Default.Groups),
            MoreMenuItem("payments","सभी भुगतान","तारीख, रकम और मजदूरवार भुगतान हिस्ट्री",Icons.Default.Payments),
            MoreMenuItem("attendance","दिहाड़ी हाजिरी","खेत चुनकर मजदूरों की हाजिरी दर्ज करें",Icons.Default.CalendarMonth),
            MoreMenuItem("accounts","महीने का हिसाब और लॉक","मजदूरी, भुगतान, बकाया और लॉक किए महीने",Icons.Default.AccountBalanceWallet),
            MoreMenuItem("today_attendance","आज की हाजिरी","आज के सेव किए गए रिकॉर्ड",Icons.Default.Today),
            MoreMenuItem("attendance_history","हाजिरी इतिहास","पुरानी तारीखों के रिकॉर्ड",Icons.Default.History),
            MoreMenuItem("reports","रिपोर्ट और Ledger","मजदूरवार रिपोर्ट और PDF",Icons.Default.Assessment),
            MoreMenuItem("field_report","तारीख और खेत रिपोर्ट","चुनी तारीखों/खेतों की हाजिरी और भुगतान PDF",Icons.Default.PictureAsPdf)
        ),
        "खेत और फसल" to listOf(
            MoreMenuItem("field","खेत प्रबंधन","खेत और उनसे जुड़े रिकॉर्ड",Icons.Default.Landscape),
            MoreMenuItem("expense","खेती का खर्च","खर्च की एंट्री और हिस्ट्री",Icons.Default.Payments),
            MoreMenuItem("sale","फसल की बिक्री","बिक्री, मात्रा और आय",Icons.Default.ShoppingCart),
            MoreMenuItem("crop","फसल प्रबंधन","फसल और संबंधित रिकॉर्ड",Icons.Default.Spa)
        ),
        "गन्ना मॉड्यूल" to listOf(
            MoreMenuItem("cane_peeling","गन्ना छिलाई","फांदी, रेट, भुगतान और बाकी",Icons.Default.Spa),
            MoreMenuItem("cane","गन्ना पर्ची","पर्ची, वजन और भाव",Icons.Default.Receipt)
        ),
        "डेटा और सेटिंग्स" to listOf(
            MoreMenuItem("backup","Backup और Restore","स्थानीय और Google Drive backup",Icons.Default.CloudUpload),
            MoreMenuItem("settings","Settings और सुरक्षा","ऐप विकल्प और सुरक्षा",Icons.Default.Settings)
        )
    )
    Column(Modifier.fillMaxSize().background(Bg)){
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            item {
                Column(Modifier.fillMaxWidth().padding(bottom=4.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                    Text("सभी सुविधाएँ",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                    Text("काम के अनुसार सुविधा चुनें। आपका डेटा फोन में सुरक्षित रहता है।",fontSize=12.sp,color=Color(0xFF65736B))
                }
            }
            sections.forEach { (heading, menuItems) ->
                item(key="section_$heading") {
                    Text(heading,Modifier.fillMaxWidth().padding(top=8.dp,bottom=2.dp),fontSize=14.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                }
                items(menuItems,key={it.key}){menuItem->
                    Card(Modifier.fillMaxWidth().clickable{onGo(menuItem.key)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){
                        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)){
                            Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE7F3EB)),contentAlignment=Alignment.Center){Icon(menuItem.icon,contentDescription=null,tint=Green,modifier=Modifier.size(23.dp))}
                            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                                Text(menuItem.title,fontWeight=FontWeight.Bold,color=AppAccentText,fontSize=15.sp)
                                Text(menuItem.subtitle,fontSize=12.sp,color=Color(0xFF65736B))
                            }
                            Icon(Icons.Default.ChevronRight,contentDescription="${menuItem.title} खोलें",tint=Color(0xFF718078))
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun DailyLabourHomeScreen(onAttendance:()->Unit,onAccounts:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        Text("दिहाड़ी मजदूर",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
        Text("सामान्य मजदूरों की हाजिरी और हिसाब",fontSize=14.sp,color=AppMuted)
        Card(Modifier.fillMaxWidth().heightIn(min=145.dp).clickable{onAttendance()},shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
            Row(Modifier.fillMaxWidth().padding(22.dp),verticalAlignment=Alignment.CenterVertically){
                Icon(Icons.Default.HowToReg,null,tint=Color.White,modifier=Modifier.size(46.dp));Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)){Text("हाजिरी लगाएँ",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Color.White);Text("पहले खेत चुनें, फिर मजदूर और तारीख",fontSize=13.sp,color=Color.White.copy(alpha=.9f))}
                Icon(Icons.Default.ChevronRight,null,tint=Color.White,modifier=Modifier.size(30.dp))
            }
        }
        Card(Modifier.fillMaxWidth().heightIn(min=145.dp).clickable{onAccounts()},shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(2.dp)){
            Row(Modifier.fillMaxWidth().padding(22.dp),verticalAlignment=Alignment.CenterVertically){
                Icon(Icons.Default.AccountBalanceWallet,null,tint=Green,modifier=Modifier.size(46.dp));Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)){Text("हिसाब देखें",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText);Text("मजदूरवार हिसाब, भुगतान और हाजिरी रिपोर्ट",fontSize=13.sp,color=AppMuted)}
                Icon(Icons.Default.ChevronRight,null,tint=Green,modifier=Modifier.size(30.dp))
            }
        }
    }
}

@Composable private fun DailyLabourAccountsScreen(store:Store,onWorkers:()->Unit,onFieldReport:()->Unit,onAttendanceHistory:()->Unit,onToday:()->Unit,onAllReport:()->Unit,onPayments:()->Unit,onBack:()->Unit){
    var selectedMonth by rememberSaveable { mutableStateOf("") }
    var lockConfirm by rememberSaveable { mutableStateOf(false) }
    val monthKeys=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}).filter{validMonthKey(it)}.distinct().sortedDescending()
    val months=(monthKeys+store.lockedLabourMonths).distinct().sortedDescending()
    if(selectedMonth.isNotBlank()){
        val month=selectedMonth
        val monthAttendance=store.attendances.filter{it.date.startsWith(month) && it.fraction>0.0}
        val monthPayments=store.payments.filter{it.date.startsWith(month)}
        val rows=store.labours.mapNotNull{l->
            val a=monthAttendance.filter{it.labourId==l.id}
            val p=monthPayments.filter{it.labourId==l.id}
            if(a.isEmpty()&&p.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},p.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=AppAccentText); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",rows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान/अग्रिम",rows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",rows.sumOf{it.wage-it.paid})} }
                    if(month !in store.lockedLabourMonths) Button(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                items(rows,key={it.labour.id}) { r->
                    val days=monthAttendance.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                            Text(r.labour.name,fontWeight=FontWeight.Bold,color=AppAccentText,fontSize=16.sp)
                            Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                            Text("इस महीने भुगतान/अग्रिम ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=AppAccentText)
                        }
                    } }
                }
                if(rows.isEmpty()) item { Text("इस महीने कोई हिसाब दर्ज नहीं है।",color=AppMuted) }
            }
        }
        if(lockConfirm) AlertDialog(onDismissRequest={lockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "इस महीने की हाजिरी में बदलाव फिर से किया जा सकेगा। पुरानी जानकारी सुरक्षित रहेगी।" else "इस महीने की हाजिरी और हिसाब सुरक्षित हो जाएगा। महीना खोलकर जानकारी देख सकते हैं; बाद के महीनों का काम जारी रहेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);lockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={lockConfirm=false}){Text("रद्द करें")}})
        return
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        DetailTopBar("हिसाब देखें",onBack)
        SmallAction("👷 मजदूरवार हिसाब",onWorkers)
        SmallAction("💸 भुगतान दर्ज करें",onPayments)
        SmallAction("🌾 खेतवार हिसाब",onFieldReport)
        SmallAction("📅 तारीखवार हाजिरी रिपोर्ट",onAttendanceHistory)
        SmallAction("📋 आज की हाजिरी",onToday)
        SmallAction("📑 सभी मजदूरों की संयुक्त रिपोर्ट / PDF",onAllReport)
        if(months.isNotEmpty()) {
            Text("महीने का हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=AppAccentText)
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                items(months,key={it}) { month ->
                    Card(Modifier.fillMaxWidth().clickable{selectedMonth=month},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Row(Modifier.padding(horizontal=14.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
                            Text(monthTitle(month),Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=16.sp,color=AppAccentText)
                            Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,contentDescription=null,tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                        }
                    }
                }
            }
        } else Text("अभी कोई महीने का हिसाब नहीं है।",fontSize=12.sp,color=AppMuted)
    }
}

private data class LabourReportRow(val labour:Labour,val wage:Double,val paid:Double,val workDays:Double,val halfDays:Int)

@Composable private fun AllLabourReportScreen(store:Store,onBack:()->Unit,onWorker:(String)->Unit,onAttendance:()->Unit){
    val context=LocalContext.current
    val reportPrefs=remember(context){context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)}
    val firstDate=store.attendances.map{it.date}.minOrNull() ?: today()
    var startDate by rememberSaveable{mutableStateOf(firstDate)}
    var endDate by rememberSaveable{mutableStateOf(today())}
    var multiDateMode by rememberSaveable{mutableStateOf(false)}
    var defaultMonthFilter by rememberSaveable{mutableStateOf(reportPrefs.getString("reportDefaultRange","all")=="current_month")}
    val selectedDates=rememberSaveable(saver=listSaver<SnapshotStateList<String>,String>(save={state->state.toList()},restore={saved->mutableStateListOf<String>().apply{addAll(saved)}})){mutableStateListOf<String>()}
    var allFields by rememberSaveable{mutableStateOf(true)}
    val selectedFields=rememberSaveable(saver=listSaver<SnapshotStateList<String>,String>(save={state->state.toList()},restore={saved->mutableStateListOf<String>().apply{addAll(saved)}})){mutableStateListOf<String>()}
    val selectedWorkers=rememberSaveable(saver=listSaver<SnapshotStateList<String>,String>(save={state->state.toList()},restore={saved->mutableStateListOf<String>().apply{addAll(saved)}})){mutableStateListOf<String>()}
    var selectedLockMonth by rememberSaveable{mutableStateOf("")}
    var showCustomReport by rememberSaveable{mutableStateOf(false)}
    var monthLockConfirm by rememberSaveable{mutableStateOf(false)}
    var validation by remember{mutableStateOf("")}
    val lockMonths=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}+store.lockedLabourMonths).filter{validMonthKey(it)}.distinct().sortedDescending()
    val reportDates=(store.attendances.map{it.date}+store.payments.map{it.date}).distinct().sortedDescending()
    if(showCustomReport) {
        val reportFields=store.fields
        val currentMonthDefault=defaultMonthFilter && selectedDates.isEmpty()
        val chosenDates=when{
            selectedDates.isNotEmpty()->selectedDates.toSet()
            currentMonthDefault->reportDates.filter{it.startsWith(today().take(7))}.toSet()
            else->emptySet()
        }
        val chosenFieldIds=if(allFields) reportFields.map{it.id}.toSet() else selectedFields.toSet()
        val matchingAttendance=store.attendances.filter{it.fraction>0.0 && (if(currentMonthDefault) it.date.startsWith(today().take(7)) else (chosenDates.isEmpty() || it.date in chosenDates)) && (allFields || it.fieldId in chosenFieldIds)}
        // Payments are worker-level ledger entries, not necessarily tied to a field ID.
        // When fields are selected, include dated payments only for workers who worked in those selected fields.
        val fieldMatchedWorkerIds=matchingAttendance.map{it.labourId}.toSet()
        val matchingPayments=store.payments.filter{(if(currentMonthDefault) it.date.startsWith(today().take(7)) else (chosenDates.isEmpty() || it.date in chosenDates)) && (allFields || it.fieldId in chosenFieldIds || (it.fieldId.isBlank() && it.labourId in fieldMatchedWorkerIds))}
        val matchingLabourIds=(matchingAttendance.map{it.labourId}+matchingPayments.map{it.labourId}).toSet()
        val reportRows=store.labours.filter{it.id in matchingLabourIds}.map{labour->
            val a=matchingAttendance.filter{it.labourId==labour.id}
            val payments=matchingPayments.filter{it.labourId==labour.id}
            LabourReportRow(labour,a.sumOf{it.fraction*it.rate},payments.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        val totalWage=reportRows.sumOf{it.wage}; val totalPaid=reportRows.sumOf{it.paid}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar("तारीख और खेत के अनुसार रिपोर्ट",{showCustomReport=false})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Text("रिपोर्ट की तारीखें चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=AppAccentText) }
                item { Text(if(defaultMonthFilter && selectedDates.isEmpty()) "Report Settings के अनुसार चालू महीने की तारीखें चुनी गई हैं। तारीख बदलने के लिए नीचे चयन करें।" else "एक या अधिक तारीखें चुनें। चयन हटाकर सभी तारीखें शामिल कर सकते हैं।",fontSize=12.sp,color=AppMuted) }
                item(content = { OutlinedButton(onClick = { selectedDates.clear(); defaultMonthFilter=false }, modifier = Modifier.fillMaxWidth()) { Text("सभी तारीखें शामिल करें / चयन हटाएँ") } })
                items(reportDates,key={"date_"+it}) { date ->
                    Row(Modifier.fillMaxWidth().background(CardBg,RoundedCornerShape(12.dp)).clickable{if(defaultMonthFilter && selectedDates.isEmpty()) {selectedDates.addAll(reportDates.filter{it.startsWith(today().take(7))});defaultMonthFilter=false};if(date in selectedDates) selectedDates.remove(date) else selectedDates.add(date)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=date in selectedDates || (defaultMonthFilter && date.startsWith(today().take(7))),onCheckedChange={v->if(defaultMonthFilter && selectedDates.isEmpty()){selectedDates.addAll(reportDates.filter{it.startsWith(today().take(7))});defaultMonthFilter=false};if(v){if(date !in selectedDates)selectedDates.add(date)}else selectedDates.remove(date)})
                        Text(displayDate(date),color=AppAccentText,fontWeight=FontWeight.Medium)
                    }
                }
                item { Divider(); Text("खेत चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=AppAccentText) }
                item { Row(Modifier.fillMaxWidth().background(CardBg,RoundedCornerShape(12.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=allFields,onCheckedChange={allFields=it;if(it)selectedFields.clear()});Text("सभी खेत",fontWeight=FontWeight.Bold,color=AppAccentText) } }
                items(reportFields,key={"field_"+it.id}) { field ->
                    Row(Modifier.fillMaxWidth().background(CardBg,RoundedCornerShape(12.dp)).clickable{allFields=false;if(field.id in selectedFields)selectedFields.remove(field.id)else selectedFields.add(field.id)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=allFields || field.id in selectedFields,onCheckedChange={v->allFields=false;if(v){if(field.id !in selectedFields)selectedFields.add(field.id)}else selectedFields.remove(field.id)})
                        Text(field.name.ifBlank{"नाम रहित खेत"},color=AppAccentText,fontWeight=FontWeight.Medium)
                    }
                }
                item {
                    Card(colors=CardDefaults.cardColors(containerColor=CardBg),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("चुनी रिपोर्ट का सार",fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                        Text("मजदूर ${reportRows.size} • हाजिरी ${quantity(matchingAttendance.sumOf{it.fraction})} दिन")
                        Text("मजदूरी ₹${money(totalWage)} • भुगतान ₹${money(totalPaid)} • बकाया ₹${money(totalWage-totalPaid)}")
                        Button(onClick={
                            val selectedAttendance=matchingAttendance.sortedWith(compareBy<Attendance>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            val selectedPayments=matchingPayments.sortedWith(compareBy<Payment>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            if(selectedAttendance.isEmpty()&&selectedPayments.isEmpty()) validation="चुनी तारीख/खेत में कोई हाजिरी या भुगतान नहीं मिला।" else {
                                val detailLines=buildList {
                                    add("हाजिरी और मजदूरी का खेतवार विवरण")
                                    selectedAttendance.forEach{a->val labour=store.labours.firstOrNull{it.id==a.labourId}?.name?:"मजदूर हटाया गया";val field=if(a.fieldId.isBlank())"खेत नहीं चुना" else store.fields.firstOrNull{it.id==a.fieldId}?.name?:"खेत हटाया गया";val attendance=if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी / अनुपस्थित" else "${quantity(a.fraction)} दिन";add("${displayDate(a.date)} • खेत $field • $labour • $attendance • मजदूरी ₹${money(a.fraction*a.rate)}")}
                                    add("भुगतान का विवरण")
                                    selectedPayments.forEach{pay->val labour=store.labours.firstOrNull{it.id==pay.labourId}?.name?:"मजदूर हटाया गया";val field=if(pay.fieldId.isBlank())"खेत नहीं चुना" else store.fields.firstOrNull{it.id==pay.fieldId}?.name?:"खेत हटाया गया";add("${displayDate(pay.date)} • खेत $field • $labour • भुगतान ₹${money(pay.amount)}")}
                                    add("कुल हाजिरी: ${quantity(selectedAttendance.sumOf{it.fraction})} दिन")
                                    add("कुल मजदूरी: ₹${money(selectedAttendance.sumOf{it.fraction*it.rate})}")
                                    add("चुने रिकॉर्ड के भुगतान: ₹${money(selectedPayments.sumOf{it.amount})}")
                                }
                                exportDateFieldReportPdf(context,"तारीख_खेत_वार_रिपोर्ट_${System.currentTimeMillis()}","तारीख: ${if(currentMonthDefault)monthTitle(today().take(7)) else if(chosenDates.isEmpty())"सभी तारीखें" else chosenDates.sorted().joinToString(", "){displayDate(it)}} • खेत: ${if(allFields)"सभी खेत" else reportFields.filter{it.id in chosenFieldIds}.joinToString(", "){it.name}}",selectedAttendance,selectedPayments,store,aggregateWorkerView = chosenDates.isEmpty() && allFields,background=true)
                            }
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text("चुनी तारीख और खेत की PDF बनाएँ") }
                        OutlinedButton(onClick={
                            val selectedAttendance=matchingAttendance.sortedWith(compareBy<Attendance>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            val selectedPayments=matchingPayments.sortedWith(compareBy<Payment>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            if(selectedAttendance.isEmpty()&&selectedPayments.isEmpty()) validation="चुनी तारीख/खेत में कोई हाजिरी या भुगतान नहीं मिला।" else exportDateFieldReportCsv(context,"तारीख_खेत_वार_रिपोर्ट_${System.currentTimeMillis()}",selectedAttendance,selectedPayments,store)
                        },modifier=Modifier.fillMaxWidth()){Text("चुनी तारीख और खेत की CSV बनाएँ")}
                        if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                    } }
                }
            }
        }
        return
    }
    if(selectedLockMonth.isNotBlank()) {
        val month=selectedLockMonth
        val ma=store.attendances.filter{it.date.startsWith(month) && it.fraction>0.0}
        val mp=store.payments.filter{it.date.startsWith(month)}
        val monthRows=store.labours.mapNotNull{l->
            val a=ma.filter{it.labourId==l.id}; val pay=mp.filter{it.labourId==l.id}
            if(a.isEmpty()&&pay.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},pay.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedLockMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=AppAccentText); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",monthRows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान",monthRows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",monthRows.sumOf{it.wage-it.paid})} }
                    if(month !in store.lockedLabourMonths) Button(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                items(monthRows,key={it.labour.id}) { r ->
                    val days=ma.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    val checked = r.labour.id in selectedWorkers
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                            androidx.compose.material3.Checkbox(
                                checked = checked,
                                onCheckedChange = { value ->
                                    if (value) { if (r.labour.id !in selectedWorkers) selectedWorkers.add(r.labour.id) }
                                    else selectedWorkers.remove(r.labour.id)
                                }
                            )
                            Column(Modifier.weight(1f).padding(start=6.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                                Text(r.labour.name,fontWeight=FontWeight.Bold,color=AppAccentText,fontSize=16.sp)
                                Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                                Text("इस महीने भुगतान/अग्रिम ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=AppAccentText)
                            }
                        }
                    }
                }
                item {
                    val picked = monthRows.filter { it.labour.id in selectedWorkers }
                    val wage = picked.sumOf { it.wage }; val paid = picked.sumOf { it.paid }
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Text("PDF / फोटो रिपोर्ट के लिए मजदूर चुनें",fontWeight=FontWeight.Bold,color=AppAccentText)
                            Text("चुने गए ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",fontSize=12.sp,color=AppMuted)
                            ExportButtons(onPhoto={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportReportPhoto(context,"महीने_${month}_${System.currentTimeMillis()}","${monthTitle(month)} • चुने मजदूर ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",picked.map{"${it.labour.name} • काम ${quantity(it.workDays)} दिन • मजदूरी ₹${money(it.wage)} • भुगतान ₹${money(it.paid)} • बकाया ₹${money(it.wage-it.paid)}"})},onPdf={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportAllWorkersLedgerPdf(context,"${month}_chune_mazdoor",monthTitle(month),"सभी खेत",picked,wage,paid,background=true)})
                            if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                        }
                    }
                }
                if(monthRows.isEmpty()) item { Text("इस महीने कोई हिसाब दर्ज नहीं है।",color=AppMuted) }
            }
        }
        if(monthLockConfirm) AlertDialog(onDismissRequest={monthLockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "पुरानी जानकारी सुरक्षित रहेगी। अनलॉक करने पर इस महीने की हाजिरी में बदलाव किया जा सकेगा।" else "इस महीने का हिसाब सुरक्षित रहेगा। पुराना हिसाब देखने के लिए महीना हमेशा खुल सकेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);monthLockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={monthLockConfirm=false}){Text("रद्द करें")}})
        return
    }
    // Main entry for the joint report: show only month names and lock icons.
    // Tapping a month opens its full month ledger above; keep report filters off this landing screen.
    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("सभी मजदूरों का हिसाब", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Button(onClick={showCustomReport=true;selectedDates.clear();selectedFields.clear();allFields=true;validation=""},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Icon(Icons.Default.PictureAsPdf,null); Spacer(Modifier.width(8.dp)); Text("तारीख और खेत के अनुसार PDF रिपोर्ट") } }
            item { Text("महीने का हिसाब", fontWeight=FontWeight.ExtraBold, fontSize=20.sp, color=AppAccentText) }
            items(lockMonths, key={it}) { month ->
                Card(Modifier.fillMaxWidth().clickable { selectedLockMonth = month }, shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(containerColor=CardBg)) {
                    Row(Modifier.padding(horizontal=16.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(monthTitle(month), Modifier.weight(1f), fontWeight=FontWeight.Bold, fontSize=17.sp, color=AppAccentText)
                        Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen, contentDescription=null, tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                    }
                }
            }
            if(lockMonths.isEmpty()) item { Text("अभी कोई महीने का हिसाब नहीं है।", color=AppMuted) }
        }
    }
    return

}


@Composable private fun AttendanceFieldPickerScreen(store:Store,onSelect:(String)->Unit,onBack:()->Unit){
    var addField by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("हाजिरी के लिए खेत चुनें",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Button(onClick={addField=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("नया खेत जोड़ें")}}
            item{
                Card(Modifier.fillMaxWidth().clickable{onSelect("")},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Edit,null,tint=AppAccentText,modifier=Modifier.size(28.dp));Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){Text("खेत नहीं चुनना",fontWeight=FontWeight.Bold,color=AppAccentText);Text("खेत का नाम भरना वैकल्पिक है",fontSize=12.sp,color=AppMuted)}
                        Icon(Icons.Default.ChevronRight,null,tint=AppAccentText)
                    }
                }
            }
            items(store.fields,key={it.id}){f->
                val cropNames=store.crops.filter{it.fieldId==f.id}.joinToString(" • "){it.name}.ifBlank{"फसल नहीं जोड़ी गई"}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.fillMaxWidth().clickable{onSelect(f.id)}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Landscape,null,tint=Green,modifier=Modifier.size(34.dp));Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)){Text(f.name.ifBlank{"नाम रहित खेत"},fontSize=18.sp,fontWeight=FontWeight.Bold,color=AppAccentText);Text("${f.area.ifBlank{"रकबा नहीं दिया"}} • $cropNames",fontSize=12.sp,color=AppMuted)}
                        Icon(Icons.Default.ChevronRight,null,tint=Green)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),horizontalArrangement=Arrangement.End){
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,null);Text("ऊपर")}
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,null);Text("नीचे")}
                    }
                }
            }
            if(store.fields.isEmpty()) item{Text("अभी कोई खेत नहीं है। पहले नया खेत जोड़ें।",color=AppMuted)}
        }
    }
    if(addField) FieldDialog(store,null){addField=false}
}

@Composable
private fun Dashboard(store:Store,onGo:(String)->Unit){
    val date=today()
    val todayAttendances=store.attendances.filter{it.date==date}
    val wage=todayAttendances.sumOf{it.fraction*it.rate}
    val exp=store.expenses.filter{it.date==date}.sumOf{it.amount}
    val sale=store.sales.filter{it.date==date}.sumOf{it.total}
    val paidToday=store.payments.filter{it.date==date}.sumOf{it.amount}
    val totalOutstanding=store.labours.sumOf{maxOf(0.0,store.outstandingBalance(it.id))}
    val present=todayAttendances.count{it.fraction>0.0}
    val fields=store.fields.size
    val crops=store.crops.size
    val workers=store.labours.count{it.active}
    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=14.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(2.dp)) {
                Box(Modifier.fillMaxWidth().heightIn(min=150.dp)) {
                    Image(painterResource(R.drawable.dashboard_hero),null,Modifier.matchParentSize().clip(RoundedCornerShape(24.dp)),contentScale=ContentScale.Crop)
                    Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color(0x22000000),GreenDark.copy(alpha=.96f)))))
                    Column(Modifier.align(Alignment.BottomStart).padding(20.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                        Text("MAJDOOR HISAAB PRO",color=Color(0xFFBFE9D3),fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.2.sp)
                        Text("आपके खेत का पूरा हिसाब",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold)
                        Text("मजदूर • हाजिरी • खर्च • बिक्री • गन्ना",color=Color.White.copy(alpha=.92f),fontSize=12.sp)
                    }
                }
            }
        }
        if(store.dataWarning.isNotBlank()) item {
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFFFF0D6))){
                Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.Top){
                    Icon(Icons.Default.Warning,null,tint=Color(0xFF8A4B00));Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)){Text("डेटा recovery चेतावनी",fontWeight=FontWeight.Bold,color=Color(0xFF8A4B00));Text(store.dataWarning,fontSize=12.sp,color=Color(0xFF65400A))}
                }
            }
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("आज का सार",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                    Text(displayDate(date),fontSize=12.sp,color=Color(0xFF65736B))
                }
                Surface(shape=RoundedCornerShape(30.dp),color=Color(0xFFE3F4EA)) {
                    Row(Modifier.padding(horizontal=11.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle,null,tint=Green,modifier=Modifier.size(15.dp));Spacer(Modifier.width(5.dp))
                        Text("स्थानीय डेटा",fontSize=11.sp,color=AppAccentText,fontWeight=FontWeight.SemiBold)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                DashboardStat("₹","मजदूरी",wage,"$present हाजिरी",Color(0xFFE6F0FF),Modifier.weight(1f)){onGo("labour")}
                DashboardStat("−","खर्च",exp,"आज दर्ज",Color(0xFFFFF0DE),Modifier.weight(1f)){onGo("expense")}
                DashboardStat("+","बिक्री",sale,"आज दर्ज",Color(0xFFE4F5E9),Modifier.weight(1f)){onGo("sale")}
            }
        }
        item {
            SummaryMoneyCard("आज का भुगतान/अग्रिम", "₹${money(paidToday)}", Color(0xFF276B8A), Modifier.fillMaxWidth())
        }
        item {
            SummaryMoneyCard("सभी मजदूरों का कुल बकाया", "₹${money(totalOutstanding)}", Color(0xFF8A4B00), Modifier.fillMaxWidth())
        }
        item {
            Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE3F4EA)),contentAlignment=Alignment.Center) { Icon(Icons.Default.HowToReg,null,tint=AppAccentText,modifier=Modifier.size(24.dp)) }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("आज की हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=AppAccentText)
                            Text("खेत चुनें और मजदूरों का हिसाब दर्ज करें",fontSize=11.sp,color=Color(0xFF65736B))
                        }
                    }
                    Button(onClick={onGo("daily_labour")},modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) {
                        Icon(Icons.Default.Fingerprint,null);Spacer(Modifier.width(8.dp));Text("हाजिरी लगाएँ",fontWeight=FontWeight.Bold)
                    }
                    OutlinedButton(onClick={onGo("attendance_history")},modifier=Modifier.fillMaxWidth().heightIn(min=48.dp),shape=RoundedCornerShape(15.dp)) {
                        Icon(Icons.Default.History,null);Spacer(Modifier.width(8.dp));Text("पुरानी हाजिरी और हिसाब देखें")
                    }
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    Text("त्वरित काम",fontSize=17.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={onGo("labour")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.Groups,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(5.dp));Text("मजदूर",maxLines=1)
                        }
                        OutlinedButton(onClick={onGo("daily_labour")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.CalendarMonth,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(5.dp));Text("हाजिरी",maxLines=1)
                        }
                        OutlinedButton(onClick={onGo("backup")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(13.dp)) {
                            Icon(Icons.Default.CloudUpload,null,modifier=Modifier.size(18.dp));Spacer(Modifier.width(5.dp));Text("बैकअप",maxLines=1)
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("मुख्य मॉड्यूल",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText,modifier=Modifier.weight(1f))
                Text("$workers मजदूर • $fields खेत • $crops फसल",fontSize=11.sp,color=AppMuted)
            }
        }
        item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            DashboardModule("👷","मजदूर","सूची और हिसाब","$workers पंजीकृत मजदूर",Color(0xFFE5EEFF),Modifier.weight(1f)){onGo("labour")}
            DashboardModule("🌾","खेत","खेत प्रबंधन","$fields पंजीकृत खेत",Color(0xFFE3F4E8),Modifier.weight(1f)){onGo("field")}
        } }
        item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            DashboardModule("💰","खर्च","खेती की लागत","खाद • बीज • दवा",Color(0xFFFFF0DE),Modifier.weight(1f)){onGo("expense")}
            DashboardModule("🧺","बिक्री","उपज और आमदनी","बिक्री रिकॉर्ड",Color(0xFFFFE9E5),Modifier.weight(1f)){onGo("sale")}
        } }
        item { DashboardModule("🌱","फसल प्रबंधन","बुवाई से कटाई तक","फसल • तारीख • खेत",Color(0xFFEDE7FF),Modifier.fillMaxWidth()){onGo("crop")} }
        item { DashboardModule("🌿","गन्ना छिलाई","दैनिक फांदी और मजदूरी हिसाब","रेट • भुगतान • बाकी",Color(0xFFE2F5E9),Modifier.fillMaxWidth()){onGo("cane_peeling")} }
        item { DashboardModule("🚜","गन्ना पर्ची","पर्ची, तौल और फोटो रिकॉर्ड","पर्ची • वजन • भाव",Color(0xFFE4F1F8),Modifier.fillMaxWidth()){onGo("cane")} }
        item {
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Text("हाल के भुगतान/अग्रिम",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText,modifier=Modifier.weight(1f));TextButton(onClick={onGo("payments")}){Text("सभी देखें")} }
                    val recentPayments=store.payments.sortedWith(compareByDescending<Payment>{it.date}.thenByDescending{it.id}).take(3)
                    if(recentPayments.isEmpty()) Text("अभी कोई भुगतान दर्ज नहीं है।",fontSize=12.sp,color=AppMuted)
                    recentPayments.forEach{payment->
                        val worker=store.labours.firstOrNull{it.id==payment.labourId}?.name ?: "मजदूर रिकॉर्ड उपलब्ध नहीं"
                        Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(worker,fontWeight=FontWeight.SemiBold);Text("${displayDate(payment.date)} • ${if(payment.kind=="advance")"अग्रिम" else "भुगतान"}",fontSize=11.sp,color=AppMuted)};Text("₹${money(payment.amount)}",fontWeight=FontWeight.Bold,color=AppAccentText)}
                    }
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Text("हाल की हाजिरी / काम",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText,modifier=Modifier.weight(1f));TextButton(onClick={onGo("attendance_history")}){Text("सभी देखें")} }
                    val recentAttendance=store.attendances.filter{it.fraction>0.0}.sortedWith(compareByDescending<Attendance>{it.date}.thenByDescending{it.id}).take(3)
                    if(recentAttendance.isEmpty()) Text("अभी कोई हाजिरी दर्ज नहीं है।",fontSize=12.sp,color=AppMuted)
                    recentAttendance.forEach{attendance->
                        val worker=store.labours.firstOrNull{it.id==attendance.labourId}?.name ?: "मजदूर रिकॉर्ड उपलब्ध नहीं"
                        val field=store.fields.firstOrNull{it.id==attendance.fieldId}?.name ?: "खेत"
                        Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(worker,fontWeight=FontWeight.SemiBold);Text("${displayDate(attendance.date)} • $field • ${if(attendance.fraction==0.0)"अनुपस्थित" else if(attendance.fraction==0.5)"आधा दिन" else "${quantity(attendance.fraction)} दिन"}",fontSize=11.sp,color=AppMuted)};Text("₹${money(attendance.fraction*attendance.rate)}",fontWeight=FontWeight.Bold,color=AppAccentText)}
                    }
                }
            }
        }
        item {
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)) {
                Row(Modifier.fillMaxWidth().clickable{onGo("backup")}.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudUpload,null,tint=AppAccentText,modifier=Modifier.size(26.dp));Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) { Text("बैकअप और डेटा सुरक्षा",fontWeight=FontWeight.Bold,color=AppAccentText);Text("फोन बैकअप या Google Drive",fontSize=11.sp,color=AppMuted) }
                    Icon(Icons.Default.ChevronRight,null,tint=AppAccentText)
                }
            }
        }
    }
}

@Composable private fun DashboardStat(icon:String,label:String,value:Double,sub:String,bgColor:Color,modifier:Modifier=Modifier,onClick:()->Unit={}){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(icon,fontSize=21.sp);Text(label,fontSize=11.sp,color=AppAccentText);Text("₹${money(value)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold);Text(sub,fontSize=9.sp,color=AppMuted,maxLines=1)}}}

@Composable private fun DashboardModule(icon:String,title:String,subtitle:String,detail:String,bgColor:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.fillMaxWidth().padding(13.dp).heightIn(min=125.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.62f)),contentAlignment=Alignment.Center){Text(icon,fontSize=27.sp)};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=19.sp,fontWeight=FontWeight.ExtraBold,color=Color(0xFF1F2924));Text(subtitle,fontSize=10.sp,color=Color(0xFF4F5E56))};Icon(Icons.Default.ChevronRight,null,tint=Color(0xFF0B6B4A))};Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.72f)){Text(detail,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=9.sp,fontWeight=FontWeight.SemiBold,color=Color(0xFF064C36),maxLines=1)}}}}

@Composable
private fun SummaryMoneyCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.heightIn(min = 82.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontSize = 10.sp, color = AppMuted, maxLines = 1)
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = accent, maxLines = 1)
        }
    }
}

@Composable private fun Stat(label:String,value:Double){
    val icon=when(label){"मजदूरी","Labour"->"👷";"खर्च","लागत","खेती खर्च"->"💰";"बिक्री","Sale"->"🧺";"भुगतान","भुगतान/अग्रिम","अग्रिम"->"💵";"बाकी"->"📌";"लाभ"->"📈";"कुल काम","कुल दिन","पूरा दिन","आधा दिन","मजदूर","कुल मजदूर","कुल खेत","कुल रिकॉर्ड","रिकॉर्ड","फांदी","कुल फांदी"->"📊";else->"📊"}
    val unit=when(label){"कुल काम","कुल दिन","पूरा दिन","आधा दिन"->" दिन";"मजदूर","कुल मजदूर"->" मजदूर";"कुल खेत"->" खेत";"कुल रिकॉर्ड","रिकॉर्ड"->" रिकॉर्ड";"फांदी","कुल फांदी"->" फांदी";else->null}
    val display=if(unit!=null) "${quantity(value)}$unit" else "₹${money(value)}"
    Card(Modifier.fillMaxWidth().heightIn(min=78.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=11.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=15.sp);Spacer(Modifier.width(5.dp));Text(label,fontSize=11.sp,color=AppMuted,maxLines=1)}
            Text(display,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}
private fun money(v:Double)=String.format(Locale.US,"%.0f",v)
private fun quantity(v:Double)=String.format(Locale.US,"%.2f",v).trimEnd('0').trimEnd('.')
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
private fun validMonthKey(value:String):Boolean = Regex("\\d{4}-(0[1-9]|1[0-2])").matches(value) && (value.take(4).toIntOrNull() ?: 0)>0

private fun validDate(v:String):Boolean{
    val value=v.trim()
    if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false
    return try{
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        f.isLenient=false
        val parsed=f.parse(value) ?: return false
        f.format(parsed)==value
    }catch(_:Exception){false}
}
private fun monthTitle(value:String):String{
    return try{
        val f=SimpleDateFormat("yyyy-MM",Locale.US).apply{isLenient=false}
        val d=f.parse(value) ?: return value
        SimpleDateFormat("MMMM yyyy",Locale("hi","IN")).format(d)
    }catch(_:Exception){value}
}
private fun displayDate(v:String):String{
    val value=v.trim()
    if(!validDate(value)) return value
    return try{
        val input=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
        val output=SimpleDateFormat("dd/MM/yyyy",Locale.US)
        output.format(input.parse(value)!!)
    }catch(_:Exception){value}
}

@Composable
private fun PhotoThumb(path:String,modifier:Modifier=Modifier.size(52.dp)){
    val bitmap=remember(path){if(path.isNotBlank()) runCatching{BitmapFactory.decodeFile(path)?.asImageBitmap()}.getOrNull() else null}
    if(bitmap!=null){
        Image(bitmap=bitmap,contentDescription=null,modifier=modifier.clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)
    }else{
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=22.sp)}
    }
}

@Composable
private fun PaymentHistoryScreen(store:Store,onWorker:(String)->Unit){
    var query by rememberSaveable{mutableStateOf("")}
    val payments=remember(store.payments,store.labours,query){
        store.payments.sortedWith(compareByDescending<Payment>{it.date}.thenByDescending{it.id}).filter{p->
            val worker=store.labours.firstOrNull{it.id==p.labourId}
            query.isBlank() || worker?.name.orEmpty().contains(query.trim(),ignoreCase=true) || p.date.contains(query.trim()) || money(p.amount).contains(query.trim()) || (if(p.kind=="advance")"अग्रिम" else "भुगतान").contains(query.trim(),ignoreCase=true)
        }
    }
    Column(Modifier.fillMaxSize().background(Bg)){
        LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            item{
                OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp),leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text("मजदूर, तारीख, रकम या प्रकार खोजें")})
                Spacer(Modifier.height(6.dp))
                Text("कुल रिकॉर्ड: ${payments.size} • कुल भुगतान/अग्रिम: ₹${money(payments.sumOf{it.amount})}",fontSize=12.sp,fontWeight=FontWeight.Bold,color=AppAccentText)
            }
            items(payments,key={it.id}){payment->
                val worker=store.labours.firstOrNull{it.id==payment.labourId}
                val field=store.fields.firstOrNull{it.id==payment.fieldId}
                val crop=store.crops.firstOrNull{it.id==payment.cropId}
                val fieldName=field?.name ?: if(payment.fieldId.isBlank())"खेत नहीं चुना" else "खेत हटाया गया"
                val cropName=crop?.name?.let{" • $it"}.orEmpty()
                Card(Modifier.fillMaxWidth().clickable{if(worker!=null)onWorker(worker.id)},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE3F4EA)),contentAlignment=Alignment.Center){Icon(Icons.Default.Payments,null,tint=Green)}
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                            Text(worker?.name?:"मजदूर रिकॉर्ड उपलब्ध नहीं",fontWeight=FontWeight.Bold,color=AppAccentText)
                            Text("${displayDate(payment.date)} • $fieldName$cropName",fontSize=11.sp,color=AppMuted)
                            Text(if(payment.kind=="advance")"अग्रिम" else "भुगतान",fontSize=11.sp,fontWeight=FontWeight.Bold,color=if(payment.kind=="advance")AppAccentText else Green)
                            if(worker?.active==false) Text("निष्क्रिय मजदूर • पुराना हिसाब सुरक्षित",fontSize=10.sp,color=AppMuted)
                        }
                        Text("₹${money(payment.amount)}",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                    }
                }
            }
            if(payments.isEmpty()) item{Text(if(query.isBlank())"अभी कोई भुगतान दर्ज नहीं है।" else "इस खोज से कोई भुगतान नहीं मिला।",color=AppMuted)}
        }
    }
}


@Composable
private fun LabourScreen(store:Store,onOpen:(String)->Unit,onAttendance:()->Unit){
    var edit by remember{mutableStateOf<Labour?>(null)}
    var delete by remember{mutableStateOf<Labour?>(null)}
    var protectedEdit by remember{mutableStateOf<Labour?>(null)}
    var protectedDelete by remember{mutableStateOf<Labour?>(null)}
    var query by remember{mutableStateOf("")}
    var showInactive by rememberSaveable{mutableStateOf(false)}
    var protectedToggleActive by remember{mutableStateOf<Labour?>(null)}
    val filtered=remember(store.labours,query,showInactive){store.labours.asReversed().filter{(showInactive || it.active) && (it.name.contains(query.trim(),ignoreCase=true)||it.mobile.contains(query.trim(),ignoreCase=true)||it.address.contains(query.trim(),ignoreCase=true))}}
    val deleteContext=LocalContext.current
    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)) { Text("मजदूर",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText);Text("नाम, दिहाड़ी और पुराना हिसाब",fontSize=12.sp,color=Color(0xFF65736B)) }
            FilledTonalButton(onClick={edit=Labour("","","",0.0,"","")},shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("नया मजदूर")}
        }
        Spacer(Modifier.height(12.dp))
        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
            Column(Modifier.fillMaxWidth().padding(12.dp)){
                OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,shape=RoundedCornerShape(14.dp),leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text("मजदूर का नाम, मोबाइल या पता खोजें")})
                Spacer(Modifier.height(7.dp))
                FilterChip(selected=showInactive,onClick={showInactive=!showInactive},label={Text(if(showInactive)"निष्क्रिय मजदूर भी दिख रहे हैं" else "निष्क्रिय मजदूर दिखाएँ")})
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("सक्रिय मजदूर: ${store.labours.count{it.active}}",fontSize=12.sp,fontWeight=FontWeight.Bold,color=AppAccentText,modifier=Modifier.weight(1f));Text("दिख रहे: ${filtered.size}",fontSize=11.sp,color=AppMuted)}
                Spacer(Modifier.height(8.dp))
                Button(onClick=onAttendance,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.CalendarMonth,null);Spacer(Modifier.width(7.dp));Text("हाजिरी / तारीख चुनें")}
            }
        }
        Spacer(Modifier.height(12.dp))
        if(filtered.isEmpty()){
            Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)){Icon(Icons.Default.Groups,null,tint=Color(0xFF91A69A),modifier=Modifier.size(48.dp));Text(if(query.isBlank())"अभी कोई मजदूर नहीं जोड़ा गया" else "इस खोज से कोई मजदूर नहीं मिला",fontWeight=FontWeight.Bold,color=AppAccentText);Text(if(query.isBlank())"‘नया मजदूर’ दबाकर पहला रिकॉर्ड बनाएँ।" else "नाम या मोबाइल के कुछ दूसरे अक्षर आज़माएँ।",fontSize=12.sp,color=AppMuted);if(query.isNotBlank()) TextButton(onClick={query=""}){Text("खोज साफ़ करें")}}}
        }else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(9.dp)){
            items(filtered,key={it.id}){l->
                Card(Modifier.fillMaxWidth().clickable{onOpen(l.id)},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                    Row(Modifier.fillMaxWidth().padding(start=12.dp,end=5.dp,top=11.dp,bottom=11.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo,Modifier.size(52.dp))
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=15.sp,color=AppAccentText,maxLines=1)
                            if(!l.active) Text("निष्क्रिय मजदूर • पुराना हिसाब सुरक्षित",fontSize=11.sp,color=AppMuted)
                            Text("₹${money(store.rateFor(l.id,today()))} / दिन",fontSize=12.sp,fontWeight=FontWeight.SemiBold,color=AppMuted)
                            if(l.mobile.isNotBlank()) Text(l.mobile,fontSize=11.sp,color=AppMuted,maxLines=1)
                        }
                        IconButton(onClick={protectedToggleActive=l}){Icon(if(l.active)Icons.Default.Pause else Icons.Default.PlayArrow,contentDescription=if(l.active)"मजदूर निष्क्रिय करें" else "मजदूर फिर सक्रिय करें",tint=if(l.active)AppMuted else Green)}
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=AppAccentText)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.DeleteOutline,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(edit!=null) LabourDialog(store,edit!!.takeIf{it.id.isNotBlank()}){edit=null}
    protectedEdit?.let{item->DeviceCredentialGate("मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedToggleActive?.let{item->DeviceCredentialGate(if(item.active)"मजदूर निष्क्रिय करें" else "मजदूर फिर सक्रिय करें",if(item.active)"मजदूर की नई हाजिरी बंद होगी; पुराना हिसाब सुरक्षित रहेगा।" else "मजदूर फिर से हाजिरी सूची में दिखाई देगा।",{val ok=store.setLabourActive(item.id,!item.active);protectedToggleActive=null;if(!ok)android.widget.Toast.makeText(deleteContext,"मजदूर की स्थिति बदली नहीं जा सकी।",android.widget.Toast.LENGTH_LONG).show()},{protectedToggleActive=null})}
    protectedDelete?.let{item->DeviceCredentialGate("मजदूर हटाएँ","मजदूर की जानकारी हटाने के लिए Android screen lock से पुष्टि करें।",{delete=item;protectedDelete=null},{protectedDelete=null})}
    if(delete!=null) ConfirmDialog("मजदूर हटाएँ?","यदि इस मजदूर की हाजिरी, भुगतान, दिहाड़ी इतिहास या फांडी रिकॉर्ड है, तो रिकॉर्ड सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteLabour(delete!!.id);delete=null;if(!ok)android.widget.Toast.makeText(deleteContext,"इस मजदूर का पुराना हिसाब मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{delete=null})
}
@Composable private fun LabourDialog(store:Store,existing:Labour?,onClose:()->Unit){
    var name by remember{mutableStateOf(existing?.name?:"")}
    var address by remember{mutableStateOf(existing?.address?:"")}
    var rate by remember{mutableStateOf(if(existing==null||existing.rate==0.0)"" else money(existing.rate))}
    var mobile by remember{mutableStateOf(existing?.mobile?:"")}
    var photo by remember{mutableStateOf(existing?.photo?:"")}
    var error by remember{mutableStateOf("")}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank()) photo=persisted}
    }
    SimpleDialog(if(existing==null)"मजदूर जोड़ें" else "मजदूर बदलें",onClose){
        OutlinedTextField(value=name,onValueChange={name=it;error=""},label={Text("मजदूर का नाम *")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true)
        OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("रुपये/दिन (Optional)")},singleLine=true)
        OutlinedTextField(value=mobile,onValueChange={mobile=it},label={Text("मोबाइल (Optional)")},singleLine=true)
        OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")}
        Button(onClick={
            when {
                name.isBlank()->error="मजदूर का नाम लिखना जरूरी है।"
                store.labourNameExists(name,existing?.id)->error="इस नाम का मजदूर पहले से मौजूद है। नाम में फर्क करके ही सेव करें।"
                else->{
                    val x=Labour(ownerId,name.trim().replace(Regex("\\s+")," "),address,rate.toDoubleOrNull()?:0.0,mobile,photo,existing?.active ?: true)
                    val saved=if(existing==null)store.addLabour(x) else store.updateLabour(x)
                    if(saved) onClose() else error="मजदूर सेव नहीं हुआ। नाम जाँचें।"
                }
            }
        },modifier=Modifier.fillMaxWidth()){Text("मजदूर सेव करें")}
    }
}

@Composable
private fun FieldScreen(store:Store,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Field?>(null)}
    var del by remember{mutableStateOf<Field?>(null)}
    var protectedEdit by remember{mutableStateOf<Field?>(null)}
    var protectedDelete by remember{mutableStateOf<Field?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌾 Field","खेतों की सूची") {add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.fields,key={it.id}){f->
                Card(Modifier.fillMaxWidth().clickable{onOpen(f.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(f.photo);Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(f.name.ifBlank{"खेत का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=17.sp)
                            Text(listOf(f.area.ifBlank{"रकबा नहीं दिया"},f.address).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=AppMuted)
                        }
                        Column(horizontalAlignment=Alignment.CenterHorizontally){
                            IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,null,tint=Green)}
                            IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,null,tint=Green)}
                        }
                        IconButton(onClick={protectedEdit=f}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=f}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FieldDialog(store,null){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("खेत बदलें","खेत की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खेत हटाएँ","खेत और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FieldDialog(store,edit!!){edit=null}
    val fieldContext=LocalContext.current
    if(del!=null)ConfirmDialog("खेत हटाएँ?","यदि इस खेत से फसल, खर्च, बिक्री, हाजिरी, भुगतान या फांडी रिकॉर्ड जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteField(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(fieldContext,"इस खेत का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun FieldDialog(store:Store,existing:Field?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var addr by remember{mutableStateOf(existing?.address?:"")};var area by remember{mutableStateOf(existing?.area?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};var error by remember{mutableStateOf("")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"खेत जोड़ें" else "खेत बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it;error=""},label={Text("खेत का नाम")},singleLine=true);OutlinedTextField(value=addr,onValueChange={addr=it},label={Text("पता/स्थान (Optional)")},singleLine=true);OutlinedTextField(value=area,onValueChange={area=it},label={Text("रकबा (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"खेत की फोटो (Optional)" else "✓ फोटो चुनी गई")};if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val x=Field(ownerId,name,addr,area,photo);val saved=if(existing==null)store.addField(x) else store.updateField(x);if(saved)onClose() else error="खेत का नाम जरूरी है और नाम/ID दोहराया नहीं जा सकता।"},modifier=Modifier.fillMaxWidth()){Text("सेव करें")}}}

@Composable
private fun CropScreen(store:Store,preField:String?,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Crop?>(null)}
    var del by remember{mutableStateOf<Crop?>(null)}
    var protectedEdit by remember{mutableStateOf<Crop?>(null)}
    var protectedDelete by remember{mutableStateOf<Crop?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌱 Crop","फसल सूची"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.crops,key={it.id}){c->
                val f=store.fields.firstOrNull{it.id==c.fieldId}
                Card(Modifier.fillMaxWidth().clickable{onOpen(c.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(c.name.ifBlank{"फसल का नाम नहीं दिया"},fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${c.season}",fontSize=12.sp,color=AppMuted)
                        }
                        IconButton(onClick={protectedEdit=c}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=c}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)CropDialog(store,null,preField){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("फसल बदलें","फसल की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("फसल हटाएँ","फसल और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)CropDialog(store,edit!!,null){edit=null}
    val cropContext=LocalContext.current
    if(del!=null)ConfirmDialog("फसल हटाएँ?","यदि इस फसल से खर्च, बिक्री, हाजिरी या भुगतान जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteCrop(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(cropContext,"इस फसल का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun CropDialog(store:Store,existing:Crop?,preField:String?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var field by remember{mutableStateOf(existing?.fieldId?:preField?:store.fields.firstOrNull()?.id?:"")};var variety by remember{mutableStateOf(existing?.variety?:"")};var sow by remember{mutableStateOf(existing?.sowingDate?:"")};var season by remember{mutableStateOf(existing?.season?:SimpleDateFormat("yyyy",Locale.US).format(Date()))};var error by remember{mutableStateOf("")};SimpleDialog(if(existing==null)"फसल जोड़ें" else "फसल बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("फसल का नाम")},singleLine=true);ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it};OutlinedTextField(value=variety,onValueChange={variety=it},label={Text("किस्म (Optional)")},singleLine=true);OutlinedTextField(value=sow,onValueChange={sow=it},label={Text("बुवाई तारीख YYYY-MM-DD (Optional)")},singleLine=true);OutlinedTextField(value=season,onValueChange={season=it},label={Text("Season")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={when{ name.isBlank()->error="फसल का नाम डालें"; field.isBlank()->error="खेत चुनें"; !sow.isBlank()&&!validDate(sow)->error="सही बुवाई तारीख डालें: YYYY-MM-DD"; else->{val x=Crop(existing?.id?:UUID.randomUUID().toString(),field,name,variety,sow,season.trim());val saved=if(existing==null)store.addCrop(x) else store.updateCrop(x);if(saved){error="";onClose()}else error="इस खेत/सीजन में फसल पहले से है, विवरण गलत है, या पुराना रिकॉर्ड जुड़ा होने से खेत बदलना सुरक्षित नहीं है।"}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun ExpenseScreen(store:Store,preField:String?,preCrop:String?,onSaved:()->Unit){
    var edit by remember{mutableStateOf<Expense?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Expense?>(null)}
    var protectedEdit by remember{mutableStateOf<Expense?>(null)}
    var protectedDelete by remember{mutableStateOf<Expense?>(null)}
    val list=store.expenses.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("💰 Kharch","खेती का खर्च"){add=true}
        if(preField==null&&preCrop==null)Text("सभी खर्च",fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){e->
                val f=store.fields.firstOrNull{it.id==e.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(e.type+if(e.item.isNotBlank())" • ${e.item}" else "",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(e.date)}",fontSize=12.sp,color=AppMuted)
                            Text("₹${money(e.amount)}",fontWeight=FontWeight.Bold)
                        }
                        IconButton(onClick={protectedEdit=e}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=e}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)ExpenseDialog(store,edit?:Expense(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),"बीज","","","",0.0,today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("खर्च बदलें","खर्च की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खर्च हटाएँ","खर्च रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)ExpenseDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("खर्च हटाएँ?","यह खर्च रिकॉर्ड हट जाएगा.",{store.deleteExpense(del!!.id);del=null},{del=null})
}
@Composable private fun ExpenseDialog(store:Store,existing:Expense,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var type by remember{mutableStateOf(existing.type)};var item by remember{mutableStateOf(existing.item)};var qty by remember{mutableStateOf(existing.qty)};var unit by remember{mutableStateOf(existing.unit)};var amount by remember{mutableStateOf(if(existing.amount==0.0)"" else money(existing.amount))};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"खर्च बदलें" else "खर्च जोड़ें",onClose){ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनना (वैकल्पिक)")+store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल (वैकल्पिक)",listOf("" to "फसल नहीं चुनना (वैकल्पिक)")+crops.map{it.id to it.name},crop){crop=it};ChoiceField("खर्च का प्रकार",listOf("बीज" to "बीज","उर्वरक/खाद" to "उर्वरक/खाद","दवा/कीटनाशक" to "दवा/कीटनाशक","डीजल" to "डीजल","सिंचाई" to "सिंचाई","ट्रैक्टर/मशीन" to "ट्रैक्टर/मशीन","ढुलाई" to "ढुलाई","अन्य" to "अन्य"),type){type=it};OutlinedTextField(value=item,onValueChange={item=it},label={Text("नाम (Optional)")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value=qty,onValueChange={qty=it},modifier=Modifier.weight(1f),label={Text("मात्रा (Optional)")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},modifier=Modifier.weight(1f),label={Text("इकाई (Optional)")},singleLine=true)};OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("रकम")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=amount.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही रकम दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,type=type,item=item,qty=qty,unit=unit,amount=n,date=date.trim());val saved=if(isEdit)store.updateExpense(x) else store.addExpense(x);if(saved)onClose() else error="खर्च सेव नहीं हुआ। रिकॉर्ड/खेत/फसल जाँचें और दोबारा कोशिश करें।"}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun SaleScreen(store:Store,preField:String?,preCrop:String?){
    var edit by remember{mutableStateOf<Sale?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Sale?>(null)}
    var protectedEdit by remember{mutableStateOf<Sale?>(null)}
    var protectedDelete by remember{mutableStateOf<Sale?>(null)}
    val list=store.sales.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🧺 Sale","बिक्री"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){s->
                val f=store.fields.firstOrNull{it.id==s.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("${s.qty} ${s.unit} × ₹${money(s.rate)}",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(s.date)}",fontSize=12.sp)
                            Text("₹${money(s.total)}",fontWeight=FontWeight.Bold,color=Green)
                        }
                        IconButton(onClick={protectedEdit=s}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=s}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)SaleDialog(store,edit?:Sale(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),0.0,"क्विंटल",0.0,0.0,"",today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("बिक्री बदलें","बिक्री की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("बिक्री हटाएँ","बिक्री रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)SaleDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("बिक्री हटाएँ?","यह बिक्री रिकॉर्ड हट जाएगा.",{store.deleteSale(del!!.id);del=null},{del=null})
}
@Composable private fun SaleDialog(store:Store,existing:Sale,onClose:()->Unit,isEdit:Boolean){
    var field by remember{mutableStateOf(existing.fieldId)}
    var crop by remember{mutableStateOf(existing.cropId)}
    var qty by remember{mutableStateOf(if(existing.qty==0.0)"" else quantity(existing.qty))}
    var unit by remember{mutableStateOf(existing.unit)}
    var rate by remember{mutableStateOf(if(existing.rate==0.0)"" else quantity(existing.rate))}
    var buyer by remember{mutableStateOf(existing.buyer)}
    var date by remember{mutableStateOf(existing.date)}
    var error by remember{mutableStateOf("")}
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""}
    val q=qty.toDoubleOrNull(); val r=rate.toDoubleOrNull()
    val total=(q?:0.0)*(r?:0.0)
    fun saveSale(){
        when {
            q==null||q<=0||!q.isFinite()->error="सही मात्रा दर्ज करें"
            unit.isBlank()->error="इकाई दर्ज करें"
            r==null||r<=0||!r.isFinite()->error="सही दर दर्ज करें"
            !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
            else->{
                val x=existing.copy(fieldId=field,cropId=crop,qty=q,unit=unit.trim(),rate=r,total=q*r,buyer=buyer.trim(),date=date.trim())
                runCatching { if(isEdit) store.updateSale(x) else store.addSale(x) }
                    .onSuccess { saved->if(saved){error="";onClose()}else error="बिक्री सेव नहीं हुई। रिकॉर्ड/खेत/फसल जाँचें और दोबारा कोशिश करें।" }
                    .onFailure { error="बिक्री सेव नहीं हुई: ${it.message?:"दोबारा कोशिश करें"}" }
            }
        }
    }
    AlertDialog(
        onDismissRequest={},
        title={Text(if(isEdit)"बिक्री बदलें" else "बिक्री जोड़ें",fontWeight=FontWeight.Bold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
            ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनना (वैकल्पिक)")+store.fields.map{it.id to it.name},field){field=it;crop=""}
            ChoiceField("फसल (वैकल्पिक)",listOf("" to "फसल नहीं चुनना (वैकल्पिक)")+crops.map{it.id to it.name},crop){crop=it}
            OutlinedTextField(value=qty,onValueChange={qty=it},label={Text("मात्रा")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=unit,onValueChange={unit=it},label={Text("इकाई (क्विंटल/किलो/टन आदि)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("दर प्रति इकाई (₹)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=buyer,onValueChange={buyer=it},label={Text("खरीदार (वैकल्पिक)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Text("कुल रकम: ₹${money(total)}",fontWeight=FontWeight.Bold,color=AppAccentText)
            if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        }},
        confirmButton={Button(onClick={saveSale()},modifier=Modifier.fillMaxWidth()){Text(if(isEdit)"बिक्री सेव करें" else "बिक्री सेव करें",fontWeight=FontWeight.Bold)}},
        dismissButton={TextButton(onClick=onClose){Text("रद्द करें")}}
    )
}

@Composable
private fun DeviceCredentialGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
){
    val context=LocalContext.current
    val hostActivity=context as? FragmentActivity
    var noLock by remember{mutableStateOf(false)}
    var launchFailed by remember{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        if(result.resultCode==Activity.RESULT_OK) onUnlocked() else onCancel()
    }
    LaunchedEffect(Unit){
        val km=context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(!km.isKeyguardSecure){
            noLock=true
        }else{
            val credentialIntent=runCatching{km.createConfirmDeviceCredentialIntent(title,message)}.getOrNull()
            fun fallbackToDeviceCredential(){
                if(credentialIntent!=null) runCatching{launcher.launch(credentialIntent)}.onFailure{launchFailed=true}
                else launchFailed=true
            }
            if(android.os.Build.VERSION.SDK_INT>=30 && hostActivity!=null){
                val authenticators=BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                val canAuthenticate=runCatching{BiometricManager.from(context).canAuthenticate(authenticators)}.getOrDefault(BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE)
                if(canAuthenticate==BiometricManager.BIOMETRIC_SUCCESS){
                    runCatching{
                        val prompt=BiometricPrompt(hostActivity,ContextCompat.getMainExecutor(context),object:BiometricPrompt.AuthenticationCallback(){
                            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){onUnlocked()}
                            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){
                                if(errorCode==BiometricPrompt.ERROR_USER_CANCELED || errorCode==BiometricPrompt.ERROR_CANCELED) onCancel()
                                else fallbackToDeviceCredential()
                            }
                        })
                        val info=BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle(message).setAllowedAuthenticators(authenticators).build()
                        prompt.authenticate(info)
                    }.onFailure{fallbackToDeviceCredential()}
                }else fallbackToDeviceCredential()
            }else fallbackToDeviceCredential()
        }
    }
    if(noLock){
        AlertDialog(
            onDismissRequest=onCancel,
            title={Text("Android Screen Lock जरूरी है")},
            text={Text("इस रिकॉर्ड को देखने, बदलने या restore करने के लिए फोन में PIN, Pattern या Password screen lock चालू होना चाहिए।")},
            confirmButton={Button(onClick=onCancel){Text("ठीक है")}}
        )
    }else if(launchFailed){
        AlertDialog(onDismissRequest=onCancel,title={Text("सुरक्षा पुष्टि नहीं खुली")},text={Text("फोन का screen lock या biometric prompt उपलब्ध नहीं हुआ। फोन का PIN/Pattern चालू करके दोबारा कोशिश करें।")},confirmButton={Button(onClick=onCancel){Text("बंद करें")}})
    }
}

@Composable
private fun DeviceCredentialDeleteGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
)=DeviceCredentialGate(title,message,onUnlocked,onCancel)

private fun isNotFutureDate(value:String):Boolean{
    return validDate(value) && value<=today()
}

@Composable
private fun AttendanceDateButton(value:String,onDateSelected:(String)->Unit){
    val context=LocalContext.current
    val parsed=try{
        SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value)
    }catch(_:Exception){Date()}
    OutlinedButton(
        onClick={
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(
                context,
                {_,year,month,day->
                    val selected=Calendar.getInstance().apply{
                        set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                    }
                    val formatted=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time)
                    if(formatted<=today()) onDateSelected(formatted)
                },
                cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)
            ).apply{
                datePicker.maxDate=System.currentTimeMillis()
            }.show()
        },
        modifier=Modifier.fillMaxWidth()
    ){
        Icon(Icons.Default.CalendarMonth,null)
        Spacer(Modifier.width(7.dp))
        Text("हाजिरी तारीख: ${displayDate(value)}")
    }
}

@Composable
private fun AttendanceScreen(store:Store,preField:String?,onBack:()->Unit){
    val context=LocalContext.current
    var selectedDate by rememberSaveable{mutableStateOf(today())}
    var activeField by rememberSaveable{mutableStateOf(preField?:store.fields.firstOrNull()?.id?:"")}
    var activeCrop by rememberSaveable{mutableStateOf("")}
    var attendanceError by remember{mutableStateOf("")}
    var addLabour by remember{mutableStateOf(false)}
    var showAbsentWorkers by rememberSaveable{mutableStateOf(false)}
    var bulkConfirm by rememberSaveable{mutableStateOf(false)}
    val selectedBulkLabours=rememberSaveable(saver=listSaver<SnapshotStateList<String>,String>(save={state->state.toList()},restore={saved->mutableStateListOf<String>().apply{addAll(saved)}})){mutableStateListOf<String>()}
    var deleteAttendance by remember{mutableStateOf<Attendance?>(null)}
    var protectedAttendanceEdit by remember{mutableStateOf<Pair<Attendance,Double>?>(null)}
    val field=store.fields.firstOrNull{it.id==activeField}
    val crops=store.crops.filter{it.fieldId==activeField}
    LaunchedEffect(activeField){activeCrop=if(crops.size==1)crops.first().id else ""}

    val credentialDelete=deleteAttendance
    val absentWorkerIds=store.attendances.filter{it.date==selectedDate && it.fraction==0.0}.map{it.labourId}.toSet()
    val rosterWorkers=store.labours.asReversed().filter{it.active && (showAbsentWorkers || it.id !in absentWorkerIds)}

    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📅 हाजिरी • ${displayDate(selectedDate)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.item{
                Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=AppPanelBg)){
                    Column(Modifier.padding(15.dp)){
                        Text("🌾 ${field?.name ?: "खेत नहीं चुना (वैकल्पिक)"}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                        Spacer(Modifier.height(8.dp))
                        AttendanceDateButton(selectedDate){selectedDate=it;attendanceError="";selectedBulkLabours.clear()}
                        Spacer(Modifier.height(6.dp))
                        Text("आज या पिछली तारीख की हाजिरी लगाएँ। आगे की तारीख की हाजिरी नहीं लगेगी।",fontSize=11.sp,color=AppMuted)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick={addLabour=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("+ मजदूर जोड़ें",fontWeight=FontWeight.Bold)}
                    }
                }
            }
            if(preField.isNullOrBlank()) this.item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.padding(14.dp)){
                        Text("🌾 खेत चुनें",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            FilterChip(selected=activeField.isBlank(),onClick={activeField="";activeCrop="";attendanceError="";selectedBulkLabours.clear()},label={Text("बिना खेत (वैकल्पिक)")})
                            store.fields.forEach{f->
                                val fieldName=f.name.ifBlank { "खेत" }
                                FilterChip(
                                    selected=f.id==activeField,
                                    onClick={activeField=f.id;attendanceError="";selectedBulkLabours.clear()},
                                    label={Text("🌾 $fieldName")}
                                )
                            }
                        }
                        if(field!=null&&crops.size>1){
                            Spacer(Modifier.height(8.dp))
                            ChoiceField("फसल",crops.map{it.id to it.name},activeCrop){activeCrop=it;attendanceError="";selectedBulkLabours.clear()}
                        }
                    }
                }
            }
            if(attendanceError.isNotBlank()) this.item{
                val isSuccess=attendanceError.contains("सफलतापूर्वक") || attendanceError.contains("सेव हो गई")
                Card(colors=CardDefaults.cardColors(containerColor=if(isSuccess)Color(0xFFE5F5EA) else Color(0xFFFFE8E6)),shape=RoundedCornerShape(14.dp)){
                    Text((if(isSuccess)"✓ " else "⚠ ")+attendanceError,Modifier.padding(12.dp),color=if(isSuccess)GreenDark else Color(0xFFB3261E),fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                }
            }
            if(field!=null || activeField.isBlank()){
                this.item{
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("मजदूरों की हाजिरी",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                        Text("${displayDate(selectedDate)}",fontSize=11.sp,color=AppMuted)
                    }
                    if(absentWorkerIds.isNotEmpty()) TextButton(onClick={showAbsentWorkers=!showAbsentWorkers;selectedBulkLabours.clear()}){Text(if(showAbsentWorkers)"अनुपस्थित मजदूर छिपाएँ (${absentWorkerIds.size})" else "अनुपस्थित मजदूर दिखाएँ (${absentWorkerIds.size})")}
                    val eligibleBulkWorkers=rosterWorkers.filter{worker->store.attendances.none{it.labourId==worker.id && it.fieldId==activeField && it.date==selectedDate}}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("चुने ${selectedBulkLabours.size}",modifier=Modifier.weight(1f),fontSize=12.sp,color=AppMuted)
                        TextButton(onClick={if(selectedBulkLabours.size==eligibleBulkWorkers.size)selectedBulkLabours.clear() else {selectedBulkLabours.clear();selectedBulkLabours.addAll(eligibleBulkWorkers.map{it.id})}}){Text(if(selectedBulkLabours.size==eligibleBulkWorkers.size && eligibleBulkWorkers.isNotEmpty())"चयन हटाएँ" else "बिना हाजिरी वाले चुनें")}
                        Button(onClick={bulkConfirm=true},enabled=selectedBulkLabours.isNotEmpty() && (crops.size<=1 || activeCrop.isNotBlank()),contentPadding=PaddingValues(horizontal=8.dp,vertical=4.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Text("पूरी हाजिरी",fontSize=11.sp)}
                    }
                }
                this.items(rosterWorkers,key={it.id}){l->
                    val a=store.attendances.firstOrNull{it.labourId==l.id&&it.fieldId==activeField&&it.date==selectedDate}
                    val totalForLabour=store.attendances.filter{it.labourId==l.id&&it.date==selectedDate}.sumOf{it.fraction}
                    val remaining=(1.0-totalForLabour+(a?.fraction?:0.0)).coerceAtLeast(0.0)
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                        Column(Modifier.padding(13.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Checkbox(checked=l.id in selectedBulkLabours,onCheckedChange={checked->if(checked){if(l.id !in selectedBulkLabours)selectedBulkLabours.add(l.id)}else selectedBulkLabours.remove(l.id)})
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=24.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp)
                                    Text("दिहाड़ी ₹${money(store.rateFor(l.id,selectedDate))}/दिन",fontSize=11.sp,color=AppMuted)
                                }
                                if(a!=null) Text(if(a.fraction==1.0)"✓ पूरा दिन" else if(a.fraction==0.5)"✓ आधा दिन" else if(a.fraction==0.0)"✓ भांजी (नहीं आया)" else "✓ ${money(a.fraction)} दिन",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                val fullSelected = a?.fraction == 1.0
                                val halfSelected = a?.fraction == 0.5
                                val bhanjiSelected = a?.fraction == 0.0
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.9999 || fullSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,1.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,1.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(fullSelected) Green else CardBg,
                                        contentColor=if(fullSelected) Color.White else Green
                                    ),
                                    border=if(fullSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Green)
                                ){Text(if(fullSelected)"✓ पूरा दिन" else "पूरा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.5 || halfSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.5)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.5,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(halfSelected) Color(0xFF6B4BC1) else CardBg,
                                        contentColor=if(halfSelected) Color.White else Color(0xFF6B4BC1)
                                    ),
                                    border=if(halfSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFF6B4BC1))
                                ){Text(if(halfSelected)"✓ आधा दिन" else "आधा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"भांजी दर्ज हो गई। इस दिन मजदूरी ₹0 रहेगी।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(bhanjiSelected) Color(0xFFB3261E) else CardBg,
                                        contentColor=if(bhanjiSelected) Color.White else Color(0xFFB3261E)
                                    ),
                                    border=if(bhanjiSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFFB3261E))
                                ){Text(if(bhanjiSelected)"✓ भांजी" else "भांजी",fontWeight=FontWeight.Bold)}
                                if(a!=null){
                                    IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                }
                            }
                        }
                    }
                }
            }
            if(store.fields.isEmpty()) this.item{Text("खेत जोड़ना वैकल्पिक है; आप बिना खेत चुने भी हाजिरी लगा सकते हैं।",color=AppMuted)}
            if(store.labours.isEmpty()) this.item{Text("पहले Labour में मजदूर जोड़ें।",color=AppMuted)}

            this.item{
                Text("इस तारीख की लगी हुई हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
            }
            this.items(store.attendances.filter{it.date==selectedDate&&it.fraction>0.0}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}),key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}",fontSize=11.sp,color=AppMuted)
                        }
                        IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }

        if(addLabour) LabourDialog(store,null){addLabour=false}

        if(bulkConfirm) AlertDialog(
            onDismissRequest={bulkConfirm=false},
            title={Text("चुने मजदूरों की हाजिरी लगाएँ?")},
            text={Text("${selectedBulkLabours.size} चुने मजदूरों की ${displayDate(selectedDate)} को खेत ${field?.name ?: "खेत नहीं चुना (वैकल्पिक)"} में पूरी दिन की हाजिरी दर्ज होगी। पहले से दर्ज हाजिरी नहीं बदली जाएगी।")},
            confirmButton={TextButton(onClick={
                var saved=0;var skipped=0
                selectedBulkLabours.toList().forEach{id->
                    val already=store.attendances.any{it.labourId==id && it.fieldId==activeField && it.date==selectedDate}
                    if(already){skipped++}else{
                        val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),id,activeField,activeCrop,selectedDate,1.0,store.rateFor(id,selectedDate)))
                        if(result==null)saved++ else skipped++
                    }
                }
                attendanceError="Bulk हाजिरी: $saved सेव, $skipped छोड़े गए।"
                selectedBulkLabours.clear();bulkConfirm=false
            }){Text("पुष्टि करें")} },
            dismissButton={TextButton(onClick={bulkConfirm=false}){Text("रद्द करें")}}
        )

    protectedAttendanceEdit?.let{pending->
            DeviceCredentialGate(
                "हाजिरी बदलें",
                "हाजिरी का पूरा दिन, आधा दिन या भांजी बदलने के लिए Android screen lock से पुष्टि करें।",
                {
                    val a=pending.first
                    val result=store.upsertAttendance(a.copy(fraction=pending.second,rate=store.rateFor(a.labourId,a.date)))
                    attendanceError=result?:"हाजिरी सफलतापूर्वक बदली गई।"
                    protectedAttendanceEdit=null
                },
                {protectedAttendanceEdit=null}
            )
        }

        credentialDelete?.let{a->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                {val deleted=store.deleteAttendance(a.id);deleteAttendance=null;attendanceError=if(deleted)"हाजिरी सफलतापूर्वक हटाई गई।" else "इस मजदूर का हिसाब फाइनल है; पुरानी हाजिरी नहीं हटाई जा सकती।"},
                {deleteAttendance=null}
            )
        }
    }
}

@Composable private fun FieldDetail(store:Store,id:String,onBack:()->Unit,onCrop:(String)->Unit,onAttendance:(String)->Unit,onExpense:()->Unit,onSale:()->Unit,onAddCrop:()->Unit){val f=store.fields.firstOrNull{it.id==id}?:return;val crops=store.crops.filter{it.fieldId==id};val labourCost=store.attendances.filter{it.fieldId==id}.sumOf{it.fraction*it.rate};val exp=store.expenses.filter{it.fieldId==id}.sumOf{it.amount};val sale=store.sales.filter{it.fieldId==id}.sumOf{it.total};val total=labourCost+exp;Column(Modifier.fillMaxSize()){DetailTopBar("🌾 ${f.name.ifBlank{"खेत"}}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",total)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-total)}}};this.item{SmallAction("👷 Labour / हाजिरी",{onAttendance(id)})};this.item{SmallAction("💰 खेती का खर्च",onExpense)};this.item{SmallAction("🧺 Sale",onSale)};this.item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("🌱 फसल",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp);IconButton(onClick=onAddCrop){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}};this.items(crops,key={it.id}){c->Card(Modifier.fillMaxWidth().clickable{onCrop(c.id)},RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=AppMuted)}}};this.item{Text("कुल मजदूरी: ₹${money(labourCost)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल खेती खर्च: ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल लागत: ₹${money(total)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल बिक्री: ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{Text("लाभ: ₹${money(sale-total)}",fontWeight=FontWeight.Bold,color=Green)}}}}

@Composable
private fun TodayAttendanceScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val day=today()
    val rows=store.attendances.filter{it.date==day}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId})
    val total=rows.sumOf{it.fraction*it.rate}
    val workerCount=rows.filter{it.fraction>0.0}.map{it.labourId}.distinct().size
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 आज की हाजिरी • ${displayDate(day)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){Stat("कुल मजदूर",workerCount.toDouble())}
                    Box(Modifier.weight(1f)){Stat("कुल मजदूरी",total)}
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"})},
                    onPdf={exportReportPdf(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"},background=true)}
                )
            }
            items(rows.filter{it.fraction>0.0},key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}; val f=store.fields.firstOrNull{it.id==a.fieldId}; val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("👷",fontSize=24.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""}",fontSize=11.sp,color=AppMuted)}
                        Surface(shape=RoundedCornerShape(10.dp),color=if(a.fraction==1.0) Color(0xFFE0F5E8) else Color(0xFFE9E0FF)){Text(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",Modifier.padding(horizontal=9.dp,vertical=6.dp),fontSize=11.sp,fontWeight=FontWeight.Bold,color=if(a.fraction==1.0)Green else Color(0xFF6B4BC1))}
                        Spacer(Modifier.width(8.dp));Text("₹${money(a.fraction*a.rate)}",fontWeight=FontWeight.Bold)
                    }
                }
            }
            if(rows.none{it.fraction>0.0}) item{Text("आज कोई मजदूर काम पर नहीं आया।",color=AppMuted)}
        }
    }
}

/** Monday-first, fixed 6-week calendar cells; null entries are leading/trailing blanks. */
internal fun attendanceCalendarCells(year:Int, monthZeroBased:Int):List<String?>{
    if(monthZeroBased !in 0..11 || year !in 1900..2200) return emptyList()
    val first=Calendar.getInstance().apply{clear();set(year,monthZeroBased,1)}
    val leading=(first.get(Calendar.DAY_OF_WEEK)+5)%7
    val days=first.getActualMaximum(Calendar.DAY_OF_MONTH)
    return List(42){index->
        val day=index-leading+1
        if(day in 1..days) String.format(Locale.US,"%04d-%02d-%02d",year,monthZeroBased+1,day) else null
    }
}

@Composable
private fun AttendanceHistoryScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val calendarNow=remember{Calendar.getInstance()}
    var calendarYear by rememberSaveable{mutableIntStateOf(calendarNow.get(Calendar.YEAR))}
    var calendarMonth by rememberSaveable{mutableIntStateOf(calendarNow.get(Calendar.MONTH))}
    var selectedCalendarDate by rememberSaveable{mutableStateOf(today())}
    val calendarCells=remember(calendarYear,calendarMonth){attendanceCalendarCells(calendarYear,calendarMonth)}
    val calendarMonthKey=String.format(Locale.US,"%04d-%02d",calendarYear,calendarMonth+1)
    val calendarRowsByDate=store.attendances.filter{it.fraction>0.0}.groupBy{it.date}
    val selectedCalendarRows=calendarRowsByDate[selectedCalendarDate].orEmpty().sortedBy{a->store.labours.firstOrNull{it.id==a.labourId}?.name.orEmpty()}
    val months=store.attendances.map{it.date.take(7)}.distinct().sortedDescending()
    var monthIndex by rememberSaveable { mutableStateOf(0) }
    val month=months.getOrNull(monthIndex) ?: today().take(7)
    val allMonthRows=store.attendances.filter{it.date.startsWith(month)}.sortedByDescending{it.date}
    val rows=allMonthRows.filter{it.fraction>0.0}
    val total=allMonthRows.sumOf{it.fraction*it.rate}
    val dayGroups=rows.groupBy{it.date}.toList().sortedByDescending{it.first}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 हाजिरी सूची",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
            item{
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.padding(14.dp)){
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            IconButton(enabled=monthIndex < months.lastIndex,onClick={if(monthIndex < months.lastIndex) monthIndex++}){Icon(Icons.Default.ChevronLeft,null)}
                            Text(if(month.isBlank())"हाजिरी सूची" else monthTitle(month),Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.ExtraBold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(enabled=monthIndex>0,onClick={if(monthIndex>0) monthIndex--}){Icon(Icons.Default.ChevronRight,null)}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल दिन",dayGroups.size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूर",rows.map{it.labourId}.distinct().size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूरी",total)}
                        }
                    }
                }
            }
            item{
                Card(Modifier.fillMaxWidth().testTag("attendance_month_calendar"),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            IconButton(onClick={
                                val c=Calendar.getInstance().apply{clear();set(calendarYear,calendarMonth,1);add(Calendar.MONTH,-1)}
                                calendarYear=c.get(Calendar.YEAR);calendarMonth=c.get(Calendar.MONTH)
                                selectedCalendarDate=""
                            }){Icon(Icons.Default.ChevronLeft,contentDescription="पिछला कैलेंडर महीना")}
                            Text(monthTitle(calendarMonthKey),Modifier.weight(1f),fontWeight=FontWeight.ExtraBold,fontSize=17.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(onClick={
                                val c=Calendar.getInstance().apply{clear();set(calendarYear,calendarMonth,1);add(Calendar.MONTH,1)}
                                val limit=Calendar.getInstance()
                                if(c.get(Calendar.YEAR)<limit.get(Calendar.YEAR) || (c.get(Calendar.YEAR)==limit.get(Calendar.YEAR)&&c.get(Calendar.MONTH)<=limit.get(Calendar.MONTH))){
                                    calendarYear=c.get(Calendar.YEAR);calendarMonth=c.get(Calendar.MONTH);selectedCalendarDate=""
                                }
                            },enabled=calendarYear<calendarNow.get(Calendar.YEAR) || calendarMonth<calendarNow.get(Calendar.MONTH)){Icon(Icons.Default.ChevronRight,contentDescription="अगला कैलेंडर महीना")}
                        }
                        Row(Modifier.fillMaxWidth()){
                            listOf("सोम","मंगल","बुध","गुरु","शुक्र","शनि","रवि").forEach{day->Box(Modifier.weight(1f),contentAlignment=Alignment.Center){Text(day,fontSize=9.sp,fontWeight=FontWeight.Bold,color=AppMuted)}}
                        }
                        calendarCells.chunked(7).forEach{week->
                            Row(Modifier.fillMaxWidth()){
                                week.forEach{date->
                                    Box(Modifier.weight(1f).aspectRatio(0.88f).padding(2.dp),contentAlignment=Alignment.Center){
                                        if(date==null) Spacer(Modifier.fillMaxSize()) else {
                                            val count=calendarRowsByDate[date].orEmpty().map{it.labourId}.distinct().size
                                            val chosen=date==selectedCalendarDate
                                            Surface(
                                                modifier=Modifier.fillMaxSize().clickable{selectedCalendarDate=date},
                                                shape=RoundedCornerShape(10.dp),
                                                color=if(chosen) GreenDark else if(count>0) Color(0xFFE5F3EA) else AppPanelBg
                                            ){
                                                Column(Modifier.fillMaxSize().padding(vertical=3.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
                                                    Text(date.takeLast(2).toInt().toString(),fontSize=12.sp,fontWeight=if(chosen||count>0) FontWeight.ExtraBold else FontWeight.Normal,color=if(chosen) Color.White else AppAccentText)
                                                    if(count>0) Text("$count",fontSize=9.sp,color=if(chosen) Color.White else Green,fontWeight=FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Text("जिस तारीख के नीचे संख्या है, उस दिन हाजिरी दर्ज है। तारीख चुनकर मजदूर देखें।",fontSize=11.sp,color=AppMuted)
                        if(selectedCalendarDate.isNotBlank()){
                            Text(displayDate(selectedCalendarDate),fontWeight=FontWeight.Bold,color=AppAccentText)
                            if(selectedCalendarRows.isEmpty()) Text("इस तारीख को कोई काम की हाजिरी नहीं है।",fontSize=12.sp,color=AppMuted)
                            else selectedCalendarRows.forEach{a->
                                val name=store.labours.firstOrNull{it.id==a.labourId}?.name?:"मजदूर"
                                Text("$name • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "${quantity(a.fraction)} दिन"} • ₹${money(a.fraction*a.rate)}",fontSize=12.sp,color=AppAccentText)
                            }
                        }
                    }
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportAttendanceHistoryPhoto(context,"हाजिरी_सूची_$month",month,dayGroups,store)},
                    onPdf={exportAttendanceHistoryPdf(context,"हाजिरी_सूची_$month",month,dayGroups,store)}
                )
            }
            dayGroups.forEach{(date,dayRows)->
                item{
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=AppPanelBg)){
                        Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(date),fontWeight=FontWeight.Bold,fontSize=16.sp);Text("${dayRows.map{it.labourId}.distinct().size} मजदूर काम पर आए",fontSize=11.sp,color=AppMuted)};Text("₹${money(dayRows.sumOf{it.fraction*it.rate})}",fontWeight=FontWeight.ExtraBold,color=Green)}
                        Column(Modifier.padding(horizontal=4.dp)){dayRows.filter{it.fraction>0.0}.forEach{a->val l=store.labours.firstOrNull{it.id==a.labourId};Text("${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "${money(a.fraction)} दिन"}",fontSize=11.sp)}}
                    }
                }
            }
            if(rows.isEmpty()) item{Text("इस महीने कोई हाजिरी रिकॉर्ड नहीं है।",color=AppMuted)}
        }
    }
}

@Composable
private fun LabourDetail(
    store: Store,
    id: String,
    onBack: () -> Unit
) {
    val l = store.labours.firstOrNull { it.id == id } ?: return
    val context=LocalContext.current

    var edit by remember { mutableStateOf(false) }
    var payment by remember { mutableStateOf(false) }
    var editPayment by remember { mutableStateOf<Payment?>(null) }
    var rate by remember { mutableStateOf(false) }
    var protectedRateEdit by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var delAttendance by remember { mutableStateOf<Attendance?>(null) }
    var protectedActiveToggle by remember { mutableStateOf(false) }

    val lastClosedThrough=store.latestClosure(id)?.throughDate.orEmpty()
    val currentAttendance=store.attendances.filter{it.labourId==id&&it.date>lastClosedThrough}
    val currentPayments=store.payments.filter{it.labourId==id&&it.date>lastClosedThrough}
    val wage = currentAttendance.sumOf { it.fraction * it.rate }
    val paid = currentPayments.sumOf { it.amount }

    Column(Modifier.fillMaxSize()) {
        DetailTopBar(
            "👷 ${l.name.ifBlank { "मजदूर" }}",
            onBack
        )

        LazyColumn(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            this.item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(1f)) { Stat("मजदूरी", wage) }
                    Box(Modifier.weight(1f)) { Stat("भुगतान/अग्रिम", paid) }
                    Box(Modifier.weight(1f)) { Stat("कुल बकाया", store.outstandingBalance(id)) }
                }
            }

            this.item {
                Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
                        Text(if(l.active)"स्थिति: सक्रिय मजदूर" else "स्थिति: निष्क्रिय मजदूर",fontWeight=FontWeight.Bold,color=if(l.active)Green else AppMuted)
                        Text(if(l.active)"यह मजदूर हाजिरी सूची में दिखाई देगा।" else "पुरानी हाजिरी और हिसाब सुरक्षित हैं; नई हाजिरी के लिए इसे फिर सक्रिय करें।",fontSize=12.sp,color=AppMuted)
                        OutlinedButton(onClick={protectedActiveToggle=true},modifier=Modifier.fillMaxWidth()) { Text(if(l.active)"मजदूर निष्क्रिय करें" else "मजदूर फिर सक्रिय करें") }
                    }
                }
            }
            this.item {
                store.latestClosure(id)?.let { closed ->
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=AppPanelBg)){
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                            Text("पुराना हिसाब फाइनल",fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                            Text("${displayDate(closed.throughDate)} तक • मजदूरी ₹${money(closed.wage)} • भुगतान ₹${money(closed.paid)} • बाकी ₹${money(closed.wage-closed.paid)}",fontSize=12.sp)
                            Text("ऊपर और PDF में केवल नए हिसाब की रकम दिखाई जाएगी। पुराना रिकॉर्ड रिपोर्ट में सुरक्षित है।",fontSize=11.sp,color=AppMuted)
                        }
                    }
                }
            }

            this.item {
                Button(
                    onClick = { payment = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("₹ Cash+ भुगतान जोड़ें")
                }
            }

            this.item {
                Button(
                    onClick = { protectedRateEdit = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
                ) {
                    Text("दिहाड़ी बदलें")
                }
            }

            this.item {
                val allAttendanceRows=store.attendances.filter{it.labourId==id}.sortedByDescending{it.date}
                val allPaymentRows=store.payments.filter{it.labourId==id}.sortedByDescending{it.date}
                val attendanceRows=allAttendanceRows.filter{it.date>lastClosedThrough}
                val paymentRows=allPaymentRows.filter{it.date>lastClosedThrough}
                val report=attendanceRows.filter{it.fraction>0.0}.map{a->val f=store.fields.firstOrNull{it.id==a.fieldId};"${displayDate(a.date)} • ${f?.name?:"खेत"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"} + listOf("","भुगतान") + paymentRows.map{p->"${displayDate(p.date)} • ${if(p.kind=="advance")"अग्रिम" else "भुगतान"} • ₹${money(p.amount)}"}
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"${l.name}_हिसाब","वर्तमान मजदूरी ₹${money(wage)} • वर्तमान भुगतान ₹${money(paid)} • कुल बकाया ₹${money(store.outstandingBalance(id))}",report)},
                    onPdf={exportWorkerLedgerPdf(context,l,store,attendanceRows,paymentRows,wage,paid,background=true)}
                )
            }

            this.item {
                Text(
                    "वर्तमान दिहाड़ी: ₹${money(store.rateFor(id, today()))}/दिन",
                    fontWeight = FontWeight.Bold,
                    color = Green
                )
            }

            this.item {
                Text(
                    "दिहाड़ी इतिहास",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(store.rateHistoryFor(id), key = { it.id }) { r ->
                Text(
                    "${displayDate(r.effectiveDate)} से ₹${money(r.rate)}/दिन",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    fontSize = 12.sp,
                    color = AppMuted
                )
            }

            this.item {
                val labourRows = currentAttendance
                val fullDays = labourRows.count { it.fraction == 1.0 }
                val halfDays = labourRows.count { it.fraction == 0.5 }
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=AppPanelBg)){
                    Column(Modifier.padding(12.dp)){
                        Text("📊 काम का सार",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल काम",labourRows.sumOf{it.fraction})}
                            Box(Modifier.weight(1f)){Stat("पूरा दिन",fullDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("आधा दिन",halfDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("कुल मजदूरी",wage)}
                        }
                    }
                }
            }

            this.item {
                Text(
                    "हाजिरी",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                currentAttendance.sortedByDescending { it.date },
                key = { it.id }
            ) { a ->
                val f = store.fields.firstOrNull { it.id == a.fieldId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(
                            "${displayDate(a.date)} • ${f?.name ?: "खेत"} • " +
                                "${store.crops.firstOrNull { it.id == a.cropId }?.name?.let { "$it • " } ?: ""}" +
                                "${if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • " +
                                "₹${money(a.fraction * a.rate)}",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick={delAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }

            this.item {
                Text(
                    "भुगतान",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                currentPayments.sortedByDescending { it.date },
                key = { it.id }
            ) { p ->
                val f = store.fields.firstOrNull { it.id == p.fieldId }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${if(p.kind=="advance")"अग्रिम" else "भुगतान"} • ${displayDate(p.date)} • ${f?.name ?: "सामान्य"}" +
                            "${store.crops.firstOrNull { it.id == p.cropId }?.name?.let { " • $it" } ?: ""}" +
                            " • ₹${money(p.amount)}",
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { editPayment = p }) { Icon(Icons.Default.Edit,contentDescription="भुगतान बदलें",tint=Green) }
                    IconButton(onClick = { delPay = p }) {
                        Icon(imageVector = Icons.Default.Delete,contentDescription = "भुगतान हटाएँ",tint = Color(0xFFB3261E))
                    }
                }
            }
        }

        if(protectedActiveToggle) DeviceCredentialGate(if(l.active)"मजदूर निष्क्रिय करें" else "मजदूर फिर सक्रिय करें",if(l.active)"पुराना हिसाब सुरक्षित रहेगा; नई हाजिरी बंद होगी।" else "मजदूर फिर से हाजिरी सूची में उपलब्ध होगा।",{store.setLabourActive(id,!l.active);protectedActiveToggle=false},{protectedActiveToggle=false})
        if (edit) {
            LabourDialog(store, l) {
                edit = false
            }
        }

        if (payment) {
            PaymentDialog(store, id, null, "", onClose={payment = false})
        }
        editPayment?.let { item ->
            PaymentDialog(store, id, item.fieldId, item.cropId, onClose={editPayment=null}, existing=item)
        }
        protectedRateEdit.takeIf{it}?.let{
            DeviceCredentialGate(
                "दिहाड़ी बदलें",
                "मजदूर की दिहाड़ी बदलने के लिए Android screen lock से पुष्टि करें।",
                {rate=true;protectedRateEdit=false},
                {protectedRateEdit=false}
            )
        }

        if (rate) {
            RateDialog(store, id) {
                rate = false
            }
        }

        delAttendance?.let { attendanceItem ->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deleteAttendance(attendanceItem.id); delAttendance = null; if(!deleted) android.widget.Toast.makeText(context,"यह हाजिरी फाइनल हिसाब में है, इसलिए नहीं हटाई गई।",android.widget.Toast.LENGTH_LONG).show() },
                { delAttendance = null }
            )
        }

        delPay?.let { paymentItem ->
            DeviceCredentialDeleteGate(
                "भुगतान हटाएँ",
                "गलत payment entry हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deletePayment(paymentItem.id); delPay = null; if(!deleted) android.widget.Toast.makeText(context,"यह महीना लॉक है या हिसाब फाइनल है, इसलिए भुगतान नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show() },
                { delPay = null }
            )
        }
        /*
        delPay?.let { paymentItem ->
            ConfirmDialog(
                "भुगतान हटाएँ?",
                "यह payment record हट जाएगा।",
                {
                    val deleted=store.deletePayment(paymentItem.id)
                    delPay = null
                    if(!deleted) android.widget.Toast.makeText(context,"यह महीना लॉक है या हिसाब फाइनल है, इसलिए भुगतान नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show()
                },
                {
                    delPay = null
                }
            )
        }
        */
    }
}


@Composable
private fun ExportButtons(onPhoto:()->Unit,onPdf:()->Unit){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
        Button(onClick=onPhoto,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4BC1))){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(6.dp));Text("Photo",fontWeight=FontWeight.Bold)}
        Button(onClick=onPdf,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(6.dp));Text("PDF",fontWeight=FontWeight.Bold)}
    }
}

private fun safeFileName(value:String):String=value.replace(Regex("[^A-Za-z0-9_-]+"),"_").trim('_').ifBlank{"report"}

private fun shareFile(context:Context,file:File,mime:String,title:String){
    require(file.exists() && file.isFile && file.length() > 0L) { "रिपोर्ट फ़ाइल खाली या उपलब्ध नहीं है" }
    val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file)
    val intent=Intent(Intent.ACTION_SEND).apply {
        type=mime
        putExtra(Intent.EXTRA_STREAM,uri)
        clipData=android.content.ClipData.newUri(context.contentResolver,title,uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser=Intent.createChooser(intent,title).apply { addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    context.startActivity(chooser)
}

private fun wrapReportText(text:String, paint:Paint, maxWidth:Float):List<String>{
    val words=text.trim().split(Regex("\\s+"))
    if(words.isEmpty()) return listOf("")
    val out=mutableListOf<String>(); var line=""
    for(word in words){
        val candidate=if(line.isBlank()) word else "$line $word"
        if(paint.measureText(candidate)<=maxWidth){line=candidate}else{
            if(line.isNotBlank()) out.add(line)
            line=word
        }
    }
    if(line.isNotBlank()) out.add(line)
    return out.ifEmpty{listOf("")}
}

private fun exportReportPhoto(context:Context,title:String,summary:String,lines:List<String>){
    try{
        val width=1200; val side=45f; val contentW=width-side*2; val lineH=38f; val headerH=255f
        val textPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;typeface=Typeface.DEFAULT;textSize=27f}
        val wrapped=lines.flatMapIndexed{idx,line->wrapReportText("${idx+1}. $line",textPaint,contentW)}
        val height=(headerH+wrapped.size*lineH+70f).toInt().coerceAtLeast(500)
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=Typeface.DEFAULT_BOLD;textSize=46f}
        canvas.drawText("MAJDOOR HISAAB PRO",side,65f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=30f;paint.color=android.graphics.Color.DKGRAY
        canvas.drawText(title,side,115f,paint)
        paint.textSize=26f;paint.color=android.graphics.Color.rgb(11,107,74)
        wrapReportText(summary,paint,contentW).take(2).forEachIndexed{i,t->canvas.drawText(t,side,165f+i*32f,paint)}
        paint.color=android.graphics.Color.LTGRAY;canvas.drawRect(side,205f,width-side,207f,paint)
        paint.color=android.graphics.Color.BLACK;paint.textSize=27f;paint.typeface=Typeface.DEFAULT
        var y=250f
        wrapped.forEach{line->canvas.drawText(line,side,y,paint);y+=lineH}
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}; val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}; bitmap.recycle(); shareFile(context,file,"image/png","Photo साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Photo report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun exportAttendanceHistoryPhoto(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
) {
    try {
        val width = 1400
        val side = 50f
        val contentW = width - side * 2
        val lineH = 42f
        val days = dayGroups.sortedByDescending { it.first }
        val totalRecords = days.sumOf { it.second.size }
        val uniqueWorkers = days.flatMap { it.second.filter { a -> a.fraction > 0.0 }.map { a -> a.labourId } }.distinct().size
        val totalWage = days.sumOf { group -> group.second.sumOf { a -> a.fraction * a.rate } }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            typeface = Typeface.DEFAULT
            textSize = 28f
        }

        var height = 330f
        days.forEach { (_, rows) ->
            height += 110f + 72f + rows.size * lineH + 58f
        }
        height += 170f

        val bitmap = Bitmap.createBitmap(width, height.toInt().coerceAtLeast(700), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)

        val darkGreen = android.graphics.Color.rgb(6, 76, 54)
        val green = android.graphics.Color.rgb(11, 107, 74)
        val lightGreen = android.graphics.Color.rgb(234, 248, 241)
        val lightBlue = android.graphics.Color.rgb(235, 245, 255)
        val lightYellow = android.graphics.Color.rgb(255, 249, 225)

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkGreen
            typeface = Typeface.DEFAULT_BOLD
            textSize = 48f
        }
        canvas.drawRoundRect(side, 25f, width - side, 145f, 24f, 24f, headerPaint)

        headerPaint.color = android.graphics.Color.WHITE
        headerPaint.textSize = 44f
        canvas.drawText("MAJDOOR HISAAB PRO", side + 28f, 78f, headerPaint)
        headerPaint.textSize = 31f
        canvas.drawText("हाजिरी सूची • ${monthTitle(month)}", side + 28f, 120f, headerPaint)

        fun summaryCard(left: Float, top: Float, right: Float, label: String, value: String, bg: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
            canvas.drawRoundRect(left, top, right, top + 125f, 20f, 20f, p)
            p.color = darkGreen
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 25f
            canvas.drawText(label, left + 22f, top + 40f, p)
            p.textSize = 42f
            canvas.drawText(value, left + 22f, top + 94f, p)
        }

        val gap = 14f
        val cardW = (contentW - gap * 3) / 4f
        val sy = 170f
        summaryCard(side, sy, side + cardW, "कुल कार्य दिवस", days.size.toString(), lightBlue)
        summaryCard(side + cardW + gap, sy, side + cardW * 2 + gap, "अलग मजदूर", uniqueWorkers.toString(), lightYellow)
        summaryCard(side + cardW * 2 + gap * 2, sy, side + cardW * 3 + gap * 2, "कुल हाजिरी", totalRecords.toString(), lightGreen)
        summaryCard(side + cardW * 3 + gap * 3, sy, width - side, "कुल मजदूरी", "₹${money(totalWage)}", android.graphics.Color.rgb(255, 237, 237))

        var y = 325f

        days.forEachIndexed { dayIndex, pair ->
            val date = pair.first
            val rows = pair.second
            val dayTotal = rows.sumOf { it.fraction * it.rate }
            val workers = rows.filter { it.fraction > 0.0 }.map { it.labourId }.distinct().size
            val sectionBg = if (dayIndex % 2 == 0) lightGreen else lightYellow

            val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sectionBg }
            canvas.drawRoundRect(side, y, width - side, y + 82f + rows.size * lineH + 65f, 22f, 22f, sectionPaint)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = darkGreen
                typeface = Typeface.DEFAULT_BOLD
                textSize = 34f
            }
            canvas.drawText(displayDate(date), side + 25f, y + 43f, titlePaint)

            titlePaint.typeface = Typeface.DEFAULT
            titlePaint.textSize = 23f
            canvas.drawText("कुल मजदूर: $workers", side + 330f, y + 42f, titlePaint)
            canvas.drawText("कुल हाजिरी: ${rows.size}", side + 570f, y + 42f, titlePaint)
            titlePaint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}", side + 830f, y + 42f, titlePaint)

            val tableTop = y + 62f
            val headerH = 45f
            val col1 = side
            val col2 = side + 105f
            val col3 = side + 570f
            val col4 = side + 1080f
            val tableRight = width - side

            val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen }
            canvas.drawRect(col1, tableTop, tableRight, tableTop + headerH, hp)

            val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                typeface = Typeface.DEFAULT_BOLD
                textSize = 21f
            }
            canvas.drawText("क्रम", col1 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूर का नाम", col2 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("काम का प्रकार", col3 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूरी (₹)", col4 + 18f, tableTop + 30f, whitePaint)

            var rowY = tableTop + headerH
            rows.sortedWith(compareBy<Attendance> { it.labourId }.thenBy { it.fieldId }).forEachIndexed { index, a ->
                val l = store.labours.firstOrNull { it.id == a.labourId }
                val bg = if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(247, 250, 249)
                val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
                canvas.drawRect(col1, rowY, tableRight, rowY + lineH, rp)

                val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.rgb(25, 25, 25)
                    typeface = Typeface.DEFAULT
                    textSize = 21f
                }
                canvas.drawText("${index + 1}", col1 + 24f, rowY + 29f, tp)
                canvas.drawText(l?.name ?: "मजदूर", col2 + 18f, rowY + 29f, tp)
                canvas.drawText(if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (नहीं आया)" else "अन्य", col3 + 18f, rowY + 29f, tp)
                tp.typeface = Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction * a.rate)}", col4 + 18f, rowY + 29f, tp)
                rowY += lineH
            }

            val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(218, 246, 222)
                typeface = Typeface.DEFAULT_BOLD
                textSize = 24f
            }
            canvas.drawRect(col1, rowY, tableRight, rowY + 55f, totalPaint)
            totalPaint.color = darkGreen
            canvas.drawText("${displayDate(date)} का कुल", col1 + 25f, rowY + 36f, totalPaint)
            canvas.drawText("₹${money(dayTotal)}", col4 + 18f, rowY + 36f, totalPaint)

            y = rowY + 85f
        }

        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(235, 245, 255)
            typeface = Typeface.DEFAULT_BOLD
            textSize = 27f
        }
        canvas.drawRoundRect(side, y, width - side, y + 135f, 22f, 22f, totalPaint)
        totalPaint.color = darkGreen
        totalPaint.textSize = 32f
        canvas.drawText("${monthTitle(month)} — कुल योग", side + 25f, y + 45f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT
        totalPaint.textSize = 24f
        canvas.drawText("कार्य दिवस: ${days.size}   •   अलग मजदूर: $uniqueWorkers   •   कुल हाजिरी रिकॉर्ड: $totalRecords", side + 25f, y + 82f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT_BOLD
        totalPaint.textSize = 34f
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}", side + 25f, y + 119f, totalPaint)

        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        shareFile(context, file, "image/png", "Photo साझा करें")
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Photo report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportAttendanceHistoryPdf(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
){
    try{
        val doc=PdfDocument()
        val pageW=595
        val pageH=842
        val left=24f
        val right=24f
        val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        var pageNo=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
        var canvas=page.canvas

        val days=dayGroups.sortedByDescending{it.first}
        val totalRecords=days.sumOf{it.second.size}
        val uniqueWorkers=days.flatMap{it.second.filter{a->a.fraction>0.0}.map{a->a.labourId}}.distinct().size
        val totalWage=days.sumOf{g->g.second.sumOf{a->a.fraction*a.rate}}

        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=22f
            canvas.drawText("MAJDOOR HISAAB PRO",left,32f,paint)
            paint.color=android.graphics.Color.BLACK
            paint.textSize=14f
            paint.typeface=Typeface.DEFAULT
            canvas.drawText("हाजिरी सूची • ${monthTitle(month)}",left,53f,paint)
            paint.textSize=9.5f
            canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी: $totalRecords • कुल मजदूरी: ₹${money(totalWage)}",left,70f,paint)
            paint.color=android.graphics.Color.LTGRAY
            canvas.drawRect(left,80f,pageW-right,81.5f,paint)
        }

        fun newPage(){
            doc.finishPage(page)
            pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
            canvas=page.canvas
            header()
        }

        fun ensure(space:Float, currentY:Float):Float{
            if(currentY+space>810f){newPage();return 100f}
            return currentY
        }

        header()
        var y=102f

        days.forEach{(date,rows)->
            val dayTotal=rows.sumOf{it.fraction*it.rate}
            val workers=rows.filter{it.fraction>0.0}.map{it.labourId}.distinct().size

            y=ensure(60f,y)
            paint.color=android.graphics.Color.rgb(234,248,241)
            canvas.drawRoundRect(left,y-18f,pageW-right,y+22f,8f,8f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=12f
            canvas.drawText(displayDate(date),left+8f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT
            paint.textSize=9.5f
            canvas.drawText("कुल मजदूर: $workers",left+115f,y+3f,paint)
            canvas.drawText("कुल हाजिरी: ${rows.size}",left+225f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}",left+365f,y+3f,paint)
            y+=35f

            // Compact table columns
            val c1=left
            val c2=left+34f
            val c3=left+235f
            val c4=left+435f
            val tr=pageW-right
            paint.color=android.graphics.Color.rgb(6,76,54)
            canvas.drawRect(c1,y,c4+100f,y+24f,paint)
            paint.color=android.graphics.Color.WHITE
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=8.5f
            canvas.drawText("क्रम",c1+6f,y+16f,paint)
            canvas.drawText("मजदूर का नाम",c2+6f,y+16f,paint)
            canvas.drawText("काम का प्रकार",c3+6f,y+16f,paint)
            canvas.drawText("मजदूरी (₹)",c4+6f,y+16f,paint)
            y+=24f

            rows.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}).forEachIndexed{index,a->
                y=ensure(18f,y)
                paint.color=if(index%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(247,250,249)
                canvas.drawRect(c1,y,tr,y+18f,paint)
                val l=store.labours.firstOrNull{it.id==a.labourId}
                paint.color=android.graphics.Color.rgb(25,25,25)
                paint.typeface=Typeface.DEFAULT
                paint.textSize=8.5f
                canvas.drawText("${index+1}",c1+6f,y+13f,paint)
                canvas.drawText((l?.name?:"मजदूर").take(28),c2+6f,y+13f,paint)
                canvas.drawText(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",c3+6f,y+13f,paint)
                paint.typeface=Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction*a.rate)}",c4+6f,y+13f,paint)
                y+=18f
            }
            paint.color=android.graphics.Color.rgb(218,246,222)
            canvas.drawRect(c1,y,tr,y+22f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=9.5f
            canvas.drawText("${displayDate(date)} का कुल",c1+6f,y+15f,paint)
            canvas.drawText("₹${money(dayTotal)}",c4+6f,y+15f,paint)
            y+=34f
        }

        y=ensure(65f,y)
        paint.color=android.graphics.Color.rgb(235,245,255)
        canvas.drawRoundRect(left,y,pageW-right,y+58f,10f,10f,paint)
        paint.color=android.graphics.Color.rgb(6,76,54)
        paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=12f
        canvas.drawText("${monthTitle(month)} — कुल योग",left+8f,y+18f,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=9.5f
        canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी रिकॉर्ड: $totalRecords",left+8f,y+36f,paint)
        paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}",left+350f,y+36f,paint)

        doc.finishPage(page)
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use{doc.writeTo(it)}
        doc.close()
        shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){
        android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportWorkerLedgerPdf(
    context: Context,
    labour: Labour,
    store: Store,
    attendanceRows: List<Attendance>,
    paymentRows: List<Payment>,
    totalWage: Double,
    totalPaid: Double,
    background: Boolean = true
) {
    val generate = {
        try {
            val doc = PdfDocument()
            val pageW = 595
            val pageH = 842
            val left = 24f
            val right = 24f
            val contentRight = pageW - right
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val green = android.graphics.Color.rgb(6, 76, 54)
            val mint = android.graphics.Color.rgb(237, 248, 243)
            val dark = android.graphics.Color.rgb(25, 25, 25)
            val grid = android.graphics.Color.rgb(205, 216, 212)
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            var canvas = page.canvas

            fun text(value: String, x: Float, y: Float, size: Float, color: Int = dark, bold: Boolean = false) {
                paint.color = color
                paint.textSize = size
                paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                canvas.drawText(value, x, y, paint)
            }
            fun rect(l: Float, t: Float, r: Float, b: Float, color: Int) {
                paint.color = color
                canvas.drawRect(l, t, r, b, paint)
            }
            fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int = grid, stroke: Float = 0.7f) {
                paint.color = color
                paint.strokeWidth = stroke
                canvas.drawLine(x1, y1, x2, y2, paint)
            }
            fun rounded(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
                paint.color = color
                canvas.drawRoundRect(l, t, r, b, radius, radius, paint)
            }
            fun header() {
                rounded(left, 18f, contentRight, 92f, 12f, green)
                runCatching {
                    val logo = BitmapFactory.decodeResource(context.resources, R.drawable.majdoor_logo_small)
                    if (logo != null) {
                        canvas.drawBitmap(logo, null, android.graphics.RectF(left + 9f, 28f, left + 62f, 82f), Paint(Paint.ANTI_ALIAS_FLAG))
                        logo.recycle()
                    }
                }
                text("MAJDOOR HISAAB PRO", left + 72f, 49f, 22f, android.graphics.Color.WHITE, true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल", left + 72f, 73f, 12f, android.graphics.Color.rgb(224, 242, 234))
                text("मजदूर का हिसाब", contentRight - 142f, 48f, 13f, android.graphics.Color.WHITE, true)
                text("व्यक्तिगत विवरण", contentRight - 142f, 69f, 11f, android.graphics.Color.WHITE)
            }
            fun footer() {
                line(left, 806f, contentRight, 806f, green, 1.3f)
                text("तैयार करने की तारीख: ${displayDate(today())}", left + 8f, 825f, 9.5f)
                text("ऐप: MAJDOOR HISAAB PRO", left + 8f, 839f, 9f)
                text("पेज $pageNo", contentRight - 50f, 825f, 9.5f)
            }
            fun startNewPage() {
                footer()
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                canvas = page.canvas
                header()
            }

            header()
            rounded(left, 102f, contentRight, 198f, 10f, mint)
            text("मजदूर का नाम", left + 17f, 124f, 11f, dark, true)
            text(labour.name.ifBlank { "मजदूर" }.take(30), left + 17f, 153f, 21f, dark, true)
            text("मोबाइल: ${labour.mobile.ifBlank { "-" }}".take(36), left + 17f, 177f, 10.5f)
            line(316f, 113f, 316f, 187f, android.graphics.Color.rgb(190, 220, 207), 0.8f)
            text("कुल हाजिरी", 334f, 124f, 11f)
            text(":  ${quantity(attendanceRows.sumOf { it.fraction })} दिन", 428f, 124f, 11f, dark, true)
            text("कुल मजदूरी", 334f, 147f, 11f)
            text(":  ₹${money(totalWage)}", 428f, 147f, 11f, dark, true)
            text("कुल भुगतान", 334f, 169f, 11f)
            text(":  ₹${money(totalPaid)}", 428f, 169f, 11f, dark, true)
            text("बकाया राशि", 334f, 190f, 11f)
            text(":  ₹${money(store.outstandingBalance(labour.id))}", 428f, 190f, 11f, green, true)

            // Work rows exclude absence/भांजी. Payments are shown only on their actual payment dates.
            data class LedgerRow(val date: String, val field: String, val attendance: String, val payment: Double?, val amount: Double?, val sortDate: String)
            val workRows = attendanceRows.filter { it.fraction > 0.0 }.map { a ->
                LedgerRow(a.date, store.fields.firstOrNull { it.id == a.fieldId }?.name ?: "खेत", if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else "${money(a.fraction)} दिन", null, a.fraction * a.rate, a.date)
            }
            val paymentsByDate = paymentRows.groupBy { it.date }.mapValues { (_, ps) -> ps.sumOf { it.amount } }
            val workDates = workRows.map { it.date }.toSet()
            val paymentOnlyRows = paymentsByDate.filterKeys { it !in workDates }.map { (date, amount) -> LedgerRow(date, "", "—", amount, null, date) }
            val rows = (workRows + paymentOnlyRows).sortedByDescending { it.sortDate }.toMutableList()
            val paidDates = paymentsByDate.keys
            val paidShown = mutableSetOf<String>()
            var y = 225f
            val cols = floatArrayOf(left, left + 43f, left + 145f, left + 332f, left + 418f, left + 500f, contentRight)
            val headers = listOf("क्रम सं.", "तारीख", "खेत / काम का नाम", "हाजिरी", "भुगतान/अग्रिम (₹)", "रकम (₹)")
            fun drawTableHeader() {
                rounded(left, y, contentRight, y + 28f, 5f, green)
                headers.forEachIndexed { i, label -> text(label, cols[i] + 5f, y + 18f, 8.8f, android.graphics.Color.WHITE, true) }
                y += 28f
            }
            drawTableHeader()
            rows.forEachIndexed { index, row ->
                if (y + 38f > 650f) {
                    startNewPage()
                    y = 112f
                    drawTableHeader()
                }
                rect(left, y, contentRight, y + 38f, if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(248, 251, 249))
                line(left, y + 38f, contentRight, y + 38f)
                for (x in cols.drop(1)) line(x, y, x, y + 38f)
                text("${index + 1}", cols[0] + 14f, y + 23f, 9.5f)
                text(displayDate(row.date), cols[1] + 5f, y + 23f, 8.6f)
                val fieldText = row.field.take(23)
                text(fieldText, cols[2] + 5f, y + 23f, 8.6f)
                text(row.attendance, cols[3] + 5f, y + 23f, 8.6f)
                val pay = if (row.date in paidDates && paidShown.add(row.date)) paymentsByDate[row.date] else null
                if (pay != null) text("₹${money(pay)}", cols[4] + 7f, y + 23f, 8.6f)
                if (row.amount != null) text("₹${money(row.amount)}", cols[5] + 8f, y + 23f, 8.6f)
                y += 38f
            }

            // Compact summary only; intentionally no note box.
            if (y + 135f > 790f) {
                startNewPage()
                y = 112f
            } else {
                y = maxOf(y + 24f, 560f)
            }
            rounded(left, y, contentRight, y + 130f, 10f, mint)
            text("कुल सारांश", left + 15f, y + 25f, 17f, green, true)
            val workDays = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction }
            text("कुल कार्य दिवस", left + 20f, y + 53f, 11f)
            text(":  ${quantity(workDays)} दिन", left + 150f, y + 53f, 11f, dark, true)
            text("कुल मजदूरी", left + 20f, y + 78f, 11f)
            text(":  ₹${money(totalWage)}", left + 150f, y + 78f, 11f, dark, true)
            text("कुल भुगतान", left + 20f, y + 103f, 11f)
            text(":  ₹${money(totalPaid)}", left + 150f, y + 103f, 11f, dark, true)
            text("बाकी राशि", left + 300f, y + 78f, 11f)
            text(":  ₹${money(store.outstandingBalance(labour.id))}", left + 385f, y + 78f, 11f, android.graphics.Color.rgb(185, 35, 35), true)
            footer()
            doc.finishPage(page)
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "${safeFileName(labour.name + "_हिसाब")}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            if (background) reportMainHandler.post {
                runCatching { shareFile(context, file, "application/pdf", "PDF साझा करें") }.onFailure {
                    android.widget.Toast.makeText(context, "PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            } else shareFile(context, file, "application/pdf", "PDF साझा करें")
        } catch (e: Exception) {
            if (background) reportMainHandler.post { android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            else android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    if (background) reportPdfExecutor.execute { generate() } else generate()
}

private val reportPdfExecutor = Executors.newSingleThreadExecutor()
private val reportMainHandler = android.os.Handler(android.os.Looper.getMainLooper())

private fun exportAllWorkersLedgerPdf(
    context:Context,
    title:String,
    dateLabel:String,
    fieldLabel:String,
    rows:List<LabourReportRow>,
    totalWage:Double,
    totalPaid:Double,
    background:Boolean=false
){
    val generate={
        try{
            val doc=PdfDocument(); val pageW=595; val pageH=842; val left=24f; val right=24f; val contentRight=pageW-right
            val green=android.graphics.Color.rgb(6,76,54); val mint=android.graphics.Color.rgb(237,248,243); val dark=android.graphics.Color.rgb(25,35,31); val red=android.graphics.Color.rgb(196,35,35)
            val paint=Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo=1
            var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
            fun text(t:String,x:Float,y:Float,size:Float=10f,color:Int=dark,bold:Boolean=false){paint.color=color;paint.textSize=size;paint.typeface=if(bold)Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL);canvas.drawText(t,x,y,paint)}
            fun line(x1:Float,y1:Float,x2:Float,y2:Float,color:Int=android.graphics.Color.LTGRAY,width:Float=0.6f){paint.color=color;paint.strokeWidth=width;canvas.drawLine(x1,y1,x2,y2,paint)}
            fun rect(l:Float,t:Float,r:Float,b:Float,color:Int){paint.color=color;canvas.drawRect(l,t,r,b,paint)}
            fun rounded(l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int){paint.color=color;canvas.drawRoundRect(l,t,r,b,rad,rad,paint)}
            fun footer(){line(left,806f,contentRight,806f,green,1.2f);text("तैयार करने की तारीख: ${displayDate(today())}",left+7f,824f,9f);text("ऐप: MAJDOOR HISAAB PRO",left+7f,838f,8.5f);text("पेज $pageNo",contentRight-48f,824f,9f)}
            fun header(){
                rounded(left,20f,contentRight,82f,9f,green)
                val logo=runCatching{BitmapFactory.decodeResource(context.resources,R.drawable.majdoor_logo_small)}.getOrNull()
                if(logo!=null){paint.isFilterBitmap=true;canvas.drawBitmap(logo,null,android.graphics.RectF(left+10f,29f,left+68f,73f),paint);logo.recycle()}
                text("MAJDOOR HISAAB PRO",left+78f,49f,21f,android.graphics.Color.WHITE,true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल",left+78f,68f,10f,android.graphics.Color.WHITE)
                text("चुने हुए मजदूरों का हिसाब",left,112f,20f,green,true)
                text("अवधि: $dateLabel",left,134f,10f,dark)
                text("खेत: ${fieldLabel.take(64)}",left,151f,10f,dark)
            }
            fun startNewPage(){footer();doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header()}
            header()
            rounded(left,166f,contentRight,229f,9f,mint)
            val workerCount=rows.size
            val summaryCols=floatArrayOf(left,left+137f,left+274f,left+411f,contentRight)
            val summaryLabels=listOf("कुल मजदूर","कुल मजदूरी","कुल भुगतान","कुल बकाया")
            val summaryValues=listOf("$workerCount मजदूर","₹${money(totalWage)}","₹${money(totalPaid)}","₹${money(totalWage-totalPaid)}")
            for(i in 0..3){
                if(i>0) line(summaryCols[i],174f,summaryCols[i],220f,android.graphics.Color.rgb(190,220,207),0.8f)
                text(summaryLabels[i],summaryCols[i]+9f,188f,8.5f,green,true)
                text(summaryValues[i],summaryCols[i]+9f,214f,if(i==0)14f else 12f,if(i==3)red else green,true)
            }
            var y=245f
            val cols=floatArrayOf(left,left+31f,left+195f,left+265f,left+355f,left+435f,contentRight)
            val headers=listOf("क्र.","मजदूर का नाम","काम के दिन","कुल मजदूरी (₹)","भुगतान (₹)","बाकी रकम (₹)")
            fun drawTableHeader(){rounded(left,y,contentRight,y+27f,4f,green);headers.forEachIndexed{i,h->text(h,cols[i]+4f,y+17f,7.5f,android.graphics.Color.WHITE,true)};y+=27f}
            drawTableHeader()
            rows.forEachIndexed{idx,r->
                if(y+29f>790f){startNewPage();y=170f;drawTableHeader()}
                rect(left,y,contentRight,y+29f,if(idx%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(248,251,249))
                for(x in cols.drop(1))line(x,y,x,y+29f)
                line(left,y+29f,contentRight,y+29f)
                val balance=r.wage-r.paid
                text("${idx+1}",cols[0]+9f,y+18f,8.5f)
                text(r.labour.name.take(26),cols[1]+4f,y+18f,8.2f)
                text(quantity(r.workDays),cols[2]+10f,y+18f,8.5f)
                text("₹${money(r.wage)}",cols[3]+5f,y+18f,8.2f)
                text("₹${money(r.paid)}",cols[4]+5f,y+18f,8.2f)
                text("₹${money(balance)}",cols[5]+5f,y+18f,8.2f,if(balance>0)red else green,true)
                y+=29f
            }
            if(y+34f>790f){startNewPage();y=170f}
            rounded(left,y,contentRight,y+34f,5f,mint)
            text("कुल योग",left+12f,y+21f,10f,green,true)
            text("${quantity(rows.sumOf{it.workDays})}",cols[2]+10f,y+21f,9f,green,true)
            text("₹${money(totalWage)}",cols[3]+5f,y+21f,9f,green,true)
            text("₹${money(totalPaid)}",cols[4]+5f,y+21f,9f,green,true)
            text("₹${money(totalWage-totalPaid)}",cols[5]+5f,y+21f,9f,red,true)
            footer();doc.finishPage(page)
            val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close()
            if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}",android.widget.Toast.LENGTH_LONG).show()}} else shareFile(context,file,"application/pdf","PDF साझा करें")
        }catch(e:Exception){if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()} else android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
    }
    if(background)reportPdfExecutor.execute{generate()}else generate()
}


/** CSV quoting plus spreadsheet-formula injection protection for user-controlled text. */
private fun csvCell(value:String):String {
    // Spreadsheet apps may ignore a BOM or zero-width format characters before
    // interpreting a formula. Ignore them during detection but preserve cell text.
    val firstMeaningful = value.dropWhile {
        it.isWhitespace() || it == '\uFEFF' || it == '\u200B' || it == '\u200C' || it == '\u200D'
    }.firstOrNull()
    val hasDangerousPrefix = value.firstOrNull() == '\t' || value.firstOrNull() == '\r' || value.firstOrNull() == '\n' || firstMeaningful in setOf('=', '+', '-', '@')
    val safe = if (hasDangerousPrefix) "'" + value else value
    return "\"${safe.replace("\"","\"\"")}\""
}

private fun buildDateFieldReportCsv(attendanceRows:List<Attendance>,paymentRows:List<Payment>,store:Store):String = buildString{
    append("तारीख,प्रकार,मजदूर,खेत,हाजिरी,मजदूरी,भुगतान/अग्रिम\n")
    attendanceRows.forEach{row->
        val worker=store.labours.firstOrNull{it.id==row.labourId}?.name ?: "मजदूर हटाया गया"
        val field=if(row.fieldId.isBlank()) "खेत नहीं चुना" else store.fields.firstOrNull{it.id==row.fieldId}?.name ?: "खेत हटाया गया"
        val attendance=when(row.fraction){1.0->"पूरा दिन";0.5->"आधा दिन";0.0->"भांजी / अनुपस्थित";else->"${quantity(row.fraction)} दिन"}
        append(listOf(displayDate(row.date),"हाजिरी",worker,field,attendance,money(row.fraction*row.rate),"0.00").joinToString(","){csvCell(it)}).append('\n')
    }
    paymentRows.forEach{row->
        val worker=store.labours.firstOrNull{it.id==row.labourId}?.name ?: "मजदूर हटाया गया"
        val field=if(row.fieldId.isBlank())"खेत नहीं चुना" else store.fields.firstOrNull{it.id==row.fieldId}?.name ?: "खेत हटाया गया"
        append(listOf(displayDate(row.date),if(row.kind=="advance")"अग्रिम" else "भुगतान",worker,field,"—","0.00",money(row.amount)).joinToString(","){csvCell(it)}).append('\n')
    }
}

private fun exportDateFieldReportCsv(context:Context,baseName:String,attendanceRows:List<Attendance>,paymentRows:List<Payment>,store:Store){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(baseName)}.csv")
        file.writeText("\uFEFF"+buildDateFieldReportCsv(attendanceRows,paymentRows,store),Charsets.UTF_8)
        shareFile(context,file,"text/csv","CSV साझा करें")
    }catch(error:Exception){android.widget.Toast.makeText(context,"CSV report नहीं बन सकी: ${error.message ?: "त्रुटि"}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun exportDateFieldReportPdf(
    context: Context,
    title: String,
    summary: String,
    attendanceRows: List<Attendance>,
    paymentRows: List<Payment>,
    store: Store,
    aggregateWorkerView: Boolean,
    background: Boolean = false
) {
    val generate = {
        try {
            val doc = PdfDocument()
            val pageW = 842
            val pageH = 595
            val left = 28f
            val right = 28f
            val rightEdge = pageW - right
            val green = android.graphics.Color.rgb(6, 76, 54)
            val paleGreen = android.graphics.Color.rgb(230, 243, 236)
            val dark = android.graphics.Color.rgb(35, 45, 40)
            val muted = android.graphics.Color.rgb(95, 105, 100)
            val grid = android.graphics.Color.rgb(196, 213, 204)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo = 0
            var page: PdfDocument.Page? = null
            var canvas: Canvas? = null
            var y = 0f
            // Five useful columns only: deliberately no wage-rate column.
            val colX = floatArrayOf(left, 100f, 195f, 325f, 405f, 505f, 605f, rightEdge)
            val headers = listOf("तारीख", "खेत का नाम", "मजदूर का नाम", "हाजिरी", "मजदूरी (₹)", "भुगतान/अग्रिम (₹)", "बकाया (₹)")
            fun fit(value: String, maxWidth: Float, size: Float, bold: Boolean = false): String {
                paint.textSize = size
                paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                val clean = value.replace('\n', ' ').replace('\r', ' ')
                var out = clean
                while (out.isNotEmpty() && paint.measureText(out) > maxWidth - 12f) out = out.dropLast(1)
                return if (out != clean) out.trimEnd() + "…" else out
            }
            fun drawTableHeader() {
                val c = canvas ?: return
                paint.color = green
                c.drawRoundRect(android.graphics.RectF(left, y, rightEdge, y + 29f), 4f, 4f, paint)
                headers.forEachIndexed { i, h ->
                    paint.color = android.graphics.Color.WHITE
                    paint.textSize = 10.5f
                    paint.typeface = Typeface.DEFAULT_BOLD
                    c.drawText(fit(h, colX[i + 1] - colX[i], 10.5f, true), colX[i] + 6f, y + 19f, paint)
                }
                y += 29f
            }
            fun startPage(first: Boolean) {
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                canvas = page!!.canvas
                val c = canvas!!
                c.drawColor(android.graphics.Color.WHITE)
                y = 18f
                paint.color = green
                c.drawRoundRect(android.graphics.RectF(left, y, rightEdge, y + 45f), 8f, 8f, paint)
                paint.color = android.graphics.Color.WHITE
                paint.textSize = 20f
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("MAJDOOR HISAAB PRO", left + 14f, y + 21f, paint)
                paint.textSize = 11f
                paint.typeface = Typeface.DEFAULT
                c.drawText(if (first) "तारीख और खेत के अनुसार मजदूर हिसाब" else "तारीख और खेत के अनुसार हिसाब — जारी", left + 14f, y + 37f, paint)
                y += 55f
                if (first) {
                    paint.color = muted
                    paint.textSize = 9.5f
                    paint.typeface = Typeface.DEFAULT
                    c.drawText(fit(summary, rightEdge - left, 9.5f), left + 2f, y + 1f, paint)
                    val wage = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction * it.rate }
                    val paid = paymentRows.sumOf { it.amount }
                    val days = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction }
                    val cardsTop = y + 11f
                    val cardsBottom = cardsTop + 43f
                    val cardW = (rightEdge - left) / 4f
                    // Keep the on-screen preview unchanged; this fix is limited to the PDF row list.
                    val labels = listOf("कुल हाजिरी", "कुल मजदूरी", "कुल भुगतान", "चयन का अंतर")
                    val values = listOf("${quantity(days)} दिन", "₹${money(wage)}", "₹${money(paid)}", "₹${money(wage - paid)}")
                    for (i in 0..3) {
                        val x1 = left + i * cardW
                        paint.color = paleGreen
                        c.drawRoundRect(android.graphics.RectF(x1 + 2f, cardsTop, x1 + cardW - 4f, cardsBottom), 6f, 6f, paint)
                        paint.color = green
                        paint.textSize = 9f
                        paint.typeface = Typeface.DEFAULT_BOLD
                        c.drawText(labels[i], x1 + 10f, cardsTop + 15f, paint)
                        paint.textSize = 13f
                        c.drawText(values[i], x1 + 10f, cardsTop + 34f, paint)
                    }
                    y = cardsBottom + 13f
                } else {
                    y += 7f
                }
                drawTableHeader()
            }
            fun finishPage() {
                val c = canvas ?: return
                paint.color = muted
                paint.textSize = 8.5f
                paint.typeface = Typeface.DEFAULT
                c.drawLine(left, pageH - 24f, rightEdge, pageH - 24f, paint)
                c.drawText("MAJDOOR HISAAB PRO • मजदूर हिसाब रिपोर्ट", left, pageH - 10f, paint)
                c.drawText("पेज $pageNo", rightEdge - 42f, pageH - 10f, paint)
                page?.let { doc.finishPage(it) }
            }
            fun drawRow(date: String, field: String, worker: String, attendance: String, wage: String, paid: String, balance: String, index: Int) {
                if (y + 25f > pageH - 32f) {
                    finishPage()
                    startPage(false)
                }
                val c = canvas ?: return
                val bottom = y + 25f
                paint.color = if (index % 2 == 0) android.graphics.Color.WHITE else paleGreen
                c.drawRect(left, y, rightEdge, bottom, paint)
                paint.color = grid
                paint.strokeWidth = 0.6f
                c.drawRect(left, y, rightEdge, bottom, paint)
                for (x in colX.drop(1).dropLast(1)) c.drawLine(x, y, x, bottom, paint)
                val vals = listOf(date, field, worker, attendance, wage, paid, balance)
                vals.forEachIndexed { i, value ->
                    paint.color = dark
                    paint.textSize = 9f
                    paint.typeface = if (i >= 4) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    c.drawText(fit(value, colX[i + 1] - colX[i], 9f, i >= 4), colX[i] + 4f, y + 16f, paint)
                }
                y = bottom
            }
            startPage(true)
            data class ReportLine(val date: String, val field: String, val worker: String, val workerId: String, val attendance: Double, val wage: Double, val paid: Double, val kind: Int)
            val allRows = mutableListOf<ReportLine>()
            attendanceRows.forEach { a ->
                val worker = store.labours.firstOrNull { it.id == a.labourId }?.name ?: "मजदूर हटाया गया"
                val field = store.fields.firstOrNull { it.id == a.fieldId }?.name ?: "—"
                allRows.add(ReportLine(a.date, field, worker, a.labourId, a.fraction, a.fraction * a.rate, 0.0, 0))
            }
            paymentRows.forEach { p ->
                val worker = store.labours.firstOrNull { it.id == p.labourId }?.name ?: "मजदूर हटाया गया"
                // A payment is not field work. Show a field only if its stored ID still resolves; never print a fake deleted-field label.
                val field = store.fields.firstOrNull { it.id == p.fieldId }?.name ?: "—"
                val paymentLabel = if(p.kind=="advance")"अग्रिम" else "भुगतान"
                allRows.add(ReportLine(p.date, "$paymentLabel • $field", worker, p.labourId, 0.0, 0.0, p.amount, if(p.kind=="advance")2 else 1))
            }
            // When the user selects all dates and all fields, show one combined row per worker.
            // For a date range or a specific field, retain the detailed date/field rows.
            // Aggregate only when the caller explicitly selected all dates and all fields.
            // Do not infer report mode from translated/display summary text.
            val reportRows = if (aggregateWorkerView) {
                // In all-dates/all-fields mode, include only workers with actual positive attendance
                // or a recorded payment, then produce exactly one combined row per worker.
                (attendanceRows.filter { it.fraction > 0.0 }.map { it.labourId } + paymentRows.map { it.labourId })
                    .distinct()
                    .mapNotNull { workerId ->
                        val worker = store.labours.firstOrNull { it.id == workerId }?.name ?: "मजदूर हटाया गया"
                        val workerAttendance = attendanceRows.filter { it.labourId == workerId && it.fraction > 0.0 }
                        val workerPayments = paymentRows.filter { it.labourId == workerId }
                        val days = workerAttendance.sumOf { it.fraction }
                        val wages = workerAttendance.sumOf { it.fraction * it.rate }
                        val paid = workerPayments.sumOf { it.amount }
                        ReportLine("सभी तारीखें", "सभी खेत", worker, workerId, days, wages, paid, 0)
                    }
                    .sortedBy { it.worker.lowercase(Locale.ROOT) }
            } else {
                allRows.sortWith(compareBy<ReportLine> { it.date }.thenBy { it.field }.thenBy { it.worker }.thenBy { it.kind })
                allRows
            }
            val reportWorkerIds = reportRows.map { it.workerId }.toSet()
            // Balances shown in the PDF use the full current account, never a misleading
            // negative running balance from a partial selection.
            val currentBalanceByWorker = reportWorkerIds.associateWith { workerId -> store.outstandingBalance(workerId) }
            reportRows.forEachIndexed { i, row ->
                drawRow(if (aggregateWorkerView) "सभी तारीखें" else displayDate(row.date), row.field, row.worker,
                    if (row.attendance == 0.0) "—" else quantity(row.attendance),
                    if (row.wage == 0.0) "—" else money(row.wage),
                    if (row.paid == 0.0) "—" else money(row.paid),
                    money(currentBalanceByWorker[row.workerId] ?: 0.0), i)
            }
            if (reportRows.isEmpty()) drawRow("—", "—", "कोई रिकॉर्ड नहीं", "—", "0", "0", "0", 0)
            val totalWage = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction * it.rate }
            val totalPaid = paymentRows.sumOf { it.amount }
            val currentOutstanding = currentBalanceByWorker.values.sum()
            if (y + 31f > pageH - 32f) {
                finishPage()
                startPage(false)
            }
            paint.color = paleGreen
            canvas!!.drawRoundRect(android.graphics.RectF(left, y + 4f, rightEdge, y + 32f), 5f, 5f, paint)
            paint.color = green
            paint.textSize = 10f
            paint.typeface = Typeface.DEFAULT_BOLD
            canvas!!.drawText("कुल मजदूरी: ₹${money(totalWage)}", left + 10f, y + 22f, paint)
            canvas!!.drawText("कुल भुगतान: ₹${money(totalPaid)}", left + 275f, y + 22f, paint)
            canvas!!.drawText("मौजूदा बकाया: ₹${money(currentOutstanding)}", left + 545f, y + 22f, paint)
            finishPage()
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            if (background) reportMainHandler.post {
                runCatching { shareFile(context, file, "application/pdf", "PDF साझा करें") }
                    .onFailure { e -> android.widget.Toast.makeText(context, "PDF तैयार है, लेकिन शेयर नहीं खुला: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            } else shareFile(context, file, "application/pdf", "PDF साझा करें")
        } catch (e: Exception) {
            if (background) reportMainHandler.post { android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            else android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    if (background) reportPdfExecutor.execute { generate() } else generate()
}

private fun exportReportPdf(context:Context,title:String,summary:String,lines:List<String>,background:Boolean=false){
    val generate = {
    try{
        val doc=PdfDocument(); val pageW=595; val pageH=842; val left=28f; val right=28f; val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG); paint.typeface=Typeface.DEFAULT; paint.textSize=11f
        var pageNo=1; var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54);paint.typeface=Typeface.DEFAULT_BOLD;paint.textSize=24f;canvas.drawText("MAJDOOR HISAAB PRO",left,42f,paint)
            paint.color=android.graphics.Color.BLACK;paint.textSize=19f;canvas.drawText(title.take(45),left,76f,paint)
            paint.textSize=12f;paint.typeface=Typeface.DEFAULT
            wrapReportText(summary,paint,maxW).take(2).forEachIndexed{i,t->canvas.drawText(t,left,100f+i*17f,paint)}
        }
        header(); var y=140f; var rowNo=1
        lines.forEach{line->
            val wrapped=wrapReportText("$rowNo. $line",paint,maxW)
            for(part in wrapped){
                if(y>805f){if(background){paint.typeface=Typeface.DEFAULT;paint.textSize=9f;paint.color=android.graphics.Color.DKGRAY;canvas.drawText("पृष्ठ $pageNo",pageW-right-48f,pageH-16f,paint)};doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header();y=140f}
                canvas.drawText(part,left,y,paint);y+=18f
            }
            rowNo++
            y+=4f
        }
        if(background){paint.typeface=Typeface.DEFAULT;paint.textSize=9f;paint.color=android.graphics.Color.DKGRAY;canvas.drawText("पृष्ठ $pageNo",pageW-right-48f,pageH-16f,paint)}
        doc.finishPage(page); val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close();if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{shareError->android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${shareError.message}",android.widget.Toast.LENGTH_LONG).show()}} else shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()} else android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
    }
    if(background)reportPdfExecutor.execute{generate()} else generate()
}

private fun caneSeason(date:String=today()):String{
    return try{
        val y=date.take(4).toInt(); val m=date.substring(5,7).toInt()
        if(m>=4) "$y-${(y+1).toString().takeLast(2)}" else "${y-1}-${y.toString().takeLast(2)}"
    }catch(_:Exception){"2026-27"}
}


@Composable
private fun CanePeelingScreen(store:Store,onBack:()->Unit){
    var tab by rememberSaveable{mutableStateOf(0)}
    var showEntry by remember{mutableStateOf(false)}
    var showPayment by remember{mutableStateOf(false)}
    var showLabours by remember{mutableStateOf(false)}
    var quickAddDate by remember{mutableStateOf(today())}
    var quickAddField by remember{mutableStateOf("")}
    var selectedLabour by remember{mutableStateOf<String?>(null)}
    var selectedField by remember{mutableStateOf<String?>(null)}
    var editEntry by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedEdit by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedDelete by remember{mutableStateOf<CanePeeling?>(null)}
    var editPayment by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentEdit by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentDelete by remember{mutableStateOf<CanePeelingPayment?>(null)}

    if(showLabours){
        CanePeelingLabourScreen(store,{showLabours=false})
        return
    }
    if(selectedLabour!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingLabourDetail(store,selectedLabour!!,{selectedLabour=null},{showPayment=true})
        }
        if(showPayment){CanePeelingPaymentDialog(store,null,selectedLabour!!){showPayment=false}}
        return
    }
    if(selectedField!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingFieldDetail(store,selectedField!!,{selectedField=null},{showEntry=true})
        }
        if(showEntry){CanePeelingSingleEntryDialog(store,selectedField!!,quickAddDate){showEntry=false;selectedField=null}}
        return
    }
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌿 गन्ना छिलाई • फांदी हिसाब",onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=12.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
            listOf("मुख्य","Search / Filter","भुगतान").forEachIndexed{index,label->FilterChip(selected=tab==index,onClick={tab=index},label={Text(label)})}
        }
        when(tab){
            0->CanePeelingHome(store,{quickAddDate=today();quickAddField="";showEntry=true},{tab=1},{tab=2},{showLabours=true})
            1->CanePeelingSearch(store,{selectedLabour=it},{selectedField=it},{editEntry=it;showEntry=true},{protectedDelete=it})
            else->CanePeelingPayments(store,{protectedPaymentEdit=it},{protectedPaymentDelete=it},{selectedLabour=it.labourId})
        }
    }
    if(showEntry){if(editEntry!=null) CanePeelingEntryDialog(store,editEntry,""){showEntry=false;editEntry=null} else CanePeelingSingleEntryDialog(store,quickAddField,quickAddDate){showEntry=false}}
    protectedDelete?.let{DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ","यह गन्ना छिलाई रिकॉर्ड स्थायी रूप से हट जाएगा।",{store.deleteCanePeeling(it.id);protectedDelete=null},{protectedDelete=null})}
    if(showPayment){CanePeelingPaymentDialog(store,null,"",{showPayment=false})}
    protectedPaymentEdit?.let{DeviceCredentialGate("छिलाई भुगतान बदलें","भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।",{editPayment=it;protectedPaymentEdit=null},{protectedPaymentEdit=null})}
    protectedPaymentDelete?.let{DeviceCredentialDeleteGate("छिलाई भुगतान हटाएँ","यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।",{store.deleteCanePeelingPayment(it.id);protectedPaymentDelete=null},{protectedPaymentDelete=null})}
    editPayment?.let{CanePeelingPaymentDialog(store,it,"",{editPayment=null})}
}

@Composable
private fun CanePeelingHome(store:Store,onAdd:()->Unit,onSearch:()->Unit,onPayments:()->Unit,onLabours:()->Unit){
    var rateText by remember(store.fandiRate){mutableStateOf(money(store.fandiRate))}
    var rateMessage by remember{mutableStateOf("")}
    var showRateDialog by remember{mutableStateOf(false)}
    val day=today()
    val todayRows=store.canePeelings.filter{it.date==day}
    val todayFandi=todayRows.sumOf{it.fandi}
    val todayAmount=todayRows.sumOf{it.total}
    val paidToday=store.canePeelingPayments.filter{it.date==day}.sumOf{it.amount}
    val todayWorkers=todayRows.map{it.labourId}.distinct().size
    val recentDates=store.canePeelings.map{it.date}.distinct().sortedDescending().take(10)
    if(showRateDialog) AlertDialog(
        onDismissRequest={showRateDialog=false},
        title={Text("फांदी का रेट बदलें",fontWeight=FontWeight.Bold)},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("वर्तमान रेट: ₹${money(store.fandiRate)} प्रति फांदी")
            OutlinedTextField(value=rateText,onValueChange={rateText=it.filter{c->c.isDigit()||c=='.'}},singleLine=true,label={Text("नया रेट (₹ प्रति फांदी)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),modifier=Modifier.fillMaxWidth())
            Text("नया रेट केवल आगे की एंट्री पर लागू होगा। पुराने रिकॉर्ड नहीं बदलेंगे।",fontSize=12.sp,color=AppMuted)
            if(rateMessage.isNotBlank()) Text(rateMessage,fontSize=12.sp,color=if(rateMessage.contains("सेव")) Green else Color(0xFFB3261E))
        }},
        confirmButton={Button(onClick={val r=rateText.toDoubleOrNull();if(r!=null&&r>0&&r.isFinite()){store.updateFandiRate(r);rateMessage="नया रेट सेव हो गया।";showRateDialog=false}else rateMessage="सही रेट दर्ज करें।"},colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("रेट सेव करें")}},
        dismissButton={TextButton(onClick={showRateDialog=false}){Text("रद्द करें")}}
    )
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){
                Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("गन्ना छिलाई",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
                            Text("दैनिक फांदी और मजदूरी का हिसाब",color=Color.White.copy(alpha=.82f),fontSize=12.sp)
                        }
                        Column(horizontalAlignment=Alignment.End,verticalArrangement=Arrangement.spacedBy(5.dp)){
                            Surface(shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.14f)){
                                Column(Modifier.padding(horizontal=10.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally){
                                    Icon(Icons.Default.DateRange,null,tint=Color.White)
                                    Text(displayDate(day),fontSize=10.sp,color=Color.White,fontWeight=FontWeight.Bold)
                                }
                            }
                            TextButton(onClick={rateText=money(store.fandiRate);rateMessage="";showRateDialog=true},contentPadding=PaddingValues(horizontal=8.dp,vertical=0.dp)){
                                Icon(Icons.Default.Settings,null,tint=Color.White,modifier=Modifier.size(15.dp));Spacer(Modifier.width(3.dp));Text("रेट बदलें",fontSize=11.sp,color=Color.White,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की फांदी",money(todayFandi),Color(0xFFE4F6EA))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की राशि","₹${money(todayAmount)}",Color(0xFFE5F0FF))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज भुगतान","₹${money(paidToday)}",Color(0xFFFFF0D9))}
                    }
                    Text("आज $todayWorkers मजदूरों की एंट्री",color=Color.White.copy(alpha=.9f),fontSize=12.sp)
                }
            }
        }
        item{
            Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("आज की छिलाई दर्ज करें",fontWeight=FontWeight.Bold,fontSize=16.sp)
            }
        }
        item{
            Button(onClick=onLabours,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){
                Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("फांदी मजदूर सूची / नया मजदूर",fontWeight=FontWeight.Bold,fontSize=14.sp)
            }
        }
        item{Text("पहले मजदूर जोड़ें, फिर ‘आज की छिलाई दर्ज करें’ से एक-एक मजदूर की फांदी सेव करें।",fontSize=12.sp,color=AppMuted,modifier=Modifier.padding(horizontal=3.dp))}
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
                OutlinedButton(onClick=onSearch,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Search,null);Spacer(Modifier.width(5.dp));Text("खोजें / रिकॉर्ड")
                }
                OutlinedButton(onClick=onPayments,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Payments,null);Spacer(Modifier.width(5.dp));Text("भुगतान")
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("हाल की छिलाई",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,color=AppAccentText)
                    Text("तारीख के अनुसार रिकॉर्ड और कुल राशि",fontSize=11.sp,color=AppMuted)
                }
                Surface(shape=RoundedCornerShape(50),color=Color(0xFFE6F5EC)){
                    Text("${store.canePeelings.size} रिकॉर्ड",Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=11.sp,color=AppAccentText,fontWeight=FontWeight.Bold)
                }
            }
        }
        if(recentDates.isEmpty()) item{EmptyCard("अभी कोई गन्ना छिलाई रिकॉर्ड नहीं है। शुरू करने के लिए ‘आज की छिलाई दर्ज करें’ दबाएँ।")}
        recentDates.forEach{d->
            item(key="cane_day_$d"){
                val rows=store.canePeelings.filter{it.date==d}
                val fieldNames=rows.map{it.fieldId}.filter{it.isNotBlank()}.distinct().mapNotNull{id->store.fields.firstOrNull{it.id==id}?.name}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFFE8F5ED)){
                                Icon(Icons.Default.DateRange,null,Modifier.padding(10.dp),tint=AppAccentText)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)){
                                Text(displayDate(d),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                                Text(if(fieldNames.isEmpty())"खेत नहीं चुना गया" else fieldNames.joinToString(", "),fontSize=11.sp,color=AppMuted,maxLines=2)
                            }
                            Text("₹${money(rows.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=Green)
                        }
                        Divider(color=Color(0xFFE8ECE9))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                            Text("${rows.map{it.labourId}.distinct().size} मजदूर",fontSize=12.sp,color=AppText)
                            Text("${money(rows.sumOf{it.fandi})} फांदी",fontSize=13.sp,fontWeight=FontWeight.Bold,color=AppAccentText)
                            Text("${rows.size} एंट्री",fontSize=11.sp,color=AppMuted)
                        }
                    }
                }
            }
        }
    }
}
@Composable private fun CaneMiniStat(label:String,value:String,bg:Color){Card(colors=CardDefaults.cardColors(containerColor=bg),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(8.dp)){Text(label,fontSize=9.sp,color=AppAccentText);Text(value,fontWeight=FontWeight.ExtraBold,fontSize=15.sp,color=AppAccentText)}}}
@Composable private fun EmptyCard(text:String){Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp)){Text(text,Modifier.padding(16.dp),color=AppMuted)}}

@Composable
private fun CanePeelingSingleEntryDialog(store:Store,presetField:String,initialDate:String=today(),onClose:()->Unit){
    var date by remember{mutableStateOf(initialDate)}
    var field by remember{mutableStateOf(presetField)}
    var labour by remember{mutableStateOf(store.fandiLabours.firstOrNull()?.id.orEmpty())}
    var fandi by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    val rate=store.fandiRate
    SimpleDialog("एक मजदूर की फांदी दर्ज करें",onClose){
        Text("एक बार में केवल एक मजदूर की एंट्री सेव होगी।",fontSize=12.sp,color=AppMuted)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("मजदूर *",store.fandiLabours.map{it.id to it.name},labour){labour=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        OutlinedTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},modifier=Modifier.fillMaxWidth(),label={Text("फांदी की संख्या *")},singleLine=true)
        Text("रेट: ₹${money(rate)} प्रति फांदी",fontWeight=FontWeight.Bold,color=AppAccentText)
        val amount=(fandi.toDoubleOrNull()?:0.0)*rate
        Card(colors=CardDefaults.cardColors(containerColor=AppPanelBg),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल मजदूरी",fontWeight=FontWeight.Bold);Text("₹${money(amount)}",fontWeight=FontWeight.ExtraBold,color=Green)}}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={val f=fandi.toDoubleOrNull()?:0.0;when{labour.isBlank()->error="पहले मजदूर जोड़ें।";!validDate(date)->error="सही तारीख चुनें।";f<=0||!f.isFinite()->error="फांदी की संख्या सही डालें।";rate<=0||!rate.isFinite()->error="पहले सही फांदी रेट सेव करें।";store.canePeelings.any{it.labourId==labour&&it.fieldId==field&&it.date==date}->error="इस मजदूर की इस तारीख और खेत की एंट्री पहले से है।";else->{val saved=store.addCanePeeling(CanePeeling(UUID.randomUUID().toString(),labour,field,date,f,rate,amount));if(saved)onClose() else error="रिकॉर्ड सेव नहीं हुआ। संभव है यह एंट्री पहले से मौजूद हो।"}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("✓ फांदी सेव करें")}
    }
}

@Composable
private fun CanePeelingEntryDialog(store:Store,existing:CanePeeling?,presetField:String,onClose:()->Unit){
    var date by remember{mutableStateOf(existing?.date?:today())}; var field by remember{mutableStateOf(existing?.fieldId?:presetField)}; var labour by remember{mutableStateOf(existing?.labourId?:store.fandiLabours.firstOrNull()?.id.orEmpty())}; var fandi by remember{mutableStateOf(if(existing!=null) money(existing.fandi) else "")}; var error by remember{mutableStateOf("")}
    val r=existing?.rate ?: store.fandiRate
    SimpleDialog(if(existing==null) "आज की छिलाई दर्ज करें" else "छिलाई रिकॉर्ड बदलें",onClose){
        Text("फांदी रेट Settings में एक बार सेट करें। नई एंट्री में वही रेट अपने-आप लगेगा। पुराने रिकॉर्ड का सेव किया हुआ रेट बदलता नहीं है।",fontSize=11.sp,color=AppMuted)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        ChoiceField("मजदूर *",store.fandiLabours.map{it.id to it.name},labour){labour=it}
        OutlinedTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},label={Text("फांदी")},singleLine=true)
        Text("फांदी रेट: ₹${money(r)} / फांदी",fontWeight=FontWeight.Bold,color=AppAccentText)
        val f=fandi.toDoubleOrNull()?:0.0
        val total=f*r
        Card(colors=CardDefaults.cardColors(containerColor=AppPanelBg),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${money(total)}",fontWeight=FontWeight.ExtraBold,color=Green)}}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={when{labour.isBlank()->error="मजदूर चुनें।";!validDate(date)->error="सही तारीख चुनें।";f<=0||!f.isFinite()->error="फांदी सही डालें।";r<=0||!r.isFinite()->error="Settings में फांदी रेट सेट करें।";else->{val duplicate=store.canePeelings.any{it.id!=existing?.id&&it.labourId==labour&&it.fieldId==field&&it.date==date};if(duplicate){error="इस मजदूर की इस तारीख और खेत की फांदी पहले से दर्ज है। पुराने रिकॉर्ड को खोलकर बदलें।"}else{val x=(existing ?: CanePeeling(UUID.randomUUID().toString(),labour,field,date,f,r,total)).copy(labourId=labour,fieldId=field,date=date,fandi=f,rate=r,total=total);val saved=if(existing==null)store.addCanePeeling(x) else store.updateCanePeeling(x);if(saved)onClose() else error="रिकॉर्ड सेव नहीं हुआ। डुप्लिकेट या अमान्य रिकॉर्ड जाँचें।"}}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("✓ फांदी सेव करें")}
    }
}

@Composable
private fun CanePeelingSearch(store:Store,onLabour:(String)->Unit,onField:(String)->Unit,onEdit:(CanePeeling)->Unit,onDelete:(CanePeeling)->Unit){
    var query by rememberSaveable{mutableStateOf("")}
    var from by rememberSaveable{mutableStateOf("")}
    var to by rememberSaveable{mutableStateOf("")}
    var labourId by rememberSaveable{mutableStateOf("")}
    var fieldId by rememberSaveable{mutableStateOf("")}
    var rate by rememberSaveable{mutableStateOf("")}
    var paymentStatus by rememberSaveable{mutableStateOf("")}
    var showExport by remember{mutableStateOf(false)}

    val base=store.canePeelings.filter{row->
        val l=store.fandiLabours.firstOrNull{it.id==row.labourId}
        val f=store.fields.firstOrNull{it.id==row.fieldId}
        val q=query.trim().lowercase(Locale.getDefault())
        val earned=store.canePeelings.filter{it.labourId==row.labourId}.sumOf{it.total}
        val paid=store.canePeelingPayments.filter{it.labourId==row.labourId}.sumOf{it.amount}
        val bal=earned-paid
        (q.isBlank()||listOf(l?.name.orEmpty(),l?.mobile.orEmpty(),f?.name.orEmpty(),row.date,row.fandi.toString(),row.rate.toString(),row.total.toString()).any{it.lowercase(Locale.getDefault()).contains(q)}) &&
        (from.isBlank()||row.date>=from)&&(to.isBlank()||row.date<=to) &&
        (labourId.isBlank()||row.labourId==labourId)&&(fieldId.isBlank()||row.fieldId==fieldId) &&
        (rate.isBlank()||row.rate==rate.toDoubleOrNull()) &&
        (paymentStatus.isBlank() || when(paymentStatus){"paid"->bal<=0.009;"partial"->paid>0.009&&bal>0.009;"pending"->paid<=0.009&&bal>0.009;else->true})
    }.sortedWith(compareByDescending<CanePeeling>{it.date}.thenBy{store.fandiLabours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})

    val totalFandi=base.sumOf{it.fandi}
    val totalAmount=base.sumOf{it.total}
    val workers=base.map{it.labourId}.distinct().size
    val fields=base.map{it.fieldId}.filter{it.isNotBlank()}.distinct().size
    val days=base.map{it.date}.distinct().size
    val context=LocalContext.current

    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item{
            OutlinedTextField(
                value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                label={Text("नाम, मोबाइल, खेत, तारीख या राशि खोजें")},
                leadingIcon={Icon(Icons.Default.Search,null)},
                trailingIcon={if(query.isNotBlank()){IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}}}
            )
        }
        item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("फिल्टर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=AppAccentText,modifier=Modifier.weight(1f));TextButton(onClick={query="";from="";to="";labourId="";fieldId="";rate="";paymentStatus=""}){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("रीसेट")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){DateFilterField("से",from){from=it}};Box(Modifier.weight(1f)){DateFilterField("तक",to){to=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("मजदूर",listOf("" to "सभी मजदूर")+store.fandiLabours.map{it.id to it.name},labourId){labourId=it}};Box(Modifier.weight(1f)){ChoiceField("खेत",listOf("" to "सभी खेत")+store.fields.map{it.id to it.name},fieldId){fieldId=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("रेट",listOf("" to "सभी रेट")+store.canePeelings.map{it.rate}.distinct().sorted().map{it.toString() to "₹${money(it)} / फांदी"},rate){rate=it}};Box(Modifier.weight(1f)){ChoiceField("भुगतान",listOf("" to "सभी","paid" to "पूरा भुगतान","partial" to "आंशिक भुगतान","pending" to "पूरा बाकी"),paymentStatus){paymentStatus=it}}}}

        item{
            Card(colors=CardDefaults.cardColors(containerColor=AppPanelBg),shape=RoundedCornerShape(16.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${base.size} रिकॉर्ड");Text("$workers मजदूर");Text("$fields खेत");Text("$days दिन")}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल फांदी",fontWeight=FontWeight.Bold);Text(money(totalFandi),fontWeight=FontWeight.ExtraBold,color=Green);Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${money(totalAmount)}",fontWeight=FontWeight.ExtraBold,color=Green)}
                }
            }
        }

        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Groups,null,tint=Green,modifier=Modifier.size(26.dp));Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("सभी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=AppAccentText);Text("नाम पर टैप करें → पूरा हिसाब",fontSize=11.sp,color=AppMuted)}}
                    if(store.fandiLabours.isEmpty()) Text("अभी कोई फांदी मजदूर नहीं है।",color=AppMuted)
                    else store.fandiLabours.sortedBy{it.name.lowercase(Locale.getDefault())}.forEach{l->
                        val rr=store.canePeelings.filter{it.labourId==l.id}
                        val earned=rr.sumOf{it.total}
                        val paid=store.canePeelingPayments.filter{it.labourId==l.id}.sumOf{it.amount}
                        Card(Modifier.fillMaxWidth().clickable{onLabour(l.id)},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF4FAF7))){
                            Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                                PhotoThumb(l.photo);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी • ₹${money(earned)}",fontSize=11.sp,color=Green);if(paid>0)Text("भुगतान ₹${money(paid)} • बाकी ₹${money(earned-paid)}",fontSize=10.sp,color=AppMuted)};Icon(Icons.Default.ChevronRight,null,tint=Green)}
                        }
                    }
                }
            }
        }

        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                Button(onClick={showExport=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4FB3))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF / Excel")}
            }
        }

        if(base.isEmpty()) item{EmptyCard("इस Filter से कोई रिकॉर्ड नहीं मिला।")}
        base.forEach{row->
            item(key=row.id){
                val l=store.fandiLabours.firstOrNull{it.id==row.labourId}; val f=store.fields.firstOrNull{it.id==row.fieldId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp)){
                    Column(Modifier.padding(11.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f).clickable{onLabour(row.labourId)}){Text(l?.name?:"मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text(displayDate(row.date),fontSize=11.sp,color=AppMuted);Text("🌾 ${f?.name?:"खेत नहीं चुना"}",fontSize=11.sp,color=Green,modifier=Modifier.clickable{if(f!=null)onField(f.id)})}
                            Text("₹${money(row.total)}",fontWeight=FontWeight.ExtraBold,color=Green)
                            IconButton(onClick={onEdit(row)}){Icon(Icons.Default.Edit,null,tint=Green)}
                            IconButton(onClick={onDelete(row)}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${money(row.fandi)} फांदी");Text("₹${money(row.rate)} / फांदी",color=AppMuted);Text("₹${money(row.total)}",fontWeight=FontWeight.Bold)}
                    }
                }
            }
        }
    }
    if(showExport) CanePeelingExportDialog(store,base){showExport=false}
}

@Composable
private fun CanePeelingExportDialog(store:Store,rows:List<CanePeeling>,onClose:()->Unit){
    val allIds=remember(rows){rows.map{it.labourId}.distinct()}
    var selected by remember(rows){mutableStateOf(allIds.toSet())}
    val context=LocalContext.current
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("रिपोर्ट बनाएं",fontWeight=FontWeight.ExtraBold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp)){
            Text("सभी मजदूर या अपनी पसंद के मजदूर चुनें।",fontSize=12.sp,color=AppMuted)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={selected=allIds.toSet()},modifier=Modifier.weight(1f)){Text("✓ Mark All")}
                OutlinedButton(onClick={selected=emptySet()},modifier=Modifier.weight(1f)){Text("सब हटाएं")}
            }
            if(allIds.isEmpty()) Text("कोई रिकॉर्ड उपलब्ध नहीं है।",color=AppMuted)
            else LazyColumn(Modifier.weight(1f,false),verticalArrangement=Arrangement.spacedBy(2.dp)){
                items(allIds){id->
                    val l=store.fandiLabours.firstOrNull{it.id==id}
                    Row(Modifier.fillMaxWidth().clickable{selected=if(selected.contains(id))selected-id else selected+id},verticalAlignment=Alignment.CenterVertically){Checkbox(checked=selected.contains(id),onCheckedChange={checked->selected=if(checked)selected+id else selected-id});Text(l?.name?:"मजदूर",fontWeight=FontWeight.SemiBold)}
                }
            }
            Text("${selected.size} मजदूर चुने गए",fontWeight=FontWeight.Bold,color=Green)
        }},
        confirmButton={Button(onClick={
            if(selected.isEmpty()) return@Button
            val chosen=rows.filter{selected.contains(it.labourId)}
            val lines=chosen.map{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId};val f=store.fields.firstOrNull{it.id==r.fieldId};"${displayDate(r.date)} • ${l?.name?:"मजदूर"} • ${f?.name?:"खेत नहीं चुना"} • ${money(r.fandi)} फांदी × ₹${money(r.rate)} = ₹${money(r.total)}"}
            exportReportPdf(context,"गन्ना_छिलाई_रिपोर्ट","${selected.size} मजदूर • ${chosen.map{it.fieldId}.distinct().size} खेत • ${chosen.map{it.date}.distinct().size} दिन • ${money(chosen.sumOf{it.fandi})} फांदी • ₹${money(chosen.sumOf{it.total})}",lines);onClose()
        },enabled=selected.isNotEmpty()){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF बनाएं")}},
        dismissButton={OutlinedButton(onClick={
            if(selected.isEmpty()) return@OutlinedButton
            exportCanePeelingCsv(context,rows.filter{selected.contains(it.labourId)},store);onClose()
        }){Text("CSV / Excel")}}
    )
}

private fun buildCanePeelingCsv(rows:List<CanePeeling>,store:Store):String = buildString{
    append("तारीख,मजदूर,खेत,फांदी,रेट,राशि\n")
    rows.forEach{r->
        val labour=store.fandiLabours.firstOrNull{it.id==r.labourId}?.name.orEmpty()
        val field=store.fields.firstOrNull{it.id==r.fieldId}?.name ?: "खेत नहीं चुना"
        append(listOf(displayDate(r.date),labour,field,quantity(r.fandi),money(r.rate),money(r.total)).joinToString(","){csvCell(it)}).append('\n')
    }
}

private fun exportCanePeelingCsv(context:Context,rows:List<CanePeeling>,store:Store){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Chhilai_${System.currentTimeMillis()}.csv")
        file.writeText("\uFEFF"+buildCanePeelingCsv(rows,store),Charsets.UTF_8)
        shareFile(context,file,"text/csv","CSV साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"CSV report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable
private fun DateFilterField(label:String,value:String,onSelected:(String)->Unit){
    val context=LocalContext.current
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        OutlinedButton(onClick={
            val parsed=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value.ifBlank{today()})}catch(_:Exception){Date()}
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(context,{_,year,month,day->
                val selected=Calendar.getInstance().apply{set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)}
                onSelected(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time))
            },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=System.currentTimeMillis()}.show()
        },modifier=Modifier.weight(1f)){Text(if(value.isBlank()) "$label: कोई सीमा" else "$label: ${displayDate(value)}",maxLines=1);Spacer(Modifier.width(4.dp));Icon(Icons.Default.DateRange,null)}
        if(value.isNotBlank()) IconButton(onClick={onSelected("")}){Icon(Icons.Default.Clear,null)}
    }
}

@Composable
private fun CanePeelingLabourScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<FandiLabour?>(null)}
    var delete by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedEdit by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedDelete by remember{mutableStateOf<FandiLabour?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    val visibleWorkers=store.fandiLabours.filter{query.isBlank()||it.name.contains(query,true)||it.mobile.contains(query,true)||it.address.contains(query,true)}.sortedBy{it.name.lowercase(Locale.ROOT)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("👷 फांदी मजदूर",onBack)
        Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
            Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("फांदी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=22.sp,color=Color.White)
                    Text("${store.fandiLabours.size} सेव मजदूर • नाम दोबारा सेव नहीं होगा",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                }
                Button(onClick={add=true},shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("नया मजदूर")}
            }
        }
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=7.dp),singleLine=true,label={Text("मजदूर का नाम / मोबाइल खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}},shape=RoundedCornerShape(15.dp))
        if(visibleWorkers.isEmpty()){
            Box(Modifier.weight(1f).fillMaxWidth().padding(14.dp),contentAlignment=Alignment.TopCenter){EmptyCard(if(query.isBlank())"अभी कोई फांदी मजदूर नहीं है। ‘नया मजदूर’ दबाकर जोड़ें।" else "इस नाम से कोई मजदूर नहीं मिला।")}
        }else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=14.dp)){
            items(visibleWorkers,key={it.id}){l->
                val workRows=store.canePeelings.filter{it.labourId==l.id}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(1.dp)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo);Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                            Text(l.mobile.ifBlank{"मोबाइल नहीं दिया"},fontSize=11.sp,color=AppMuted)
                            Text("${workRows.size} रिकॉर्ड • ${money(workRows.sumOf{it.fandi})} फांदी • ₹${money(workRows.sumOf{it.total})}",fontSize=11.sp,color=Green,fontWeight=FontWeight.SemiBold)
                        }
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FandiLabourDialog(store,null){add=false}
    protectedEdit?.let{worker->DeviceCredentialGate("फांदी मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=worker;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{worker->DeviceCredentialDeleteGate("फांदी मजदूर हटाएँ","पुराने छिलाई/भुगतान रिकॉर्ड सुरक्षित रखने के लिए रिकॉर्ड जुड़े होने पर मजदूर हटाया नहीं जा सकेगा।",{delete=worker;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FandiLabourDialog(store,edit){edit=null}
    delete?.let{worker->ConfirmDialog("फांदी मजदूर हटाएँ?","यदि इस मजदूर की छिलाई या भुगतान हिस्ट्री है, तो रिकॉर्ड की सुरक्षा के लिए हटाना रोका जाएगा।",{val removed=store.deleteFandiLabour(worker.id);if(!removed)android.widget.Toast.makeText(context,"इस मजदूर का हिस्ट्री रिकॉर्ड मौजूद है। हिसाब सुरक्षित रखने के लिए मजदूर नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show();delete=null},{delete=null})}
}
@Composable
private fun FandiLabourDialog(store:Store,existing:FandiLabour?,onClose:()->Unit){
    var name by remember{mutableStateOf(existing?.name.orEmpty())}
    var address by remember{mutableStateOf(existing?.address.orEmpty())}
    var mobile by remember{mutableStateOf(existing?.mobile.orEmpty())}
    var photo by remember{mutableStateOf(existing?.photo.orEmpty())}
    var showExtra by remember{mutableStateOf(existing!=null)}
    var error by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank())photo=persisted}
    }
    SimpleDialog(if(existing==null)"फांदी मजदूर जोड़ें" else "फांदी मजदूर बदलें",onClose){
        Text("पहले मजदूर का नाम सेव करें। फांदी की एंट्री अलग से ‘एक मजदूर की फांदी दर्ज करें’ से होगी।",fontSize=12.sp,color=AppMuted)
        OutlinedTextField(value=name,onValueChange={name=it;error=""},label={Text("मजदूर का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        TextButton(onClick={showExtra=!showExtra}){Text(if(showExtra)"− अतिरिक्त जानकारी छिपाएँ" else "+ पता / मोबाइल / फोटो (वैकल्पिक)")}
        if(showExtra){
            OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (वैकल्पिक)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=mobile,onValueChange={mobile=it.filter{c->c.isDigit()||c=='+'};error=""},label={Text("मोबाइल (वैकल्पिक)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (वैकल्पिक)" else "✓ फोटो चुनी गई")}
        }
        if(error.isNotBlank())Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE8E6)),shape=RoundedCornerShape(12.dp)){Text(error,Modifier.padding(10.dp),color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)}
        Button(enabled=!saving,onClick={
            if(!saving){
                val normalizedName=name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
                val sameNameAlreadySaved=store.fandiLabours.any{old->
                    old.id!=existing?.id && old.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)==normalizedName
                }
                val phoneKey=mobile.filter{it.isDigit()}
                val duplicatePhone=phoneKey.length>=7 && store.fandiLabours.any{old->
                    old.id!=existing?.id && old.mobile.filter{it.isDigit()}.let{it.length>=7&&it==phoneKey}
                }
                when{
                    name.isBlank()->error="मजदूर का नाम लिखें।"
                    sameNameAlreadySaved->error="यह नाम पहले से सेव है। उसी मजदूर को सूची से चुनें; नाम दोबारा सेव नहीं होगा।"
                    duplicatePhone->error="यह मोबाइल नंबर पहले से सेव है। मौजूदा मजदूर की जानकारी देखें।"
                    else->{
                        saving=true
                        val x=FandiLabour(existing?.id?:ownerId,name.trim(),address.trim(),existing?.rate?:0.0,mobile.trim(),photo)
                        val saved=if(existing==null)store.addFandiLabour(x) else store.updateFandiLabour(x)
                        if(saved)onClose() else {error="मजदूर सेव नहीं हुआ। नाम या मोबाइल पहले से मौजूद है या जानकारी गलत है।";saving=false}
                    }
                }
            }
        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){
            Text(if(saving)"सेव हो रहा है…" else if(existing==null)"✓ फांदी मजदूर सेव करें" else "✓ बदलाव सेव करें")
        }
    }
}

@Composable
private fun CanePeelingLabourDetail(
    store: Store,
    labourId: String,
    onBack: () -> Unit,
    onPay: () -> Unit
) {
    val labour = store.fandiLabours.firstOrNull { it.id == labourId }
    if (labour == null) { onBack(); return }

    val rows = store.canePeelings.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val paid = store.canePeelingPayments.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val earned = rows.sumOf { it.total }
    val paidTotal = paid.sumOf { it.amount }
    val balance = earned - paidTotal
    val fields = rows.map { it.fieldId }.distinct()
    val days = rows.map { it.date }.distinct().size

    var selectedFieldId by remember { mutableStateOf<String?>(null) }
    var selectedRow by remember { mutableStateOf<CanePeeling?>(null) }
    var selectedPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedEdit by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedDelete by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedPaymentEdit by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedPaymentDelete by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var editRow by remember { mutableStateOf<CanePeeling?>(null) }
    var editPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("👷 ${labour.name} • पूरा हिसाब", onBack)
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = AppPanelBg)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoThumb(labour.photo); Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(labour.name, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color=AppAccentText)
                            if (labour.mobile.isNotBlank()) Text(labour.mobile, fontSize = 11.sp, color = AppMuted)
                            Text("गन्ना छिलाई / फांदी मजदूर", fontSize = 11.sp, color = Green)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = CardBg), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.weight(1f)) { Stat("कुल दिन", days.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल खेत", fields.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल रिकॉर्ड", rows.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("फांदी", rows.sumOf { it.fandi }) }
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            SummaryMoneyCard("कुल छिलाई राशि", "₹${money(earned)}", Green, Modifier.weight(1f))
                            SummaryMoneyCard("कुल भुगतान", "₹${money(paidTotal)}", Color(0xFF276B8A), Modifier.weight(1f))
                            SummaryMoneyCard("बाकी", "₹${money(balance)}", if (balance > 0) Color(0xFFB3261E) else Green, Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                Button(onClick = onPay, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Icon(Icons.Default.Payments, null); Spacer(Modifier.width(7.dp)); Text("इस मजदूर को भुगतान दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            item { SectionTitle("🌾 खेतवार हिसाब", "हर खेत में कितने दिन, फांदी और राशि • कार्ड पर टैप करें") }
            if (fields.isEmpty()) item { EmptyCard("इस मजदूर का अभी कोई छिलाई रिकॉर्ड नहीं है।") }
            fields.forEach { fieldId ->
                item(key = "field_$fieldId") {
                    val fieldRows = rows.filter { it.fieldId == fieldId }
                    val fieldName = store.fields.firstOrNull { it.id == fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedFieldId = fieldId },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = CardBg)
                    ) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🌾", fontSize = 27.sp); Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(fieldName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color=AppAccentText)
                                Text("${fieldRows.map { it.date }.distinct().size} दिन • ${money(fieldRows.sumOf { it.fandi })} फांदी", fontSize = 12.sp, color = AppMuted)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹${money(fieldRows.sumOf { it.total })}", fontWeight = FontWeight.ExtraBold, color = Green)
                                Text("विवरण देखें ›", fontSize = 10.sp, color = AppMuted)
                            }
                        }
                    }
                }
            }
            item { SectionTitle("📅 तारीखवार पूरा हिसाब", "हर काम का पूरा रिकॉर्ड • रिकॉर्ड पर टैप करें") }
            rows.forEach { row ->
                item(key = "day_${row.id}") {
                    val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedRow = row },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = CardBg)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(104.dp)) {
                                Text(displayDate(row.date), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color=AppAccentText)
                                Text(try { SimpleDateFormat("EEEE", Locale("hi", "IN")).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(row.date) ?: Date()) } catch (_: Exception) { "" }, fontSize = 10.sp, color = AppMuted)
                            }
                            Column(Modifier.weight(1f)) {
                                Text("🌾 $fieldName", fontWeight = FontWeight.SemiBold)
                                Text("${money(row.fandi)} फांदी × ₹${money(row.rate)}", fontSize = 12.sp, color = AppMuted)
                                Text("₹${money(row.total)}", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                            }
                            Text("›", fontSize = 26.sp, color = Green)
                        }
                    }
                }
            }
            item { SectionTitle("💳 भुगतान इतिहास", "किस दिन कितने रुपये दिए गए • भुगतान पर टैप करें") }
            if (paid.isEmpty()) item { EmptyCard("अभी कोई भुगतान दर्ज नहीं है।") }
            paid.forEach { payment ->
                item(key = "payment_${payment.id}") {
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedPayment = payment },
                        RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = CardBg)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(displayDate(payment.date), fontWeight = FontWeight.Bold)
                                Text(payment.method.ifBlank { "नकद" }, fontSize = 11.sp, color = AppMuted)
                                if (payment.note.isNotBlank()) Text(payment.note, fontSize = 11.sp, color = AppMuted)
                            }
                            Text("₹${money(payment.amount)}  ›", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                        }
                    }
                }
            }
        }
    }

    selectedFieldId?.let { fid ->
        val field = store.fields.firstOrNull { it.id == fid }
        val fr = rows.filter { it.fieldId == fid }
        SimpleDialog("🌾 ${field?.name ?: "खेत"} • पूरा हिसाब", { selectedFieldId = null }) {
            Text("कुल दिन: ${fr.map { it.date }.distinct().size}")
            Text("कुल फांदी: ${money(fr.sumOf { it.fandi })}")
            Text("कुल राशि: ₹${money(fr.sumOf { it.total })}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(6.dp))
            fr.forEach { r ->
                Text("${displayDate(r.date)} • ${money(r.fandi)} फांदी × ₹${money(r.rate)} = ₹${money(r.total)}", fontSize = 12.sp)
            }
        }
    }

    selectedRow?.let { row ->
        SimpleDialog("📅 छिलाई रिकॉर्ड", { selectedRow = null }) {
            val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
            Text("दिनांक: ${displayDate(row.date)}")
            Text("खेत: $fieldName")
            Text("फांदी: ${money(row.fandi)}")
            Text("दर: ₹${money(row.rate)}")
            Text("कुल राशि: ₹${money(row.total)}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedEdit = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedDelete = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    selectedPayment?.let { payment ->
        SimpleDialog("💳 भुगतान विवरण", { selectedPayment = null }) {
            Text("दिनांक: ${displayDate(payment.date)}")
            Text("राशि: ₹${money(payment.amount)}", fontWeight = FontWeight.Bold, color = Green)
            Text("तरीका: ${payment.method.ifBlank { "नकद" }}")
            if (payment.note.isNotBlank()) Text("टिप्पणी: ${payment.note}")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedPaymentEdit = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedPaymentDelete = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    protectedEdit?.let { row ->
        DeviceCredentialGate("छिलाई रिकॉर्ड बदलें", "इस रिकॉर्ड की तारीख, खेत या फांदी बदलने के लिए Android screen lock से पुष्टि करें।", { editRow = row; protectedEdit = null }, { protectedEdit = null })
    }
    protectedDelete?.let { row ->
        DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ", "यह छिलाई रिकॉर्ड स्थायी रूप से हट जाएगा।", { store.deleteCanePeeling(row.id); protectedDelete = null }, { protectedDelete = null })
    }
    protectedPaymentEdit?.let { payment ->
        DeviceCredentialGate("भुगतान बदलें", "भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।", { editPayment = payment; protectedPaymentEdit = null }, { protectedPaymentEdit = null })
    }
    protectedPaymentDelete?.let { payment ->
        DeviceCredentialDeleteGate("भुगतान हटाएँ", "यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।", { store.deleteCanePeelingPayment(payment.id); protectedPaymentDelete = null }, { protectedPaymentDelete = null })
    }
    editRow?.let { row -> CanePeelingEntryDialog(store, row, row.fieldId) { editRow = null } }
    editPayment?.let { payment -> CanePeelingPaymentDialog(store, payment, labourId) { editPayment = null } }
}

@Composable
private fun CanePeelingFieldDetail(store:Store,fieldId:String,onBack:()->Unit,onAdd:()->Unit){
    val f=store.fields.firstOrNull{it.id==fieldId}?:run{onBack();return}
    val rows=store.canePeelings.filter{it.fieldId==fieldId}.sortedByDescending{it.date}
    val workers=rows.map{it.labourId}.distinct()
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌾 ${f.name} • छिलाई हिसाब",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
            item{
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                        Text(f.name,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
                        Text("इस खेत का पूरा फांदी और मजदूरी हिसाब",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){CaneMiniStat("मजदूर",workers.size.toString(),Color(0xFFE5F6EA))}
                            Box(Modifier.weight(1f)){CaneMiniStat("फांदी",money(rows.sumOf{it.fandi}),Color(0xFFE5F0FF))}
                            Box(Modifier.weight(1f)){CaneMiniStat("कुल राशि","₹${money(rows.sumOf{it.total})}",Color(0xFFFFF0D9))}
                        }
                    }
                }
            }
            item{Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("इस खेत में छिलाई दर्ज करें",fontWeight=FontWeight.Bold)}}
            item{Text("मजदूरवार हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=AppAccentText)}
            if(workers.isEmpty())item{EmptyCard("इस खेत में अभी कोई छिलाई दर्ज नहीं है।")}
            workers.forEach{lid->item(key="field_worker_$lid"){
                val rr=rows.filter{it.labourId==lid};val l=store.fandiLabours.firstOrNull{it.id==lid}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){PhotoThumb(l?.photo.orEmpty());Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold,color=AppAccentText);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी",fontSize=12.sp,color=AppMuted)};Text("₹${money(rr.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
            item{Text("तारीखवार रिकॉर्ड",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=AppAccentText)}
            rows.forEach{r->item(key="field_entry_${r.id}"){
                val l=store.fandiLabours.firstOrNull{it.id==r.labourId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(r.date),fontWeight=FontWeight.Bold,color=AppAccentText);Text(l?.name?:"मजदूर",fontSize=12.sp);Text("${money(r.fandi)} फांदी × ₹${money(r.rate)}",fontSize=11.sp,color=AppMuted)};Text("₹${money(r.total)}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
        }
    }
}
@Composable
private fun CanePeelingPayments(
    store: Store,
    onEdit: (CanePeelingPayment) -> Unit,
    onDelete: (CanePeelingPayment) -> Unit,
    onOpenLabour: (CanePeelingPayment) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }

    val rows = store.canePeelingPayments
        .filter { payment ->
            val labour = store.fandiLabours.firstOrNull { worker ->
                worker.id == payment.labourId
            }
            query.isBlank() ||
                labour?.name?.contains(query, true) == true ||
                payment.date.contains(query)
        }
        .sortedByDescending { payment -> payment.date }

    val total = rows.sumOf { payment -> payment.amount }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { value -> query = value },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("भुगतान में नाम / तारीख खोजें") },
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )
        }

        item {
            val earned = store.canePeelings.sumOf { it.total }
            val allPaid = store.canePeelingPayments.sumOf { it.amount }
            val balance = earned - allPaid
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenDark), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("छिलाई भुगतान", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("${rows.size} भुगतान रिकॉर्ड • इस सूची में ₹${money(total)}", color = Color.White.copy(alpha = .82f), fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल मजदूरी", "₹${money(earned)}", Color(0xFFE5F6EA)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल भुगतान", "₹${money(allPaid)}", Color(0xFFE5F0FF)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("बाकी", "₹${money(balance)}", Color(0xFFFFF0D9)) }
                    }
                }
            }
        }

        rows.forEach { payment ->
            item(key = payment.id) {
                val labour = store.fandiLabours.firstOrNull { worker ->
                    worker.id == payment.labourId
                }

                Card(
                    Modifier.fillMaxWidth(),
                    RoundedCornerShape(15.dp)
                ) {
                    Row(
                        Modifier.padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable { onOpenLabour(payment) }
                        ) {
                            Text(
                                labour?.name ?: "मजदूर",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                displayDate(payment.date),
                                fontSize = 11.sp,
                                color = AppMuted
                            )
                            Text(
                                payment.method.ifBlank { "नकद" },
                                fontSize = 11.sp,
                                color = AppMuted
                            )
                            if (payment.note.isNotBlank()) {
                                Text(
                                    payment.note,
                                    fontSize = 11.sp,
                                    color = AppMuted
                                )
                            }
                        }

                        Text(
                            "₹${money(payment.amount)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = Green
                        )

                        IconButton(onClick = { onEdit(payment) }) {
                            Icon(Icons.Default.Edit, null, tint = Green)
                        }

                        IconButton(onClick = { onDelete(payment) }) {
                            Icon(
                                Icons.Default.Delete,
                                null,
                                tint = Color(0xFFB3261E)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CanePeelingPaymentDialog(
    store: Store,
    existing: CanePeelingPayment?,
    presetLabour: String,
    onClose: () -> Unit
) {
    var labour by remember {
        mutableStateOf(
            existing?.labourId
                ?: presetLabour.ifBlank {
                    store.fandiLabours.firstOrNull()?.id.orEmpty()
                }
        )
    }

    var date by remember {
        mutableStateOf(existing?.date ?: today())
    }

    var amount by remember {
        mutableStateOf(
            if (existing != null) money(existing.amount) else ""
        )
    }

    var method by remember {
        mutableStateOf(existing?.method ?: "नकद")
    }

    var note by remember {
        mutableStateOf(existing?.note ?: "")
    }
    var error by remember { mutableStateOf("") }

    SimpleDialog(
        if (existing == null) "छिलाई भुगतान दर्ज करें" else "छिलाई भुगतान बदलें",
        onClose
    ) {
        if (presetLabour.isNotBlank()) {
            val selectedLabour = store.fandiLabours.firstOrNull { worker ->
                worker.id == labour
            }

            Text(
                "मजदूर: ${selectedLabour?.name ?: "मजदूर"}",
                fontWeight = FontWeight.Bold,
                color = Green
            )
        } else {
            ChoiceField(
                "मजदूर *",
                store.fandiLabours.map { worker ->
                    worker.id to worker.name
                },
                labour
            ) { selectedId ->
                labour = selectedId
            }
        }

        Text(
            "भुगतान तारीख",
            fontWeight = FontWeight.SemiBold
        )

        AttendanceDateButton(date) { selectedDate ->
            date = selectedDate
        }

        OutlinedTextField(
            value = amount,
            onValueChange = { value ->
                amount = value.filter { character ->
                    character.isDigit() || character == '.'
                }
            },
            label = { Text("कितने रुपये दिए? *") },
            singleLine = true
        )

        ChoiceField(
            "भुगतान तरीका",
            listOf(
                "नकद" to "नकद",
                "बैंक" to "बैंक",
                "UPI" to "UPI",
                "अन्य" to "अन्य"
            ),
            method
        ) { selectedMethod ->
            method = selectedMethod
        }

        OutlinedTextField(
            value = note,
            onValueChange = { value ->
                note = value
            },
            label = { Text("टिप्पणी (Optional)") },
            singleLine = true
        )
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)

        Button(
            onClick = {
                val parsedAmount = amount.toDoubleOrNull()

                if (labour.isBlank()) { error="मजदूर चुनें।"; return@Button }
                if (parsedAmount == null || parsedAmount <= 0 || !parsedAmount.isFinite()) { error="भुगतान की राशि सही डालें।"; return@Button }
                if (!validDate(date)) { error="भुगतान की तारीख सही चुनें।"; return@Button }

                val payment = (
                    existing
                        ?: CanePeelingPayment(
                            UUID.randomUUID().toString(),
                            labour,
                            date,
                            parsedAmount,
                            method,
                            note.trim()
                        )
                    ).copy(
                        labourId = labour,
                        date = date,
                        amount = parsedAmount,
                        method = method,
                        note = note.trim()
                    )

                val saved = if (existing == null) store.addCanePeelingPayment(payment) else store.updateCanePeelingPayment(payment)
                if(saved) onClose() else error="भुगतान सेव नहीं हुआ। कृपया विवरण जाँचकर दोबारा कोशिश करें।"
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Text("✓ सेव करें")
        }
    }
}

private fun exportCaneCsv(context:Context,list:List<CaneParchi>,season:String){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Parchi_${safeFileName(season)}_${System.currentTimeMillis()}.csv")
        FileOutputStream(file).use{out->
            out.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()))
            out.bufferedWriter(Charsets.UTF_8).use{w->
                w.append("नाम,पिता का नाम,पर्ची कोड,दिनांक,वजन (क्विंटल),भाव/क्विंटल,कुल राशि,टिप्पणी").append('\n')
                list.forEach{p->
                    w.append(listOf(p.name,p.fatherName,p.code,displayDate(p.date),String.format(Locale.US,"%.2f",p.weight),money(p.rate),money(p.weight*p.rate),p.remark).joinToString(","){csvCell(it)}).append('\n')
                }
            }
        }
        shareFile(context,file,"text/csv","Excel साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Excel रिपोर्ट नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable private fun SummaryMini(label:String,value:Double,unit:String,modifier:Modifier){Card(modifier,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Column(Modifier.padding(9.dp)){Text(label,fontSize=10.sp,color=AppMuted);Text(if(label=="कुल राशि")"₹${money(value)}" else money(value),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText);if(unit.isNotBlank())Text(unit,fontSize=9.sp,color=AppMuted)}}}


private fun filterCaneParchiSeason(rows:List<CaneParchi>,season:String):List<CaneParchi> =
    if(season=="ALL") rows else rows.filter{it.season==season}

@Composable
private fun CaneParchiDashboardScreen(store:Store){
    var showForm by rememberSaveable { mutableStateOf(false) }
    var edit by remember { mutableStateOf<CaneParchi?>(null) }
    var detail by remember { mutableStateOf<CaneParchi?>(null) }
    var delete by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedEdit by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedDelete by remember { mutableStateOf<CaneParchi?>(null) }
    var showPriceHistory by rememberSaveable { mutableStateOf(false) }
    var season by rememberSaveable { mutableStateOf(caneSeason()) }
    var query by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    val seasons = remember(store.caneParchis) {
        (store.caneParchis.map { it.season }.filter { it.isNotBlank() } + caneSeason()).distinct().sortedDescending()
    }
    if (season != "ALL" && season !in seasons) season = seasons.firstOrNull() ?: caneSeason()
    val allRows = filterCaneParchiSeason(store.caneParchis, season)
    val rows = allRows.filter {
        query.isBlank() || listOf(it.name, it.fatherName, it.code, it.remark).any { value ->
            value.contains(query.trim(), ignoreCase = true)
        }
    }.sortedWith(compareByDescending<CaneParchi> { it.date }.thenBy { it.name })
    val totalWeight = allRows.sumOf { it.weight }
    val totalAmount = allRows.sumOf { it.weight * it.rate }
    val avgRate = if (allRows.isEmpty()) 0.0 else allRows.sumOf { it.rate } / allRows.size

    if (showForm) {
        CaneParchiFormScreen(store, edit) {
            showForm = false
            edit = null
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🌾 गन्ना पर्ची", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color=AppAccentText)
                    Text("पर्ची का पूरा हिसाब • पुराना सीजन • रिपोर्ट", fontSize = 11.sp, color = AppMuted)
                }
                Button(
                    onClick = { edit = null; showForm = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("नई पर्ची") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = GreenDark)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("पर्ची डैशबोर्ड", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("कुल पर्ची", allRows.size.toDouble(), "", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल वजन", totalWeight, "क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल राशि", totalAmount, "", Modifier.fillMaxWidth()) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("औसत भाव", avgRate, "/ क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल सीजन", seasons.size.toDouble(), "सीजन", Modifier.fillMaxWidth()) }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = CardBg)) {
                Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceField(
                        "सीजन / पुरानी पर्चियां",
                        listOf("ALL" to "सभी सीजन") + seasons.map { it to "सीजन $it" },
                        season
                    ) { season = it }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("पर्ची खोजें — नाम / पिता / कोड") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { showPriceHistory = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.History, null); Spacer(Modifier.width(4.dp)); Text("भाव इतिहास")
                }
                OutlinedButton(onClick = {
                    exportCaneCsv(context, rows, if (season == "ALL") "ALL" else season)
                }, enabled = rows.isNotEmpty(), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.TableChart, null); Spacer(Modifier.width(4.dp)); Text("Excel / CSV")
                }
                OutlinedButton(onClick = {
                    val lines = rows.map { p ->
                        "${p.name} • पिता: ${p.fatherName} • कोड: ${p.code} • ${displayDate(p.date)} • ${String.format(Locale.US, "%.2f", p.weight)} क्विंटल • ₹${money(p.rate)}/क्विंटल • कुल ₹${money(p.weight * p.rate)}${if (p.remark.isNotBlank()) " • ${p.remark}" else ""}"
                    }
                    exportReportPdf(context, "गन्ना_पर्ची_${safeFileName(season)}", "${rows.size} पर्चियां • ${money(totalWeight)} क्विंटल • कुल ₹${money(totalAmount)}", lines)
                }, enabled = rows.isNotEmpty(), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(4.dp)); Text("PDF")
                }
            }
        }
        item { Text("${if (season == "ALL") "सभी सीजन" else "सीजन $season"} की पर्चियां (${rows.size})", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color=AppAccentText) }
        if (rows.isEmpty()) {
            item { EmptyCard("इस सीजन में अभी कोई पर्ची नहीं है। ऊपर 'नई पर्ची' दबाकर जोड़ें।") }
        }
        items(rows, key = { it.id }) { p ->
            Card(
                Modifier.fillMaxWidth().clickable { detail = p },
                RoundedCornerShape(17.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (p.photo.isNotBlank()) PhotoThumb(p.photo, Modifier.size(58.dp)) else Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8F3ED)), contentAlignment = Alignment.Center) { Text("🌾", fontSize = 25.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color=AppAccentText)
                            Text("पिता: ${p.fatherName.ifBlank { "—" }}", fontSize = 11.sp, color = AppMuted)
                            Text("कोड: ${p.code} • ${displayDate(p.date)}", fontSize = 11.sp, color = AppMuted)
                        }
                        IconButton(onClick = { protectedEdit = p }) { Icon(Icons.Default.Edit, "पर्ची बदलें", tint = Green) }
                        IconButton(onClick = { protectedDelete = p }) { Icon(Icons.Default.Delete, "पर्ची हटाएं", tint = Color(0xFFB3261E)) }
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${String.format(Locale.US, "%.2f", p.weight)} क्विंटल", fontWeight = FontWeight.Bold)
                        Text("₹${money(p.rate)} / क्विंटल", color = Green)
                        Text("₹${money(p.weight * p.rate)}", fontWeight = FontWeight.ExtraBold, color=AppAccentText)
                    }
                }
            }
        }
    }

    detail?.let { p -> CaneParchiDetail(p) { detail = null } }
    protectedEdit?.let { p ->
        DeviceCredentialGate("गन्ना पर्ची बदलें", "पर्ची की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।", {
            edit = p; protectedEdit = null; showForm = true
        }, { protectedEdit = null })
    }
    protectedDelete?.let { p ->
        DeviceCredentialDeleteGate("गन्ना पर्ची हटाएं", "यह पर्ची स्थायी रूप से हट जाएगी।", {
            store.deleteCaneParchi(p.id); protectedDelete = null
        }, { protectedDelete = null })
    }
    if (showPriceHistory) {
        val selectedSeason = if (season == "ALL") caneSeason() else season
        CanePriceDialog(store, selectedSeason) { showPriceHistory = false }
    }
}

@Composable
private fun CaneParchiFormScreen(store:Store,existing:CaneParchi?=null,onClose:()->Unit){
    var name by rememberSaveable(existing?.id){mutableStateOf(existing?.name?:"")}
    var father by rememberSaveable(existing?.id){mutableStateOf(existing?.fatherName?:"")}
    var code by rememberSaveable(existing?.id){mutableStateOf(existing?.code?:"")}
    var date by rememberSaveable(existing?.id){mutableStateOf(existing?.date?:today())}
    var weight by rememberSaveable(existing?.id){mutableStateOf(if(existing==null)"" else existing.weight.toString())}
    var remark by rememberSaveable(existing?.id){mutableStateOf(existing?.remark?:"")}
    var photo by rememberSaveable(existing?.id){mutableStateOf(existing?.photo?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val season=caneSeason(date)
    val rate=store.caneRateFor(season,date)
    val amount=(weight.toDoubleOrNull()?:0.0)*rate
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)photo=store.persistPhoto(uri.toString(),"cane")}
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){bitmap->if(bitmap!=null)photo=store.persistBitmapPhoto(bitmap,"cane")}
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onClose){Icon(Icons.Default.ArrowBack,"वापस")}
            Text(if(existing==null)"नई गन्ना पर्ची जोड़ें" else "गन्ना पर्ची बदलें",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
        }
        OutlinedTextField(value=name,onValueChange={name=it},label={Text("नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=father,onValueChange={father=it},label={Text("पिता का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(value=code,onValueChange={code=it.filter(Char::isDigit).take(7)},label={Text("पर्ची कोड * (6–7 अंक)")},singleLine=true,modifier=Modifier.weight(1f))
            OutlinedTextField(value=date,onValueChange={date=it},label={Text("दिनांक *")},singleLine=true,modifier=Modifier.weight(1f))
        }
        OutlinedTextField(value=weight,onValueChange={weight=it.filter{c->c.isDigit()||c=='.'}},label={Text("वजन (क्विंटल) *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFF1F4F2)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){
                Text("भाव/क्विंटल (इस तारीख का)",fontSize=12.sp,color=AppMuted)
                Text("₹${money(rate)}",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
            }
        }
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=AppPanelBg),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){Text("कुल अनुमानित राशि",fontSize=12.sp,color=AppMuted);Text("₹${money(amount)}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)}
        }
        OutlinedTextField(value=remark,onValueChange={remark=it},label={Text("टिप्पणी (वैकल्पिक)")},minLines=2,maxLines=3,modifier=Modifier.fillMaxWidth())
        Text("पर्ची की फोटो",fontWeight=FontWeight.Bold,color=AppAccentText)
        if(photo.isNotBlank())PhotoThumb(photo,Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={camera.launch(null)},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(5.dp));Text("कैमरा से लें")}
            OutlinedButton(onClick={picker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoLibrary,null);Spacer(Modifier.width(5.dp));Text("गैलरी से चुनें")}
        }
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
        Button(onClick={
            val w=weight.toDoubleOrNull()
            when{
                name.isBlank()->error="नाम दर्ज करें"
                father.isBlank()->error="पिता का नाम दर्ज करें"
                !Regex("\\d{6,7}").matches(code)->error="पर्ची कोड 6–7 अंक का होना चाहिए"
                !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
                date>today()->error="भविष्य की तारीख नहीं हो सकती"
                w==null||w<=0||!w.isFinite()->error="सही वजन दर्ज करें"
                else->{
                    val x=(existing?:CaneParchi(UUID.randomUUID().toString(),name.trim(),father.trim(),code.trim(),date.trim(),w,rate,photo,remark.trim(),season)).copy(name=name.trim(),fatherName=father.trim(),code=code.trim(),date=date.trim(),weight=w,rate=rate,photo=photo,remark=remark.trim(),season=season)
                    val saved=if(existing==null) store.addCaneParchi(x) else store.updateCaneParchi(x)
                    if(saved) onClose() else error="इस सीजन में यह पर्ची कोड पहले से मौजूद है या विवरण अमान्य है। पुराना रिकॉर्ड जाँचें।"
                }
            }
        },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(existing==null)"पर्ची सेव करें" else "पर्ची अपडेट करें",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun CanePriceDialog(store:Store,season:String,onClose:()->Unit){
    var date by remember{mutableStateOf(today())};var rate by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};
    SimpleDialog("गन्ना भाव इतिहास",onClose){Text("सीजन: $season",fontWeight=FontWeight.Bold,color=AppAccentText);Text("नया भाव जिस तारीख से लागू हो, वही तारीख डालें। उसी सीजन और तारीख पर पहले से भाव है तो वही रिकॉर्ड अपडेट होगा। पुरानी पर्चियों का सेव किया हुआ भाव नहीं बदलेगा।",fontSize=11.sp,color=AppMuted);OutlinedTextField(value=rate,onValueChange={rate=it.filter{c->c.isDigit()||c=='.'}},label={Text("भाव / क्विंटल")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val r=rate.toDoubleOrNull();when{r==null||r<=0->error="सही भाव दर्ज करें";!validDate(date)->error="सही तारीख डालें";date>today()->error="भविष्य की तारीख नहीं";else->{store.addCanePrice(CanePrice(UUID.randomUUID().toString(),season,date,r));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("नया भाव सेव करें")};Spacer(Modifier.height(8.dp));Text("भाव इतिहास",fontWeight=FontWeight.ExtraBold);store.canePricesFor(season).forEach{p->Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(displayDate(p.effectiveDate),Modifier.weight(1f));Text("₹${money(p.rate)} / क्विंटल",fontWeight=FontWeight.Bold,color=AppAccentText)}}}
}

@Composable private fun CaneParchiDetail(p:CaneParchi,onClose:()->Unit){SimpleDialog("पर्ची विवरण",onClose){Text("नाम: ${p.name}",fontWeight=FontWeight.Bold);Text("पिता का नाम: ${p.fatherName.ifBlank{"—"}}");Text("पर्ची कोड: ${p.code}");Text("दिनांक: ${displayDate(p.date)}");Text("वजन: ${String.format(Locale.US,"%.2f",p.weight)} क्विंटल");Text("भाव: ₹${money(p.rate)} / क्विंटल");Text("कुल राशि: ₹${money(p.weight*p.rate)}",fontWeight=FontWeight.ExtraBold,color=AppAccentText);if(p.remark.isNotBlank())Text("Remark: ${p.remark}");if(p.photo.isNotBlank())PhotoThumb(p.photo,Modifier.fillMaxWidth().height(220.dp))}}

@Composable
private fun ProfileScreen(themeChoice:String,onThemeChanged:(String)->Unit,onBackup:()->Unit){
    val context=LocalContext.current
    val prefs=remember(context){context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)}
    var autoLockMinutes by rememberSaveable{mutableIntStateOf(prefs.getInt("autoLockMinutes",5).coerceIn(1,30))}
    var reminderEnabled by rememberSaveable{mutableStateOf(prefs.getBoolean("dailyAttendanceReminderEnabled",false))}
    var reminderHour by rememberSaveable{mutableIntStateOf(prefs.getInt("dailyAttendanceReminderHour",7).coerceIn(0,23))}
    var reminderMinute by rememberSaveable{mutableIntStateOf(prefs.getInt("dailyAttendanceReminderMinute",0).coerceIn(0,59))}
    var reportDefaultRange by rememberSaveable{mutableStateOf(prefs.getString("reportDefaultRange","all")?.takeIf{it in setOf("all","current_month")} ?: "all")}
    var backupBeforeRestore by rememberSaveable{mutableStateOf(prefs.getBoolean("backupBeforeRestore",true))}
    var notificationStatus by rememberSaveable{mutableStateOf("")}
    var enableReminderAfterPermission by rememberSaveable{mutableStateOf(false)}
    fun enableReminder(){reminderEnabled=true;prefs.edit().putBoolean("dailyAttendanceReminderEnabled",true).apply();scheduleDailyAttendanceReminder(context,reminderHour,reminderMinute);notificationStatus="दैनिक हाजिरी रिमाइंडर चालू है। Android बैटरी/अलार्म नीति के कारण समय में थोड़ा अंतर हो सकता है।"}
    val notificationPermissionLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted->
        if(granted && enableReminderAfterPermission) enableReminder() else if(enableReminderAfterPermission) notificationStatus="Notification अनुमति नहीं मिली। फोन Settings में अनुमति देकर दोबारा चालू करें।"
        enableReminderAfterPermission=false
    }
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.AccountCircle,null,tint=Color.White,modifier=Modifier.size(52.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Majdoor Hisaab PRO",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)
                        Text("प्रोफाइल और डेटा सुरक्षा",color=Color.White.copy(alpha=.85f),fontSize=12.sp)
                    }
                }
            }
        }
        item{
            Card(Modifier.fillMaxWidth().clickable(onClick=onBackup),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(2.dp)){
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE4F2FF)),contentAlignment=Alignment.Center){Text("☁️",fontSize=27.sp)}
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Backup & Restore",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
                        Text("Android Auto Backup + Manual Backup",fontSize=11.sp,color=AppMuted)
                    }
                    Icon(Icons.Default.ChevronRight,null,tint=AppAccentText)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("🛡️ Backup Settings",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
                            Text("Restore से पहले safety backup",fontWeight=FontWeight.Bold,color=AppText)
                            Text("Restore करने से पहले मौजूदा मजदूर, हाजिरी, भुगतान, खेत, फसल, खर्च, बिक्री और फोटो की स्थानीय कॉपी बनाएं। Backup न बन पाए तो Restore रोक दिया जाएगा।",fontSize=11.sp,color=AppMuted)
                        }
                        Switch(checked=backupBeforeRestore,onCheckedChange={enabled->backupBeforeRestore=enabled;prefs.edit().putBoolean("backupBeforeRestore",enabled).apply()})
                    }
                    Text("Safety backup फोन के app-private storage में रहता है और Backup & Restore स्क्रीन से वापस लाया जा सकता है।",fontSize=11.sp,color=AppMuted)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("🎨 ऐप थीम",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Text("लाइट, डार्क या फोन की सिस्टम सेटिंग के अनुसार चुनें।",fontSize=12.sp,color=AppMuted)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        listOf("light" to "लाइट","dark" to "डार्क","system" to "सिस्टम").forEach{(key,label)->
                            val selected=themeChoice==key
                            OutlinedButton(onClick={onThemeChanged(key)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=8.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(selected)GreenDark else Color.Transparent,contentColor=if(selected)Color.White else GreenDark)){Text(label,fontSize=12.sp,fontWeight=if(selected)FontWeight.Bold else FontWeight.Normal)}
                        }
                    }
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("🔐 सुरक्षा",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Text("App खोलने, Edit/Delete और Backup Restore पर Android screen lock से पुष्टि होगी। App background में चुने गए समय से अधिक रहने पर दोबारा पुष्टि माँगी जाएगी।",fontSize=12.sp,color=AppText)
                    Text("अपने-आप लॉक होने का समय",fontWeight=FontWeight.Bold,color=AppAccentText)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        listOf(1,5,15,30).forEach{minutes->
                            val selected=autoLockMinutes==minutes
                            OutlinedButton(onClick={autoLockMinutes=minutes;prefs.edit().putInt("autoLockMinutes",minutes).apply()},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=4.dp,vertical=8.dp),colors=ButtonDefaults.outlinedButtonColors(containerColor=if(selected)GreenDark else Color.Transparent,contentColor=if(selected)Color.White else GreenDark)){
                                Text("${minutes} मिनट",fontSize=11.sp,fontWeight=if(selected)FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                    Text("चयनित समय फोन के background में रहने पर लागू होगा।",fontSize=11.sp,color=AppMuted)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Text("🔔 Notification Settings",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){Text("दैनिक हाजिरी रिमाइंडर",fontWeight=FontWeight.Bold,color=AppText);Text("हर दिन चुने हुए समय पर याद दिलाएँ।",fontSize=12.sp,color=AppMuted)}
                        Switch(checked=reminderEnabled,onCheckedChange={enabled->
                            if(!enabled){reminderEnabled=false;prefs.edit().putBoolean("dailyAttendanceReminderEnabled",false).apply();cancelDailyAttendanceReminder(context);notificationStatus="दैनिक रिमाइंडर बंद कर दिया गया।"}
                            else if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){enableReminderAfterPermission=true;notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)}
                            else enableReminder()
                        })
                    }
                    OutlinedButton(onClick={TimePickerDialog(context,{_,hour,minute->reminderHour=hour;reminderMinute=minute;prefs.edit().putInt("dailyAttendanceReminderHour",hour).putInt("dailyAttendanceReminderMinute",minute).apply();if(reminderEnabled)scheduleDailyAttendanceReminder(context,hour,minute);notificationStatus="रिमाइंडर समय सेव हो गया।"},reminderHour,reminderMinute,true).show()},modifier=Modifier.fillMaxWidth()){Text("समय चुनें: %02d:%02d".format(Locale.US,reminderHour,reminderMinute))}
                    if(notificationStatus.isNotBlank()) Text(notificationStatus,fontSize=12.sp,color=AppMuted)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("📑 Report Settings",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Text("रिपोर्ट खोलने पर शुरुआती तारीख चयन",fontWeight=FontWeight.Bold,color=AppText)
                    listOf("all" to "सभी तारीखें","current_month" to "चालू महीना").forEach{(key,label)->
                        Row(Modifier.fillMaxWidth().clickable{reportDefaultRange=key;prefs.edit().putString("reportDefaultRange",key).apply()}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                            RadioButton(selected=reportDefaultRange==key,onClick={reportDefaultRange=key;prefs.edit().putString("reportDefaultRange",key).apply()})
                            Text(label,color=AppText)
                        }
                    }
                    Text("रिपोर्ट स्क्रीन पर तारीखें बदल सकते हैं; यह केवल शुरुआती चयन है।",fontSize=11.sp,color=AppMuted)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.fillMaxWidth().padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("ℹ️ ऐप के बारे में",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                    Text("Majdoor Hisaab PRO",fontWeight=FontWeight.Bold,color=AppText)
                    Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",fontSize=12.sp,color=AppMuted)
                    Text("Package: ${BuildConfig.APPLICATION_ID}",fontSize=11.sp,color=AppMuted)
                    Text("डेटा फोन में स्थानीय रूप से सेव होता है। Google Drive केवल आपके शुरू किए गए Backup/Restore के लिए उपयोग होता है।",fontSize=12.sp,color=AppMuted)
                }
            }
        }
    }
}

@Composable
private fun BackupScreen(store:Store,status:String,onStatus:(String)->Unit,onBackup:()->Unit,onRestore:()->Unit,onRestoreSafety:()->Unit,driveEmail:String,driveBusy:Boolean,onDriveSignIn:()->Unit,onDriveBackup:()->Unit,onDriveRestore:()->Unit){
    val context=LocalContext.current
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){
        Text("☁️ Backup & Restore",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=AppAccentText)
        Spacer(Modifier.height(4.dp))
        Text("आपका मजदूर, हाजिरी, भुगतान, खेत, फसल, खर्च और बिक्री data सुरक्षित रखें।",fontSize=12.sp,color=AppMuted)
        Spacer(Modifier.height(14.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=AppPanelBg)){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("☁️ Android Auto Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Android Auto Backup ON है। फोन में Google Account लगा होने पर Android का app-data backup system backup ले सकता है।",fontSize=12.sp,color=AppText)
                Text("यह Google Drive की सामान्य files list में अलग backup file के रूप में जरूरी नहीं दिखेगा।",fontSize=11.sp,color=AppMuted)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(2.dp)){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                Text("☁️ Direct Google Drive",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Google Account: $driveEmail",fontSize=12.sp,color=if(driveEmail.contains("@")) GreenDark else Color.Gray)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick=onDriveSignIn,enabled=!driveBusy,modifier=Modifier.weight(1f)){Text(if(driveEmail.contains("@"))"Account बदलें" else "Google Account जोड़ें")}
                    Button(onClick=onDriveBackup,enabled=!driveBusy&&driveEmail.contains("@"),modifier=Modifier.weight(1f)){Text(if(driveBusy)"काम हो रहा है…" else "Drive Backup")}
                }
                OutlinedButton(onClick=onDriveRestore,enabled=!driveBusy&&driveEmail.contains("@"),modifier=Modifier.fillMaxWidth()){Text("Drive से Latest Restore")}
                Text("Backup सीधे Google Drive के ‘Majdoor Hisaab PRO’ folder में जाएगा।",fontSize=11.sp,color=AppMuted)
                Spacer(Modifier.height(8.dp))

                Text("📦 Manual Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Google Drive में रखने के लिए नीचे Backup बनाएं दबाएँ। अगली screen में Google Drive चुनकर अपना Gmail account और folder चुनें।",fontSize=12.sp,color=AppAccentText,fontWeight=FontWeight.SemiBold)
                Button(onClick=onBackup,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                    Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(8.dp));Text("Google Drive / फोन में Backup",fontWeight=FontWeight.Bold)
                }
                OutlinedButton(onClick=onRestore,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){
                    Icon(Icons.Default.CloudDownload,null);Spacer(Modifier.width(8.dp));Text("Google Drive से Restore करें",fontWeight=FontWeight.Bold)
                }
                val safetyFile=File(context.filesDir,"mhpro_pre_restore_safety.zip")
                OutlinedButton(onClick=onRestoreSafety,enabled=safetyFile.isFile&&safetyFile.length()>0L,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){
                    Icon(Icons.Default.Restore,null);Spacer(Modifier.width(8.dp));Text("पिछला Safety Backup Restore करें",fontWeight=FontWeight.Bold)
                }
                Text(if(safetyFile.isFile&&safetyFile.length()>0L) "Safety copy उपलब्ध है • ${String.format(Locale.US,"%.1f",safetyFile.length()/1024.0)} KB" else "Safety copy पहली सफल Restore से पहले बनेगी।",fontSize=11.sp,color=AppMuted)
                Text("Restore से पहले Android screen lock पूछा जाएगा। Restore करने पर मौजूदा app data backup के data से replace होगा।",fontSize=11.sp,color=AppMuted)
            }
        }
        if(status.isNotBlank()){
            Spacer(Modifier.height(12.dp))
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Text(status,Modifier.padding(14.dp),fontWeight=FontWeight.SemiBold,color=AppAccentText)
            }
        }
        val history=remember(status){runCatching{JSONArray(context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE).getString("backupHistory","[]") ?: "[]")}.getOrElse{JSONArray()}}
        Spacer(Modifier.height(12.dp))
        Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
            Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text("Backup / Restore History",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=AppAccentText)
                if(history.length()==0) Text("अभी कोई सफल Backup या Restore दर्ज नहीं है।",fontSize=12.sp,color=AppMuted)
                else for(index in (history.length()-1 downTo maxOf(0,history.length()-5))){
                    val row=history.optJSONObject(index) ?: continue
                    val stamp=row.optLong("at",0L)
                    val dateText=if(stamp>0) SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(Date(stamp)) else "समय उपलब्ध नहीं"
                    Column(Modifier.fillMaxWidth().padding(vertical=2.dp)){
                        Text(row.optString("action","Backup"),fontWeight=FontWeight.Bold,color=AppText)
                        Text("$dateText • ${row.optString("detail","")}",fontSize=11.sp,color=AppMuted)
                    }
                }
            }
        }
    }
}

@Composable private fun PaymentDialog(store:Store,labourId:String,preField:String?,preCrop:String?,onClose:()->Unit,existing:Payment?=null){
    var field by remember{mutableStateOf(existing?.fieldId ?: preField?:"")}
    var crop by remember{mutableStateOf(existing?.cropId ?: preCrop?:"")}
    var amount by remember{mutableStateOf(existing?.amount?.let{money(it)} ?: "")}
    var kind by rememberSaveable{mutableStateOf(existing?.kind ?: "payment")}
    var date by remember{mutableStateOf(existing?.date ?: today())}
    var error by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    val lockedField=preField?.isNotBlank()==true
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){
        if(crop.isNotBlank() && crops.none{it.id==crop}) crop=""
        if(crop.isBlank() && crops.size==1) crop=crops.first().id
    }
    SimpleDialog(if(existing==null){if(kind=="advance")"अग्रिम दर्ज करें" else "भुगतान दर्ज करें"}else{if(kind=="advance")"अग्रिम बदलें" else "भुगतान बदलें"},onClose){
        if(lockedField){
            val name=store.fields.firstOrNull{it.id==field}?.name?:"खेत"
            Text("खेत: $name",fontWeight=FontWeight.Bold,color=Green)
        } else {
            ChoiceField("खेत (Optional)",listOf("" to "खेत नहीं चुनना")+store.fields.map{it.id to it.name},field){field=it}
        }
        if(field.isNotBlank() && crops.size>1){
            ChoiceField("फसल (Optional)",listOf("" to "फसल नहीं चुनना")+crops.map{it.id to it.name},crop){crop=it}
        }
        ChoiceField("प्रविष्टि का प्रकार",listOf("payment" to "भुगतान", "advance" to "अग्रिम"),kind){kind=it}
        AttendanceDateButton(date){date=it}
        OutlinedTextField(value=amount,onValueChange={amount=it;error=""},label={Text(if(kind=="advance")"अग्रिम की रकम (₹)" else "भुगतान की रकम (₹)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(enabled=!saving,onClick={
            if(saving) return@Button
            val n=amount.toDoubleOrNull()
            when {
                n==null||n<=0||!n.isFinite()->error="सही भुगतान रकम दर्ज करें।"
                !validDate(date)->error="सही भुगतान तारीख चुनें।"
                existing!=null && store.isMonthLocked(existing.date)->error="यह भुगतान लॉक महीने का है। पुराना भुगतान बदला या हटाया नहीं जा सकता।"
                store.isMonthLocked(date)->error="${monthTitle(date.take(7))} का हिसाब लॉक है। इस महीने में भुगतान दर्ज/बदल नहीं सकते; पुराने बकाये के लिए खुली बाद की तारीख चुनें।"
                (existing!=null && store.isClosedDate(labourId,existing.date)) || store.isClosedDate(labourId,date)->error="इस तारीख तक का हिसाब फाइनल है। पुराना भुगतान नहीं बदलेगा; बाद की खुली तारीख चुनें।"
                else->{saving=true;val row=Payment(existing?.id?:UUID.randomUUID().toString(),labourId,field,crop,date,n,kind);val saved=if(existing==null)store.addPayment(row) else store.updatePayment(row);if(saved)onClose() else {saving=false;error="प्रविष्टि सेव नहीं हुई। लॉक महीना, मजदूर और फाइनल हिसाब जाँचें।"}}
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(existing!=null)"बदलाव सेव करें" else if(kind=="advance")"अग्रिम सेव करें" else "भुगतान सेव करें")}
    }
}

@Composable private fun RateDialog(store:Store,labourId:String,onClose:()->Unit){var rate by remember{mutableStateOf("")};var date by remember{mutableStateOf(today())};var error by remember{mutableStateOf("")};val current=store.rateFor(labourId,today());SimpleDialog("दिहाड़ी बदलें",onClose){Text("अभी की प्रभावी दिहाड़ी: ₹${money(current)}/दिन",fontWeight=FontWeight.SemiBold,color=Green);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("नई दिहाड़ी")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=rate.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही दिहाड़ी दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";store.setRate(WageRate(UUID.randomUUID().toString(),labourId,date.trim(),n));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save नई दर")}}}

@Composable private fun CropDetail(store:Store,id:String,onBack:()->Unit,onExpense:()->Unit,onSale:()->Unit){val c=store.crops.firstOrNull{it.id==id}?:return;val f=store.fields.firstOrNull{it.id==c.fieldId};val exp=store.expenses.filter{it.cropId==id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==id}.sumOf{it.total};val wage=store.attendances.filter{it.cropId==id}.sumOf{it.fraction*it.rate};Column(Modifier.fillMaxSize()){DetailTopBar("🌱 ${c.name}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Text("खेत: ${f?.name?:"नहीं चुना"}",fontWeight=FontWeight.Bold)};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",exp+wage)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-exp-wage)}}};this.item{Text("मजदूरी ₹${money(wage)}",fontWeight=FontWeight.Bold)};this.item{Text("खेती खर्च ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("बिक्री ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{SmallAction("💰 इस फसल के खर्च",onExpense)};this.item{SmallAction("🧺 इस फसल की बिक्री",onSale)}}}}

@Composable private fun DetailTopBar(title:String,onBack:()->Unit){
    Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(GreenDark,Green))).shadow(3.dp)){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack,modifier=Modifier.size(44.dp)){Icon(Icons.Default.ArrowBack,"पीछे जाएँ",tint=Color.White)}
            Text(title,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=17.sp,maxLines=1)
        }
    }
}

@Composable private fun SectionTitle(title:String,sub:String,onAdd:(()->Unit)?=null){
    Row(Modifier.fillMaxWidth().padding(bottom=4.dp),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
            Text(title,fontWeight=FontWeight.ExtraBold,fontSize=21.sp,color=AppAccentText)
            Text(sub,fontSize=12.sp,color=Color(0xFF65736B))
        }
        if(onAdd!=null){
            FilledTonalButton(onClick=onAdd,shape=RoundedCornerShape(14.dp)){
                Icon(imageVector=Icons.Default.Add,contentDescription=null,tint=AppAccentText)
                Spacer(Modifier.width(4.dp));Text("जोड़ें",fontWeight=FontWeight.Bold)
            }
        }
    }
}
@Composable private fun SmallAction(text:String,onClick:()->Unit){
    Card(Modifier.fillMaxWidth().clickable{onClick()},shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=15.dp),verticalAlignment=Alignment.CenterVertically){
            Text(text,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=AppAccentText)
            Icon(Icons.Default.ChevronRight,contentDescription=null,tint=Green)
        }
    }
}
@Composable private fun SimpleDialog(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){BackHandler{onClose()};AlertDialog(onDismissRequest={},title={Text(title,fontWeight=FontWeight.Bold)},text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)},confirmButton={},dismissButton={TextButton(onClick=onClose){Text("बंद")}})}
@Composable private fun ConfirmDialog(title:String,message:String,onYes:()->Unit,onNo:()->Unit){AlertDialog(onDismissRequest=onNo,title={Text(title)},text={Text(message)},confirmButton={Button(onClick=onYes){Text("हटाएँ")}},dismissButton={TextButton(onClick=onNo){Text("रद्द")}})}
@Composable
private fun ChoiceField(label:String,options:List<Pair<String,String>>,selected:String,onSelected:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    Column{
        Text(label,fontSize=12.sp,color=AppMuted)
        Box{
            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){
                Text(options.firstOrNull{it.first==selected}?.second?.ifBlank{"नहीं चुना"} ?: "चुनें")
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                options.forEach{(id,name)->
                    DropdownMenuItem(text={Text(name.ifBlank{"नहीं चुना"})},onClick={onSelected(id);open=false})
                }
            }
        }
    }
}
