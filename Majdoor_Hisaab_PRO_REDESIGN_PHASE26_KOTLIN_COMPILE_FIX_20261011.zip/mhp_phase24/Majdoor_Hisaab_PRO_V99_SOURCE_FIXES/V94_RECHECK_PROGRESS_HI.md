# Majdoor Hisaab PRO — V94 Re-check Progress (NOT FINAL)

Date: 2026-10-11
Working source version is now configured as 1.94.0 / versionCode 94; this is still a working build, not a verified release.

## Re-check and actual fixes

- Re-ran all 11 established source-audit scripts and the new Fandi UI regression suite (12 scripts total).
- Fixed two stale source-test expectations: dashboard payment card label and Fandi profile-save/combined-entry behavior.
- Fixed a real accounting integrity defect in `Store.updatePayment`: previously, a payment stored in a locked month or finalized closure period could potentially be moved forward to a later unlocked date because validation checked only the proposed date. The update now checks both the existing row's original date/worker closure and the proposed row before changing anything.
- Added isolated Android runtime regression cases for moving an October locked-month payment into November and moving a September closed-period payment beyond its closure date. These are written tests but are not yet executed on an emulator.
- Corrected the current-month report audit to independently assert attendance filtering and payment filtering, rather than accidentally checking the same generic pattern twice.
- Added `scripts_v94_fandi_ui_regression.py` to the GitHub Actions source audit sequence.
- The Fandi regression suite confirms a single rate editor on Chhilai home, profile-only worker save, separate one-worker daily entry, optional field, duplicate prevention, and legacy-data normalization.

## Re-check results

- Daily Labour source audit: 30/30 PASS
- Date/field report audit: 11/11 PASS
- Google Drive consent source audit: PASS (no failed assertions)
- Report selection audit: 16/16 PASS
- Navigation regression audit: 10/10 PASS
- Data-integrity source audit: 62/62 PASS
- Restore atomicity source audit: 23/23 PASS
- CRUD feedback source audit: 14/14 PASS
- Selected source-fix audit: 73/73 PASS
- Locked-month/payment audit: 42/42 PASS
- Fandi UI regression audit: 11/11 PASS
- 96-point source trace: 96/96 patterns found
- Python audit scripts compile: PASS
- Android XML resource/manifest parse: PASS
- GitHub Actions workflow YAML parse: PASS

**Total counted source/static assertions: 399 PASS. The 96-point tracker records 51 source-fix rows, 44 existing-source rows awaiting complete runtime audit, and 1 final-package gate row; all 96 runtime-verification ticks remain unchecked.** Source pattern presence is not proof that the app behaves correctly on a device.

## Still not verified — do not tick as complete

- Fully fixed + Android runtime verified: 0/96. Do not change this without evidence.
- Local Gradle build is unavailable here: `gradle/wrapper/gradle-wrapper.jar` is absent, no Gradle executable or Android SDK is installed, and distribution download failed due to unavailable network. Workflow includes a pinned Gradle wrapper bootstrap, but the current working source has not been built by CI.
- Emulator instrumentation tests have not been executed.
- Physical-phone tests remain pending: theme/system theme, lock/biometric, auto-lock, notification and reboot behavior, PDF appearance, back navigation, font scaling/rotation.
- Actual Google Drive account sign-in/consent, upload, download, and restore round-trip remain pending.
- PDF visual review, Ganna Chhilayi and Ganna Parchi end-to-end regressions, offline/restart/rotation verification, APK signature/alignment/package verification remain pending.
- `scripts_finalize_release_package.py` remains fail-closed and refuses to create a final ZIP until all 96 runtime ticks, evidence JSON, all mandatory gates, and APK SHA-256 match.

## Preservation constraints

- Package stays `com.majdoor.hisaabpro`.
- Preserve local-first behavior, existing data, legacy backup compatibility, photos, field order, Fandi rate, monthly closures, and both Ganna Chhilayi (फांदी) and Ganna Parchi modules.
- No final ZIP/APK is being published or declared ready in this pass.
