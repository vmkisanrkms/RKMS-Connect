# Majdoor Hisaab PRO — V98 Source Fix Progress (NOT FINAL)

## इस pass में किए गए source fixes

### 1. Attendance future-date guard
- UI के अलावा Store/data layer भी अब भविष्य की तारीख की हाजिरी reject करता है। इससे direct Store writes या replayed code UI restriction bypass नहीं कर सकते।
- Isolated Android runtime regression harness में `9999-12-31` test जोड़ा; rejection पर attendance list unchanged रहनी चाहिए।
- CI static audit: `scripts_v97_future_attendance_guard_audit.py` — 5/5 PASS.

### 2. Backup Settings / safety restore
- Profile में `Backup Settings` section और persisted `backupBeforeRestore` toggle जोड़ा; default ON.
- Restore से पहले existing app records और referenced photos का safety ZIP temporary file में बनता है और validate होता है। नई copy सुरक्षित रूप से install न हो सके तो restore रोक दिया जाता है और app data replace नहीं होता।
- Backup & Restore screen से पिछले safety snapshot को दोबारा restore करने का action जोड़ा। Safety snapshot restore करते समय वही file overwrite/delete नहीं होती। Normal restore और safety restore दोनों Android device-credential gate से गुजरते हैं।
- Checklist point O08 में source-fix tick जोड़ा; runtime tick अभी unchecked है।
- CI static audit: `scripts_v98_backup_safety_settings_audit.py` — 8/8 PASS.

## Verification अभी तक
- Existing source/static audit suites फिर से चलाए: सभी PASS — 30/30, 11/11, Drive consent checks, 16/16, 10/10, 62/62, 23/23, 14/14, 73/73, 96/96 source trace, 42/42, 10/10, 11/11, 4/4, calendar 12/12, future-date 5/5, backup safety 8/8.
- All Python audit scripts compile; workflow YAML and Android manifest/backup XML parse.
- Checklist: 96 points; source-fix rows 54/96; full Android runtime-verified rows 0/96.

## अभी final नहीं
- Full Android app compile, emulator install/launch, real backup/restore, Google Drive consent, PDF visual rendering, restart/offline/rotation, and Ganna Chhilayi/Parchi regression evidence are not yet available in this environment.
- Final packaging gate remains blocked until all 96 runtime evidence rows are verified.
- User's instruction followed: no new ZIP/APK created in this pass.
