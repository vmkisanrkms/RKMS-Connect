#!/usr/bin/env python3
"""Static guardrails for the V88 data-integrity fixes and Android emulator smoke-test wiring."""
from pathlib import Path
import sys
root=Path(__file__).parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
workflow=(root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
test=(root/'app/src/androidTest/java/com/majdoor/hisaabpro/AppLaunchRuntimeSmokeTest.kt').read_text(encoding='utf-8')
checks={
  'V94 version is set': 'versionCode = 94' in gradle and 'versionName = "1.94.0"' in gradle,
  'Android instrumentation runner is configured': 'androidx.test.runner.AndroidJUnitRunner' in gradle,
  'Compose Android UI test dependency exists': 'androidTestImplementation("androidx.compose.ui:ui-test-junit4")' in gradle,
  'App background auto-lock timeout is persisted and lifecycle-aware': 'putLong("appBackgroundAt",System.currentTimeMillis())' in src and 'getInt("autoLockMinutes",5)' in src and 'Lifecycle.Event.ON_START' in src and 'Lifecycle.Event.ON_STOP' in src,
  'Settings exposes supported auto-lock choices': 'listOf(1,5,15,30)' in src and 'putInt("autoLockMinutes",minutes)' in src,
  'Dashboard has quick actions': 'Text("त्वरित काम"' in src and 'onGo("daily_labour")' in src,
  'More menu is grouped by task': '"मजदूरी और हिसाब"' in src and '"खेत और फसल"' in src and '"गन्ना मॉड्यूल"' in src,
  'Bottom navigation has selected-state surface': 'background(if(selected) Color(0xFFE4F3EA)' in src,
  'Shared top bars use consistent green gradient': 'Brush.horizontalGradient(listOf(GreenDark,Green))' in src,
  'Shared section titles and actions use reusable styling': 'Text("जोड़ें",fontWeight=FontWeight.Bold)' in src and 'defaultElevation=1.dp' in src,
  'Runtime test launches MainActivity': 'createAndroidComposeRule<MainActivity>()' in test,
  'Runtime test checks device-lock requirement': 'Android Screen Lock जरूरी है' in test,
  'Runtime test exercises local accounting and backup rules': 'coreLocalAccountingAndBackupRegressionChecksPass' in test and 'runCoreStoreRuntimeRegression' in src,
  'Runtime regression uses isolated test preferences': 'mhpro_runtime_regression' in src and 'testPrefs.edit().clear().commit()' in src,
  'Runtime harness refuses unsafe pre-API-24 storage fallback': 'SDK_INT<24' in src and 'createDeviceProtectedStorageContext()' in src,
  'Backup restore test is isolated from production photo storage': 'File(isolatedContext.filesDir,"photos").deleteRecursively()' in src,
  'Runtime regression checks backup restore round-trip': 'store.restoreBackupZip(backup)' in src and 'backup restore recovers original worker and attendance' in src,
  'Runtime regression checks Fandi rate persistence': 'Fandi rate survives Store reinitialization' in src and 'backup restore preserves Fandi rate' in src,
  'Fandi worker deletion protects historical ledger': 'fun deleteFandiLabour(id:String):Boolean' in src and 'if(canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}) return false' in src,
  'Cane peeling edits prevent duplicate worker-field-date': 'fun updateCanePeeling(x:CanePeeling):Boolean' in src and 'it.id!=x.id && it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date' in src,
  'Cane peeling payments validate IDs and amounts': 'fun addCanePeelingPayment(x:CanePeelingPayment):Boolean' in src and 'fun updateCanePeelingPayment(x:CanePeelingPayment):Boolean' in src,
  'Restore validates all required arrays before mutation': 'backupKeys.forEach{key->' in src and "Backup में '$key' डेटा गलत या गायब है।" in src and 'validateBackupZip(input)' in src,
  'ZIP entries are read with a bounded size limit': 'readZipEntryLimited(zis,100L*1024L*1024L-total)' in src and 'Backup में duplicate file entry मिली' in src,
  'New payments reject invalid date/amount/id': 'private fun validPayment(x:Payment):Boolean' in src and 'x.amount>0 && x.amount.isFinite()' in src and 'isClosedDate(x.labourId,x.date)' in src,
  'Payments validate optional field/crop references and field-crop consistency': 'private fun validPayment(x:Payment):Boolean' in src and 'x.cropId.isBlank() || crops.any{it.id==x.cropId && (x.fieldId.isBlank() || it.fieldId==x.fieldId)}' in src,
  'Payment regression covers bad field and crop references': 'bad field/crop references are rejected' in src,
  'Expenses reject invalid amounts/dates and references': 'private fun validExpense(x:Expense):Boolean' in src and 'if(!validExpense(x) || expenses.any{it.id==x.id}) return' in src,
  'Sales reject invalid quantities/rates/totals': 'private fun validSale(x:Sale):Boolean' in src and 'kotlin.math.abs(x.total-(x.qty*x.rate))<=0.02' in src,
  'Fandi entries validate quantities/rates/totals': 'x.total<=0 || !x.total.isFinite() || kotlin.math.abs(x.total-(x.fandi*x.rate))>0.02' in src,
  'Cane parchi rejects duplicate season/code': 'private fun validCaneParchi' in src and 'ignoreCase=true' in src,
  'Account closure validates worker and nonnegative totals': 'labours.none{it.id==labourId} || !validDate(throughDate) || wage<0 || paid<0' in src,
  'Wage-rate history rejects invalid rate/date': 'labours.none{it.id==x.labourId} || !validDate(x.effectiveDate) || x.rate<=0' in src,
  'Runtime tests cover malformed payment rejection': 'negative/invalid payments and bad field/crop references are rejected' in src,
  'Runtime tests cover expense validation': 'invalid expense and duplicate expense saves return failure' in src,
  'Runtime tests cover sale arithmetic': 'invalid sale and duplicate sale saves return failure' in src,
  'Runtime tests cover invalid closure/rate': 'invalid closure and wage rate are rejected' in src,
  'Worker store rejects duplicate IDs, blank IDs and invalid rates': 'x.id.isBlank() || x.name.isBlank() || !x.rate.isFinite() || x.rate<0 || labours.any{it.id==x.id}' in src and 'labours.none{it.id==x.id}' in src,
  'Cane price rejects duplicate IDs outside the same effective date': 'val sameEffective=canePrices.firstOrNull' in src and 'canePrices.any{it.id==x.id && it.id!=sameEffective?.id}' in src,
  'Cane parchi rejects duplicate IDs and blank season': 'x.season.isNotBlank() && validDate(x.date)' in src and '(it.id==x.id || (it.code.trim()' in src,
  'Wage rate rejects duplicate IDs outside the replacement row': 'val sameEffective=rates.firstOrNull{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}' in src,
  'Runtime harness covers worker and parchi identity integrity': 'blank/duplicate worker IDs and invalid worker rates are rejected' in src and 'duplicate parchi code and ID are rejected' in src,
  'Runtime tests cover duplicate Fandi names': 'duplicate normalized Fandi worker name and invalid Fandi rate are rejected' in src,
  'Runtime tests cover duplicate parchi codes': 'duplicate parchi code and ID are rejected' in src,
  'Parchi form reports failed save instead of closing': 'इस सीजन में यह पर्ची कोड पहले से मौजूद है या विवरण अमान्य है।' in src,
  'Runtime tests cover incomplete backup safety': 'incomplete backup is rejected before changing records' in src,
  'Legacy schema-1 backup compatibility retained': 'raw==null && schema==1 -> JSONArray()' in src,
  'Package ID remains unchanged': 'applicationId = "com.majdoor.hisaabpro"' in gradle,
  'Attendance storage rejects invalid worker/date/fraction/rate and invalid references': 'if(x.id.isBlank() || x.labourId.isBlank() || labours.none{it.id==x.labourId})' in src and 'if(!validDate(x.date) || !x.fraction.isFinite() || x.fraction<0 || x.fraction>1.0' in src and 'चुनी गई फसल इस खेत से मेल नहीं खाती।' in src,
  'Field add/update rejects blank and duplicate normalized names': 'fun addField(x:Field)' in src and 'fields.any{it.id==x.id || it.name.trim().replace(Regex("\\\\s+")' in src,
  'Runtime harness checks field/crop duplicate and reference rules': 'field persists and duplicate field names/IDs return failure' in src and 'crop requires valid field and duplicate save returns failure' in src,
  'Crop add/update validates field, season duplicate and sowing date': 'fun addCrop(x:Crop)' in src and 'fields.none{it.id==x.fieldId}' in src and 'x.sowingDate.isNotBlank() && !validDate(x.sowingDate)' in src,
  'Cane peeling update validates references and arithmetic total': 'fandiLabours.none{it.id==x.labourId}' in src and 'kotlin.math.abs(x.total-(x.fandi*x.rate))>0.02' in src,
  'Cane peeling payments require an existing Fandi worker': 'fandiLabours.none{it.id==x.labourId}' in src and 'fun updateCanePeelingPayment(x:CanePeelingPayment):Boolean' in src,
  'Runtime harness checks malformed attendance rejection': 'invalid attendance date, fraction and worker are rejected' in src,
  'Runtime harness checks missing Fandi worker rejection': 'invalid cane quantities, worker references and mismatched totals are rejected' in src,
  'Backup preserves locked months and field order': '"lockedLabourMonths"' in src and 'put("fieldOrder",prefs.getString("fieldOrder","").orEmpty())' in src and 'lockedLabourMonths=loadLockedLabourMonths()' in src,
  'Runtime regression covers history delete protection': 'Fandi worker with history cannot be deleted' in src,
  'Fandi delete UI warns that linked history is retained': 'हिसाब सुरक्षित रखने के लिए मजदूर नहीं हटाया गया' in src,
  'Payment dialog stays open when save fails': 'भुगतान सेव नहीं हुआ। कृपया विवरण जाँचकर दोबारा कोशिश करें।' in src,
  'Runtime regression covers locked month and field-order restore': 'backup restore recovers monthly lock and field order' in src,
  'Workflow runs emulator tests': 'reactivecircus/android-emulator-runner@v2' in workflow and ':app:connectedDebugAndroidTest' in workflow,
  'V94 artifact name configured': 'Majdoor-Hisaab-PRO-V94-FINAL.apk' in workflow,
}
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} V92 data-integrity regression checks passed')
sys.exit(1 if failed else 0)
