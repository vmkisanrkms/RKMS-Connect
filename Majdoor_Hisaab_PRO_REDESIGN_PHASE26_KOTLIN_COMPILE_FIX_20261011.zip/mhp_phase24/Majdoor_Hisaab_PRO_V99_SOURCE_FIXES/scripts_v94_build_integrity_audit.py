#!/usr/bin/env python3
"""Source checks for pinned Gradle wrapper bootstrap and release build gates."""
from pathlib import Path
root = Path(__file__).resolve().parent
workflow = (root / '.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
props = (root / 'gradle/wrapper/gradle-wrapper.properties').read_text(encoding='utf-8')
build = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
checks = {
    'Gradle distribution URL is pinned to 8.11.1': 'distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip' in props,
    'Gradle distribution checksum exists in wrapper properties': 'distributionSha256Sum=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6' in props,
    'wrapper bootstrap refuses to proceed without pinned checksum': 'test -n "$EXPECTED_GRADLE_SHA256"' in workflow,
    'wrapper bootstrap verifies downloaded distribution before extraction': 'sha256sum --check --strict' in workflow and workflow.index('sha256sum --check --strict') < workflow.index('unzip -q "$RUNNER_TEMP/gradle-8.11.1-bin.zip"'),
    'wrapper bootstrap restores checksum property if Gradle wrapper task drops it': 'sed -i "/^distributionUrl=/a distributionSha256Sum=$EXPECTED_GRADLE_SHA256"' in workflow,
    'wrapper JAR is verified after bootstrap': 'test -s gradle/wrapper/gradle-wrapper.jar' in workflow,
    'Gradle distribution checksum remains asserted after bootstrap': "grep -q '^distributionSha256Sum=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6$' gradle/wrapper/gradle-wrapper.properties" in workflow,
    'Release compile and assembly are required': './gradlew :app:compileReleaseKotlin' in workflow and './gradlew :app:clean :app:assembleRelease' in workflow,
    'signed APK signature and zip alignment are checked': '"$APKSIGNER" verify --verbose "$APK"' in workflow and '"$ZIPALIGN" -c -P 16 -v 4 "$APK"' in workflow,
    'version 1.94.0 / code 94 matches final artifact name': 'versionCode = 94' in build and 'versionName = "1.94.0"' in build and 'Majdoor-Hisaab-PRO-V94-FINAL.apk' in workflow,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'{sum(checks.values())}/{len(checks)} build integrity checks passed')
if not all(checks.values()):
    raise SystemExit(1)
