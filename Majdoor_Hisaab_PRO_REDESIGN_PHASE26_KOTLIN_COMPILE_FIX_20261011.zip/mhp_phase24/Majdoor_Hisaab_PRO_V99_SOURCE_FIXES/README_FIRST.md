# Majdoor Hisaab PRO V87 — Start Here

**Version:** 1.87.0 / versionCode 87  
**Package:** `com.majdoor.hisaabpro`

## What changed in V87

1. Fandi worker profiles with linked work/payment history cannot be deleted, preventing accidental loss of the historical ledger.
2. Editing cane-peeling entries now checks duplicate worker + field + date at the storage layer, not only in the form.
3. Fandi payment create/update validates record IDs, dates and positive finite amounts. Failed saves keep the dialog open and show an error.
4. Labour payment updates reject missing IDs and invalid amount/date values rather than reporting a no-op as success.
5. Local backup now includes locked-month state and field order. Restore reloads the lock state in memory.
6. Runtime regression harness adds tests for these data-integrity rules and backup state round-trip.

## Files to use

- `A_TO_Z_REMAINING_FIX_LIST_V87.csv` — 135-item row-by-row checklist. Source fixes are marked `IN PROGRESS`, not PASS, until emulator/device verification.
- `SCREEN_PROGRESS_TRACKER.csv` — screen progress; runtime tests remain untested.
- `V87_DATA_INTEGRITY_FIX_AUDIT_HI.md` — changes, static check results and limitations.
- `app/` — Android source project.
- `.github/workflows/majdoor-hisaab.yml` — CI source audits, Android emulator instrumentation tests, Release build/signing/alignment checks.

## Verification status

- 104 targeted source-level checks passed.
- Kotlin delimiter scan: PASS; no syntax-token diagnostics were detected by the scan.
- Workflow YAML parse: PASS.
- ZIP integrity: checked when packaged.
- **Android compile, emulator tests and signed APK are not verified locally.** Run the GitHub Actions workflow with the required `RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD` repository secrets. Then install and test the APK on a real phone.

This is an incremental data-integrity fix batch, not a claim that all 135 checklist items or the complete visual redesign are finished. Existing local data behavior, monthly accounting, Google Drive Backup/Restore and Ganna modules are retained.

## Current 96-point status
- Source fixes recorded: 51/96 (K10/K11 V99 fixes are included in the checklist).
- Android runtime verified: 0/96.
- This is an incremental source-fix ZIP, not a final verified APK/package.


## Latest incremental hardening — 2026-10-11
- K10 CSV formula-injection detection now considers BOM and zero-width prefixes and has expanded regression assertions; see `K10_CSV_UNICODE_PREFIX_HARDENING_20261011.md`.
- CSV static audit: 13/13 PASS. This is an incremental source hardening, not completion of all 96 screens.


## 96-point source audit status — 2026-10-11
See `SOURCE_96_FIX_AUDIT_STATUS_20261011.md`. Source-trace coverage is 96/96; explicitly recorded source fixes remain 51/96; Android runtime verification remains 0/96. These are intentionally separate measures.


## Phase 20 Backup / Restore hardening (2026-10-11)
- Hardened staged ZIP creation, Drive archive selection, local export verification, restore validation, and retained safety rollback/recovery.
- Backup audit 24/24 PASS; runtime and live Drive remain NOT TESTED. See `PHASE20_BACKUP_RESTORE_GOOGLE_CONSENT_20261011.md`.


## Phase 22 — Locked-month payment safety (2026-10-11)
Payment create/edit/delete now has explicit locked-month UI feedback, Store-level immutable-period guards, worker ownership protection, and regression assertions. Run `python3 scripts_phase22_locked_payment_immutability_audit.py`. Android runtime verification is still pending.
