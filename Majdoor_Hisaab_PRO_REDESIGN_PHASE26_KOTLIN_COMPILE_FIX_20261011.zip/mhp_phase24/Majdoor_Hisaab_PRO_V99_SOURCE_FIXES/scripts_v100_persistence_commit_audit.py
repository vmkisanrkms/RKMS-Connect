#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'month lock persists candidate before mutating in-memory state':'val next=(if(locked) (lockedLabourMonths+month) else lockedLabourMonths.filterNot{it==month}).distinct().sortedDescending()' in s and 'if(!prefs.edit().putString("lockedLabourMonths",payload).commit()) return false\n        lockedLabourMonths=next' in s,
 'month lock operation is synchronized':'@Synchronized fun setLabourMonthLocked(month:String,locked:Boolean):Boolean' in s,
 'field reorder persists before publishing reordered list':'if(!persistFieldOrder(reordered)) return false\n        fields=reordered' in s,
 'field order uses synchronous commit':'prefs.edit().putString("fieldOrder",order.joinToString("|"){it.id}).commit()' in s,
 'Fandi rate rejects invalid values':'if(!value.isFinite() || value<=0.0) return false' in s,
 'Fandi rate persists before memory update':'if(!prefs.edit().putString("fandiRate",value.toString()).commit()) return false\n        fandiRate=value' in s,
 'regression checks cover invalid and persistent Fandi rate':'invalid Fandi rate cannot replace persisted setting' in s and 'valid Fandi rate persists before publishing new state' in s,
 'regression checks cover lock persistence after Store recreation':'month lock commits before reporting success and survives Store recreation' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
print(f'{sum(checks.values())}/{len(checks)} persistence checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
