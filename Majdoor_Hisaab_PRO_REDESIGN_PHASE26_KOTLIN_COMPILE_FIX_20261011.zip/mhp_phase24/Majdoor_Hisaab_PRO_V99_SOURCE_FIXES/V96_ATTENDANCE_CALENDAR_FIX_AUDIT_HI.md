# V96 — Attendance Calendar Fix Audit

## Actual source change
- `AttendanceHistoryScreen` now includes a Monday-first, six-week calendar.
- Previous-month navigation works; next-month navigation is bounded to the current month.
- Dates with attendance show a distinct background and a distinct-worker count.
- Tapping a date shows the recorded workers, attendance fraction, and wage for that day.
- Selected date and calendar month use saveable Compose state.
- Added `attendanceCalendarCells(year, monthZeroBased)` with invalid-month protection and deterministic ISO date cells.
- Added isolated Android runtime assertions for October 2026 weekday offset, six-week grid, leap-year February 29, and invalid month rejection.

## Checks run in this workspace
- `scripts_v96_attendance_calendar_audit.py`: 12/12 PASS.
- `scripts_v93_96_point_source_trace.py`: 96/96 source traces PASS.
- Android instrumentation runtime remains pending until GitHub Actions/emulator actually executes the test.

## Status
E07 is source-fixed and statically checked. It is **not** marked as Android UI runtime verified until a real emulator run passes.
