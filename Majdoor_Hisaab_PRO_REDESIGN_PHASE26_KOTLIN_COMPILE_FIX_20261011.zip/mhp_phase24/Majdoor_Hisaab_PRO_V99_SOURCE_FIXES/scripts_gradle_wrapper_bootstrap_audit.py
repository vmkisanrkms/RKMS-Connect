#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
workflow=(ROOT/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
bootstrap=(ROOT/'scripts/bootstrap-gradle-wrapper.sh').read_text(encoding='utf-8')
props=(ROOT/'gradle/wrapper/gradle-wrapper.properties').read_text(encoding='utf-8')
checks={
 'wrapper bootstrap script exists': (ROOT/'scripts/bootstrap-gradle-wrapper.sh').is_file(),
 'Gradle distribution pinned to 8.11.1': 'gradle-8.11.1-bin.zip' in props,
 'distribution checksum is a 64-character SHA-256': any(line.startswith('distributionSha256Sum=') and len(line.split('=',1)[1])==64 for line in props.splitlines()),
 'bootstrap verifies distribution checksum before unpacking': 'sha256sum --check --strict' in bootstrap,
 'bootstrap has two official distribution hosts': 'services.gradle.org/distributions/' in bootstrap and 'downloads.gradle.org/distributions/' in bootstrap,
 'bootstrap validates GradleWrapperMain class': "org/gradle/wrapper/GradleWrapperMain.class" in bootstrap,
 'bootstrap re-pins distribution URL and checksum': 'distributionSha256Sum=$EXPECTED_DIST_SHA' in bootstrap and 'EXPECTED_URL=' in bootstrap,
 'workflow invokes bootstrap before wrapper build': 'bash scripts/bootstrap-gradle-wrapper.sh' in workflow,
 'workflow validates wrapper version before compile': './gradlew --version' in workflow,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+label)
print(f'SUMMARY: {sum(checks.values())}/{len(checks)} PASS, {sum(not v for v in checks.values())} FAIL')
sys.exit(0 if all(checks.values()) else 1)
