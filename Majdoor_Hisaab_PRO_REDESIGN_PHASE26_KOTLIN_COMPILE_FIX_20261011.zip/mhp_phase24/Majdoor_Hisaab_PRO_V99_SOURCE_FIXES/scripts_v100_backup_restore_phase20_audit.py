from pathlib import Path
import sys
root=Path(__file__).resolve().parent
s=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text()
checks={
 'backup uses staging and previous destination before replacing':'output.name+".staging-"+UUID.randomUUID()' in s and 'output.name+".previous-"+UUID.randomUUID()' in s and 'validateBackupZip(staging)' in s,
 'backup metadata keeps history and recovery raw data':'put("backupHistory"' in s and 'put("recoveryData"' in s,
 'backup captures locked month and all modules':'"lockedLabourMonths"' in s and '"canePeelingPayment"' in s,
 'backup archive validated after final install':'validateBackupZip(output)' in s,
 'ZIP validation limits decompressed bytes':'readZipEntryLimited(zis,100L*1024L*1024L-total)' in s,
 'ZIP validation rejects duplicate names/traversal/absolute paths':'if(!names.add(name))' in s and 'name.contains("..")' in s and 'Regex("^[A-Za-z]:")' in s,
 'schema-v2 requires valid collections and photos':'schema>=2 && photoMap==null' in s and 'डेटा गलत या गायब है' in s,
 'restore validates before mutation':'// Complete validation happens before any preference/photo mutation.\n        validateBackupZip(input)' in s,
 'restore snapshots preferences and recovery keys':'val preferenceSnapshot=managedKeys.associateWith' in s and 'existingRecoveryKeys' in s,
 'restore keeps rollback photo copy':'val rollbackPhotos=File(rollbackDir,"photos")' in s and 'if(hadPhotoDir) copyDirectory(photoDir,rollbackPhotos)' in s,
 'failure-injection rollback hook retained':'restoreBackupZipWithInjectedFailureForTest' in s and 'Injected restore failure for rollback regression test' in s,
 'restore rollback uses snapshot':'preferenceSnapshot[key]' in s and 'पुराने डेटा को वापस रखने की कोशिश' in s,
 'persisted JSON validated before rollback snapshot discarded':'backupKeys.forEach{key->JSONArray(prefs.getString(key,"[]") ?: "[]")}' in s,
 'Drive restore selects only mhbackup':'chosen ?: throw IllegalStateException("Google Drive folder में कोई वैध .mhbackup' in s,
 'Drive backup validates archive before upload':'store.createBackupZip(temp)\n                        store.validateBackupZip(temp)' in s,
 'consent retry uses recoverable intent and guard':'driveConsentLauncher.launch(error.consentIntent)' in s and 'consentRetryInProgress' in s and 'pendingDriveAction="" // consume before any retry' in s,
 'manual export validates and checks byte count':'store.validateBackupZip(temp)' in s and 'copied!=expectedBytes' in s,
 'manual export reads back and validates':'mhpro_backup_verify_' in s and 'store.validateBackupZip(verify)' in s,
 'restore picker validates before confirmation':'store.validateBackupZip(temp!!)' in s and 'Restore से पहले पुष्टि और screen-lock जाँच होगी' in s,
 'pre-restore safety backup enabled by default':'backupBeforeRestore",true' in s and 'safety backup नहीं बन पाया' in s,
 'backup history recorded and shown':'recordBackupHistory(context,"Local Backup"' in s and 'recordBackupHistory(context,"Google Drive Backup"' in s and 'Backup / Restore History' in s,
 'local store remains offline capable':'getSharedPreferences("mhpro_store"' in s,
 'Drive permission and auth dependency present':'android.permission.INTERNET' in (root/'app/src/main/AndroidManifest.xml').read_text() and 'play-services-auth:21.3.0' in (root/'app/build.gradle.kts').read_text(),
 'restore failure-injection hook remains available':'restoreBackupZipWithInjectedFailureForTest(input:File)' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS, {sum(not x for x in checks.values())} FAIL')
sys.exit(0 if all(checks.values()) else 1)
