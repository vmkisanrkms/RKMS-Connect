# Majdoor Hisaab PRO — Feature Preservation Matrix V93

**Purpose:** Verify that cross-app hardening does not remove or rewrite existing business modules. This is a source-preservation matrix; it is not a substitute for the Android runtime regression run.

## Preserved modules and boundaries

| Module | Source components / data | Required behavior | V93 source status | Runtime status |
|---|---|---|---|---|
| App launch / device lock | `MainActivity`, `DeviceCredentialGate`, `appUnlocked` | Keep Android screen-lock gate; do not add mandatory app account login | Preserved | Pending emulator test |
| Local/offline data | `Store`, `SharedPreferences`, `read`, `write`, recovery raw keys | Local accounting must not depend on internet; malformed JSON must not crash launch or silently destroy original raw data | Hardened; recovery copy is backed up | Pending device/offline test |
| Workers | `Labour`, `LabourScreen`, `LabourDetail`, `addLabour`, `updateLabour`, `deleteLabour` | Prevent duplicates; preserve attendance/payment/rate/closure history | Preserved; delete guard now includes finalized closures | Pending device test |
| Daily Labour / attendance | `AttendanceScreen`, `AttendanceHistoryScreen`, `TodayAttendanceScreen`, `upsertAttendance`, `lockedLabourMonths` | Full/half-day, absent marker, optional field attendance, month lock, old ledger visibility; bulk actions must skip already marked workers | Hardened; absent and bulk attendance paths added | Pending device test |
| Wage/payment ledger | `Payment`, `addPayment`, `updatePayment`, `outstandingBalance`, worker ledger PDF | Payment on later unlocked date can settle old outstanding; payment add/edit/delete inside a locked month is rejected; old closed balance must be included in total balance | Hardened; reconciliation helper and locked-month payment mutation guards added; runtime pending | Pending device/PDF test |
| Fields / crops | `Field`, `Crop`, `FieldDetail`, `CropDetail` | Keep field/crop relations; reject invalid references; do not delete linked financial history | Preserved | Pending device test |
| Expenses / sales | `Expense`, `Sale`, `ExpenseScreen`, `SaleScreen` | Validate positive finite values and relation references; keep blank field optional where designed | Preserved / storage validation present; expense field/crop now explicitly optional | Pending device test |
| Reports / PDF / CSV | `AllLabourReportScreen`, `exportWorkerLedgerPdf`, `exportAllWorkersLedgerPdf`, `exportDateFieldReportPdf` | Keep selected date/field/worker scopes; show payment on payment date; avoid Excel-style ledger layout and daily-rate column | Hardened for default range and reconciled balance | Pending visual PDF test |
| Ganna Chhilayi / फांदी | `CanePeeling`, `CanePeelingScreen`, `CanePeelingLabourDetail`, `fandiLabours`, `canePeelings`, `canePeelingPayments` | Preserve existing single-worker workflow, फांदी label, persistent rate, duplicate prevention, totals and payment records | Business logic left in place; regression source checks retained | Pending emulator/device test |
| Ganna Parchi | `CaneParchi`, `CaneParchiDashboardScreen`, `CaneParchiDetail`, `caneParchis` | Preserve season, code, date, weight, rate, photo and remark data; reject duplicate season+code | Business logic left in place; regression source checks retained | Pending emulator/device test |
| Google Drive backup/restore | `GoogleDriveDirect`, consent flow, `createBackupZip`, `validateBackupZip`, `restoreBackupZip` | User-triggered Drive only; validate before mutation; preserve raw recovery metadata and roll back on failure | Hardened; backup history included | Pending real Google-account round-trip |
| Settings | `ProfileScreen`, theme preference, reminder settings, report range, About | Light/Dark/System, auto-lock, optional attendance reminder, default report range and app version visible | Source changes added | Pending Android UI/permission tests |
| Navigation/lifecycle | `Screen`, `encodeScreen`, `decodeScreen`, saveable stack and report selections | Back navigation and selected date/field/worker state should survive recreation | Saveable state added | Pending rotation/recreate test |
| Build/release | `.github/workflows/majdoor-hisaab.yml`, version `1.93.0`, versionCode `93` | Compile, test, sign with permanent release key, verify package/alignment/signature | Workflow updated; not executed for V93 | Pending CI run |

## Mandatory release gates

- [ ] V93 `compileReleaseKotlin` and `assembleRelease` succeed.
- [ ] Android instrumentation regression tests execute and pass on emulator.
- [ ] Install and test on a real Android phone, including theme, reminder permission, reboot rescheduling and navigation.
- [ ] Create a backup, restore it into a clean test install, and verify all records, photos, lock state and recovery metadata.
- [ ] Visually inspect the green-and-white worker PDF ledger and confirm payment dates/amounts and no daily-rate column.
- [ ] Run Daily Labour, Ganna Chhilayi and Ganna Parchi regression scenarios without data loss.
- [ ] Confirm signed APK package ID, signing certificate, zip alignment and SHA-256.
- [ ] Only then produce the final ZIP/APK and tick Q10.

**Current verdict:** source preservation checks exist, but no claim of full runtime verification or final release readiness is made.
