#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
 'shared persistList reports synchronous commit result':'private fun <T> persistList(key:String,list:List<T>,mapper:(T)->JSONObject):Boolean' in s and '.commit()' in s[s.index('private fun <T> persistList'):s.index('private fun <T> write')],
 'worker add persists profile and rate history atomically before publish':'val editor=prefs.edit().putString("labour",JSONArray(nextLabours.map(::obj)).toString())' in s and 'if(!editor.commit()) return false\n        labours=nextLabours' in s,
 'worker edit persists candidate before publish':'val nextLabours=labours.map{if(it.id==x.id)normalized else it}' in s and 'if(!editor.commit()) return false\n        labours=nextLabours' in s,
 'worker active status persists before publish':'if(!persistList("labour",next,::obj)) return false\n        labours=next' in s,
 'Fandi add persists before publish':'if(!persistList("fandiLabour",next,::obj)) return false\n        fandiLabours=next' in s,
 'Fandi edit persists before publish':'val next=fandiLabours.map{if(it.id==x.id)x.copy(name=x.name.trim().replace(Regex("\\\\s+")," ")) else it}' in s,
 'Fandi delete persists before publish':'val next=fandiLabours.filterNot{it.id==id}\n        if(!persistList("fandiLabour",next,::obj)) return false\n        fandiLabours=next' in s,
 'field add persists data and ordering atomically':'val next=fields+x.copy(name=name)' in s and '.putString("fieldOrder",next.joinToString("|"){it.id})' in s and 'if(!editor.commit()) return false\n        fields=next' in s,
 'field edit persists candidate before publish':'val next=fields.map{if(it.id==x.id)x.copy(name=name) else it}\n        if(!persistList("field",next,::obj)) return false' in s,
 'crop add persists candidate before publish':'val next=crops+x.copy(name=name,season=x.season.trim())\n        if(!persistList("crop",next,::obj)) return false' in s,
 'crop edit persists candidate before publish':'val next=crops.map{if(it.id==x.id)x.copy(name=name,season=x.season.trim()) else it}\n        if(!persistList("crop",next,::obj)) return false' in s,
 'crop delete persists candidate before publish':'val next=crops.filterNot{it.id==id}\n        if(!persistList("crop",next,::obj)) return false' in s,
 'expense add persists candidate before publish':'val next=expenses+x\n        if(!persistList("expense",next,::obj)) return false' in s,
 'expense edit persists candidate before publish':'val next=expenses.map{if(it.id==x.id)x else it}\n        if(!persistList("expense",next,::obj)) return false' in s,
 'sale add persists candidate before publish':'val next=sales+x\n        if(!persistList("sale",next,::obj)) return false' in s,
 'sale edit persists candidate before publish':'val next=sales.map{if(it.id==x.id)x else it}\n        if(!persistList("sale",next,::obj)) return false' in s,
 'payment add persists candidate before publish':'val next=payments+x\n        if(!persistList("payment",next,::obj)) return false' in s,
 'payment edit persists candidate before publish':'val next=payments.map{if(it.id==x.id)x else it}\n        if(!persistList("payment",next,::obj)) return false' in s,
 'payment delete persists candidate before publish':'val next=payments.filterNot{it.id==id}\n        if(!persistList("payment",next,::obj)) return false' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} V101 persist-first checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
