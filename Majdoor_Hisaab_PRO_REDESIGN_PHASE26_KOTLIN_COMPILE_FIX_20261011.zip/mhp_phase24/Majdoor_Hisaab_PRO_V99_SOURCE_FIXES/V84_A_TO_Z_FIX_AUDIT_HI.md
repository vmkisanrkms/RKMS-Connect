# Majdoor Hisaab PRO V84 — A-to-Z Fix Audit

तारीख: 11 अक्टूबर 2026
Package: `com.majdoor.hisaabpro`
Version: `1.84.0` / versionCode `84`

## इस संशोधन में वास्तविक source fixes

1. Dashboard का **मजदूर** कार्ड अब `LabourList` खोलता है; पहले यह गलती से Daily Labour home खोल रहा था।
2. Dashboard की **हाजिरी लगाएँ** कार्रवाई `DailyLabourHome` पर ही जाती है।
3. अज्ञात Dashboard route को Crop List पर भेजने के बजाय More screen पर भेजा जाता है।
4. Daily Labour Accounts का **खेतवार हिसाब** शॉर्टकट अब Field List के बजाय मौजूदा report centre खोलता है।
5. More menu में मजदूर सूची, महीने का हिसाब/लॉक, तारीख-खेत रिपोर्ट और खेत प्रबंधन के सीधे shortcuts जोड़े गए।
6. GitHub Actions में पाँच source regression audit scripts जोड़ी गई हैं; audit fail होने पर build रुक जाएगा।
7. Version `1.84.0` / `versionCode 84` और V84 release artifact नाम सेट किया गया है।

## इस पैकेज पर चले source-level checks

- Daily Labour + navigation: **30/30 PASS**
- Date/field report: **11/11 PASS**
- Google Drive consent/restore static checks: **11/11 PASS**
- Selected worker/report/sale checks: **16/16 PASS**
- V84 navigation regression: **10/10 PASS**
- Kotlin parser diagnostic scan: `expecting` / `unexpected tokens` जैसे syntax diagnostics नहीं मिले।

## क्या अभी प्रमाणित नहीं है

- Android Gradle compile और Release APK assembly इस environment में सफलतापूर्वक नहीं चला। Android/Compose dependencies और Gradle wrapper JAR उपलब्ध नहीं थे; इसलिए Kotlin parser scan को Android build PASS नहीं माना गया है।
- वास्तविक फोन पर install/upgrade, back navigation, screen rotation, restart persistence, offline behavior, PDF share, Google Sign-In/Drive backup/restore का परीक्षण नहीं हुआ।
- Google Drive के सफल sign-in के लिए GitHub/Google Cloud में सही OAuth client तथा signing SHA configuration होना आवश्यक है।
- पूरी ऐप की प्रत्येक स्क्रीन के लिए end-to-end व्यवहारिक परीक्षण अभी बाकी है।

## सुरक्षित रखे गए नियम

- मौजूदा local data model और record IDs नहीं बदले गए।
- Google Drive Backup/Restore बना हुआ है; कोई नया Supabase/Firebase/cloud sync या mandatory login नहीं जोड़ा गया।
- गन्ना छिलाई/फांदी की गणना, saved rate और single-worker entry logic तथा गन्ना पर्ची का business logic इस pass में नहीं बदला गया।
- मासिक lock और भुगतान/हिसाब calculations को UI/navigation correction के दौरान नहीं बदला गया।

**निष्कर्ष:** इस ZIP में उपर्युक्त navigation bugs और source-level routing issues ठीक किए गए हैं तथा regression checks CI में जोड़े गए हैं। इसे Android build-tested या पूर्ण device-verified घोषित नहीं किया जा सकता, जब तक GitHub Actions build और वास्तविक फोन पर smoke tests सफल न हों।
