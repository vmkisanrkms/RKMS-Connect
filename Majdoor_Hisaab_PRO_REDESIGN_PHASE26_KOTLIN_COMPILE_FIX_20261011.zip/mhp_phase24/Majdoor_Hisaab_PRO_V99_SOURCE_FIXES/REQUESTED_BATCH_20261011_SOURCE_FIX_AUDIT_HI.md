# अनुरोधित source-fix batch — 11 अक्टूबर 2026

## इस batch में वास्तविक source बदलाव

1. **I03 / J03 — Expense और Sale delete safety:** delete functions अब `@Synchronized` हैं, blank/unknown IDs पर `false` लौटाते हैं, पहले next-state तैयार करते हैं और SharedPreferences `commit()` सफल होने के बाद ही in-memory state बदलते हैं। इससे double-tap/unknown-ID delete को स्पष्ट रूप से reject किया जाता है और disk-write failure पर memory को सफल deletion जैसा नहीं दिखाया जाता।
2. **M03 / M-parchi delete safety:** Parchi deletion में वही synchronized, known-ID-only, commit-before-state-update guard जोड़ा गया। Existing add/edit duplicate-season/code validation बरकरार है।
3. **L12 — Chhilayi/Fandi delete safety:** Chhilayi entry और Fandi payment deletion अब synchronized, known-ID-only और commit-before-state-update हैं। Existing duplicate worker-field-date और payment validation बरकरार है।
4. **Regression checks:** Expense/Sale delete idempotence + persistence, Parchi duplicate edit rejection + delete persistence के isolated Store regression assertions जोड़े।

## Recheck

- Requested 96-point source trace: **96/96 PASS** (source markers/route presence only).
- Data integrity audit: **62/62 PASS**.
- Restore atomicity audit: **23/23 PASS**.
- Locked-month payment audit: **42/42 PASS**.
- Fandi UI regression audit: **11/11 PASS**.
- CSV formula-injection audit: **13/13 PASS**.
- Empty Parchi export guard: **5/5 PASS**.

## अभी प्रमाणित नहीं

यह batch Android compile/install/runtime का प्रमाण नहीं है। इस environment में Gradle wrapper JAR/Android SDK उपलब्ध नहीं हैं; इसलिए device PIN/biometric, attendance UI, backup/restore round-trip, PDF visuals, rotation और Ganna regressions को runtime PASS नहीं माना गया। Checklist में runtime status को कृत्रिम रूप से PASS नहीं किया गया।
