#!/usr/bin/env python3
"""Phase 22 locked-month payment immutability audit (source assertions)."""
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/"app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt").read_text(encoding="utf-8")
checks={
 "new payment rejected in locked month": "payments.any{it.id==x.id} || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)" in src,
 "editing stored locked payment rejected before changing date": "if(isMonthLocked(existing.date) || isClosedDate(existing.labourId,existing.date)) return false" in src,
 "editing proposed locked date rejected": "x.labourId!=existing.labourId || !validPayment(x) || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)" in src,
 "payment owner cannot change during edit": "x.labourId!=existing.labourId" in src,
 "deleting locked payment rejected": "if(isMonthLocked(row.date) || isClosedDate(row.labourId,row.date)) return false" in src,
 "UI explains existing locked payment cannot be changed": "यह भुगतान लॉक महीने का है। पुराना भुगतान बदला या हटाया नहीं जा सकता।" in src,
 "UI explains target locked month and recommends later open date": "इस महीने में भुगतान दर्ज/बदल नहीं सकते; पुराने बकाये के लिए खुली बाद की तारीख चुनें।" in src,
 "locked payment edit/delete regression present": "locked month payment cannot be edited or deleted even when later date is open" in src,
 "locked payment move-forward regression present": "locked payment cannot be moved to an unlocked month" in src,
 "locked month add/edit/delete regression present": "locked-month payment cannot be edited into or deleted from finalized month" in src,
 "later unlocked payment can settle old balance": "later unlocked payment can settle locked month's outstanding balance" in src,
 "worker transfer regression present": "payment edit cannot transfer an existing payment to another worker" in src,
 "payment form checks locked old and target dates": "existing!=null && store.isMonthLocked(existing.date)" in src and "store.isMonthLocked(date)->error=" in src,
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+" - "+name)
print(f"{sum(checks.values())}/{len(checks)} Phase 22 payment-lock checks passed")
raise SystemExit(0 if all(checks.values()) else 1)
