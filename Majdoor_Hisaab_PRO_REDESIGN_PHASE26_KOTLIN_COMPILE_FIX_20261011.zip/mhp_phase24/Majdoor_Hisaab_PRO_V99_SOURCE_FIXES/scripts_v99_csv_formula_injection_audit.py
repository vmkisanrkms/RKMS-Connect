#!/usr/bin/env python3
"""Static regression audit for spreadsheet formula injection in exported CSV files."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt"
s = SRC.read_text(encoding="utf-8")
checks = {
    "shared CSV cell sanitizer exists": "private fun csvCell(value:String):String {" in s,
    "formula equals prefix is neutralized": "firstMeaningful in setOf('=', '+', '-', '@')" in s,
    "tab prefix is neutralized": "value.firstOrNull() == '\\t'" in s,
    "carriage return prefix is neutralized": "value.firstOrNull() == '\\r'" in s,
    "line feed prefix is neutralized": "value.firstOrNull() == '\\n'" in s,
    "BOM and zero-width prefixes are considered during detection": "it == '\\uFEFF'" in s and "it == '\\u200B'" in s,
    "runtime regression covers BOM/zero-width/newline prefixes": 'csvCell("\\uFEFF=1+1")' in s and 'csvCell("\\u200B@cmd")' in s and 'csvCell("\\n=1+1")' in s,
    "CSV quoting still doubles embedded quotes": 'safe.replace("\\\"","\\\"\\\"")' in s,
    "date-field export uses sanitizer": 'joinToString(","){csvCell(it)}' in s,
    "cane peeling export uses sanitizer": 'buildCanePeelingCsv' in s and 'joinToString(","){csvCell(it)}' in s,
    "cane parchi CSV uses sanitizer": 'p.name,p.fatherName,p.code,displayDate(p.date)' in s and 'joinToString(","){csvCell(it)}' in s,
    "runtime formula injection regression exists": 'CSV cells neutralize spreadsheet formula injection' in s,
    "runtime regression checks normal numeric cells": 'csvCell("125.50")=="\\\"125.50\\\""' in s,
}
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"RESULT: {sum(checks.values())}/{len(checks)}")
if not all(checks.values()):
    sys.exit(1)
