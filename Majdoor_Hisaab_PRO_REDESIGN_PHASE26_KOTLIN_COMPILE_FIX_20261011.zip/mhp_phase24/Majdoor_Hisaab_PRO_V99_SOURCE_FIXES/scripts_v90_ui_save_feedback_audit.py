#!/usr/bin/env python3
"""Static regression gate for CRUD rejection feedback and no silent form close."""
from pathlib import Path
s = Path('app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks = {
    'field add/update report explicit success': 'fun addField(x:Field):Boolean' in s and 'fun updateField(x:Field):Boolean' in s,
    'crop add/update report explicit success': 'fun addCrop(x:Crop):Boolean' in s and 'fun updateCrop(x:Crop):Boolean' in s,
    'expense add/update report explicit success': 'fun addExpense(x:Expense):Boolean' in s and 'fun updateExpense(x:Expense):Boolean' in s,
    'sale add/update report explicit success': 'fun addSale(x:Sale):Boolean' in s and 'fun updateSale(x:Sale):Boolean' in s,
    'field form remains open on duplicate or invalid save': 'if(saved)onClose() else error="खेत का नाम जरूरी है और नाम/ID दोहराया नहीं जा सकता।"' in s,
    'crop form remains open on duplicate or invalid save': 'if(saved){error="";onClose()}else error="इस खेत/सीजन में फसल पहले से है, विवरण गलत है, या पुराना रिकॉर्ड जुड़ा होने से खेत बदलना सुरक्षित नहीं है।"' in s,
    'expense form remains open when persistence rejects row': 'if(saved)onClose() else error="खर्च सेव नहीं हुआ। रिकॉर्ड/खेत/फसल जाँचें और दोबारा कोशिश करें।"' in s,
    'sale form checks Boolean result rather than exception only': '.onSuccess { saved->if(saved){error="";onClose()}else error=' in s,
    'runtime harness verifies duplicate field/crop writes return false': 'duplicate field names/IDs return failure' in s and 'duplicate save returns failure' in s,
    'runtime harness verifies expense/sale rejected writes return false': 'duplicate expense saves return failure' in s and 'duplicate sale saves return failure' in s,
    'month lock accepts only real month numbers': 'Regex(\"\\\\d{4}-(0[1-9]|1[0-2])\")' in s and 'month lock rejects impossible month values' in s,
    'Fandi worker rates reject non-finite and negative values': 'fun addFandiLabour(x:FandiLabour):Boolean{\n        if(x.id.isBlank() || x.name.isBlank() || !x.rate.isFinite() || x.rate<0' in s and 'fun updateFandiLabour(x:FandiLabour):Boolean{\n        if(fandiLabours.none{it.id==x.id} || x.name.isBlank() || !x.rate.isFinite() || x.rate<0' in s,
    'Cane parchi code is numeric six or seven digits at storage layer': 'Regex(\"\\\\d{6,7}\").matches(x.code.trim())' in s and 'code=\"ABC123\"' in s,
    'version remains 1.94': 'versionCode = 94' in Path('app/build.gradle.kts').read_text() and 'versionName = "1.94.0"' in Path('app/build.gradle.kts').read_text(),
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'{sum(checks.values())}/{len(checks)} V92 CRUD feedback checks passed')
if not all(checks.values()): raise SystemExit(1)
