#!/usr/bin/env python3
"""Point-by-point source trace for the 96 requested items. Presence is not runtime proof."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parent
SRC=(ROOT/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
WORKFLOW=(ROOT/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
MATRIX=(ROOT/'FEATURE_PRESERVATION_MATRIX_V93.md').read_text(encoding='utf-8')
PACKAGER=(ROOT/'scripts_finalize_release_package.py').read_text(encoding='utf-8')
markers={
'A01':['installSplashScreen()'], 'A04':['dataWarning','recovery_raw_$key'], 'A05':['स्थानीय डेटा','Drive से खाली backup मिला'], 'A06':['themeChoice','LightPalette','DarkPalette'],
'B01':['private fun Dashboard(store:Store'], 'B02':['todayAttendances'], 'B03':['paidToday'], 'B04':['totalOutstanding'], 'B05':['recentPayments','recentAttendance','onGo("payments")','PaymentHistoryScreen'], 'B06':['त्वरित काम','onGo("labour")'], 'B07':['val crops=store.crops.size'],
'C01':['private fun LabourScreen(store:Store'], 'C04':['private fun LabourDetail('], 'C05':['private fun AttendanceHistoryScreen'], 'C06':['workDays'], 'C07':['paymentRows','PaymentHistoryScreen','kind=="advance"','ChoiceField("प्रविष्टि का प्रकार"'], 'C08':['exportWorkerLedgerPdf','exportAllWorkersLedgerPdf'], 'C09':['fun deleteLabour(id:String):Boolean','fun setLabourActive(id:String,active:Boolean):Boolean','showInactive','it.active &&'],
'D01':['DailyLabourHomeScreen'], 'D02':['DailyLabourAccountsScreen','setLabourMonthLocked'], 'D03':['var selectedMonth by rememberSaveable','monthAttendance=store.attendances.filter'], 'D07':['exportAllWorkersLedgerPdf'],
'E02':['AttendanceDateButton(selectedDate)'], 'E04':['fraction==0.5','fraction==0.0'], 'E05':['bulkConfirm','Bulk हाजिरी:'], 'E06':['upsertAttendance'], 'E07':['attendanceCalendarCells','attendance_month_calendar','calendarRowsByDate'], 'E08':['AttendanceHistoryScreen','fraction>0.0'], 'E10':['attendanceConflict','इस मजदूर की इस तारीख'],
'F01':['AttendanceScreen(store'], 'F02':['workDays','attendanceRows'], 'F03':['rateHistoryFor','fun setRate'], 'F08':['outstandingBalance(labourId:String)'],
'G03':['private fun FieldDetail(store:Store'], 'G05':['exportDateFieldReportPdf'], 'H03':['private fun CropDetail(store:Store'], 'H04':['private fun ExpenseScreen'], 'H05':['private fun SaleScreen'],
'I01':['private fun ExpenseScreen'], 'I04':['private fun ExpenseDialog'], 'I05':['store.expenses.filter{it.cropId==id}.sumOf{it.amount}','val labourCost=store.attendances.filter{it.fieldId==id}'],
'J01':['private fun SaleScreen'], 'J03':['fun deleteSale(id:String)','protectedDelete=s'], 'J04':['लाभ','sale-total'],
'K01':['private fun AllLabourReportScreen'], 'K02':['तारीख और खेत के अनुसार PDF रिपोर्ट'], 'K03':['currentMonthDefault','reportDefaultRange'], 'K04':['selectedWorkers','selectedFields'], 'K05':['selectedAttendance','selectedPayments'], 'K06':['exportAllWorkersLedgerPdf'], 'K07':['exportDateFieldReportCsv'], 'K08':['exportAttendanceHistoryPdf'], 'K09':['exportWorkerLedgerPdf'], 'K10':['shareFile(context'], 'K11':['कोई हाजिरी या भुगतान नहीं मिला'],
'L01':['private fun CanePeelingScreen'], 'L08':['private fun CanePeelingLabourDetail'], 'L11':['exportCanePeelingCsv'],
'M01':['private fun CaneParchiDashboardScreen'], 'M02':['val allRows = filterCaneParchiSeason(store.caneParchis, season)','listOf("ALL" to "सभी सीजन")'], 'M04':['private fun CaneParchiDetail'], 'M05':['deleteCaneParchi','पर्ची हटाएं'], 'M06':['exportCaneCsv','गन्ना_पर्ची_'],
'N01':['private fun BackupScreen'], 'N02':['driveSignInLauncher','GoogleSignIn.getSignedInAccountFromIntent'], 'N03':['drive.upload(account,temp)','drive.downloadLatest(account,temp)'], 'N04':['ActivityResultContracts.OpenDocument'], 'N05':['ActivityResultContracts.CreateDocument'], 'N07':['Restore से पहले','Restore करने पर मौजूदा app data'], 'N09':['validateBackupZip'], 'N10':['backupHistory','recordBackupHistory'],
'O01':['private fun ProfileScreen'], 'O02':['onThemeChanged','themeChoice'], 'O03':['DeviceCredentialGate'], 'O04':['BiometricPrompt'], 'O05':['autoLockMinutes','Lifecycle.Event.ON_STOP'], 'O06':['dailyAttendanceReminderEnabled','scheduleDailyAttendanceReminder'], 'O07':['reportDefaultRange'], 'O08':['onBackup','Backup & Restore'], 'O09':['BuildConfig.VERSION_NAME','BuildConfig.APPLICATION_ID'],
'P01':['BackHandler(enabled=true)','fun back()'], 'P02':['IconButton(onClick'], 'P03':['SimpleDialog'], 'P05':['AlertDialog('], 'P06':['डेटा recovery चेतावनी','attendanceError'], 'P07':['ConfirmDialog('], 'P08':['labourNameExists','duplicate parchi code'], 'P09':['fontSize=','Modifier.fillMaxWidth()'], 'P10':['LifecycleEventObserver','rememberSaveable(saver=screenStackSaver)'],
'Q01':['Mandatory release gates','Ganna Chhilayi','Ganna Parchi'], 'Q03':['runCoreStoreRuntimeRegression','duplicate parchi code and ID are rejected'], 'Q05':['offline local worker record survives Store recreation'], 'Q06':['Store reinitialization','navigation routes survive save/restore serialization','payment-history'], 'Q08':['Compile Release Kotlin','scripts_v93_96_point_source_trace.py'], 'Q09':['verify --verbose','Upload Release APK'], 'Q10':['REQUIRED_GATES','FINAL_RUNTIME_VERIFICATION.json','Fully fixed + Android runtime verified']
}
rows=list(csv.DictReader((ROOT/'V94_REQUESTED_96_POINT_FIX_CHECKLIST.csv').open(encoding='utf-8-sig')))
if len(rows)!=96: raise SystemExit(f'FAIL - checklist row count {len(rows)} != 96')
failed=[]
for row in rows:
    pid=row['ID']; source=SRC
    if pid=='Q01': source=MATRIX
    if pid=='Q08' or pid=='Q09': source=WORKFLOW
    if pid=='Q10': source=PACKAGER
    required=markers.get(pid,[])
    ok=bool(required) and all(mark in source for mark in required)
    print(('PASS' if ok else 'FAIL')+f' - {pid} {row["Point"]}')
    if not ok: failed.append((pid,required))
print(f'{96-len(failed)}/96 requested point source traces found')
if failed:
    print('Missing:',failed)
    raise SystemExit(1)
