#!/usr/bin/env python3
from pathlib import Path
import re, sys
p=Path(__file__).resolve().parents[0]/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'selected worker IDs filter the monthly rows': 'val picked = monthRows.filter { it.labour.id in selectedWorkers }' in s,
 'PDF export receives only selected rows': 'exportAllWorkersLedgerPdf(context,"${month}_chune_mazdoor",monthTitle(month),"सभी खेत",picked,wage,paid,background=true)' in s,
 'photo export receives only selected rows': 'picked.map{"${it.labour.name} • काम ${quantity(it.workDays)} दिन • मजदूरी ₹${money(it.wage)} • भुगतान ₹${money(it.paid)} • बकाया ₹${money(it.wage-it.paid)}"}' in s,
 'selected totals are calculated from selected rows': 'val wage = picked.sumOf { it.wage }; val paid = picked.sumOf { it.paid }' in s,
 'empty selection is blocked for PDF/photo': s.count('if(picked.isEmpty()) validation="पहले मजदूर चुनें।"') >= 2,
 'selection controls appear before export controls': s.index('items(rows,key={it.labour.id})') < s.index('PDF / फोटो रिपोर्ट के लिए मजदूर चुनें'),
 'individual PDF omits zero-fraction attendance': 'attendanceRows.filter { it.fraction > 0.0 }' in s,
 'individual PDF has payment column and no note box': '"भुगतान (₹)"' in s and 'intentionally no note box' in s.lower(),
 'new-period worker detail excludes dates through closure': 'it.date>lastClosedThrough' in s,
 'attendance writes on closed dates are blocked': 'if(closedThrough.isNotBlank() && x.date<=closedThrough)' in s,
 'fractional formatter preserves half-days': "private fun quantity(v:Double)=String.format(Locale.US,\"%.2f\",v).trimEnd('0').trimEnd('.')" in s,
 'sale save button is visible in dialog confirm area': 'confirmButton={Button(onClick={saveSale()},modifier=Modifier.fillMaxWidth())' in s,
 'sale quantity and rate must be positive finite numbers': 'q==null||q<=0||!q.isFinite()' in s and 'r==null||r<=0||!r.isFinite()' in s,
 'sale total is quantity times rate': 'total=q*r' in s and 'val total=(q?:0.0)*(r?:0.0)' in s,
 'sale persists through existing add/update methods': 'if(isEdit) store.updateSale(x) else store.addSale(x)' in s,
 'sale only closes after successful persistence': '.onSuccess { saved->if(saved){error="";onClose()}else error=' in s,
}
failed=[]
for name, ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} targeted checks passed')
sys.exit(1 if failed else 0)
