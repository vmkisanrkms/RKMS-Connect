# Majdoor Hisaab PRO V90 — continuing fix log

## This pass: backup/restore failure safety
- Restore now validates the archive before mutation and snapshots all managed preference keys plus the existing photo directory.
- Preference writes are synchronously checked; restored photo writes are verified by file size.
- If restore fails, the code attempts to restore old managed preferences and photos, then reloads all in-memory collections from the rolled-back state.
- Temporary rollback data is cleaned in `finally`.
- Schema-2 backup validation now rejects photoMap entries whose mapped photo file is missing.
- Added an internal, test-only injected-failure route and regression assertion that checks records, field order and locked months are rolled back after restore has begun.
- Field/Crop/Expense/Sale add/update storage methods now return explicit Boolean success. The UI leaves the form open and shows an error if storage rejects a duplicate or invalid record.
- Month locking now rejects impossible month values (`00`, `13`, malformed years).
- Fandi worker add/edit storage rejects non-finite and negative rates. Cane parchi storage enforces the same 6–7 digit numeric code contract as its form.
- Legacy schema-1 compatibility remains; missing/invalid Fandi rate now resets to the documented default instead of accidentally retaining the previous device's rate.
- Runtime regression harness now covers linked field/crop deletion protection, finalized labour closure date protection, and ZIP path-traversal rejection without changing existing records.

## Checks
- `scripts_v90_restore_atomicity_audit.py`: 15/15 PASS.
- `scripts_v90_ui_save_feedback_audit.py`: 14/14 PASS.
- `scripts_v88_data_integrity_audit.py`: 62/62 PASS.
- Targeted static scripts: 30/30 + 11/11 + 11 consent checks + 16/16 + 10/10 + 62/62 + 15/15 + 14/14 = 169 checks passed.
- Android compile, signed Release APK and emulator/device runtime are still unverified in this environment. Do not mark V90 final-ready until GitHub Actions/emulator run passes and the remaining tracker rows are resolved.

## Still open
- 130-row A-to-Z tracker remains open; 32 rows have source-hardening evidence but are still runtime-pending. N08 restore rollback also needs real Android failure-path verification.
- Other screens and end-to-end flows still require item-by-item implementation and verification.
