#!/usr/bin/env python3
"""Static regression checks for configurable pre-restore safety backups."""
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
workflow=(root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
checks={
    'safety backup is enabled by default':'getBoolean("backupBeforeRestore",true)' in src,
    'profile exposes a persisted safety-backup setting':'Backup Settings' in src and 'putBoolean("backupBeforeRestore",enabled)' in src,
    'restore creates safety copy before replacing data':'store.createBackupZip(tempSafety)' in src and 'store.validateBackupZip(tempSafety)' in src and 'Pre-restore safety copy' in src,
    'restore is blocked when safety copy creation fails':'safeToRestore=false' in src and 'Restore रोक दिया गया: safety backup नहीं बन पाया। मौजूदा data नहीं बदला।' in src,
    'backup screen exposes the safety restore action':'पिछला Safety Backup Restore करें' in src and 'onClick=onRestoreSafety' in src,
    'safety backup is preserved when selected for restore':'if(!restoringSafety) file.delete()' in src,
    'normal and safety restore both require device credential gate':'DeviceCredentialGate("Backup Restore करें"' in src,
    'CI runs the safety backup settings audit':'python3 scripts_v98_backup_safety_settings_audit.py' in workflow,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+label)
print(f'{sum(checks.values())}/{len(checks)} backup safety settings checks passed')
if not all(checks.values()): raise SystemExit(1)
