#!/usr/bin/env python3
"""Static regression gate for V90 transactional local backup restore."""
from pathlib import Path

source = Path('app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks = {
    'backup validated before restore mutation': source.index('validateBackupZip(input)', source.index('fun restoreBackupZip')) < source.index('val preferenceSnapshot=', source.index('fun restoreBackupZip')),
    'managed preference snapshot exists': 'val preferenceSnapshot=managedKeys.associateWith{key->prefs.getString(key,null)}' in source,
    'old photo folder copied for rollback': 'copyDirectory(photoDir,rollbackPhotos)' in source,
    'restore preference writes are synchronously checked': 'putString(key,arr.toString()).commit()' in source,
    'restored photo bytes are verified': 'target.length().toLong()!=bytes.size.toLong()' in source,
    'failure restores previous managed preferences': 'managedKeys.forEach{key->' in source and 'if(!editor.commit()) throw IllegalStateException("पुरानी preferences वापस सेव नहीं हुईं।")' in source,
    'failure restores prior photo folder': 'if(hadPhotoDir) copyDirectory(rollbackPhotos,photoDir)' in source,
    'forced failure injection is isolated to an internal test method': 'restoreBackupZipWithInjectedFailureForTest' in source and 'restoreBackupZipImpl(input) { throw java.io.IOException(\"Injected restore failure for rollback regression test\") }' in source,
    'runtime test verifies rollback after mutation starts': 'restore failure rolls back existing records, field order and locked months' in source,
    'failure reloads all in-memory store collections': 'labours=loadLabours(); fandiLabours=loadFandiLabours(); fields=loadFields(); crops=loadCrops()' in source and 'canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()' in source,
    'rollback temporary folder always cleaned': 'finally{\n            rollbackDir.deleteRecursively()\n        }' in source,
    'traversal backup regression exists': 'path-traversal backup is rejected without data mutation' in source,
    'schema-2 backup rejects missing mapped photo files': '"photos/$value" !in names' in source,
    'biometric gate uses system biometric plus device credential on Android 11+': 'BiometricPrompt(hostActivity' in source and 'BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL' in source,
    'older Android versions retain device-credential fallback': 'fallbackToDeviceCredential()' in source and 'createConfirmDeviceCredentialIntent(title,message)' in source,
    'MainActivity uses FragmentActivity for biometric prompt host': 'class MainActivity:FragmentActivity()' in source,
    'biometric dependency is declared': 'androidx.biometric:biometric:1.1.0' in Path('app/build.gradle.kts').read_text(),
    'schema-1 missing arrays preserve newer module data': 'if(schema==1 && !root.has(key)) return@forEach' in source,
    'schema-1 missing field order and Fandi rate preserve current settings': 'if(root.has("fieldOrder"))' in source and 'if(root.has("fandiRate") && !prefs.edit().putString("fandiRate",restoredFandiRate.toString()).commit())' in source,
    'runtime regression checks partial schema-1 restore preserves Fandi and field order': 'schema-1 partial restore preserves newer modules and settings' in source,
    'schema-1 restore merges legacy photos instead of deleting absent photo entries': 'if(schema>=2 && photoDir.exists() && !photoDir.deleteRecursively())' in source and 'schema-1 restore without photo entries preserves existing photo file and path' in source,
    'missing mapped-photo regression exists': 'backup with missing mapped photo is rejected before mutation' in source,
    'app version bumped to 1.94': 'versionCode = 94' in Path('app/build.gradle.kts').read_text() and 'versionName = "1.94.0"' in Path('app/build.gradle.kts').read_text(),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'{sum(checks.values())}/{len(checks)} V92 restore atomicity checks passed')
if not all(checks.values()):
    raise SystemExit(1)
