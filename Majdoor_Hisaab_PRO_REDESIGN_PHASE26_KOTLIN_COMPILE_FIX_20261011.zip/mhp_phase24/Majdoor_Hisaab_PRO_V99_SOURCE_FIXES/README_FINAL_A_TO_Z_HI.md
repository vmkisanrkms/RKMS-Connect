> **V86 अपडेट (11 अक्टूबर 2026):** Version `1.86.0` / code `86`. V86 remaining-fix tracker और audit के लिए `V86_INDEPENDENT_AUDIT_AND_REMAINING_FIXES_HI.md` तथा `A_TO_Z_REMAINING_FIX_LIST_V86.csv` देखें। 96/96 source-level checks पास हैं; Android build/emulator/real-device test अभी सत्यापित नहीं हैं।

# Majdoor Hisaab PRO V84 — Final A-to-Z ZIP

## GitHub में लगाने का तरीका
1. ZIP extract करें।
2. अंदर `mhp` project folder के **contents** को अपने `vmkisanrkms/RKMS-Connect` या सही Majdoor Hisaab PRO Android repository में डालें (इस app के लिए dedicated repository बेहतर है); project root में `settings.gradle.kts`, `gradlew`, `app/` और `.github/` दिखाई देने चाहिए।
3. GitHub Actions में Release workflow चलाएँ। Signed Release के लिए `RELEASE_KEYSTORE_BASE64`, `RELEASE_KEYSTORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD` secrets सेट होने चाहिए।
4. Workflow successful होने पर `Majdoor-Hisaab-PRO-V84-FINAL` artifact से APK लें।

## ध्यान दें
- Package ID: `com.majdoor.hisaabpro`; version: `1.84.0` (83).
- Google Drive Backup/Restore रखा गया है; रोजमर्रा का रिकॉर्ड स्थानीय/offline रहता है।
- गन्ना छिलाई/फांदी और गन्ना पर्ची के logic को UI polish से अलग रखा गया है।
- Audit report `FINAL_A_TO_Z_READINESS_REPORT_HI.md` में PASS और NOT TESTED अलग-अलग लिखे हैं। इस वातावरण में APK compile/device runtime सत्यापित नहीं हो सका।


## V87 data integrity fix batch (11 October 2026)
See `V87_DATA_INTEGRITY_FIX_AUDIT_HI.md` and `A_TO_Z_REMAINING_FIX_LIST_V87.csv`. Source-level fixes now protect historical Fandi records from deletion, reject duplicate edits/payments, and preserve locked-month/field-order state in local backup. Runtime tests and Release APK remain unverified until GitHub Actions succeeds.
