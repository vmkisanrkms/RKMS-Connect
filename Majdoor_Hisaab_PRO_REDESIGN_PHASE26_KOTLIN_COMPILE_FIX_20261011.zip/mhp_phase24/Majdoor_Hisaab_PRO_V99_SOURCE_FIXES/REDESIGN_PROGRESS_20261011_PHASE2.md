# Majdoor Hisaab PRO — Redesign Progress Report (Phase 2)

Date: 2026-10-11

## Implemented in this incremental pass
1. Reorganized the root bottom navigation from six crowded items to four primary destinations: Home, Labour, Fields, and More.
2. Added a dedicated More screen with direct navigation to attendance, attendance history, reports/ledger, expenses, sales, crops, Ganna Chhilayi, Ganna Parchi, Backup/Restore, and Settings.
3. Added the More screen to the existing screen title/subtitle and root-navigation logic.
4. Corrected date/field report payment filtering: field-tagged payments now respect the selected field IDs; legacy payments with no field ID are included only for workers found in the selected fields; date filtering remains applied once.
5. Updated the release workflow so a running release build is not automatically cancelled by another run (`cancel-in-progress: false`). The workflow builds the checked-out project source and bootstraps the missing Gradle wrapper JAR in CI.
6. Updated static audit scripts to validate the actual current workflow and selected-worker export behavior rather than obsolete source strings.

## Verification results
- Daily Labour/source audit: 26/26 PASS.
- Date/field report audit: 11/11 PASS.
- Google Drive consent/restore static audit: 11/11 PASS.
- Report selection and related accounting checks: 16/16 PASS.
- Android Kotlin/Gradle compile: NOT TESTED successfully. The Gradle wrapper JAR is absent in this package and the execution environment could not resolve `raw.githubusercontent.com` to bootstrap it. No APK build result is claimed.
- Real-device tests: NOT TESTED (navigation/back, font scaling, restart, rotation, offline use, Google Drive sign-in/backup/restore).

## Important limits
- This is incremental progress, not the completed A-to-Z redesign.
- The new navigation is statically reviewed but not yet verified on a real Android runtime.
- Existing business logic was intentionally not changed except for the date/field report payment filter described above.
- Google Drive Backup/Restore remains present. No Supabase, Firebase, or new cloud-sync dependency was added.


## Final package update — V83 (11 Oct 2026)
- Dashboard visual hierarchy and primary attendance flow polished; labels normalized to Hindi-first language.
- Labour list now has search by name/mobile/address, worker count, no-results/empty state, and clearer worker cards.
- Dashboard attendance action now routes to Daily Labour Home.
- Version bumped to 1.83.0 / versionCode 83; release artifact renamed `Majdoor-Hisaab-PRO-V83-FINAL.apk`.
- Final integration checks: 8/8 PASS. Targeted audits remain 27/27, 11/11, 11/11 and 16/16 PASS.
- Android Release compile and physical-device runtime remain NOT TESTED in this environment.


## V84 regression fixes (11 Oct 2026)
- Corrected Dashboard's “मजदूर” card so it opens the worker list instead of Daily Labour home.
- Kept the dedicated attendance action routed to Daily Labour home. Unknown Dashboard keys now go to More rather than unexpectedly opening Crop List.
- Corrected “खेतवार हिसाब” in Daily Labour Accounts to open the existing report centre instead of the Field List.
- Expanded More with direct entries for worker list, monthly accounts/lock screen, date-and-field report, and field management.
- Added static navigation regression checks. These prove source routing only; Android compilation and real-device interaction remain unverified until CI/device tests run.
