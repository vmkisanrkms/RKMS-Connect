#!/usr/bin/env python3
"""Static regression guard for the Fandi single-worker workflow and one rate editor."""
from pathlib import Path

root = Path(__file__).resolve().parent
source = (root / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')

def section(start: str, end: str) -> str:
    a = source.index(start)
    b = source.index(end, a)
    return source[a:b]

home = section('private fun CanePeelingHome(', 'private fun CaneMiniStat(')
worker_list = section('private fun CanePeelingLabourScreen(', 'private fun FandiLabourDialog(')
profile_dialog = section('private fun FandiLabourDialog(', 'private fun CanePeelingLabourDetail(')
single_entry = section('private fun CanePeelingSingleEntryDialog(', 'private fun CanePeelingEntryDialog(')
checks = {
    'only Chhilai home owns the rate-change dialog': 'showRateDialog' in home and 'store.updateFandiRate(r)' in home and 'store.updateFandiRate' not in worker_list,
    'Fandi worker list has no duplicate rate editor': 'रेट सेव करें' not in worker_list and 'OutlinedTextField(value=rateText' not in worker_list,
    'combined add-worker plus Fandi checkbox removed': 'saveTodayFandi' not in profile_dialog and 'आज की फांदी भी साथ में सेव करें' not in profile_dialog,
    'profile dialog saves a worker profile only': 'store.addFandiLabour(x)' in profile_dialog and 'store.addCanePeeling' not in profile_dialog,
    'worker name is required and normalized duplicates are rejected': 'name.isBlank()' in profile_dialog and 'sameNameAlreadySaved' in profile_dialog and 'Regex("\\\\s+")' in profile_dialog,
    'mobile/address/photo remain optional profile fields': 'पता / मोबाइल / फोटो (वैकल्पिक)' in profile_dialog and 'मोबाइल (वैकल्पिक)' in profile_dialog,
    'daily Fandi entry remains a separate single-worker form': 'एक बार में केवल एक मजदूर की एंट्री सेव होगी।' in single_entry and 'ChoiceField("मजदूर *"' in single_entry,
    'field remains optional in single-worker Fandi entry': 'ChoiceField("खेत (वैकल्पिक)"' in single_entry and 'खेत नहीं चुनें' in single_entry,
    'single-worker duplicate date-field record is rejected': 'store.canePeelings.any{it.labourId==labour&&it.fieldId==field&&it.date==date}' in single_entry,
    'Fandi labour screen uses profile-only add dialog': 'if(add)FandiLabourDialog(store,null){add=false}' in worker_list,
    'legacy Fandi data normalization remains present': 'normalizeFandiData()' in source and 'Consolidate legacy duplicate rows by ADDING their quantities' in source,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'{sum(checks.values())}/{len(checks)} Fandi UI regression checks passed')
if not all(checks.values()):
    raise SystemExit(1)
