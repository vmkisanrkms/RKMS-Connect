#!/usr/bin/env python3
"""Regression checks for finalized-month payment immutability. Source assertions only."""
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
    'new payment cannot be backdated into locked month': 'if(!validPayment(x) || payments.any{it.id==x.id} || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)) return false' in src,
    'payment edit protects both old and proposed locked/closed dates': 'val existing=payments.firstOrNull{it.id==x.id} ?: return false' in src and 'isMonthLocked(existing.date) || isClosedDate(existing.labourId,existing.date)' in src and '!validPayment(x) || isMonthLocked(x.date) || isClosedDate(x.labourId,x.date)' in src,
    'locked payment cannot be moved to unlocked date regression exists': 'locked payment cannot be moved to an unlocked month' in src and 'historicalLockedPayment.copy(date="2026-11-08")' in src,
    'closed payment cannot be moved beyond closure regression exists': 'closed-period payment cannot be moved beyond closure date' in src and 'historicalClosedPayment.copy(date="2026-11-08")' in src,
    'payment delete cannot mutate locked month': 'if(isMonthLocked(row.date) || isClosedDate(row.labourId,row.date)) return false' in src,
    'later unlocked payment can settle previous balance regression exists': 'later unlocked payment can settle locked month\'s outstanding balance' in src,
    'backdated locked payment rejection regression exists': 'locked month rejects backdated payment changes' in src,
    'edit/delete locked payment regression exists': 'locked-month payment cannot be edited into or deleted from finalized month' in src,
    'legacy locked month can be viewed without mutating payment records': 'if(month !in store.lockedLabourMonths)' in src,
    'malformed persisted lock months are filtered to real calendar months': 'filter{validMonthKey(it)}' in src and 'private fun validMonthKey(value:String):Boolean' in src,
    'malformed persisted lock month regression exists': 'malformed stored lock months are ignored while valid month remains' in src,
    'attendance lock regression compares against pre-write count': 'attendanceCountBeforeLockedWrite=store.attendances.size' in src and 'store.attendances.size==attendanceCountBeforeLockedWrite' in src,
    'store recreation regression verifies both retained attendance rows': 'reloaded.attendances.size==2' in src and 'reloaded.attendances.any{it.id=="rt-present-after-absence"}' in src,
    'backup roundtrip regression verifies attendance identities and absence cleanup': 'restored.attendances.size==2' in src and 'restored.attendances.none{it.id=="rt-absence-marker"}' in src,
    'later payment regression checks actual outstanding balance': 'store.outstandingBalance(worker.id)-650.0' in src,
    'Fandi worker add/update return explicit save results': '@Synchronized fun addFandiLabour(x:FandiLabour):Boolean' in src and '@Synchronized fun updateFandiLabour(x:FandiLabour):Boolean' in src,
    'Fandi form remains open when profile save is rejected': 'if(saved)onClose() else {error="मजदूर सेव नहीं हुआ। नाम या मोबाइल पहले से मौजूद है या जानकारी गलत है।";saving=false}' in src,
    'Fandi profile and daily entry remain separate workflows': 'saveTodayFandi' not in src[src.index('private fun FandiLabourDialog'):src.index('private fun CanePeelingLabourDetail')] and 'store.addCanePeeling' not in src[src.index('private fun FandiLabourDialog'):src.index('private fun CanePeelingLabourDetail')],
    'Fandi duplicate-mobile update regression exists': 'Fandi update rejects duplicate mobile without overwriting existing profile' in src,
    'attendance picker offers an explicit no-field option': 'खेत नहीं चुनना' in src and 'onSelect("")' in src,
    'attendance list is usable when no field is selected': 'if(field!=null || activeField.isBlank())' in src and 'बिना खेत (वैकल्पिक)' in src,
    'attendance, expense and sale fields are optional where supported': 'ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनना (वैकल्पिक)")' in src and 'attendance, expense and sale can be saved without selecting a field' in src and 'field.isBlank()->error="खेत चुनें"' not in src[src.index('private fun SaleDialog'):src.index('private fun DeviceCredentialGate')],
    'reports label blank field as optional rather than deleted': 'blank-field report rows say no field instead of field deleted' in src and 'if(row.fieldId.isBlank()) "खेत नहीं चुना" else' in src,
    'ALL cane parchi season is not reset and has runtime regression': 'if (season != "ALL" && season !in seasons)' in src and 'filterCaneParchiSeason(store.caneParchis, season)' in src and 'ALL cane parchi season includes every season and specific season filters' in src,
    'crop field cannot be changed after linked history exists': 'existing.fieldId!=x.fieldId && (expenses.any{it.cropId==x.id} || sales.any{it.cropId==x.id} || attendances.any{it.cropId==x.id} || payments.any{it.cropId==x.id})' in src and 'crop field cannot change while financial history is linked' in src,
    'cane peeling CSV escapes worker and field values safely': 'private fun buildCanePeelingCsv' in src and 'joinToString(","){csvCell(it)}' in src and 'cane peeling CSV safely escapes quoted names and labels optional field' in src,
    'cane peeling CSV writes UTF-8 BOM for spreadsheet compatibility': 'file.writeText("\\uFEFF"+buildCanePeelingCsv(rows,store),Charsets.UTF_8)' in src,
    'backup rejects invalid record dates and malformed locked-month values': 'val dateFields=mapOf(' in src and 'dateFields[key]' in src and 'validDate(dateValue)' in src and 'Backup में लॉक महीने का मान गलत है' in src and 'backup with impossible record date is rejected before mutation' in src,
    'worker active flag is backward-compatible and persisted': 'it.optBoolean("active",true)' in src and 'put("active",x.active)' in src and 'fun setLabourActive(id:String,active:Boolean):Boolean' in src,
    'dashboard recent payments open a complete searchable payment history': 'onGo("payments")' in src and 'private fun PaymentHistoryScreen' in src and 'मजदूर, तारीख, रकम या प्रकार खोजें' in src and 'Screen.PaymentHistory->PaymentHistoryScreen' in src,
    'payment/advance type persists, validates and appears in reports': 'val kind:String="payment"' in src and 'put("kind",x.kind)' in src and 'x.kind=="payment" || x.kind=="advance"' in src and 'payment and advance type persist across Store reload; invalid type rejected' in src and 'if(row.kind=="advance")"अग्रिम" else "भुगतान"' in src and 'ChoiceField("प्रविष्टि का प्रकार"' in src,
    'inactive workers are excluded from attendance and remain visible on request': 'val rosterWorkers=store.labours.asReversed().filter{it.active && (showAbsentWorkers || it.id !in absentWorkerIds)}' in src and 'निष्क्रिय मजदूर दिखाएँ' in src,
    'deactivation keeps history and can be reversed after Store reload': 'worker can be deactivated without losing history and reactivated after reload' in src and 'inactiveReload.outstandingBalance(worker.id)==balanceBeforeDeactivation' in src,
    'unused worker hard delete atomically removes profile and rate metadata while blocking accounting history': 'unused worker can be deleted together with rate metadata' in src and 'hasAccountingHistory=attendances.any{it.labourId==id} || payments.any{it.labourId==id}' in src and 'val committed=prefs.edit()' in src and 'putString("rateHistory",JSONArray().apply{nextRates.forEach{put(obj(it))}}.toString())' in src,
    'workflow runs this audit': 'python3 scripts_v93_locked_month_payment_audit.py' in (root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8'),
    'workflow runs 96-point source trace audit': 'python3 scripts_v93_96_point_source_trace.py' in (root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8'),
    'dark theme uses theme-aware card surfaces in cane modules': 'containerColor = CardBg' in src and 'containerColor=CardBg' in src and 'containerColor = Color.White' not in src and 'containerColor=Color.White' not in src,
    'theme option buttons keep selected contrast in light and dark modes': 'containerColor=if(selected)GreenDark else Color.Transparent,contentColor=if(selected)Color.White else GreenDark' in src,
    'workflow and Gradle version agree on V94': 'versionCode = 94' in (root/'app/build.gradle.kts').read_text(encoding='utf-8') and 'Majdoor-Hisaab-PRO-V94-FINAL.apk' in (root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8'),
    'emulator smoke test runs on the target Android API 36': 'ANDROID_API: "36"' in (root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8') and 'api-level: 36' in (root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8'),
    'Android instrumentation test covers Activity recreation and lock gate': 'activityRecreationKeepsDeviceLockGateVisible' in (root/'app/src/androidTest/java/com/majdoor/hisaabpro/AppLaunchRuntimeSmokeTest.kt').read_text(encoding='utf-8') and 'composeRule.activityRule.scenario.recreate()' in (root/'app/src/androidTest/java/com/majdoor/hisaabpro/AppLaunchRuntimeSmokeTest.kt').read_text(encoding='utf-8'),
    'final package script requires all 96 runtime ticks and explicit evidence': 'Fully fixed + Android runtime verified' in (root/'scripts_finalize_release_package.py').read_text(encoding='utf-8') and 'REQUIRED_GATES' in (root/'scripts_finalize_release_package.py').read_text(encoding='utf-8'),
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
print(f'{sum(checks.values())}/{len(checks)} V94 locked-month payment checks passed')
raise SystemExit(0 if all(checks.values()) else 1)
