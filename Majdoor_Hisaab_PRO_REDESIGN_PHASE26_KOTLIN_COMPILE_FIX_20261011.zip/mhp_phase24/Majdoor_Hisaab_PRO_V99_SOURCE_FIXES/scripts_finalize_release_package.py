#!/usr/bin/env python3
"""Fail-closed final packaging gate. It intentionally refuses to make a final ZIP until every runtime gate is evidenced."""
from __future__ import annotations
import csv, hashlib, json, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHECKLIST = ROOT / "V94_REQUESTED_96_POINT_FIX_CHECKLIST.csv"
EVIDENCE = ROOT / "FINAL_RUNTIME_VERIFICATION.json"
APK = ROOT / "app/build/outputs/apk/release/app-release.apk"
OUT = ROOT / "Majdoor_Hisaab_PRO_V94_FINAL_READY.zip"
REQUIRED_GATES = (
    "release_build_passed",
    "emulator_instrumentation_passed",
    "physical_device_test_passed",
    "drive_backup_restore_roundtrip_passed",
    "pdf_visual_review_passed",
    "daily_labour_regression_passed",
    "ganna_chhilayi_regression_passed",
    "ganna_parchi_regression_passed",
    "offline_restart_rotation_passed",
    "signed_apk_verified",
)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def fail(message: str) -> None:
    print(f"FINAL PACKAGE BLOCKED: {message}", file=sys.stderr)
    raise SystemExit(2)

if not CHECKLIST.is_file():
    fail("96-point requested checklist is missing")
with CHECKLIST.open(encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
if len(rows) != 96:
    fail(f"expected 96 checklist rows, found {len(rows)}")
pending = [r.get("ID", "?") for r in rows if r.get("Fully fixed + Android runtime verified") != "☑"]
if pending:
    fail(f"{len(pending)} checklist points lack full runtime verification: {', '.join(pending[:20])}")
if not EVIDENCE.is_file():
    fail("FINAL_RUNTIME_VERIFICATION.json evidence file is missing")
try:
    evidence = json.loads(EVIDENCE.read_text(encoding="utf-8"))
except Exception as exc:
    fail(f"runtime evidence JSON is invalid: {exc}")
missing = [gate for gate in REQUIRED_GATES if evidence.get(gate) is not True]
if missing:
    fail("required gates are not explicitly true: " + ", ".join(missing))
if not APK.is_file() or APK.stat().st_size == 0:
    fail("verified Release APK is missing")
if evidence.get("apk_sha256") != sha256(APK):
    fail("runtime evidence APK SHA-256 does not match the current Release APK")

excluded = {".git", ".gradle", "build", "__pycache__", "node_modules"}
files = []
for p in ROOT.rglob("*"):
    if not p.is_file() or p == OUT:
        continue
    rel = p.relative_to(ROOT)
    if any(part in excluded for part in rel.parts):
        continue
    if p.suffix in {".jks", ".keystore", ".pem", ".p12"} or "secret" in p.name.lower():
        continue
    files.append(p)
files.append(APK)
manifest = {
    "package": "com.majdoor.hisaabpro",
    "version": "1.94.0",
    "version_code": 94,
    "runtime_evidence": evidence,
    "files": {str(p.relative_to(ROOT)): sha256(p) for p in sorted(set(files))},
}
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(set(files)):
        z.write(p, str(p.relative_to(ROOT)))
    z.writestr("FINAL_PACKAGE_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(OUT) as z:
    bad = z.testzip()
    if bad:
        OUT.unlink(missing_ok=True)
        fail(f"ZIP integrity failure at {bad}")
print(f"FINAL PACKAGE CREATED: {OUT}")
print(f"SHA256: {sha256(OUT)}")
