#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(__file__).parent/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s=p.read_text(encoding='utf-8')
checks={
 'daily labour home screen': 'DailyLabourHomeScreen' in s,
 'two primary dashboard actions': 'Text("हाजिरी लगाएँ"' in s and 'Text("हिसाब देखें"' in s,
 'field-first attendance picker': 'AttendanceFieldPickerScreen' in s and 'हाजिरी के लिए खेत चुनें' in s,
 'persistent field order': 'fieldOrder' in s and 'fun moveField' in s,
 'add worker on attendance screen': '+ मजदूर जोड़ें' in s and 'if(addLabour) LabourDialog(store,null)' in s,
 'newest workers first': 'store.labours.asReversed()' in s,
 'attendance unique key ignores crop': 'it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date' in s,
 'attendance stable ID on upsert': 'x.copy(id=existing.id)' in s,
 'payment update preserves ID': 'fun updatePayment(x:Payment)' in s and 'Payment(existing?.id?:UUID.randomUUID().toString()' in s,
 'all workers report and PDF': 'AllLabourReportScreen' in s and 'सभी मजदूरों का हिसाब' in s and 'महीने का हिसाब' in s and 'selectedLockMonth = month' in s and 'exportAllWorkersLedgerPdf' in s and 'chune_mazdoor' in s and 'PDF / फोटो रिपोर्ट के लिए मजदूर चुनें' in s,
 'Fandi module retained': 'CanePeelingScreen' in s and 'CanePeelingPaymentDialog' in s and 'fandiLabours' in s,
 'Parchi module retained': 'CaneParchiDashboardScreen' in s and 'CaneParchiFormScreen' in s and 'caneParchi' in s,
 'explicit payment entry in accounts': 'भुगतान दर्ज करें' in s and 'onPayments={go(Screen.LabourList)}' in s,
 'worker history protected from delete': 'fun deleteLabour(id:String):Boolean' in s and 'if(hasHistory) return false' in s,
 'field history protected from delete': 'fun deleteField(id:String):Boolean' in s and 'if(hasHistory) return false' in s,
 'crop history protected from delete': 'fun deleteCrop(id:String):Boolean' in s and 'if(hasHistory) return false' in s,
 'PDF generation moved off UI thread': 'reportPdfExecutor.execute' in s and 'reportMainHandler.post' in s,
 'attendance save feedback': 'हाजिरी सेव हो गई।' in s,
 'Hindi attendance labels': '✓ पूरा दिन' in s and '✓ आधा दिन' in s and 'आधी' in s,
 'Bhanji means absent and zero wage': 'भांजी दर्ज हो गई। इस दिन मजदूरी ₹0 रहेगी।' in s and 'fraction==0.0' in s,
 'Bhanji shown in attendance and reports': 'भांजी (काम पर नहीं आया)' in s and 'भांजी (नहीं आया)' in s,
 'Bhanji edit uses protected flow': 'protectedAttendanceEdit=Pair(a,0.0)' in s,
 'report PDF page footer': 'पृष्ठ $pageNo' in s and 'background:Boolean=false' in s,
 'legacy data-safe deletes': 'पुराना हिसाब मौजूद है' in s and 'डेटा सुरक्षित रखने के लिए हटाना रोका गया' in s,
}
wf=Path(__file__).parent/'.github/workflows/majdoor-hisaab.yml'
w=wf.read_text(encoding='utf-8') if wf.exists() else ''
checks['workflow builds checked-out source directly']='Checkout source project' in w and './gradlew :app:compileReleaseKotlin' in w and './gradlew :app:clean :app:assembleRelease' in w
checks['four-tab navigation and More screen wired']='MoreScreen' in s and 'Triple("more",Icons.Default.Menu,"अन्य")' in s and 'Screen.More->MoreScreen' in s
checks['dashboard labour card opens worker list']='\"labour\"->Screen.LabourList' in s and '\"daily_labour\"->Screen.DailyLabourHome' in s
checks['monthly field report opens report centre']='onFieldReport={go(Screen.AllLabourReport)}' in s
checks['More menu exposes accounts and field report']='MoreMenuItem(\"accounts\"' in s and 'MoreMenuItem(\"field_report\"' in s and '\"accounts\"->Screen.DailyLabourAccounts' in s
checks['workflow bootstraps missing wrapper JAR']='gradle-wrapper.jar' in w and 'wrapper --gradle-version 8.11.1' in w and 'gradle-8.11.1/bin/gradle' in w
failed=[]
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' - '+name)
 if not ok: failed.append(name)
print(f'{len(checks)-len(failed)}/{len(checks)} source checks passed')
sys.exit(1 if failed else 0)
