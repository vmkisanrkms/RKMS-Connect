# Majdoor Hisaab PRO V87 — Independent Fix Batch Audit

Date: 11 October 2026  
Package: `com.majdoor.hisaabpro`  
Version: `1.87.0` / versionCode `87`

## Actual source changes

- Fandi worker deletion is blocked if the worker has linked cane-peeling or payment history; UI explains that the ledger is protected.
- Cane-peeling update validates existing ID and rejects duplicate worker + field + date rows.
- Cane-peeling payment create/update validates ID, worker, date, and positive finite amount. The dialog remains open with an error if persistence fails.
- Labour payment update rejects missing record IDs and invalid date/amount instead of returning a false success.
- Local backup includes `lockedLabourMonths` and `fieldOrder`; restore reloads the lock list into Store state after replacing data.
- Runtime regression harness covers historical Fandi delete protection, duplicate edit, duplicate payment ID, missing payment IDs, locked month restoration and field order restoration.
- Eight relevant checklist rows were updated to `IN PROGRESS`; their runtime test status remains `NOT TESTED`.

## Static checks run

| Check | Result |
|---|---:|
| Daily Labour/navigation | 30/30 PASS |
| Date/field report | 11/11 PASS |
| Google Drive consent static checks | 11/11 PASS |
| Report selection/sale | 16/16 PASS |
| Navigation regression | 10/10 PASS |
| V87 data-integrity source wiring | 26/26 PASS |
| **Total targeted source checks** | **104/104 PASS** |

Also: Kotlin delimiter scan PASS; workflow YAML parse PASS; ZIP CRC integrity PASS.

## Tracker state

The checklist still contains 135 items. In the row-by-row tracker, 5 items have an existing source-level PASS status; 8 specific items are marked IN PROGRESS for this batch, while the rest still require implementation/audit. The screen tracker has 11 items marked IN PROGRESS overall (including earlier visual/navigation work). Test status is still 130 NOT TESTED and 5 PASS. These counts do not imply 130 confirmed bugs; they mean that those items do not yet have accepted verification evidence.

## Not verified

- No successful Android Gradle compile or Release APK was produced in this environment; no local Android SDK/Gradle installation was available and the wrapper JAR is absent from the source ZIP.
- Emulator instrumentation tests are added to CI but have not actually run here.
- Real Google Drive sign-in/consent/upload/download/restore, photo recovery, PDF/CSV output, month-lock/settlement, and Ganna flows still require emulator/real-device testing.
- Complete A-to-Z redesign of every screen remains unfinished.

## Next step

Run the V87 GitHub Actions workflow with the four required release signing secrets. Fix any compiler/test failures it reports; then install the resulting APK and execute the remaining checklist. Do not mark untested items PASS without evidence.
