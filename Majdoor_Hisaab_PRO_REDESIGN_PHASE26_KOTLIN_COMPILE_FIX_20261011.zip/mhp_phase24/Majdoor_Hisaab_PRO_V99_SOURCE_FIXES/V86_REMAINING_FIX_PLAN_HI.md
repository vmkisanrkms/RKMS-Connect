# Majdoor Hisaab PRO V86 — Remaining Fix List & Audit

तारीख: 11 अक्टूबर 2026  
आधार: V85 source package + V86 test/CI updates  
Package: `com.majdoor.hisaabpro`

## वास्तविक सूची — अनुमान नहीं

मौजूदा `SCREEN_PROGRESS_TRACKER.csv` में कुल **135 checklist items** हैं। इसमें:
- **5 items:** source-level PASS दर्ज हैं; इनका मतलब real-device PASS नहीं है।
- **130 items:** `NOT TESTED`; इन्हें bug मान लेना सही नहीं होगा, लेकिन इन्हें पूरा/सही घोषित भी नहीं कर सकते।

यह आपकी 1000 में 800/200 वाली मिसाल की तरह tracking है, लेकिन यहाँ वास्तविक संख्या 135 है। इस सूची में हर item का priority और अगला concrete action दिया गया है।

## प्राथमिकता

- **P0 - Ganna regression: 18 items**
- **P1 - Reports/exports: 11 items**
- **P0 - Attendance/accounting: 10 items**
- **P0 - Backup/data recovery: 10 items**
- **P1 - Navigation/common UI: 10 items**
- **P1 - Build/release: 10 items**
- **P1 - Worker data: 9 items**
- **P1 - Security/settings: 9 items**
- **P0 - Accounting/lock: 8 items**
- **P0 - Accounting/settlement: 8 items**
- **P2 - Dashboard UX: 7 items**
- **P0 - Security/data integrity: 6 items**
- **P2 - Field management: 5 items**
- **P2 - Crop management: 5 items**
- **P2 - Expenses: 5 items**
- **P2 - Sales/income: 4 items**

## इस batch में वास्तव में किए गए fixes

1. Runtime regression harness अब Android API 24+ पर Device Protected Storage इस्तेमाल करता है, ताकि test का backup/restore सामान्य app preferences और production photos को न छुए।
2. Runtime checks में Fandi rate का local preferences से load होना और Store reinitialization के बाद बने रहना जोड़ा।
3. Backup test अब केवल ZIP validate नहीं करता: snapshot बनाने के बाद temporary worker जोड़ता है, restore करता है, फिर temporary record हटने और मूल worker/attendance/Fandi rate वापस आने की जाँच करता है।
4. App version और release artifact को `1.86.0` / `versionCode 86` तथा V86 नाम पर अपडेट किया।
5. V86 static audit script में backup round-trip और Fandi rate persistence की wiring checks जोड़ीं।
6. पूरी 135-row list को `A_TO_Z_REMAINING_FIX_LIST_V86.csv` में priority, evidence/status और next action सहित लिखा।

## V86 source-level checks

- Daily Labour / navigation: **30/30 PASS**
- Date/field report: **11/11 PASS**
- Google Drive consent static audit: **11/11 PASS**
- Report selection / sale: **16/16 PASS**
- V84 navigation regression: **10/10 PASS**
- V86 UI/runtime wiring: **16/16 PASS**
- Total targeted source checks: **96/96 PASS**

कुछ Python processes startup पर optional `artifact_tool` warning लिखते हैं, लेकिन प्रत्येक script का exit code `0` रहा। ये checks source patterns verify करते हैं; Compose compile, emulator test, real Drive account, PDF rendering, or actual phone behavior prove नहीं करते।

## Remaining work — order of execution

### P0 — पहले data/accounting safety
- Monthly lock/unlock, closed-date protection, later outstanding settlement payment.
- Attendance present/absent/half-day, conflict handling, restart persistence.
- Google Drive backup/restore round-trip, consent cancellation/retry, photos, corrupt ZIP recovery.
- Ganna Chhilayi/Fandi rate persistence, same-name handling, duplicate worker-field-date prevention, payment ledger.
- Ganna Parchi add/edit/delete, season/rate, search and historical record persistence.

### P1 — core workflows
- Worker add/edit/search/deactivate and complete ledger.
- Actual PDF/CSV generation, selected date/field/worker filtering, totals, share intent.
- Settings/security controls, screen lock, theme, auto-lock.
- Successful GitHub build, emulator tests, signing, package ID, alignment and install/upgrade.

### P2 — visual polish and secondary records
- Dashboard summary correctness and all shortcut destinations.
- Fields/crops/expenses/sales CRUD, empty/error states and restart persistence.
- Small-screen, large-font, rotation and accessibility review.

## Honest release status

**Not yet production-ready.** No signed APK was built in this environment and emulator tests have not actually run here. Do not mark the 130 pending checklist items as fixed just because source checks pass. Next release can only mark these items PASS after the relevant test evidence exists.
