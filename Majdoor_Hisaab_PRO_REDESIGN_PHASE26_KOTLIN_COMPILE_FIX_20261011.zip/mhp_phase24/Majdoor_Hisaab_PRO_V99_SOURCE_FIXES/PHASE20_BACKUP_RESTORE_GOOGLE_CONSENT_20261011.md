# Phase 20 — Backup / Restore and Google Consent (V99 source)

- Backup archive staging and validation before replacing an existing backup.
- Retains backup history and raw recovery metadata.
- Validates ZIP size, duplicate entries, traversal, schema, collection/date fields and photo map before restore.
- Google Drive restore selects only `.mhbackup`; uploads validate archive first; recoverable OAuth consent has one retry and cancellation protection.
- Manual backup verifies bytes and read-back archive; restore file validates before confirmation.
- Existing pre-restore safety copy, device credential gate, preference snapshot, photo rollback copy and failure-injection hook remain.

V99 Phase 20 backup audit: **24/24 PASS**. Canonical redesign backup audit: **30/30 PASS**. Android build, live Google Drive round-trip and real-device rollback remain **NOT TESTED**.
