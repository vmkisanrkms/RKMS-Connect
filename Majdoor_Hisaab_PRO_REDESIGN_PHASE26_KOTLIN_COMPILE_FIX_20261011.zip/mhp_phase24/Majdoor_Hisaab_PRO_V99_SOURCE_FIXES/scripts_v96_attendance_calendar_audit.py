#!/usr/bin/env python3
"""Static acceptance checks for the date-driven attendance calendar."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SRC=(ROOT/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
checks={
    'calendar helper validates month/year range':'if(monthZeroBased !in 0..11 || year !in 1900..2200) return emptyList()',
    'calendar is Monday-first':'val leading=(first.get(Calendar.DAY_OF_WEEK)+5)%7',
    'calendar always renders six stable weeks':'return List(42){index->',
    'month and date selection survive recreation':'var calendarYear by rememberSaveable' ,
    'month navigation is bounded to current month':'enabled=calendarYear<calendarNow.get(Calendar.YEAR) || calendarMonth<calendarNow.get(Calendar.MONTH)',
    'calendar highlights dates with attendance':'val count=calendarRowsByDate[date].orEmpty().map{it.labourId}.distinct().size',
    'calendar date tap updates selected day':'clickable{selectedCalendarDate=date}',
    'selected date lists workers and wage':'selectedCalendarRows.forEach{a->',
    'calendar uses accessible content description for previous month':'contentDescription="पिछला कैलेंडर महीना"',
    'calendar uses accessible content description for next month':'contentDescription="अगला कैलेंडर महीना"',
    'runtime regression checks October 2026 weekday offset':'octoberCalendar[3]=="2026-10-01"',
    'runtime regression checks leap-year February':'leapFebruaryCalendar.filterNotNull().size==29',
}
failed=[]
for label,needle in checks.items():
    ok=needle in SRC
    print(('PASS' if ok else 'FAIL')+' - '+label)
    if not ok: failed.append(label)
print(f'{len(checks)-len(failed)}/{len(checks)} attendance calendar source checks passed')
if failed: raise SystemExit(1)
