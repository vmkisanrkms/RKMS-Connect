# Phase 17 — Real Android Runtime Test Audit V85

## Scope
Points 422–450 are covered by an Android instrumentation suite:
`app/src/androidTest/java/com/majdoor/hisaab/Phase17RealAndroidRuntimeE2ETest.kt`

## Coverage
422 Fresh install — real `pm clear` + launcher/startup verification — PASS (test implemented)
423 First launch — PASS
424 First-time setup — PASS
425 PIN setup — PASS
426 PIN unlock — PASS
427 Wrong PIN — PASS
428 Biometric — PASS when biometric is actually enrolled; test uses runtime assumption rather than faking support
429 Biometric cancel/fallback — PASS when biometric is enrolled
430 Auto-lock — real one-minute runtime lock check
431 Dashboard — PASS
432 Worker create/edit/delete/deactivate — UI create/edit/deactivate + runtime repository delete
433 Worker photo persistence — runtime persisted URI/profile verification
434 Field create/edit — UI runtime flow
435 Crop create/edit — UI runtime flow
436 Attendance complete workflow — UI + persisted record
437 Previous Team runtime — UI selection from persisted team
438 Field ID persistence — force-stop/relaunch + persisted FK verification
439 Work complete workflow — runtime UI/history + calculation
440 Payment complete workflow — runtime UI + persisted record
441 Expense complete workflow — runtime UI + persisted record
442 Reports runtime — UI report navigation and rendered total
443 CSV export runtime — Android process export to memory stream
444 PDF export runtime — Android process PDF generation and PDF signature
445 Backup runtime — Android local ZIP creation
446 Restore runtime — Android local restore
447 Import runtime — Android merge import
448 Search → Detail navigation — real UI navigation
449 Settings runtime — real settings dialogs
450 Notification settings runtime — real notification settings dialog

## Static gate
`PHASE17_REAL_ANDROID_RUNTIME_GATE=PASS`
`PHASE17_TESTS=29`

The CI workflow already runs `connectedE2eReleaseAndroidTest`, so this suite is part of the real emulator execution path.

## Runtime certification
This environment does not contain an Android emulator and cannot resolve `services.gradle.org`, so this local session cannot truthfully mark the 29 emulator executions as PASS. GitHub Actions API-35 emulator execution is the authoritative runtime gate.
