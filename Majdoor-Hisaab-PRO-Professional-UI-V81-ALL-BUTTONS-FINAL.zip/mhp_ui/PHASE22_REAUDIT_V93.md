# Phase 22 Re-Audit — V93

Date: 2026-09-30

## Scope
Re-audit of Red List 519–540 from V92, with emphasis on real acceptance behavior rather than marker-only tests.

## Findings fixed
1. Release version mismatch: app was versionCode 77 / versionName 1.77.0, while debug/release/signing scripts still expected versionCode 76. All release gates now require 77.
2. Phase22 E2E contained weak/contract-only checks for clean-install/restore, offline behavior, search-detail, and CRUD coverage. These were replaced with behavioral assertions.
3. `p534` now creates an actual local backup, clears data, restores the backup, and verifies the worker and relational health.
4. `p536` now disables Wi-Fi/mobile data on the emulator, launches the app, and verifies local data remains available; network is restored in finally.
5. `p533` now creates a real Worker, opens Global Search, enters the worker name, selects the search result, and verifies the detail screen.
6. `p523` verifies Field ID survives a second LocalStore instance after attendance persistence.
7. `p524` exercises Attendance Calendar plus Previous/Next navigation.
8. `p537` verifies persisted data survives Activity recreation.
9. Phase22 gate now rejects trivial always-true assertions and stale direct-store-only smoke markers.
10. Phase 6 work gate was stale after the architecture refactor; it expected direct `WorkRateEngine.cost(...)` calls in MainActivity. It now checks the correct `app.calculation.workCost(...)` boundary.

## Static gates
- Phase 22 Red List: PASS 519–540 (22/22)
- Acceptance gates: PASS
- Phase 6 Work gate: PASS
- Phase 12 Backup: PASS
- Phase 13 Settings: PASS
- Phase 17 Runtime contract: PASS
- Phase 21 UI gate: PASS

## Release/build wiring
- `assembleRelease`: wired
- production `apksigner sign`: wired
- pinned production certificate: wired
- `adb install`: wired
- API-35 emulator runtime: wired
- signed Release APK smoke workflow: wired
- Phase22 E2E: wired

## Important limitation
The current execution environment cannot resolve `services.gradle.org`, so Gradle 8.11.1 and the Android emulator/JUnit runtime could not be executed here. Therefore this audit certifies source/static/CI wiring only; it does not falsely claim that the APK was compiled, installed, signed, or executed in this environment.
