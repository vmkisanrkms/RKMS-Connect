# V75 Phase 12–13 Hardened Re-audit

## Fixes
- Foreground auto-lock is actively checked every 10 seconds while the activity is alive.
- Date formatting is centralized and validated to supported patterns.
- Settings changes are audit-logged.
- Backup manifest now records exact file count, file sizes and SHA-256 checksums for every required JSON entity.
- Backup validation and restore verify manifest completeness and checksums before touching live data.
- Existing relational and post-restore validation remains mandatory.
- Notification settings reschedule alarms when toggles/times change and after reboot/package replacement.
- Version synchronized to 75 / 1.75.0.

Runtime Android build/device execution remains an external evidence requirement.
