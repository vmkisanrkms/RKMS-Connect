
## V14 CRUD + Attendance Field-ID Fix
- Added real JSON `LocalStore` CRUD regression suite for all persisted entities.
- Attendance now has an explicit Field selector and persists `fieldId`.
- Attendance edit/delete flow implemented.
- Backup/restore regression verifies `fieldId` survives round-trip.
- CI runs `:app:testDebugUnitTest` before Release build/signing/runtime checks.

# Majdoor Hisaab PRO — V13

Professional offline-first agricultural labour accounting app based on the supplied Master Blueprint.

## Storage rule
This project uses an **offline SQLite core database** for runtime records. JSON files are retained only as a backward-compatible backup/export mirror. No Supabase, Firebase, or other remote backend is used.

## V13 changes
- First-time setup + optional PIN
- Biometric unlock
- Worker/field photos
- Automatic daily local backup
- Complete-backup validation
- Expense category management
- Report filters and custom report filters
- Report-specific CSV export
- Correct advance/outstanding display
- Existing attendance critical rules preserved

## Build
GitHub Actions workflow: `.github/workflows/build-release-apk.yml` (restored in V28)

The workflow runs unit tests, assembles the release APK, signs it, verifies the APK with `apksigner`, and uploads the signed APK artifact.

## Important
This source has not been physically compiled or installed in the current execution environment because Android SDK/Gradle are unavailable here. Do not treat the ZIP alone as proof of a final APK build.


## Release signing requirements
The GitHub release workflow intentionally fails if production signing credentials are missing. Configure these GitHub Actions secrets before a release build:
- `MH_RELEASE_KEYSTORE_BASE64` — base64-encoded production `.keystore` file
- `MH_RELEASE_KEYSTORE_PASSWORD`
- `MH_RELEASE_KEY_PASSWORD`
- `MH_RELEASE_KEY_ALIAS`
A temporary/generated keystore is never accepted for a release artifact.


## Release build verification
The repository workflow performs the real Gradle 8.11.1 `assembleDebug` and `assembleRelease` tasks on GitHub Actions, then signs the Release APK with the required production keystore secrets, verifies it with `apksigner`, installs the **signed Release APK** on an API 35 emulator, launches it, force-stops/relaunches it, checks the package/version, and scans logcat for fatal exceptions. A missing production keystore fails the workflow; no temporary signing key is generated.

Required GitHub Actions secrets: `MH_RELEASE_KEYSTORE_BASE64`, `MH_RELEASE_KEYSTORE_PASSWORD`, `MH_RELEASE_KEY_PASSWORD`, `MH_RELEASE_KEY_ALIAS`.


## Release verification
Actual release build/runtime PASS requires a successful GitHub Actions run. The workflow tests the signed Release APK on an API 36 emulator and verifies the persistent production certificate fingerprint.


## V16 Auto-Lock
Real inactivity-based Auto-Lock is implemented with PIN/biometric re-authentication and unit-tested policy logic. See `docs/AUTO_LOCK_FIX.md`.

## V22 Audit Log Fix
Audit Log is persistent in local JSON storage and records core CRUD changes plus import, restore, backup and export events. Settings > Audit Log provides refresh and controlled clearing.

### V25 Restart Persistence
Restart persistence was hardened: local JSON writes are flushed and synced before replacement, and `RestartPersistenceTest` verifies a new `LocalStore` instance reads records written by the previous instance. See `docs/RESTART_PERSISTENCE_FIX.md`.

## Build tool compatibility
- AGP 8.9.1
- Gradle Wrapper 8.11.1
- JDK 17
- Run `scripts/gradle-agp-compatibility.sh` before building.

## Phase 15 Architecture V78
- Data boundary: `data/database` -> DAO -> `data/repository` -> domain use cases.
- Feature composition: `feature/AppServices.kt` with explicit Dashboard, Workers, Fields, Crops, Attendance, Work, Payments, Expenses, Reports, Backup, Settings, Security and Export modules.
- MainActivity is restricted to application lifecycle/navigation/UI coordination and consumes feature use cases through AppServices; it has no direct storage/database/repository/calculation/report-service dependency.


## V98 release truth gate

The repository never grants a final release PASS from source/static checks alone. `scripts/final-release-gate.sh` requires signed-APK runtime evidence markers, APK SHA-256, signature verification, install/launch, force-stop/relaunch, reboot persistence, rotation, offline, security, and clean-install restore evidence.

`MainActivity` is now a lifecycle/coordinator shell; screen and helper methods live in `MainActivityScreens.kt`.
