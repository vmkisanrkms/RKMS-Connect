package com.majdoor.hisaab.domain.usecase

import com.majdoor.hisaab.data.repository.LocalRepository
import com.majdoor.hisaab.model.*
import java.io.File
import java.io.InputStream
import java.io.OutputStream

class WorkerUseCases(private val r:LocalRepository) { fun list()=r.workers(); fun documents()=r.workerDocuments(); fun wageHistory()=r.workerWageHistory(); fun wageFor(id:String,date:String,fallback:Double)=r.wageFor(id,date,fallback); fun saveWage(x:WorkerWageHistory)=r.upsertWorkerWage(x); fun deleteWage(id:String)=r.deleteWorkerWage(id); fun save(x:Worker)=r.upsertWorker(x); fun delete(id:String)=r.deleteWorker(id); fun saveDocument(x:WorkerDocument)=r.upsertWorkerDocument(x); fun deleteDocument(id:String)=r.deleteWorkerDocument(id) }
class FieldUseCases(private val r:LocalRepository) { fun list()=r.fields(); fun save(x:Field)=r.upsertField(x); fun delete(id:String)=r.deleteField(id) }
class CropUseCases(private val r:LocalRepository) { fun list()=r.crops(); fun varieties()=r.cropVarieties(); fun save(x:Crop)=r.upsertCrop(x); fun delete(id:String)=r.deleteCrop(id); fun saveVariety(x:CropVariety)=r.upsertCropVariety(x); fun deleteVariety(id:String)=r.deleteCropVariety(id) }
class AttendanceUseCases(private val r:LocalRepository) { fun list()=r.attendance(); fun save(x:Attendance)=r.upsertAttendance(x); fun delete(id:String)=r.deleteAttendance(id) }
class WorkUseCases(private val r:LocalRepository) { fun list()=r.work(); fun templates()=r.workTemplates(); fun save(x:WorkRecord)=r.upsertWork(x); fun delete(id:String)=r.deleteWork(id); fun saveTemplate(x:WorkTemplate)=r.upsertWorkTemplate(x); fun deleteTemplate(id:String)=r.deleteWorkTemplate(id) }
class PaymentUseCases(private val r:LocalRepository) { fun list()=r.payments(); fun save(x:Payment)=r.upsertPayment(x); fun delete(id:String)=r.deletePayment(id) }
class ExpenseUseCases(private val r:LocalRepository) { fun list()=r.expenses(); fun save(x:Expense)=r.upsertExpense(x); fun delete(id:String)=r.deleteExpense(id) }
class FarmAccountingUseCases(private val r:LocalRepository) { fun production()=r.production(); fun revenue()=r.revenue(); fun saveProduction(x:Production)=r.upsertProduction(x); fun deleteProduction(id:String)=r.deleteProduction(id); fun saveRevenue(x:Revenue)=r.upsertRevenue(x); fun deleteRevenue(id:String)=r.deleteRevenue(id) }
class TeamUseCases(private val r:LocalRepository) { fun list()=r.teams(); fun save(x:Team)=r.upsertTeam(x); fun delete(id:String)=r.deleteTeam(id) }
class BackupUseCases(private val r:LocalRepository) { fun create():File=r.backupToInternal(); fun export(out:OutputStream)=r.exportBackup(out); fun merge(input:InputStream)=r.importBackupMerge(input); fun validate(input:InputStream)=r.validateBackup(input); fun restore(input:InputStream)=r.restore(input); fun health()=r.health(); fun storageInfo()=r.storageInfo() }
