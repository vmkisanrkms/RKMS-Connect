package com.majdoor.hisaab.notification

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object NotificationSettings {
    private const val PREFS = "settings"
    private const val MASTER = "notifications_enabled"
    private const val ATTENDANCE = "notification_attendance"
    private const val PAYMENT = "notification_payment"
    private const val ATTENDANCE_HOUR = "notification_attendance_hour"
    private const val ATTENDANCE_MINUTE = "notification_attendance_minute"
    private const val PAYMENT_HOUR = "notification_payment_hour"
    private const val PAYMENT_MINUTE = "notification_payment_minute"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun enabled(context: Context) = prefs(context).getBoolean(MASTER, true)
    fun attendanceEnabled(context: Context) = prefs(context).getBoolean(ATTENDANCE, false)
    fun paymentEnabled(context: Context) = prefs(context).getBoolean(PAYMENT, false)
    fun attendanceTime(context: Context) = Pair(prefs(context).getInt(ATTENDANCE_HOUR, 8), prefs(context).getInt(ATTENDANCE_MINUTE, 0))
    fun paymentTime(context: Context) = Pair(prefs(context).getInt(PAYMENT_HOUR, 20), prefs(context).getInt(PAYMENT_MINUTE, 0))

    fun setMaster(context: Context, value: Boolean) { prefs(context).edit().putBoolean(MASTER, value).apply(); reschedule(context) }
    fun setAttendance(context: Context, value: Boolean) { prefs(context).edit().putBoolean(ATTENDANCE, value).apply(); reschedule(context) }
    fun setPayment(context: Context, value: Boolean) { prefs(context).edit().putBoolean(PAYMENT, value).apply(); reschedule(context) }
    fun setAttendanceTime(context: Context, h: Int, m: Int) { prefs(context).edit().putInt(ATTENDANCE_HOUR,h).putInt(ATTENDANCE_MINUTE,m).apply(); reschedule(context) }
    fun setPaymentTime(context: Context, h: Int, m: Int) { prefs(context).edit().putInt(PAYMENT_HOUR,h).putInt(PAYMENT_MINUTE,m).apply(); reschedule(context) }

    private fun pending(context: Context, request: Int): PendingIntent = PendingIntent.getBroadcast(
        context, request, Intent(context, NotificationReceiver::class.java).putExtra("request", request),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun reschedule(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context, 8101)); am.cancel(pending(context, 8102))
        if (!enabled(context)) return
        if (attendanceEnabled(context)) schedule(context, am, 8101, attendanceTime(context).first, attendanceTime(context).second)
        if (paymentEnabled(context)) schedule(context, am, 8102, paymentTime(context).first, paymentTime(context).second)
    }

    private fun schedule(context: Context, am: AlarmManager, request: Int, hour: Int, minute: Int) {
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,hour); set(Calendar.MINUTE,minute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if(timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, c.timeInMillis, AlarmManager.INTERVAL_DAY, pending(context, request))
    }
}
