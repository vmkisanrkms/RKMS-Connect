package com.majdoor.hisaab.feature.attendance

import com.majdoor.hisaab.domain.usecase.AttendanceUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class AttendanceFeatureModule(val useCase: AttendanceUseCases)
