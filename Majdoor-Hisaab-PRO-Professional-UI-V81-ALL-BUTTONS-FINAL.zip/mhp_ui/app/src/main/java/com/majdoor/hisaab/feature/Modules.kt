package com.majdoor.hisaab.feature

import com.majdoor.hisaab.domain.usecase.*

// Compatibility type aliases retained for existing composition code.
typealias DashboardModule = com.majdoor.hisaab.feature.dashboard.DashboardFeatureModule
typealias WorkersModule = com.majdoor.hisaab.feature.workers.WorkersFeatureModule
typealias FieldsModule = com.majdoor.hisaab.feature.fields.FieldsFeatureModule
typealias CropsModule = com.majdoor.hisaab.feature.crops.CropsFeatureModule
typealias AttendanceModule = com.majdoor.hisaab.feature.attendance.AttendanceFeatureModule
typealias WorkModule = com.majdoor.hisaab.feature.work.WorkFeatureModule
typealias PaymentsModule = com.majdoor.hisaab.feature.payments.PaymentsFeatureModule
typealias ExpensesModule = com.majdoor.hisaab.feature.expenses.ExpensesFeatureModule
typealias ReportsModule = com.majdoor.hisaab.feature.reports.ReportsFeatureModule
typealias BackupModule = com.majdoor.hisaab.feature.backup.BackupFeatureModule
typealias SettingsModule = com.majdoor.hisaab.feature.settings.SettingsFeatureModule
typealias SecurityModule = com.majdoor.hisaab.feature.security.SecurityFeatureModule
typealias ExportModule = com.majdoor.hisaab.feature.export.ExportFeatureModule

class CalculationModule(val useCase: CalculationUseCase)
