package com.majdoor.hisaab.feature.crops

import com.majdoor.hisaab.domain.usecase.CropUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class CropsFeatureModule(val useCase: CropUseCases)
