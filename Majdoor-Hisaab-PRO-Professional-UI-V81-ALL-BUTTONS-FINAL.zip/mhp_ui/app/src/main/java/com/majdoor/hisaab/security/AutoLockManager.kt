package com.majdoor.hisaab.security

/** Pure auto-lock policy. Timeout is measured from the last user activity/background time. */
object AutoLockManager {
    const val OFF = 0L
    const val MINUTE = 60_000L
    fun timeoutMinutes(value: String?): Long = when (value) {
        "1 minute" -> 1 * MINUTE
        "5 minutes" -> 5 * MINUTE
        "10 minutes" -> 10 * MINUTE
        "15 minutes" -> 15 * MINUTE
        "30 minutes" -> 30 * MINUTE
        "60 minutes" -> 60 * MINUTE
        else -> OFF
    }
    fun shouldLock(hasPin: Boolean, unlocked: Boolean, lastActivity: Long, now: Long, timeout: Long): Boolean =
        hasPin && unlocked && timeout > 0 && now - lastActivity >= timeout
}
