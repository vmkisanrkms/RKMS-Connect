package com.majdoor.hisaab.feature.work

import com.majdoor.hisaab.domain.usecase.WorkUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class WorkFeatureModule(val useCase: WorkUseCases)
