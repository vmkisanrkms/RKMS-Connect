package com.majdoor.hisaab.feature.security

import com.majdoor.hisaab.domain.usecase.SecurityUseCase

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class SecurityFeatureModule(val useCase: SecurityUseCase)
