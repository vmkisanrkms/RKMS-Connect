package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.model.Attendance
import com.majdoor.hisaab.model.Payment
import com.majdoor.hisaab.model.WorkRecord
import com.majdoor.hisaab.model.Worker

object WorkerQuery {
    fun search(workers: List<Worker>, query: String): List<Worker> {
        val q=query.trim().lowercase(); if(q.isBlank()) return workers
        return workers.filter { listOf(it.name,it.mobile,it.workerType,it.referenceId,it.address,it.notes).any{v->v.lowercase().contains(q)} }
    }
    fun active(w:List<Worker>)=w.filter{it.active}
    fun inactive(w:List<Worker>)=w.filter{!it.active}
    fun wagePositive(w:List<Worker>)=w.filter{it.defaultRate>0.0}
    fun wageZero(w:List<Worker>)=w.filter{it.defaultRate==0.0}
    fun outstandingPositive(w:List<Worker>,a:List<Attendance>,wr:List<WorkRecord>,p:List<Payment>)=w.filter{LedgerCalculator.summary(it.id,a,wr,p).outstanding>0.0001}
    fun outstandingZero(w:List<Worker>,a:List<Attendance>,wr:List<WorkRecord>,p:List<Payment>)=w.filter{LedgerCalculator.summary(it.id,a,wr,p).outstanding<=0.0001}
    fun sortNameAsc(w:List<Worker>)=w.sortedWith(compareBy<Worker>{it.name.trim().lowercase()}.thenBy{it.id})
    fun sortNameDesc(w:List<Worker>)=w.sortedWith(compareByDescending<Worker>{it.name.trim().lowercase()}.thenBy{it.id})
    fun sortWageDesc(w:List<Worker>)=w.sortedWith(compareByDescending<Worker>{it.defaultRate}.thenBy{it.name.lowercase()}.thenBy{it.id})
    fun sortWageAsc(w:List<Worker>)=w.sortedWith(compareBy<Worker>{it.defaultRate}.thenBy{it.name.lowercase()}.thenBy{it.id})
}
