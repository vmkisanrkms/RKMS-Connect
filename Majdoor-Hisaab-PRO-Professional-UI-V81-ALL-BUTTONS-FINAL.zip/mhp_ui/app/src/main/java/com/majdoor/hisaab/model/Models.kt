package com.majdoor.hisaab.model

import org.json.JSONObject
import java.util.UUID

data class Worker(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var mobile: String = "",
    var address: String = "",
    var workerType: String = "General",
    var defaultRate: Double = 0.0,
    var rateUnit: String = "DAY",
    var joiningDate: String = "",
    var referenceId: String = "",
    var notes: String = "",
    var photoUri: String = "",
    var active: Boolean = true
) {
    fun json() = JSONObject()
        .put("id", id).put("name", name).put("mobile", mobile)
        .put("address", address).put("workerType", workerType)
        .put("defaultRate", defaultRate).put("rateUnit", rateUnit)
        .put("joiningDate", joiningDate).put("referenceId", referenceId).put("notes", notes).put("photoUri", photoUri).put("active", active)

    companion object {
        fun from(j: JSONObject) = Worker(
            j.optString("id"), j.optString("name"), j.optString("mobile"),
            j.optString("address"), j.optString("workerType", "General"),
            j.optDouble("defaultRate"), j.optString("rateUnit", "DAY"),
            j.optString("joiningDate"), j.optString("referenceId"), j.optString("notes"), j.optString("photoUri"), j.optBoolean("active", true)
        )
    }
}

data class Field(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var area: Double = 0.0,
    var unit: String = "acre",
    var location: String = "",
    var soilType: String = "",
    var irrigation: String = "",
    var notes: String = "",
    var photoUri: String = "",
    var active: Boolean = true
) {
    fun json() = JSONObject()
        .put("id", id).put("name", name).put("area", area).put("unit", unit)
        .put("location", location).put("soilType", soilType)
        .put("irrigation", irrigation).put("notes", notes).put("photoUri", photoUri).put("active", active)
    companion object {
        fun from(j: JSONObject) = Field(
            j.optString("id"), j.optString("name"), j.optDouble("area"),
            j.optString("unit","acre"), j.optString("location"),
            j.optString("soilType"), j.optString("irrigation"),
            j.optString("notes"), j.optString("photoUri"), j.optBoolean("active",true)
        )
    }
}

data class Crop(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var variety: String = "",
    var fieldId: String = "",
    var plantingDate: String = "",
    var area: Double = 0.0,
    var notes: String = "",
    var active: Boolean = true
) {
    fun json() = JSONObject()
        .put("id", id).put("name", name).put("variety", variety)
        .put("fieldId", fieldId).put("plantingDate", plantingDate)
        .put("area", area).put("notes", notes).put("active", active)
    companion object {
        fun from(j: JSONObject) = Crop(
            j.optString("id"), j.optString("name"), j.optString("variety"),
            j.optString("fieldId"), j.optString("plantingDate"),
            j.optDouble("area"), j.optString("notes"), j.optBoolean("active",true)
        )
    }
}

data class Attendance(
    val id: String = UUID.randomUUID().toString(),
    var date: String,
    var workerId: String,
    var fieldId: String = "",
    var status: String = "NONE",
    var rate: Double = 0.0,
    var note: String = ""
) {
    fun json() = JSONObject()
        .put("id",id).put("date",date).put("workerId",workerId)
        .put("fieldId",fieldId).put("status",status).put("rate",rate).put("note",note)
    companion object {
        fun from(j: JSONObject) = Attendance(
            j.optString("id"), j.optString("date"), j.optString("workerId"),
            j.optString("fieldId"), j.optString("status","NONE"),
            j.optDouble("rate"), j.optString("note")
        )
    }
}

data class Team(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var workerIds: MutableList<String> = mutableListOf()
) {
    fun json() = JSONObject().put("id",id).put("name",name)
        .put("workerIds", org.json.JSONArray(workerIds))
    companion object {
        fun from(j: JSONObject): Team {
            val a=j.optJSONArray("workerIds") ?: org.json.JSONArray()
            val ids=mutableListOf<String>()
            for(i in 0 until a.length()) ids.add(a.optString(i))
            return Team(j.optString("id"),j.optString("name"),ids)
        }
    }
}

data class WorkRecord(
    val id: String = UUID.randomUUID().toString(),
    var date: String,
    var fieldId: String,
    var cropId: String,
    var workType: String,
    var quantity: Double = 0.0,
    var rateType: String = "QUANTITY",
    var unit: String = "",
    var rate: Double = 0.0,
    var workerIds: MutableList<String> = mutableListOf(),
    var startTime: String = "",
    var endTime: String = "",
    var notes: String = ""
) {
    fun fingerprint(): String =
        listOf(date.trim(),fieldId.trim(),cropId.trim(),workType.trim().lowercase(),quantity,rateType.trim().uppercase(),unit.trim().lowercase(),rate,startTime.trim(),endTime.trim(),workerIds.distinct().sorted().joinToString(",")).joinToString("|")
    fun json() = JSONObject()
        .put("id",id).put("date",date).put("fieldId",fieldId).put("cropId",cropId)
        .put("workType",workType).put("quantity",quantity).put("rateType",rateType).put("unit",unit).put("rate",rate)
        .put("workerIds",org.json.JSONArray(workerIds)).put("startTime",startTime)
        .put("endTime",endTime).put("notes",notes).put("fingerprint",fingerprint())
    companion object {
        fun from(j: JSONObject): WorkRecord {
            val a=j.optJSONArray("workerIds") ?: org.json.JSONArray()
            val ids=mutableListOf<String>()
            for(i in 0 until a.length()) ids.add(a.optString(i))
            return WorkRecord(j.optString("id"),j.optString("date"),j.optString("fieldId"),
                j.optString("cropId"),j.optString("workType"),j.optDouble("quantity"),
                j.optString("rateType", "QUANTITY"),j.optString("unit"),j.optDouble("rate"),ids,j.optString("startTime"),
                j.optString("endTime"),j.optString("notes"))
        }
    }
}

data class Payment(
    val id:String=UUID.randomUUID().toString(),
    var workerId:String,
    var date:String,
    var amount:Double,
    var method:String="Cash",
    var advance:Boolean=false,
    var reference:String="",
    var notes:String=""
) {
    fun json()=JSONObject().put("id",id).put("workerId",workerId).put("date",date)
        .put("amount",amount).put("method",method).put("advance",advance)
        .put("reference",reference).put("notes",notes)
    companion object {
        fun from(j:JSONObject)=Payment(j.optString("id"),j.optString("workerId"),
            j.optString("date"),j.optDouble("amount"),j.optString("method","Cash"),
            j.optBoolean("advance"),j.optString("reference"),j.optString("notes"))
    }
}

data class Expense(
    val id:String=UUID.randomUUID().toString(),
    var date:String,
    var category:String,
    var amount:Double,
    var fieldId:String="",
    var cropId:String="",
    var notes:String=""
) {
    fun json()=JSONObject().put("id",id).put("date",date).put("category",category)
        .put("amount",amount).put("fieldId",fieldId).put("cropId",cropId).put("notes",notes)
    companion object {
        fun from(j:JSONObject)=Expense(j.optString("id"),j.optString("date"),
            j.optString("category"),j.optDouble("amount"),j.optString("fieldId"),
            j.optString("cropId"),j.optString("notes"))
    }
}

data class Production(
    val id:String=UUID.randomUUID().toString(),
    var cropId:String,
    var date:String,
    var quantity:Double,
    var unit:String,
    var note:String=""
) {
    fun json()=JSONObject().put("id",id).put("cropId",cropId).put("date",date)
        .put("quantity",quantity).put("unit",unit).put("note",note)
    companion object {
        fun from(j:JSONObject)=Production(j.optString("id"),j.optString("cropId"),
            j.optString("date"),j.optDouble("quantity"),j.optString("unit"),j.optString("note"))
    }
}

data class Revenue(
    val id:String=UUID.randomUUID().toString(),
    var cropId:String,
    var date:String,
    var amount:Double,
    var note:String=""
) {
    fun json()=JSONObject().put("id",id).put("cropId",cropId).put("date",date)
        .put("amount",amount).put("note",note)
    companion object {
        fun from(j:JSONObject)=Revenue(j.optString("id"),j.optString("cropId"),
            j.optString("date"),j.optDouble("amount"),j.optString("note"))
    }
}


data class WorkerDocument(
    val id:String=UUID.randomUUID().toString(),
    var workerId:String,
    var name:String,
    var uri:String,
    var addedAt:Long=System.currentTimeMillis()
){
    fun json()=JSONObject().put("id",id).put("workerId",workerId).put("name",name).put("uri",uri).put("addedAt",addedAt)
    companion object { fun from(j:JSONObject)=WorkerDocument(j.optString("id"),j.optString("workerId"),j.optString("name"),j.optString("uri"),j.optLong("addedAt")) }
}


data class WorkerWageHistory(
    val id:String=UUID.randomUUID().toString(),
    var workerId:String,
    var effectiveFrom:String,
    var rate:Double,
    var rateUnit:String="DAY",
    var source:String="WORKER",
    var note:String=""
){
    fun json()=JSONObject().put("id",id).put("workerId",workerId).put("effectiveFrom",effectiveFrom)
        .put("rate",rate).put("rateUnit",rateUnit).put("source",source).put("note",note)
    companion object {
        fun from(j:JSONObject)=WorkerWageHistory(j.optString("id"),j.optString("workerId"),j.optString("effectiveFrom"),j.optDouble("rate"),j.optString("rateUnit","DAY"),j.optString("source","WORKER"),j.optString("note"))
    }
}

data class CropVariety(
    val id:String=UUID.randomUUID().toString(),
    var cropId:String,
    var name:String,
    var notes:String="",
    var active:Boolean=true
){
    fun json()=JSONObject().put("id",id).put("cropId",cropId).put("name",name).put("notes",notes).put("active",active)
    companion object {
        fun from(j:JSONObject)=CropVariety(j.optString("id"),j.optString("cropId"),j.optString("name"),j.optString("notes"),j.optBoolean("active",true))
    }
}

data class BackupMetadata(
    val id:String="current",
    var lastBackupAt:Long=0L,
    var formatVersion:Int=2,
    var schemaVersion:Int=4,
    var storage:String="JSON",
    var lastOperation:String=""
){
    fun json()=JSONObject().put("id",id).put("lastBackupAt",lastBackupAt).put("formatVersion",formatVersion)
        .put("schemaVersion",schemaVersion).put("storage",storage).put("lastOperation",lastOperation)
    companion object {
        fun from(j:JSONObject)=BackupMetadata(j.optString("id","current"),j.optLong("lastBackupAt"),j.optInt("formatVersion",2),j.optInt("schemaVersion",4),j.optString("storage","JSON"),j.optString("lastOperation"))
    }
}


data class WorkTemplate(
    val id:String=UUID.randomUUID().toString(),
    var name:String,
    var workType:String,
    var unit:String,
    var rate:Double,
    var rateType:String = "QUANTITY",
    var notes:String=""
){
    fun json()=JSONObject().put("id",id).put("name",name).put("workType",workType).put("unit",unit).put("rate",rate).put("rateType",rateType).put("notes",notes)
    companion object { fun from(j:JSONObject)=WorkTemplate(j.optString("id"),j.optString("name"),j.optString("workType"),j.optString("unit"),j.optDouble("rate"),j.optString("rateType", "QUANTITY"),j.optString("notes")) }
}
