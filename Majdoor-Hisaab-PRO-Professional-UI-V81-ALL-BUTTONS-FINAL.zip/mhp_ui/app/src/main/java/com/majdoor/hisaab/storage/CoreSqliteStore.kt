package com.majdoor.hisaab.storage

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * SQLite-backed core record store for the offline-first application.
 *
 * The JSON files under the app's external-files area remain a human-readable
 * backup/export mirror, but SQLite is the authoritative runtime store.
 * Records are kept as JSON payloads inside an indexed entity/id table so the
 * existing domain models and backup format remain backward compatible.
 */
internal class CoreSqliteStore(
    context: Context,
    private val mirrorDir: File,
    private val allowedFiles: Set<String>
) {
    private val helper = Helper(context.applicationContext)

    init {
        migrateMirrorIfDatabaseEmpty()
    }

    private fun entity(fileName: String): String = fileName.removeSuffix(".json")

    private fun idFor(record: JSONObject, index: Int): String =
        record.optString("id").ifBlank { "__index_$index" }

    private fun database(): SQLiteDatabase = helper.writableDatabase

    fun read(fileName: String): JSONArray {
        val out = JSONArray()
        database().query(
            "core_records",
            arrayOf("payload"),
            "entity = ?",
            arrayOf(entity(fileName)),
            null,
            null,
            "rowid ASC"
        ).use { cursor ->
            val index = cursor.getColumnIndexOrThrow("payload")
            while (cursor.moveToNext()) {
                out.put(JSONObject(cursor.getString(index)))
            }
        }
        return out
    }

    fun replace(fileName: String, array: JSONArray) {
        val db = database()
        val entity = entity(fileName)
        db.beginTransaction()
        try {
            db.delete("core_records", "entity = ?", arrayOf(entity))
            for (i in 0 until array.length()) {
                val payload = array.getJSONObject(i)
                val values = android.content.ContentValues().apply {
                    put("entity", entity)
                    put("record_id", idFor(payload, i))
                    put("payload", payload.toString())
                }
                db.insertOrThrow("core_records", null, values)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun reloadFromMirrors() {
        val db = database()
        db.beginTransaction()
        try {
            db.delete("core_records", null, null)
            allowedFiles.sorted().forEach { fileName ->
                val file = File(mirrorDir, fileName)
                if (!file.exists()) return@forEach
                val array = JSONArray(file.readText())
                val entity = entity(fileName)
                for (i in 0 until array.length()) {
                    val payload = array.getJSONObject(i)
                    val values = android.content.ContentValues().apply {
                        put("entity", entity)
                        put("record_id", idFor(payload, i))
                        put("payload", payload.toString())
                    }
                    db.insertOrThrow("core_records", null, values)
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun migrateMirrorIfDatabaseEmpty() {
        val db = database()
        val count = db.rawQuery("SELECT COUNT(*) FROM core_records", null).use { c ->
            if (c.moveToFirst()) c.getLong(0) else 0L
        }
        if (count != 0L) return

        db.beginTransaction()
        try {
            allowedFiles.sorted().forEach { fileName ->
                val file = File(mirrorDir, fileName)
                if (!file.exists()) return@forEach
                val array = JSONArray(file.readText())
                val entity = entity(fileName)
                for (i in 0 until array.length()) {
                    val payload = array.getJSONObject(i)
                    val values = android.content.ContentValues().apply {
                        put("entity", entity)
                        put("record_id", idFor(payload, i))
                        put("payload", payload.toString())
                    }
                    db.insertOrThrow("core_records", null, values)
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private class Helper(context: Context) : SQLiteOpenHelper(
        context,
        "majdoor_hisaab_core.db",
        null,
        1
    ) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE core_records (
                    entity TEXT NOT NULL,
                    record_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    PRIMARY KEY(entity, record_id)
                )
                """.trimIndent()
            )
            db.execSQL(
                "CREATE INDEX idx_core_records_entity ON core_records(entity)"
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 1) onCreate(db)
        }
    }
}
