package com.majdoor.hisaab.data.database

import android.content.Context
import com.majdoor.hisaab.storage.LocalStore

/** Database boundary. Runtime records are stored in the offline SQLite core store; JSON is retained only as backup/export mirror. */
class LocalDatabase(context: Context) {
    internal val store = LocalStore(context)
}
