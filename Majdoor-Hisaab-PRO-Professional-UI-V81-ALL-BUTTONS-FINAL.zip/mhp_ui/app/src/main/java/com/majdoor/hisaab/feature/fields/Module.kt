package com.majdoor.hisaab.feature.fields

import com.majdoor.hisaab.domain.usecase.FieldUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class FieldsFeatureModule(val useCase: FieldUseCases)
