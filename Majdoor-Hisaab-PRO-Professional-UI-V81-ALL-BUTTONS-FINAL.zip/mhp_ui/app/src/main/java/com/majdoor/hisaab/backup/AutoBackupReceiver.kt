package com.majdoor.hisaab.backup

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.majdoor.hisaab.feature.AppServices

class AutoBackupReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs=context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if(!prefs.getBoolean("auto_backup", false)) return
        try { AppServices(context).backup.create(); prefs.edit().putLong("last_auto_backup",System.currentTimeMillis()).apply() } catch(_:Exception) { }
    }
}
