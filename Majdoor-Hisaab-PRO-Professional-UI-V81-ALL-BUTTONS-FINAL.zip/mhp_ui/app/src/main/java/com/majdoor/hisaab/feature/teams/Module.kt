package com.majdoor.hisaab.feature.teams

import com.majdoor.hisaab.domain.usecase.TeamUseCases

/** Team feature boundary. */
class TeamsFeatureModule(val useCase: TeamUseCases)
