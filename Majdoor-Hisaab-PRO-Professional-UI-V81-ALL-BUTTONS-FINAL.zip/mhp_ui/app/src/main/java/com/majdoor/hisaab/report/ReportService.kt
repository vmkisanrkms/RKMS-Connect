package com.majdoor.hisaab.report

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.majdoor.hisaab.data.repository.LocalRepository
import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import java.io.OutputStream
import java.util.Locale

class ReportService(private val context: Context, private val store: LocalRepository) {
    private fun filter(): ReportFilter {
        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        return ReportFilter(
            prefs.getString("report_from", "") ?: "",
            prefs.getString("report_to", "") ?: "",
            prefs.getString("report_worker", "") ?: "",
            prefs.getString("report_field", "") ?: "",
            prefs.getString("report_crop", "") ?: ""
        )
    }

    fun csvWorkers(out: OutputStream) {
        val sb = StringBuilder()
        if (csvHeadersEnabled()) sb.append("ID,Name,Mobile,Rate,Unit,Active\n")
        store.workers().forEach { w ->
            sb.append(csv(w.id)).append(',').append(csv(w.name)).append(',')
                .append(csv(w.mobile)).append(',').append(w.defaultRate).append(',')
                .append(csv(w.rateUnit)).append(',').append(w.active).append('\n')
        }
        if (csvBomEnabled()) out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
    }

    fun csvLedger(out: OutputStream) {
        val sb = StringBuilder()
        if (csvHeadersEnabled()) sb.append("Worker ID,Worker,Earned,Paid,Advance,Outstanding,Credit\n")
        val a = store.attendance(); val w = store.work(); val p = store.payments()
        store.workers().forEach { x ->
            val ledger = LedgerCalculator.summary(x.id, a, w, p)
            sb.append(csv(x.id)).append(',').append(csv(x.name)).append(',')
                .append(ledger.earned).append(',').append(ledger.normalPaid).append(',').append(ledger.advance).append(',')
                .append(ledger.outstanding).append(',').append(ledger.credit).append('\n')
        }
        if (csvBomEnabled()) out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
    }

    fun csvReport(title: String, out: OutputStream) {
        val bytes = reportCsv(title).toByteArray(Charsets.UTF_8)
        if (csvBomEnabled()) out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
        out.write(bytes)
    }

    private fun reportCsv(title: String): String {
        val f = ReportEngine.periodFilter(title, filter(), java.time.LocalDate.now().toString())
        val d = ReportEngine.filter(f, store.attendance(), store.work(), store.payments(), store.expenses(), store.revenue(), store.production(), store.crops().associate { it.id to it.fieldId })
        val workers=store.workers().associateBy{it.id}; val fields=store.fields().associateBy{it.id}; val crops=store.crops().associateBy{it.id}
        val sb=StringBuilder()
        when(title){
            "Daily Labour","Weekly Labour","Monthly Labour" -> { sb.append("Report,From,To,Attendance Wages,Work Cost,Total Labour\n"); sb.append(csv(title)).append(',').append(csv(f.from)).append(',').append(csv(f.to)).append(',').append(d.attendanceCost()).append(',').append(d.workCost()).append(',').append(d.totalLabourCost()).append('\n') }
            "Worker Report","Outstanding Report" -> { sb.append("Worker,Earned,Paid,Advance,Outstanding,Credit\n"); val list=if(f.workerId.isBlank())store.workers() else store.workers().filter{it.id==f.workerId}; list.forEach{w->val s=ReportEngine.workerSummary(w,d); sb.append(csv(w.name)).append(',').append(s.earned).append(',').append(s.normalPaid).append(',').append(s.advance).append(',').append(s.outstanding).append(',').append(s.credit).append('\n')} }
            "Payment Report" -> { sb.append("Date,Worker,Amount,Type,Method,Reference\n"); d.payments.sortedByDescending{it.date}.forEach{p->sb.append(p.date).append(',').append(csv(workers[p.workerId]?.name?:p.workerId)).append(',').append(p.amount).append(',').append(if(p.advance)"Advance" else "Payment").append(',').append(csv(p.method)).append(',').append(csv(p.reference)).append('\n')} }
            "Field Report","Field Cost Report" -> { sb.append("Field,Labour Cost,Expenses,Revenue,Profit Loss\n"); val list=if(f.fieldId.isBlank())store.fields() else store.fields().filter{it.id==f.fieldId}; list.forEach{field->val labour=d.attendance.filter{it.fieldId==field.id}.sumOf{when(it.status.uppercase()){"FULL"->it.rate;"HALF"->it.rate/2.0;else->0.0}}+d.work.filter{it.fieldId==field.id}.sumOf{WorkRateEngine.cost(it)}; val exp=d.expenses.filter{it.fieldId==field.id}.sumOf{it.amount}; val ids=store.crops().filter{it.fieldId==field.id}.map{it.id}.toSet(); val rev=d.revenues.filter{it.cropId in ids}.sumOf{it.amount}; sb.append(csv(field.name)).append(',').append(labour).append(',').append(exp).append(',').append(rev).append(',').append(rev-labour-exp).append('\n')} }
            "Crop Report","Crop Cost Report" -> { sb.append("Crop,Production,Labour Cost,Other Cost,Revenue,Profit Loss\n"); val list=if(f.cropId.isBlank())store.crops() else store.crops().filter{it.id==f.cropId}; list.forEach{c->val labour=d.work.filter{it.cropId==c.id}.sumOf{WorkRateEngine.cost(it)}; val exp=d.expenses.filter{it.cropId==c.id}.sumOf{it.amount}; val rev=d.revenues.filter{it.cropId==c.id}.sumOf{it.amount}; val prod=d.production.filter{it.cropId==c.id}.sumOf{it.quantity}; sb.append(csv(c.name)).append(',').append(prod).append(',').append(labour).append(',').append(exp).append(',').append(rev).append(',').append(rev-labour-exp).append('\n')} }
            "Attendance Report" -> { sb.append("Date,Worker,Field,Status,Rate,Earned\n"); d.attendance.sortedByDescending{it.date}.forEach{a->val earned=when(a.status.uppercase()){"FULL"->a.rate;"HALF"->a.rate/2.0;else->0.0}; sb.append(a.date).append(',').append(csv(workers[a.workerId]?.name?:a.workerId)).append(',').append(csv(fields[a.fieldId]?.name?:"")).append(',').append(a.status).append(',').append(a.rate).append(',').append(earned).append('\n')} }
            "Expense Report" -> { sb.append("Date,Category,Field,Crop,Amount\n"); d.expenses.sortedByDescending{it.date}.forEach{e->sb.append(e.date).append(',').append(csv(e.category)).append(',').append(csv(fields[e.fieldId]?.name?:"")).append(',').append(csv(crops[e.cropId]?.name?:"")).append(',').append(e.amount).append('\n')} }
            "Labour Cost Report" -> { sb.append("Attendance Cost,Work Cost,Total Labour Cost\n"); sb.append(d.attendanceCost()).append(',').append(d.workCost()).append(',').append(d.totalLabourCost()).append('\n') }
            "Profit/Loss Report","Custom Report" -> { sb.append("Revenue,Labour Cost,Other Costs,Tracked Cost,Profit Loss\n"); sb.append(d.revenueTotal()).append(',').append(d.totalLabourCost()).append(',').append(d.expenseCost()).append(',').append(d.trackedCost()).append(',').append(d.profitLoss()).append('\n') }
            else -> { sb.append("Report,From,To,Amount\n").append(csv(title)).append(',').append(csv(f.from)).append(',').append(csv(f.to)).append(",0\n") }
        }
        val raw = sb.toString()
        if (csvHeadersEnabled() || raw.isBlank()) return raw
        val firstNewline = raw.indexOf('\n')
        return if (firstNewline >= 0) raw.substring(firstNewline + 1) else ""
    }

    /** Generates the selected report as a real report-specific PDF, using the same filtered data as CSV. */
    fun pdfReport(title: String, out: OutputStream) {
        val lines = reportCsv(title).trimEnd().split('\n').filter { it.isNotBlank() }
        val doc = PdfDocument(); val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val size = pageSize()
        var pageWidth = size.first; var pageHeight = size.second
        if (orientation() == "Landscape") { val t = pageWidth; pageWidth = pageHeight; pageHeight = t }
        paint.textSize = 16f; paint.isFakeBoldText = true
        var pageNo = 1; var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
        var y = 40f
        val left = 28f; val bottom = pageHeight - 30f
        fun newPage() { drawFooter(page.canvas, pageWidth, pageHeight, pageNo, paint); doc.finishPage(page); pageNo++; page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create()); y = 40f }
        if (headerEnabled()) { page.canvas.drawText(reportHeader(title), left, y, paint); y += 24f }
        paint.textSize = 9f; paint.isFakeBoldText = false
        if (filtersEnabled()) { val f = filter(); page.canvas.drawText("From: ${f.from.ifBlank{"Any"}}   To: ${f.to.ifBlank{"Any"}}", left, y, paint); y += 18f }
        for (raw in lines) {
            if (y > bottom - 18f) newPage()
            val line = raw.replace('"',' ')
            val maxChars = if (pageWidth > 800) 145 else 105
            for (chunk in line.chunked(maxChars)) { if (y > bottom - 18f) newPage(); page.canvas.drawText(chunk, left, y, paint); y += 13f }
            y += 3f
        }
        drawFooter(page.canvas, pageWidth, pageHeight, pageNo, paint)
        doc.finishPage(page); doc.writeTo(out); doc.close()
    }


    fun pdfSummary(out: OutputStream) {
        val doc = PdfDocument(); val workers = store.workers(); val a = store.attendance(); val w = store.work(); val p = store.payments()
        val size = pageSize(); var pageWidth=size.first; var pageHeight=size.second
        if (orientation()=="Landscape") { val t=pageWidth; pageWidth=pageHeight; pageHeight=t }
        var pageNumber=1; var page=doc.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNumber).create())
        val paint=Paint(Paint.ANTI_ALIAS_FLAG); paint.textSize=16f; paint.isFakeBoldText=true; var y=45f
        if(headerEnabled()){page.canvas.drawText(reportHeader("Labour Summary"),30f,y,paint);y+=28f}
        paint.textSize=11f;paint.isFakeBoldText=false
        for(x in workers){if(y>pageHeight-45f){drawFooter(page.canvas,pageWidth,pageHeight,pageNumber,paint);doc.finishPage(page);pageNumber++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNumber).create());y=40f};val ledger=LedgerCalculator.summary(x.id,a,w,p);page.canvas.drawText(String.format(Locale.US,"%s  Earned %.2f  Paid %.2f  Advance %.2f  Balance %.2f",x.name,ledger.earned,ledger.normalPaid,ledger.advance,ledger.outstanding),30f,y,paint);y+=20f}
        drawFooter(page.canvas,pageWidth,pageHeight,pageNumber,paint);doc.finishPage(page);doc.writeTo(out);doc.close()
    }

    private fun settings() = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private fun headerEnabled() = settings().getBoolean("report_include_header", true)
    private fun filtersEnabled() = settings().getBoolean("report_include_filters", true)
    private fun footerEnabled() = settings().getBoolean("report_include_footer", true)
    private fun csvHeadersEnabled() = settings().getBoolean("report_csv_headers", true)
    private fun csvBomEnabled() = settings().getBoolean("report_csv_bom", true)
    private fun orientation() = settings().getString("report_orientation", "Portrait") ?: "Portrait"
    private fun pageSize(): Pair<Int,Int> = when(settings().getString("report_page_size", "A4")) { "Letter" -> 612 to 792; else -> 595 to 842 }
    private fun reportHeader(title:String):String = "${settings().getString("farm_name", "My Farm") ?: "My Farm"} — Majdoor Hisaab PRO — $title"
    private fun drawFooter(canvas: android.graphics.Canvas, width:Int, height:Int, page:Int, paint:Paint){
        if(!footerEnabled()) return
        paint.textSize=8f;paint.isFakeBoldText=false
        canvas.drawText("Page $page", width-65f, height-15f, paint)
    }

    private fun csv(s: String) = "\"${s.replace("\"", "\"\"")}\""
}
