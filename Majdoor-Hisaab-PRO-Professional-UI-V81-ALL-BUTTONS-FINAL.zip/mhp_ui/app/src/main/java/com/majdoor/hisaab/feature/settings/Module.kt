package com.majdoor.hisaab.feature.settings

import com.majdoor.hisaab.domain.usecase.SettingsUseCase

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class SettingsFeatureModule(val useCase: SettingsUseCase)
