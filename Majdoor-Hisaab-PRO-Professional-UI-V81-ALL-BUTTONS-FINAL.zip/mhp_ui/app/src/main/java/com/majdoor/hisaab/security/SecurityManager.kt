package com.majdoor.hisaab.security

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.util.Base64
import java.security.MessageDigest
import java.util.concurrent.Executor

class SecurityManager(private val context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("security", Context.MODE_PRIVATE)

    fun setPin(pin: String) {
        p.edit().putString("pin", hash(pin)).apply()
    }

    fun hasPin(): Boolean = p.contains("pin")

    fun verifyPin(pin: String): Boolean =
        p.getString("pin", "") == hash(pin)

    fun clearPin() {
        p.edit().remove("pin").apply()
    }

    fun biometricEnabled(): Boolean =
        p.getBoolean("biometric", false)

    fun setBiometricEnabled(enabled: Boolean) {
        p.edit().putBoolean("biometric", enabled).apply()
    }

    fun biometricAvailable(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false

        val manager = context.getSystemService(BiometricManager::class.java)
            ?: return false

        return manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
    }

    fun authenticate(
        activity: Activity,
        executor: Executor,
        onSuccess: () -> Unit,
        onFailure: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            onFailure()
            return
        }

        try {
            val prompt = BiometricPrompt.Builder(activity)
                .setTitle("Unlock Majdoor Hisaab PRO")
                .setSubtitle("Use your enrolled biometric")
                .setDescription("Your local farm records remain on this device.")
                .setNegativeButton(
                    "Use PIN",
                    executor
                ) { _, _ -> onFailure() }
                .build()

            val cancellationSignal = CancellationSignal()

            prompt.authenticate(
                cancellationSignal,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(
                        result: BiometricPrompt.AuthenticationResult
                    ) {
                        onSuccess()
                    }

                    override fun onAuthenticationError(
                        errorCode: Int,
                        errString: CharSequence
                    ) {
                        onFailure()
                    }

                    override fun onAuthenticationFailed() {
                        // Prompt remains available for another attempt.
                    }
                }
            )
        } catch (_: Throwable) {
            onFailure()
        }
    }

    private fun hash(value: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(value.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
