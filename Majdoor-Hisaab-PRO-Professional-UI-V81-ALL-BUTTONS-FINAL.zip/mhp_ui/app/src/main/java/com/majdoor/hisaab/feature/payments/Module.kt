package com.majdoor.hisaab.feature.payments

import com.majdoor.hisaab.domain.usecase.PaymentUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class PaymentsFeatureModule(val useCase: PaymentUseCases)
