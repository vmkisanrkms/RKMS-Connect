package com.majdoor.hisaab.feature

import android.content.Context
import com.majdoor.hisaab.data.database.LocalDatabase
import com.majdoor.hisaab.data.database.dao.*
import com.majdoor.hisaab.data.repository.LocalRepository
import com.majdoor.hisaab.domain.usecase.*
import com.majdoor.hisaab.feature.dashboard.DashboardFeatureModule
import com.majdoor.hisaab.feature.workers.WorkersFeatureModule
import com.majdoor.hisaab.feature.fields.FieldsFeatureModule
import com.majdoor.hisaab.feature.crops.CropsFeatureModule
import com.majdoor.hisaab.feature.attendance.AttendanceFeatureModule
import com.majdoor.hisaab.feature.work.WorkFeatureModule
import com.majdoor.hisaab.feature.payments.PaymentsFeatureModule
import com.majdoor.hisaab.feature.expenses.ExpensesFeatureModule
import com.majdoor.hisaab.feature.reports.ReportsFeatureModule
import com.majdoor.hisaab.feature.backup.BackupFeatureModule
import com.majdoor.hisaab.feature.settings.SettingsFeatureModule
import com.majdoor.hisaab.feature.security.SecurityFeatureModule
import com.majdoor.hisaab.feature.export.ExportFeatureModule
import com.majdoor.hisaab.feature.teams.TeamsFeatureModule
import com.majdoor.hisaab.feature.accounting.AccountingFeatureModule

/** Composition root. MainActivity consumes feature modules and never reaches storage/database classes. */
class AppServices(context: Context) {
    private val database = LocalDatabase(context)
    private val repository = LocalRepository(database)
    val dashboardModule = DashboardFeatureModule(DashboardUseCase(repository))
    val workersModule = WorkersFeatureModule(WorkerUseCases(repository))
    val fieldsModule = FieldsFeatureModule(FieldUseCases(repository))
    val cropsModule = CropsFeatureModule(CropUseCases(repository))
    val attendanceModule = AttendanceFeatureModule(AttendanceUseCases(repository))
    val workModule = WorkFeatureModule(WorkUseCases(repository))
    val paymentsModule = PaymentsFeatureModule(PaymentUseCases(repository))
    val expensesModule = ExpensesFeatureModule(ExpenseUseCases(repository))
    val reportsModule = ReportsFeatureModule(ReportsUseCase(context,repository))
    val backupModule = BackupFeatureModule(BackupUseCases(repository))
    val settingsModule = SettingsFeatureModule(SettingsUseCase(context))
    val securityModule = SecurityFeatureModule(SecurityUseCase(context))
    val exportModule = ExportFeatureModule(ExportUseCase(reportsModule.useCase))
    val teamsModule = TeamsFeatureModule(TeamUseCases(repository))
    val accountingModule = AccountingFeatureModule(FarmAccountingUseCases(repository))
    val audit = AuditUseCase(repository)
    val calculationModule = CalculationModule(CalculationUseCase(repository))

    // Compatibility aliases for the existing UI migration; these are use-case objects, not data stores.
    val workers get() = workersModule.useCase
    val fields get() = fieldsModule.useCase
    val crops get() = cropsModule.useCase
    val attendance get() = attendanceModule.useCase
    val work get() = workModule.useCase
    val payments get() = paymentsModule.useCase
    val expenses get() = expensesModule.useCase
    val accounting get() = accountingModule.useCase
    val teams get() = teamsModule.useCase
    val backup get() = backupModule.useCase
    val reports get() = reportsModule.useCase
    val export get() = exportModule.useCase
    val calculation get() = calculationModule.useCase
}
