package com.majdoor.hisaab.feature.accounting

import com.majdoor.hisaab.domain.usecase.FarmAccountingUseCases

/** Farm accounting feature boundary for production and revenue. */
class AccountingFeatureModule(val useCase: FarmAccountingUseCases)
