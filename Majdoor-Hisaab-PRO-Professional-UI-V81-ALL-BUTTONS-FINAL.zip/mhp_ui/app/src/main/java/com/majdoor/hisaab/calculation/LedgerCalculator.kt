package com.majdoor.hisaab.calculation

import com.majdoor.hisaab.model.*
import kotlin.math.max

/** Deterministic wage rules used by every ledger/report screen. */
data class LedgerSummary(
    val earned: Double,
    val normalPaid: Double,
    val advance: Double
) {
    /** Total cash actually paid to the worker, including advances. */
    val totalPaid: Double get() = normalPaid + advance
    /** Amount still payable; never negative. */
    val outstanding: Double get() = max(0.0, earned - totalPaid)
    /** Amount paid beyond earned; never negative. */
    val credit: Double get() = max(0.0, totalPaid - earned)
}

object LedgerCalculator {
    fun attendanceEarned(workerId:String, attendance:List<Attendance>):Double =
        attendance.filter{it.workerId==workerId}.sumOf {
            when(it.status.uppercase()){
                "FULL" -> max(0.0,it.rate)
                "HALF" -> max(0.0,it.rate)/2.0
                else -> 0.0
            }
        }

    /**
     * A work record has one labour cost (quantity × rate). When multiple workers
     * are linked and no per-worker allocation exists in the blueprint, the cost is
     * split equally. This prevents the old over-counting bug where every worker
     * received the entire work cost.
     */
    fun workEarned(workerId:String, work:List<WorkRecord>):Double =
        work.filter{workerId in it.workerIds}.sumOf { record ->
            val ids = record.workerIds.distinct()
            if (ids.isEmpty()) 0.0 else WorkRateEngine.cost(record) / ids.size
        }

    fun paid(workerId:String,payments:List<Payment>) =
        payments.filter{it.workerId==workerId && !it.advance}.sumOf{max(0.0,it.amount)}

    fun advances(workerId:String,payments:List<Payment>) =
        payments.filter{it.workerId==workerId && it.advance}.sumOf{max(0.0,it.amount)}

    fun totalEarned(workerId:String,a:List<Attendance>,w:List<WorkRecord>) =
        attendanceEarned(workerId,a)+workEarned(workerId,w)

    fun summary(workerId:String,a:List<Attendance>,w:List<WorkRecord>,p:List<Payment>): LedgerSummary {
        val earned = totalEarned(workerId,a,w)
        val normalPaid = paid(workerId,p)
        val advance = advances(workerId,p)
        return LedgerSummary(earned, normalPaid, advance)
    }

    fun outstanding(workerId:String,a:List<Attendance>,w:List<WorkRecord>,p:List<Payment>): Double =
        summary(workerId,a,w,p).outstanding
}
