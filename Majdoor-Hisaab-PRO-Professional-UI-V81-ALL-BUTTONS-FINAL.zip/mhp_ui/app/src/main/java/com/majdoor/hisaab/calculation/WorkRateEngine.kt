package com.majdoor.hisaab.calculation

import com.majdoor.hisaab.model.WorkRecord
import kotlin.math.max

/** Central, deterministic work-rate engine. All screens/reports must use this. */
object WorkRateEngine {
    const val DAILY = "DAILY"
    const val HALF_DAY = "HALF_DAY"
    const val HOURLY = "HOURLY"
    const val AREA_ACRE = "AREA_ACRE"
    const val QUANTITY = "QUANTITY"
    const val PIECE = "PIECE"

    val types = listOf(DAILY, HALF_DAY, HOURLY, AREA_ACRE, QUANTITY, PIECE)
    /** Standard agricultural work names; the form remains free-text for Custom work. */
    val workTypes = listOf("Planting", "Sowing", "Weeding", "Harvesting", "Cutting", "Loading", "Irrigation", "Spraying", "Fertilizing", "Custom")
    fun normalize(type: String, unit: String = ""): String {
        val t = type.trim().uppercase().replace('-', '_').replace(' ', '_')
        return when (t) {
            DAILY, "DAY", "DAILY_RATE" -> DAILY
            HALF_DAY, "HALF", "HALFDAY", "HALF_DAY_RATE" -> HALF_DAY
            HOURLY, "HOUR", "HOURLY_RATE" -> HOURLY
            AREA_ACRE, "ACRE", "AREA", "AREA_RATE" -> AREA_ACRE
            PIECE, "PER_PIECE", "PIECE_RATE" -> PIECE
            QUANTITY, "QTY", "PER_UNIT", "UNIT" -> QUANTITY
            else -> inferFromUnit(unit)
        }
    }

    private fun inferFromUnit(unit: String): String = when (unit.trim().lowercase()) {
        "acre", "acres", "bigha", "hectare", "ha" -> AREA_ACRE
        "hour", "hours", "hr", "hrs" -> HOURLY
        "piece", "pieces", "pc", "pcs" -> PIECE
        "day", "days" -> DAILY
        "half-day", "half day" -> HALF_DAY
        else -> QUANTITY
    }

    private fun durationHours(start: String, end: String): Double? {
        fun minutes(s: String): Int? {
            val parts = s.trim().split(":")
            if (parts.size != 2) return null
            val h = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            if (h !in 0..23 || m !in 0..59) return null
            return h * 60 + m
        }
        val a = minutes(start) ?: return null
        val b = minutes(end) ?: return null
        val diff = if (b >= a) b - a else (24 * 60 - a) + b
        return diff / 60.0
    }

    fun cost(record: WorkRecord): Double {
        val rate = max(0.0, record.rate)
        val qty = max(0.0, record.quantity)
        return when (normalize(record.rateType, record.unit)) {
            DAILY -> qty * rate
            HALF_DAY -> qty * rate * 0.5
            HOURLY -> {
                val hours = durationHours(record.startTime, record.endTime)
                    ?: qty
                max(0.0, hours) * rate
            }
            AREA_ACRE, QUANTITY, PIECE -> qty * rate
            else -> qty * rate
        }
    }

    fun allocatedCost(record: WorkRecord, workerId: String): Double {
        val ids = record.workerIds.distinct()
        if (workerId !in ids || ids.isEmpty()) return 0.0
        return cost(record) / ids.size
    }
}
