package com.majdoor.hisaab.feature.export

import com.majdoor.hisaab.domain.usecase.ExportUseCase

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class ExportFeatureModule(val useCase: ExportUseCase)
