package com.majdoor.hisaab.feature.reports

import com.majdoor.hisaab.domain.usecase.ReportsUseCase

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class ReportsFeatureModule(val useCase: ReportsUseCase)
