package com.majdoor.hisaab.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-registers configured notification alarms after reboot/app replacement. */
class NotificationBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            NotificationSettings.reschedule(context)
        }
    }
}
