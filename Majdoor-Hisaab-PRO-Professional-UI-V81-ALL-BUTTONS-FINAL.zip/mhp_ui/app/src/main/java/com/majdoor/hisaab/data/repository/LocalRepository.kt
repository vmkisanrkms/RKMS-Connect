package com.majdoor.hisaab.data.repository

import com.majdoor.hisaab.data.database.LocalDatabase
import com.majdoor.hisaab.data.database.dao.*
import com.majdoor.hisaab.model.*
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Single application data boundary. Repositories depend on DAOs only; UI and
 * domain use cases never reach LocalStore/database implementation directly.
 */
class LocalRepository(db: LocalDatabase) {
    private val workersDao = WorkerDao(db)
    private val fieldsDao = FieldDao(db)
    private val cropsDao = CropDao(db)
    private val attendanceDao = AttendanceDao(db)
    private val workDao = WorkDao(db)
    private val paymentsDao = PaymentDao(db)
    private val expensesDao = ExpenseDao(db)
    private val accountingDao = FarmAccountingDao(db)
    private val teamsDao = TeamDao(db)
    private val auditDao = AuditDao(db)
    private val storageDao = StorageDao(db)

    fun workers() = workersDao.all()
    fun workerDocuments() = workersDao.documents()
    fun workerWageHistory() = workersDao.wageHistory()
    fun wageFor(workerId:String,date:String,fallback:Double=0.0) = workersDao.wageFor(workerId,date,fallback)
    fun upsertWorkerWage(x: WorkerWageHistory) = workersDao.upsertWage(x)
    fun deleteWorkerWage(id: String) = workersDao.deleteWage(id)
    fun workTemplates() = workDao.templates()
    fun fields() = fieldsDao.all()
    fun crops() = cropsDao.all()
    fun cropVarieties() = cropsDao.varieties()
    fun attendance() = attendanceDao.all()
    fun teams() = teamsDao.all()
    fun work() = workDao.all()
    fun payments() = paymentsDao.all()
    fun expenses() = expensesDao.all()
    fun production() = accountingDao.production()
    fun revenue() = accountingDao.revenue()
    fun auditLog(): List<JSONObject> = auditDao.all()
    fun clearAuditLog() = auditDao.clear()
    fun logSettingChange(key:String,value:String) = auditDao.logSettingChange(key,value)

    fun upsertWorker(x: Worker) = workersDao.upsert(x)
    fun deleteWorker(id: String) = workersDao.delete(id)
    fun upsertWorkerDocument(x: WorkerDocument) = workersDao.upsertDocument(x)
    fun deleteWorkerDocument(id: String) = workersDao.deleteDocument(id)
    fun upsertField(x: Field) = fieldsDao.upsert(x)
    fun deleteField(id: String) = fieldsDao.delete(id)
    fun upsertCrop(x: Crop) = cropsDao.upsert(x)
    fun deleteCrop(id: String) = cropsDao.delete(id)
    fun upsertCropVariety(x: CropVariety) = cropsDao.upsertVariety(x)
    fun deleteCropVariety(id: String) = cropsDao.deleteVariety(id)
    fun upsertAttendance(x: Attendance) = attendanceDao.upsert(x)
    fun deleteAttendance(id: String) = attendanceDao.delete(id)
    fun upsertTeam(x: Team) = teamsDao.upsert(x)
    fun deleteTeam(id: String) = teamsDao.delete(id)
    fun upsertWork(x: WorkRecord) = workDao.upsert(x)
    fun deleteWork(id: String) = workDao.delete(id)
    fun upsertPayment(x: Payment) = paymentsDao.upsert(x)
    fun deletePayment(id: String) = paymentsDao.delete(id)
    fun upsertExpense(x: Expense) = expensesDao.upsert(x)
    fun deleteExpense(id: String) = expensesDao.delete(id)
    fun upsertProduction(x: Production) = accountingDao.upsertProduction(x)
    fun deleteProduction(id: String) = accountingDao.deleteProduction(id)
    fun upsertRevenue(x: Revenue) = accountingDao.upsertRevenue(x)
    fun deleteRevenue(id: String) = accountingDao.deleteRevenue(id)
    fun upsertWorkTemplate(x: WorkTemplate) = workDao.upsertTemplate(x)
    fun deleteWorkTemplate(id: String) = workDao.deleteTemplate(id)

    fun backupToInternal(): File = storageDao.backupToInternal()
    fun exportBackup(out: OutputStream) = storageDao.exportBackup(out)
    fun importBackupMerge(input: InputStream) = storageDao.importBackupMerge(input)
    fun validateBackup(input: InputStream) = storageDao.validateBackup(input)
    fun restore(input: InputStream) = storageDao.restore(input)
    fun health() = storageDao.health()
    fun storageInfo() = storageDao.storageInfo()
}
