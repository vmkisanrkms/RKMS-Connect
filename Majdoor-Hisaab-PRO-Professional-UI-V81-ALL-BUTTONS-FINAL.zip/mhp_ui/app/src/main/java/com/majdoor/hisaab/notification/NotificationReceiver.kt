package com.majdoor.hisaab.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!NotificationSettings.enabled(context)) return
        when (intent.getIntExtra("request", 0)) {
            8101 -> if (NotificationSettings.attendanceEnabled(context)) NotificationHelper.show(context, "Attendance Reminder", "Today's attendance अभी दर्ज करें।", true)
            8102 -> if (NotificationSettings.paymentEnabled(context)) NotificationHelper.show(context, "Payment Reminder", "आज के मजदूर भुगतान/बकाया की समीक्षा करें।", true)
        }
    }
}
