package com.majdoor.hisaab.feature.expenses

import com.majdoor.hisaab.domain.usecase.ExpenseUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class ExpensesFeatureModule(val useCase: ExpenseUseCases)
