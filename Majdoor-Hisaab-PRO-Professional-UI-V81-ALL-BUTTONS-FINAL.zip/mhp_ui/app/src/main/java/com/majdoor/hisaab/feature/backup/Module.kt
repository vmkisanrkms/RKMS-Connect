package com.majdoor.hisaab.feature.backup

import com.majdoor.hisaab.domain.usecase.BackupUseCases

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class BackupFeatureModule(val useCase: BackupUseCases)
