package com.majdoor.hisaab

import com.majdoor.hisaab.model.Team

/** Pure rules for the critical attendance workflow. */
object AttendanceRules {
    const val UNMARKED = "NONE"

    /** Previous Team copies worker membership only; it never carries attendance state. */
    fun copyWorkersOnly(team: Team?, validWorkerIds: Set<String>): Set<String> =
        team?.workerIds.orEmpty().filter { it in validWorkerIds }.toSet()

    /** Selecting a worker must never create a Full/Half status. */
    fun statusAfterWorkerSelection(existing: String? = null): String =
        existing?.takeIf { it.uppercase() in setOf("FULL", "HALF", "NONE") } ?: UNMARKED
}
