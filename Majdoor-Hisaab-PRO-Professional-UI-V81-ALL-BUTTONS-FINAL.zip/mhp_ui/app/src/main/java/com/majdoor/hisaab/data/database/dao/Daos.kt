package com.majdoor.hisaab.data.database.dao

import com.majdoor.hisaab.data.database.LocalDatabase
import com.majdoor.hisaab.model.*
import org.json.JSONObject

class WorkerDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.workers(); fun documents()=s.workerDocuments(); fun wageHistory()=s.workerWageHistory(); fun wageFor(id:String,date:String,fallback:Double)=s.wageFor(id,date,fallback); fun upsertWage(x:WorkerWageHistory)=s.upsertWorkerWage(x); fun deleteWage(id:String)=s.deleteWorkerWage(id)
    fun upsert(x:Worker)=s.upsertWorker(x); fun delete(id:String)=s.deleteWorker(id); fun upsertDocument(x:WorkerDocument)=s.upsertWorkerDocument(x); fun deleteDocument(id:String)=s.deleteWorkerDocument(id)
}
class FieldDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.fields(); fun upsert(x:Field)=s.upsertField(x); fun delete(id:String)=s.deleteField(id)
}
class CropDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.crops(); fun varieties()=s.cropVarieties(); fun upsert(x:Crop)=s.upsertCrop(x); fun delete(id:String)=s.deleteCrop(id); fun upsertVariety(x:CropVariety)=s.upsertCropVariety(x); fun deleteVariety(id:String)=s.deleteCropVariety(id)
}
class AttendanceDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.attendance(); fun upsert(x:Attendance)=s.upsertAttendance(x); fun delete(id:String)=s.deleteAttendance(id)
}
class WorkDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.work(); fun templates()=s.workTemplates(); fun upsert(x:WorkRecord)=s.upsertWork(x); fun delete(id:String)=s.deleteWork(id); fun upsertTemplate(x:WorkTemplate)=s.upsertWorkTemplate(x); fun deleteTemplate(id:String)=s.deleteWorkTemplate(id)
}
class PaymentDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.payments(); fun upsert(x:Payment)=s.upsertPayment(x); fun delete(id:String)=s.deletePayment(id)
}
class ExpenseDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.expenses(); fun upsert(x:Expense)=s.upsertExpense(x); fun delete(id:String)=s.deleteExpense(id)
}
class FarmAccountingDao(db: LocalDatabase) { private val s=db.store
    fun production()=s.production(); fun revenue()=s.revenue(); fun upsertProduction(x:Production)=s.upsertProduction(x); fun deleteProduction(id:String)=s.deleteProduction(id); fun upsertRevenue(x:Revenue)=s.upsertRevenue(x); fun deleteRevenue(id:String)=s.deleteRevenue(id)
}
class TeamDao(db: LocalDatabase) { private val s=db.store
    fun all()=s.teams(); fun upsert(x:Team)=s.upsertTeam(x); fun delete(id:String)=s.deleteTeam(id)
}
class AuditDao(db: LocalDatabase) { private val s=db.store
    fun all():List<JSONObject> = s.auditLog(); fun clear()=s.clearAuditLog(); fun logSettingChange(k:String,v:String)=s.logSettingChange(k,v)
}


class StorageDao(db: LocalDatabase) {
    private val s=db.store
    fun backupToInternal(): java.io.File = s.backupToInternal()
    fun exportBackup(out: java.io.OutputStream) = s.exportBackup(out)
    fun importBackupMerge(input: java.io.InputStream) = s.importBackupMerge(input)
    fun validateBackup(input: java.io.InputStream) = s.validateBackup(input)
    fun restore(input: java.io.InputStream) = s.restore(input)
    fun health() = s.health()
    fun storageInfo() = s.storageInfo()
}
