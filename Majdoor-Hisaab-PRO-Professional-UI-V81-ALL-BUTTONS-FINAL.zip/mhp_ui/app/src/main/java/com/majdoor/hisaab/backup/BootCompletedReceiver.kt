package com.majdoor.hisaab.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.majdoor.hisaab.feature.AppServices

/** Restores the automatic-backup schedule after device reboot.
 *  If an auto-backup became overdue while the phone was off, one backup is
 *  performed immediately, then the next 24-hour alarm is scheduled.
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("auto_backup", false)) return

        val now = System.currentTimeMillis()
        val last = prefs.getLong("last_auto_backup", 0L)
        if (last == 0L || now - last >= DAY_MS) {
            try {
                AppServices(context).backup.create()
                prefs.edit().putLong("last_auto_backup", now).apply()
            } catch (_: Exception) {
                // Keep the alarm scheduled so a later run can retry.
            }
        }
        scheduleNext(context)
    }

    private fun scheduleNext(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, AutoBackupReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        am.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + DAY_MS,
            DAY_MS,
            pi
        )
    }

    companion object {
        const val REQUEST_CODE = 9001
        const val DAY_MS = 24L * 60L * 60L * 1000L
    }
}
