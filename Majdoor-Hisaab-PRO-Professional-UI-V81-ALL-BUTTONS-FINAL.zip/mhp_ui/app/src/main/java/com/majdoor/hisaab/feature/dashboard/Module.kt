package com.majdoor.hisaab.feature.dashboard

import com.majdoor.hisaab.domain.usecase.DashboardUseCase

/** Real feature boundary: owns its domain use case and exposes no storage implementation. */
class DashboardFeatureModule(val useCase: DashboardUseCase)
