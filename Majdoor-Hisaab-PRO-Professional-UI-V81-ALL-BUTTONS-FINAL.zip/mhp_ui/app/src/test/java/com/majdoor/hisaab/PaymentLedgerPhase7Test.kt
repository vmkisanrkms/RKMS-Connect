package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.model.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PaymentLedgerPhase7Test {
    private fun earned(): List<Attendance> = listOf(
        Attendance(date="2026-09-29", workerId="w", status="FULL", rate=600.0),
        Attendance(date="2026-09-30", workerId="w", status="HALF", rate=600.0)
    )

    @Test fun partialPaymentOutstandingAndAdvanceAreDeterministic() {
        val payments=listOf(
            Payment(workerId="w",date="2026-09-30",amount=400.0,method="Cash"),
            Payment(workerId="w",date="2026-09-30",amount=100.0,method="UPI",advance=true)
        )
        val s=LedgerCalculator.summary("w",earned(),emptyList(),payments)
        assertEquals(900.0,s.earned,0.001)
        assertEquals(400.0,s.normalPaid,0.001)
        assertEquals(100.0,s.advance,0.001)
        assertEquals(500.0,s.totalPaid,0.001)
        assertEquals(400.0,s.outstanding,0.001)
    }

    @Test fun allPaymentMethodsAreAcceptedByLedgerCalculation() {
        val p=listOf(
            Payment(workerId="w",date="2026-09-30",amount=10.0,method="Cash"),
            Payment(workerId="w",date="2026-09-30",amount=20.0,method="Bank"),
            Payment(workerId="w",date="2026-09-30",amount=30.0,method="UPI")
        )
        assertEquals(60.0,LedgerCalculator.paid("w",p),0.001)
    }

    @Test fun editReplacementRecomputesLedgerWithoutDoubleCounting() {
        val original=Payment(id="p",workerId="w",date="2026-09-30",amount=200.0,method="Cash")
        val edited=original.copy(amount=350.0,method="Bank")
        val before=LedgerCalculator.summary("w",earned(),emptyList(),listOf(original))
        val after=LedgerCalculator.summary("w",earned(),emptyList(),listOf(edited))
        assertEquals(700.0,before.outstanding,0.001)
        assertEquals(550.0,after.outstanding,0.001)
    }

    @Test fun deletePaymentRecomputesLedger() {
        val p=Payment(id="p",workerId="w",date="2026-09-30",amount=300.0)
        val withPayment=LedgerCalculator.summary("w",earned(),emptyList(),listOf(p))
        val afterDelete=LedgerCalculator.summary("w",earned(),emptyList(),emptyList())
        assertEquals(600.0,withPayment.outstanding,0.001)
        assertEquals(900.0,afterDelete.outstanding,0.001)
    }

    @Test fun overpaymentCreatesCreditAndNeverNegativeOutstanding() {
        val p=listOf(Payment(workerId="w",date="2026-09-30",amount=1200.0,method="UPI"))
        val s=LedgerCalculator.summary("w",earned(),emptyList(),p)
        assertTrue(s.outstanding >= 0.0)
        assertEquals(300.0,s.credit,0.001)
    }

    @Test fun paymentLedger_exposesCreditWhenOverpaid() {
        val source = UiSourceContract.text()
        assertTrue(source.contains("ledger.credit"))
        assertTrue(source.contains("Credit \${money(ledger.credit)}"))
    }

    @Test fun workerLinkingKeepsOtherWorkersSeparate() {
        val p=listOf(Payment(workerId="w1",date="2026-09-30",amount=250.0))
        assertEquals(250.0,LedgerCalculator.paid("w1",p),0.001)
        assertEquals(0.0,LedgerCalculator.paid("w2",p),0.001)
    }
}
