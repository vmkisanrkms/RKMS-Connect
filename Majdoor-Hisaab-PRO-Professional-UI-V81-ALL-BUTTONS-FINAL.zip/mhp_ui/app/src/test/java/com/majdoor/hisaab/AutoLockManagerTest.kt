package com.majdoor.hisaab

import com.majdoor.hisaab.security.AutoLockManager
import org.junit.Assert.*
import org.junit.Test

class AutoLockManagerTest {
    @Test fun timeout_values_are_deterministic(){
        assertEquals(0L, AutoLockManager.timeoutMinutes("Off"))
        assertEquals(60_000L, AutoLockManager.timeoutMinutes("1 minute"))
        assertEquals(300_000L, AutoLockManager.timeoutMinutes("5 minutes"))
        assertEquals(3_600_000L, AutoLockManager.timeoutMinutes("60 minutes"))
    }
    @Test fun locks_after_timeout_when_pin_exists(){
        assertTrue(AutoLockManager.shouldLock(true,true,1_000L,301_000L,300_000L))
    }
    @Test fun does_not_lock_before_timeout_or_without_pin(){
        assertFalse(AutoLockManager.shouldLock(true,true,1_000L,299_999L,300_000L))
        assertFalse(AutoLockManager.shouldLock(false,true,1_000L,999_999L,300_000L))
        assertFalse(AutoLockManager.shouldLock(true,false,1_000L,999_999L,300_000L))
        assertFalse(AutoLockManager.shouldLock(true,true,1_000L,999_999L,0L))
    }
}
