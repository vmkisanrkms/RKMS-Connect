package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test

class AutoBackupScheduleTest {
    @Test fun oneDayIsTwentyFourHours() {
        assertTrue(24L * 60L * 60L * 1000L == 86_400_000L)
    }

    @Test fun overdueBackupIsRecognized() {
        val now = 2L * 86_400_000L
        val last = now - 86_400_001L
        assertTrue(now - last >= 24L * 60L * 60L * 1000L)
    }
}
