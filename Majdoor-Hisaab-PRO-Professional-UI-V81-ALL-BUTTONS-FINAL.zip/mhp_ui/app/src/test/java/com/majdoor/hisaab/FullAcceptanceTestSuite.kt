package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.report.ReportEngine
import com.majdoor.hisaab.report.ReportFilter
import org.junit.Assert.*
import org.junit.Test

/** Blueprint acceptance tests for the pure/domain layer. UI/device gates are executed in CI smoke tests. */
class FullAcceptanceTestSuite {
    private fun att(id:String="a", worker:String="w", date:String="2026-09-29", status:String="FULL", rate:Double=600.0) =
        Attendance(id=id, date=date, workerId=worker, status=status, rate=rate)

    @Test fun attendance_full_half_none_are_deterministic() {
        val xs = listOf(att(status="FULL",rate=600.0), att(id="b",date="2026-09-30",status="HALF",rate=600.0), att(id="c",date="2026-10-01",status="NONE",rate=600.0))
        assertEquals(900.0, LedgerCalculator.attendanceEarned("w", xs), 0.001)
    }

    @Test fun attendance_field_id_is_persisted_as_selected_field() {
        val a = Attendance(date = "2026-09-30", workerId = "w1", fieldId = "field-123", status = "FULL", rate = 600.0)
        val roundTrip = Attendance.from(a.json())
        assertEquals("field-123", roundTrip.fieldId)
    }

    @Test fun attendance_other_worker_is_excluded() {
        val xs = listOf(att(worker="w1"), att(id="b",worker="w2",rate=900.0))
        assertEquals(600.0, LedgerCalculator.attendanceEarned("w1", xs), 0.001)
    }

    @Test fun previous_team_contract_is_workers_only_by_model() {
        val team = Team(id="t", name="Morning", workerIds=mutableListOf("w1","w2"))
        assertEquals(listOf("w1","w2"), team.workerIds)
    }

    @Test fun work_rates_all_blueprint_modes() {
        val base = { type:String, q:Double, rate:Double -> WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Harvest",quantity=q,unit="unit",rate=rate,rateType=type,workerIds=mutableListOf("w")) }
        assertEquals(1000.0, WorkRateEngine.cost(base(WorkRateEngine.DAILY,2.0,500.0)),0.001)
        assertEquals(500.0, WorkRateEngine.cost(base(WorkRateEngine.HALF_DAY,2.0,500.0)),0.001)
        assertEquals(2700.0, WorkRateEngine.cost(base(WorkRateEngine.AREA_ACRE,3.0,900.0)),0.001)
        assertEquals(200.0, WorkRateEngine.cost(base(WorkRateEngine.QUANTITY,10.0,20.0)),0.001)
        assertEquals(200.0, WorkRateEngine.cost(base(WorkRateEngine.PIECE,25.0,8.0)),0.001)
    }

    @Test fun hourly_work_uses_time_duration() {
        val x=WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Spraying",quantity=0.0,unit="hour",rate=100.0,rateType=WorkRateEngine.HOURLY,startTime="09:00",endTime="12:30",workerIds=mutableListOf("w"))
        assertEquals(350.0, WorkRateEngine.cost(x),0.001)
    }

    @Test fun multi_worker_work_total_is_not_duplicated() {
        val x=WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Weeding",quantity=1.0,unit="acre",rate=900.0,rateType=WorkRateEngine.AREA_ACRE,workerIds=mutableListOf("a","b","c"))
        val total=listOf("a","b","c").sumOf { LedgerCalculator.workEarned(it,listOf(x)) }
        assertEquals(900.0,total,0.001)
    }

    @Test fun advance_is_counted_once_and_outstanding_never_negative() {
        val p=listOf(Payment(workerId="w",date="2026-09-29",amount=600.0), Payment(workerId="w",date="2026-09-29",amount=200.0,advance=true))
        val s=LedgerCalculator.summary("w",listOf(att(rate=1000.0)),emptyList(),p)
        assertEquals(800.0,s.totalPaid,0.001)
        assertEquals(200.0,s.outstanding,0.001)
        assertEquals(0.0,s.credit,0.001)
    }

    @Test fun overpayment_becomes_credit() {
        val p=listOf(Payment(workerId="w",date="2026-09-29",amount=1200.0))
        val s=LedgerCalculator.summary("w",listOf(att(rate=1000.0)),emptyList(),p)
        assertEquals(0.0,s.outstanding,0.001)
        assertEquals(200.0,s.credit,0.001)
    }

    @Test fun report_date_filter_does_not_drift_to_today() {
        val a=listOf(att(date="2026-01-10",rate=500.0),att(id="b",date="2026-01-11",rate=700.0))
        val d=ReportEngine.filter(ReportFilter(from="2026-01-10",to="2026-01-10"),a,emptyList(),emptyList(),emptyList(),emptyList(),emptyList())
        assertEquals(1,d.attendance.size)
        assertEquals(500.0,d.attendanceCost(),0.001)
    }

    @Test fun report_entity_filters_are_combined() {
        val a=listOf(att(worker="w1",date="2026-01-10"),att(id="b",worker="w2",date="2026-01-10",rate=700.0))
        val d=ReportEngine.filter(ReportFilter(from="2026-01-10",to="2026-01-10",workerId="w1"),a,emptyList(),emptyList(),emptyList(),emptyList(),emptyList())
        assertEquals(1,d.attendance.size)
        assertEquals("w1",d.attendance.first().workerId)
    }

    @Test fun report_profit_loss_is_revenue_minus_labour_minus_expense() {
        val a=listOf(att(rate=500.0))
        val w=listOf(WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Weeding",quantity=1.0,rateType=WorkRateEngine.QUANTITY,rate=200.0,workerIds=mutableListOf("w")))
        val e=listOf(Expense(date="2026-09-29",category="Diesel",amount=50.0))
        val r=listOf(Revenue(cropId="c",date="2026-09-29",amount=1000.0))
        val d=ReportEngine.filter(ReportFilter(from="2026-09-29",to="2026-09-29"),a,w,emptyList(),e,r,emptyList())
        assertEquals(250.0,d.profitLoss(),0.001)
    }
}
