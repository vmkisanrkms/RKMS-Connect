package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Static acceptance tests for rotation/configuration resilience and user-facing error handling. */
class ConfigurationAndErrorStateTest {
    private val root = File("app/src/main")
    private val activity = File(root, "java/com/majdoor/hisaab/MainActivity.kt")
    private val manifest = File(root, "AndroidManifest.xml")

    @Test
    fun rotationStateIsSavedAndRestored() {
        val s = activity.readText()
        assertTrue(s.contains("override fun onSaveInstanceState(outState:Bundle)"))
        assertTrue(s.contains("outState.putString(\"route\", currentRoute)"))
        assertTrue(s.contains("restoredRoute=b?.getString(\"route\")"))
        assertTrue(s.contains("private fun openRestoredRoute()"))
        assertTrue(s.contains("currentRoute=when(title)"))
    }

    @Test
    fun configurationDoesNotRelyOnPermanentPortraitLock() {
        val s = manifest.readText()
        // Configuration changes must be allowed to recreate the activity; state restoration handles the route.
        assertTrue(!s.contains("configChanges=\"orientation"))
        assertTrue(!s.contains("android:screenOrientation=\"portrait\""))
    }

    @Test
    fun visibleButtonErrorsHaveRecoveryPath() {
        val s = activity.readText()
        assertTrue(s.contains("catch(e:Exception){ showErrorState(s,e) }"))
        assertTrue(s.contains("Something went wrong"))
        assertTrue(s.contains("Existing local data was not intentionally deleted"))
        assertTrue(s.contains("setNegativeButton(\"Home\""))
        assertTrue(s.contains("setPositiveButton(\"Retry\""))
    }

    @Test
    fun startupHasNoUncaughtConfigurationRestoreRequirement() {
        val s = activity.readText()
        assertTrue(s.contains("if(!prefs.getBoolean(\"first_setup_done\", false))"))
        assertTrue(s.contains("if(security.hasPin())"))
        assertTrue(s.contains("openRestoredRoute()"))
    }
}
