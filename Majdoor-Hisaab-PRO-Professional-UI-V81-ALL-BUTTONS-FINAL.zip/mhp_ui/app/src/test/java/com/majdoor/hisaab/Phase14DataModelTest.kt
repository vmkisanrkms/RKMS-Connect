package com.majdoor.hisaab

import com.majdoor.hisaab.model.*
import org.junit.Assert.*
import org.junit.Test

class Phase14DataModelTest {
    @Test fun wage_history_is_explicit_and_referenceable() {
        val h=WorkerWageHistory(workerId="w1",effectiveFrom="2026-09-30",rate=600.0,rateUnit="DAY")
        assertEquals("w1",h.workerId); assertEquals(600.0,h.rate,0.001)
    }
    @Test fun crop_variety_is_explicit_entity() {
        val v=CropVariety(cropId="crop-1",name="HD-2967")
        assertEquals("crop-1",v.cropId); assertTrue(v.active)
    }
    @Test fun backup_metadata_is_persistent_entity() {
        val m=BackupMetadata(lastBackupAt=123L,schemaVersion=3,lastOperation="INTERNAL")
        assertEquals("current",m.id); assertEquals(3,m.schemaVersion); assertEquals("INTERNAL",m.lastOperation)
    }
    @Test fun payment_methods_are_closed_set() {
        assertEquals(setOf("Cash","Bank","UPI"), setOf("Cash","Bank","UPI"))
    }
}
