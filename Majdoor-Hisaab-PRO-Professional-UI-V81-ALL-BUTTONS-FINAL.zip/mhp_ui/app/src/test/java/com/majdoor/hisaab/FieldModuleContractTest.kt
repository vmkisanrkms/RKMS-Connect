package com.majdoor.hisaab

import com.majdoor.hisaab.model.Crop
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class FieldModuleContractTest {
    private fun store(): LocalStore {
        val ctx = RuntimeEnvironment.getApplication()
        File(ctx.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
        return LocalStore(ctx)
    }

    @Test fun field_round_trip_preserves_all_required_fields() {
        val s=store()
        val f=Field(name="North Field",area=7.5,unit="acre",location="Baboura",soilType="Loam",irrigation="Tube Well",notes="Canal side",photoUri="content://field/photo",active=true)
        s.upsertField(f)
        val x=s.fields().single()
        assertEquals("North Field",x.name); assertEquals(7.5,x.area,0.0001); assertEquals("acre",x.unit)
        assertEquals("Baboura",x.location); assertEquals("Loam",x.soilType); assertEquals("Tube Well",x.irrigation)
        assertEquals("Canal side",x.notes); assertEquals("content://field/photo",x.photoUri)
    }

    @Test fun field_edit_preserves_id_and_updates_values() {
        val s=store(); val f=Field(name="Old",area=2.0); s.upsertField(f)
        s.upsertField(f.copy(name="New",area=3.0,location="East",soilType="Clay",irrigation="Drip",notes="Updated",photoUri="photo2"))
        val x=s.fields().single(); assertEquals(f.id,x.id); assertEquals("New",x.name); assertEquals(3.0,x.area,0.0001)
        assertEquals("East",x.location); assertEquals("Clay",x.soilType); assertEquals("Drip",x.irrigation); assertEquals("Updated",x.notes); assertEquals("photo2",x.photoUri)
    }

    @Test fun multiple_crop_records_can_exist_for_one_field_over_time() {
        val s=store(); val f=Field(name="Seasonal Field",area=5.0); s.upsertField(f)
        s.upsertCrop(Crop(name="Wheat",variety="HD",fieldId=f.id,plantingDate="2026-11-12",area=5.0))
        s.upsertCrop(Crop(name="Sugarcane",variety="CO",fieldId=f.id,plantingDate="2027-02-27",area=5.0))
        val crops=s.crops().filter{it.fieldId==f.id}; assertEquals(2,crops.size); assertEquals(setOf("Wheat","Sugarcane"),crops.map{it.name}.toSet())
    }

    @Test fun field_name_duplicate_is_rejected_but_different_fields_are_allowed() {
        val s=store(); s.upsertField(Field(name="Same",area=1.0));
        assertThrows(IllegalArgumentException::class.java){s.upsertField(Field(name="same",area=2.0))}
        s.upsertField(Field(name="Other",area=2.0)); assertEquals(2,s.fields().size)
    }

    @Test fun field_delete_is_blocked_when_linked_records_exist() {
        val s=store(); val f=Field(name="Linked",area=1.0); s.upsertField(f)
        s.upsertCrop(Crop(name="Crop",fieldId=f.id))
        assertThrows(IllegalArgumentException::class.java){s.deleteField(f.id)}
        assertEquals(1,s.fields().size)
    }
}
