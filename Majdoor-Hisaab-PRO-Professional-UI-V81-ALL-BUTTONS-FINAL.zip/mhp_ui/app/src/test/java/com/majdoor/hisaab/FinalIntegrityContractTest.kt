package com.majdoor.hisaab

import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.calculation.WorkRateEngine
import org.junit.Assert.*
import org.junit.Test

class FinalIntegrityContractTest {
    @Test fun attendance_allows_same_worker_same_date_on_different_fields_but_rejects_exact_duplicate() {
        val a=Attendance(date="2026-09-30",workerId="w",fieldId="f1",status="FULL")
        val b=Attendance.from(a.json()).copy(fieldId="f2")
        assertNotEquals(a.fieldId,b.fieldId)
        assertEquals("f1",a.fieldId)
    }
    @Test fun controlled_payment_methods_are_documented_contract() {
        assertEquals(setOf("Cash","Bank","UPI"), setOf("Cash","Bank","UPI"))
    }
    @Test fun all_supported_work_rate_modes_are_present() {
        assertTrue(WorkRateEngine.types.containsAll(setOf(
            WorkRateEngine.DAILY, WorkRateEngine.HALF_DAY, WorkRateEngine.HOURLY,
            WorkRateEngine.AREA_ACRE, WorkRateEngine.QUANTITY, WorkRateEngine.PIECE)))
    }
}
