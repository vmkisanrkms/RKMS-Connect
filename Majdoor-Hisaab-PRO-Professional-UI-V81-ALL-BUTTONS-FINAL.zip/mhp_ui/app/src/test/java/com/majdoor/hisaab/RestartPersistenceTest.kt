package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File

/**
 * Restart persistence acceptance test.
 * A second LocalStore instance represents a new app process reading the same
 * on-device JSON files after the first process has stopped.
 */
class RestartPersistenceTest {
    private lateinit var context: Context
    private lateinit var root: File

    @Before
    fun cleanBefore() {
        context = ApplicationProvider.getApplicationContext()
        root = File(context.getExternalFilesDir(null), "majdoor_hisaab")
        root.deleteRecursively()
    }

    @Test
    fun recordsSurviveStoreRecreationAndReadBack() {
        val firstProcess = LocalStore(context)
        val worker = Worker(id = "restart-worker-1", name = "Restart Worker", mobile = "8888888888")
        val field = Field(id = "restart-field-1", name = "Restart Field", area = 3.5)

        firstProcess.upsertWorker(worker)
        firstProcess.upsertField(field)
        assertEquals(1, firstProcess.workers().count { it.id == worker.id })
        assertEquals(1, firstProcess.fields().count { it.id == field.id })

        // Simulate force-stop/process death: discard the repository instance.
        firstProcess.toString()

        // New repository instance must read the exact persisted files.
        val restartedProcess = LocalStore(context)
        assertEquals(1, restartedProcess.workers().count { it.id == worker.id && it.name == worker.name })
        assertEquals(1, restartedProcess.fields().count { it.id == field.id && it.name == field.name })
        assertTrue(restartedProcess.health().none { it.startsWith("ERROR:") })
    }
}
