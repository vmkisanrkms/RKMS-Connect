package com.majdoor.hisaab

import com.majdoor.hisaab.model.Worker
import org.junit.Assert.assertEquals
import org.junit.Test

class WorkerQueryTest {
 private val a=Worker(id="a",name="Raju",mobile="9000000001",workerType="Skilled",defaultRate=700.0,referenceId="REF-A",address="Baboura")
 private val b=Worker(id="b",name="Mohan",mobile="9000000002",workerType="General",defaultRate=0.0,active=false,referenceId="REF-B",address="Palia")
 private val c=Worker(id="c",name="Amar",mobile="9000000003",workerType="Driver",defaultRate=500.0,referenceId="REF-C",address="Lucknow")
 @Test fun search_all_fields(){val all=listOf(a,b,c);assertEquals("Raju",WorkerQuery.search(all,"9000000001").single().name);assertEquals("Mohan",WorkerQuery.search(all,"general").single().name);assertEquals("Amar",WorkerQuery.search(all,"REF-C").single().name);assertEquals("Raju",WorkerQuery.search(all,"Baboura").single().name);assertEquals("Mohan",WorkerQuery.search(all,"mohan").single().name)}
 @Test fun filters(){val all=listOf(a,b,c);assertEquals(listOf("Raju","Amar"),WorkerQuery.active(all).map{it.name});assertEquals(listOf("Mohan"),WorkerQuery.inactive(all).map{it.name});assertEquals(listOf("Raju","Amar"),WorkerQuery.wagePositive(all).map{it.name});assertEquals(listOf("Mohan"),WorkerQuery.wageZero(all).map{it.name})}
 @Test fun sorts(){val all=listOf(a,b,c);assertEquals(listOf("Amar","Mohan","Raju"),WorkerQuery.sortNameAsc(all).map{it.name});assertEquals(listOf("Raju","Mohan","Amar"),WorkerQuery.sortNameDesc(all).map{it.name});assertEquals(listOf("Raju","Amar","Mohan"),WorkerQuery.sortWageDesc(all).map{it.name});assertEquals(listOf("Mohan","Amar","Raju"),WorkerQuery.sortWageAsc(all).map{it.name})}
}
