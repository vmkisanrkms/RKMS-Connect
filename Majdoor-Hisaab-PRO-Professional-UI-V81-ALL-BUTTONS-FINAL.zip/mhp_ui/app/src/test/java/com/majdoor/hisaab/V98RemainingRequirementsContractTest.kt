package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** V98 contract checks for every previously-unverified implementation family. */
class V98RemainingRequirementsContractTest {
    private val root = File("src/main/java/com/majdoor/hisaab")
    private val all = root.walkTopDown().filter { it.isFile && it.extension == "kt" }.joinToString("\n") { it.readText() }
    private val screens = File(root, "MainActivityScreens.kt").readText()
    private val workflow = File("../.github/workflows/build-release-apk.yml").readText()

    @Test fun security_runtime_paths_are_real() {
        assertTrue(all.contains("verifyPin")); assertTrue(all.contains("BiometricPrompt"))
        assertTrue(all.contains("AutoLockManager.shouldLock")); assertTrue(all.contains("pin_blocked_until"))
        assertTrue(all.contains("biometricEnabled"))
    }

    @Test fun settings_theme_date_notification_report_are_real() {
        assertTrue(screens.contains("arrayOf(\"Light\",\"Dark\",\"System\")"))
        assertTrue(screens.contains("selectedDatePattern")); assertTrue(screens.contains("NotificationSettings"))
        assertTrue(screens.contains("Report Settings")); assertTrue(screens.contains("report_include_header"))
    }

    @Test fun backup_restore_health_import_rollback_are_real() {
        assertTrue(all.contains("fun health()")); assertTrue(all.contains("restore(input"))
        assertTrue(all.contains("openImport")); assertTrue(all.contains("rollback"))
        assertTrue(all.contains("backup_metadata.json")); assertTrue(all.contains("schemaVersion"))
    }

    @Test fun audit_search_calendar_reports_are_real() {
        assertTrue(screens.contains("auditLogScreen")); assertTrue(screens.contains("Global Search"))
        assertTrue(screens.contains("attendanceCalendar")); assertTrue(screens.contains("reportFiltersDialog"))
        assertTrue(screens.contains("Report Settings")); assertTrue(all.contains("PdfDocument"))
    }

    @Test fun data_model_relations_are_real() {
        assertTrue(all.contains("WorkerWageHistory")); assertTrue(all.contains("CropVariety"))
        assertTrue(all.contains("worker_wage_history")); assertTrue(all.contains("crop_varieties"))
        assertTrue(all.contains("payment methods") || all.contains("PaymentMethod") || all.contains("method"))
        assertTrue(all.contains("AuditLog")); assertTrue(all.contains("BackupMetadata"))
    }

    @Test fun coordinator_architecture_is_enforced() {
        assertTrue(File(root, "MainActivity.kt").readLines().size <= 260)
        assertTrue(screens.contains("fun MainActivity.dashboard"))
        assertTrue(screens.contains("fun MainActivity.workers"))
        assertTrue(screens.contains("fun MainActivity.attendance"))
        assertTrue(screens.contains("fun MainActivity.reports"))
        assertTrue(screens.contains("fun MainActivity.backup"))
        assertTrue(screens.contains("fun MainActivity.settings"))
    }

    @Test fun release_workflow_requires_real_runtime_evidence() {
        listOf(
            "gradle/actions/setup-gradle@v4", "assembleRelease", "apksigner sign", "apksigner verify",
            "adb uninstall", "adb install", "adb reboot", "svc wifi disable", "svc data disable",
            "connectedE2eReleaseAndroidTest", "final-release-gate.sh", "cmd package resolve-activity",
            "MH_RELEASE_KEYSTORE_BASE64", "MH_RELEASE_CERT_SHA256"
        ).forEach { assertTrue("Missing release evidence: $it", workflow.contains(it)) }
    }
}
