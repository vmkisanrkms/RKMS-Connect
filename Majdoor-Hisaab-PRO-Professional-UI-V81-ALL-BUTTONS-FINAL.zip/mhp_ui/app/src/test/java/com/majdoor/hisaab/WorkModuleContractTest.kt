package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.WorkRecord
import org.junit.Assert.*
import org.junit.Test

/** Phase 6 deterministic work calculation and allocation contract. */
class WorkModuleContractTest {
    private fun work(type:String, q:Double, rate:Double, unit:String="unit", start:String="", end:String="", workers:List<String> = listOf("w")) =
        WorkRecord(date="2026-09-30", fieldId="f", cropId="c", workType="Test", quantity=q,
            rateType=type, unit=unit, rate=rate, workerIds=workers.toMutableList(), startTime=start, endTime=end)

    @Test fun daily_rate_calculation() = assertEquals(1200.0, WorkRateEngine.cost(work(WorkRateEngine.DAILY,2.0,600.0,"day")),0.001)
    @Test fun half_day_calculation() = assertEquals(600.0, WorkRateEngine.cost(work(WorkRateEngine.HALF_DAY,2.0,600.0,"half-day")),0.001)
    @Test fun hourly_calculation_from_time() = assertEquals(350.0, WorkRateEngine.cost(work(WorkRateEngine.HOURLY,0.0,100.0,"hour","09:00","12:30")),0.001)
    @Test fun acre_area_rate_calculation() = assertEquals(2700.0, WorkRateEngine.cost(work(WorkRateEngine.AREA_ACRE,3.0,900.0,"acre")),0.001)
    @Test fun quantity_rate_calculation() = assertEquals(200.0, WorkRateEngine.cost(work(WorkRateEngine.QUANTITY,10.0,20.0,"kg")),0.001)
    @Test fun piece_rate_calculation() = assertEquals(200.0, WorkRateEngine.cost(work(WorkRateEngine.PIECE,25.0,8.0,"piece")),0.001)
    @Test fun hourly_rate_uses_explicit_quantity_when_time_is_missing() = assertEquals(300.0, WorkRateEngine.cost(work(WorkRateEngine.HOURLY,3.0,100.0,"hour")),0.001)
    @Test fun hourly_rate_supports_overnight_shift() = assertEquals(300.0, WorkRateEngine.cost(work(WorkRateEngine.HOURLY,0.0,100.0,"hour","22:00","01:00")),0.001)

    @Test fun multi_worker_allocation_preserves_total_cost() {
        val x=work(WorkRateEngine.AREA_ACRE,1.0,900.0,"acre",workers=listOf("a","b","c"))
        assertEquals(900.0, WorkRateEngine.cost(x),0.001)
        assertEquals(300.0, WorkRateEngine.allocatedCost(x,"a"),0.001)
        assertEquals(300.0, WorkRateEngine.allocatedCost(x,"b"),0.001)
        assertEquals(300.0, WorkRateEngine.allocatedCost(x,"c"),0.001)
        assertEquals(900.0, x.workerIds.distinct().sumOf { WorkRateEngine.allocatedCost(x,it) },0.001)
    }

    @Test fun all_required_work_types_are_available_and_custom_is_allowed() {
        assertTrue(WorkRateEngine.workTypes.containsAll(listOf("Planting","Sowing","Weeding","Harvesting","Cutting","Loading","Irrigation","Spraying","Fertilizing","Custom")))
        assertEquals("Custom", WorkRateEngine.workTypes.last())
    }

    @Test fun work_json_round_trip_preserves_all_work_fields() {
        val x=work(WorkRateEngine.HOURLY,0.0,150.0,"hour","08:15","12:45",listOf("a","b")).copy(
            workType="Spraying", notes="Morning spray"
        )
        val y=WorkRecord.from(x.json())
        assertEquals(x.date,y.date); assertEquals(x.fieldId,y.fieldId); assertEquals(x.cropId,y.cropId)
        assertEquals(x.workType,y.workType); assertEquals(x.quantity,y.quantity,0.001); assertEquals(x.rateType,y.rateType)
        assertEquals(x.unit,y.unit); assertEquals(x.rate,y.rate,0.001); assertEquals(x.workerIds,y.workerIds)
        assertEquals(x.startTime,y.startTime); assertEquals(x.endTime,y.endTime); assertEquals(x.notes,y.notes)
    }
}
