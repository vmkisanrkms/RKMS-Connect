package com.majdoor.hisaab

import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.report.ReportEngine
import com.majdoor.hisaab.report.ReportFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReportEngineTest {
    private val a=listOf(
        Attendance(date="2026-09-01",workerId="w1",fieldId="f1",status="FULL",rate=500.0),
        Attendance(date="2026-09-02",workerId="w2",fieldId="f2",status="FULL",rate=700.0))
    private val work=listOf(
        WorkRecord(date="2026-09-01",fieldId="f1",cropId="c1",workType="Weeding",quantity=2.0,rateType="QUANTITY",rate=100.0,workerIds=mutableListOf("w1")),
        WorkRecord(date="2026-09-02",fieldId="f2",cropId="c2",workType="Harvest",quantity=3.0,rateType="QUANTITY",rate=200.0,workerIds=mutableListOf("w2")))
    private val p=listOf(Payment(workerId="w1",date="2026-09-01",amount=100.0))
    private val e=listOf(Expense(date="2026-09-01",category="Diesel",amount=50.0,fieldId="f1",cropId="c1"), Expense(date="2026-09-01",category="Seed",amount=900.0,fieldId="f2",cropId="c2"))
    private val r=listOf(Revenue(cropId="c1",date="2026-09-01",amount=1000.0), Revenue(cropId="c2",date="2026-09-01",amount=9000.0))
    private val prod=listOf(Production(cropId="c1",date="2026-09-01",quantity=10.0,unit="qtl"), Production(cropId="c2",date="2026-09-01",quantity=20.0,unit="qtl"))
    private val cropFields=mapOf("c1" to "f1", "c2" to "f2")

    @Test fun dateAndEntityFiltersApplyToAllReportSources(){
        val d=ReportEngine.filter(ReportFilter(from="2026-09-01",to="2026-09-01",workerId="w1",fieldId="f1",cropId="c1"),a,work,p,e,r,prod,cropFields)
        assertEquals(1,d.attendance.size); assertEquals(1,d.work.size); assertEquals(1,d.payments.size); assertEquals(1,d.expenses.size); assertEquals(1,d.revenues.size); assertEquals(1,d.production.size)
        assertEquals(500.0,d.attendanceCost(),0.001); assertEquals(200.0,d.workCost(),0.001); assertEquals(50.0,d.expenseCost(),0.001); assertEquals(1000.0,d.revenueTotal(),0.001); assertEquals(250.0,d.profitLoss(),0.001)
    }
    @Test fun report_periods_are_deterministic() {
        val base = ReportFilter()
        assertEquals("2026-09-15", ReportEngine.periodFilter("Daily Labour", base, "2026-09-15").from)
        assertEquals("2026-09-15", ReportEngine.periodFilter("Daily Labour", base, "2026-09-15").to)
        val weekly = ReportEngine.periodFilter("Weekly Labour", base.copy(from="2026-09-16"), "2026-09-15")
        assertEquals("2026-09-14", weekly.from); assertEquals("2026-09-20", weekly.to)
        val monthly = ReportEngine.periodFilter("Monthly Labour", base.copy(from="2026-02-17"), "2026-09-15")
        assertEquals("2026-02-01", monthly.from); assertEquals("2026-02-28", monthly.to)
    }
    @Test fun report_entity_filters_are_combined() {
        val d=ReportEngine.filter(ReportFilter(from="2026-09-10",to="2026-09-10",workerId="w1",fieldId="f1"),listOf(Attendance(date="2026-09-10",workerId="w1",fieldId="f1",status="FULL",rate=500.0),Attendance(date="2026-09-10",workerId="w2",fieldId="f2",status="FULL",rate=700.0)),emptyList(),emptyList(),emptyList(),emptyList(),emptyList(),emptyMap())
        assertEquals(1,d.attendance.size); assertEquals("w1",d.attendance.first().workerId)
    }
    @Test fun report_profit_loss_is_revenue_minus_labour_minus_expense() {
        val d=ReportEngine.filter(ReportFilter(from="2026-09-29",to="2026-09-29"),listOf(Attendance(date="2026-09-29",workerId="w",fieldId="f",status="FULL",rate=500.0)),listOf(WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Weeding",quantity=1.0,rateType="QUANTITY",rate=200.0,workerIds=mutableListOf("w"))),emptyList(),listOf(Expense(date="2026-09-29",category="Diesel",amount=50.0)),listOf(Revenue(cropId="c",date="2026-09-29",amount=1000.0)),emptyList(),mapOf("c" to "f"))
        assertEquals(250.0,d.profitLoss(),0.001)
    }
    @Test fun field_filter_excludes_other_field_revenue_and_production() {
        val d=ReportEngine.filter(ReportFilter(from="2026-09-01",to="2026-09-01",fieldId="f1"),a,work,p,e,r,prod,cropFields)
        assertEquals(1000.0,d.revenueTotal(),0.001); assertEquals(1,d.production.size); assertEquals("c1",d.production.first().cropId)
    }
    @Test fun crop_filter_is_respected_by_field_filter() {
        val d=ReportEngine.filter(ReportFilter(from="2026-09-01",to="2026-09-01",fieldId="f1",cropId="c1"),a,work,p,e,r,prod,cropFields)
        assertEquals(1,d.revenues.size); assertEquals(1,d.production.size); assertTrue(d.expenses.all{it.cropId=="c1"})
    }
    @Test fun unfiltered_report_keeps_all_revenue() {
        val d=ReportEngine.filter(ReportFilter(from="2026-09-01",to="2026-09-01"),a,work,p,e,r,prod,cropFields)
        assertEquals(2,d.revenues.size); assertEquals(10000.0,d.revenueTotal(),0.001)
    }
}
