package com.majdoor.hisaab

import android.content.Context
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35])
class WorkCrudTest {
    private lateinit var store: LocalStore
    private lateinit var worker1: Worker
    private lateinit var worker2: Worker
    private lateinit var field: Field
    private lateinit var crop: Crop

    @Before fun setup() {
        val ctx=RuntimeEnvironment.getApplication() as Context
        File(ctx.getExternalFilesDir(null),"majdoor_hisaab").deleteRecursively()
        store=LocalStore(ctx)
        worker1=Worker(id="w1",name="Raju",mobile="9000000001")
        worker2=Worker(id="w2",name="Mohan",mobile="9000000002")
        field=Field(id="f1",name="Field A",area=5.0)
        crop=Crop(id="c1",name="Sugarcane",variety="CO",fieldId=field.id,area=5.0)
        store.upsertWorker(worker1); store.upsertWorker(worker2); store.upsertField(field); store.upsertCrop(crop)
    }

    private fun sample(id:String="work1")=WorkRecord(id=id,date="2026-09-30",fieldId=field.id,cropId=crop.id,workType="Planting",quantity=2.0,rateType=WorkRateEngine.DAILY,unit="day",rate=600.0,workerIds=mutableListOf(worker1.id),startTime="08:00",endTime="12:00",notes="Initial")

    @Test fun work_create_read_update_delete_persists_every_field_and_audit() {
        val x=sample(); store.upsertWork(x)
        val saved=store.work().single(); assertEquals(x.date,saved.date); assertEquals(x.fieldId,saved.fieldId); assertEquals(x.cropId,saved.cropId)
        assertEquals(x.workType,saved.workType); assertEquals(x.quantity,saved.quantity,0.001); assertEquals(x.rateType,saved.rateType); assertEquals(x.unit,saved.unit); assertEquals(x.rate,saved.rate,0.001)
        assertEquals(x.workerIds,saved.workerIds); assertEquals("08:00",saved.startTime); assertEquals("12:00",saved.endTime); assertEquals("Initial",saved.notes)
        store.upsertWork(x.copy(workType="Harvesting",quantity=3.0,rate=700.0,workerIds=mutableListOf(worker1.id,worker2.id),notes="Edited"))
        val edited=store.work().single(); assertEquals("Harvesting",edited.workType); assertEquals(3.0,edited.quantity,0.001); assertEquals(2,edited.workerIds.size); assertEquals("Edited",edited.notes)
        val logs=store.auditLog().filter{it.optString("entity")=="work" && it.optString("entityId")==x.id}
        assertTrue(logs.any{it.optString("action")=="CREATE"}); assertTrue(logs.any{it.optString("action")=="UPDATE"})
        store.deleteWork(x.id); assertTrue(store.work().isEmpty()); assertTrue(store.auditLog().any{it.optString("entity")=="work" && it.optString("action")=="DELETE"})
    }

    @Test fun work_template_create_update_delete_is_functional() {
        val t=WorkTemplate(id="tpl1",name="Sugarcane Spray",workType="Spraying",unit="acre",rate=450.0,rateType=WorkRateEngine.AREA_ACRE,notes="Morning")
        store.upsertWorkTemplate(t)
        assertEquals("Spraying",store.workTemplates().single().workType)
        store.upsertWorkTemplate(t.copy(rate=500.0,notes="Updated"))
        assertEquals(500.0,store.workTemplates().single().rate,0.001)
        store.deleteWorkTemplate(t.id)
        assertTrue(store.workTemplates().isEmpty())
    }

    @Test fun work_rejects_invalid_time_and_invalid_relationships() {
        val x=sample(startTime="8:00")
        try { store.upsertWork(x); fail("Invalid HH:mm time must be rejected") } catch (_:IllegalArgumentException) { }
        try { store.upsertWork(x.copy(startTime="08:00",cropId="wrong")); fail("Crop-field mismatch must be rejected") } catch (_:IllegalArgumentException) { }
    }

    @Test fun duplicate_work_protection_is_deterministic() {
        val x=sample(); store.upsertWork(x)
        try { store.upsertWork(x.copy(id="different")); fail("Exact duplicate work must be rejected") }
        catch (_:IllegalArgumentException) { }
        // A genuinely different work record remains valid.
        store.upsertWork(x.copy(id="different",startTime="09:00",endTime="13:00"))
        assertEquals(2,store.work().size)
    }
}
