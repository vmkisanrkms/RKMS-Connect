package com.majdoor.hisaab

import java.io.File

/**
 * Source-contract helper used by static tests after MainActivity was reduced to
 * a lifecycle/coordinator. UI implementations live in MainActivityScreens.kt.
 */
object UiSourceContract {
    fun text(): String {
        val root = File("src/main/java/com/majdoor/hisaab")
        return listOf("MainActivity.kt", "MainActivityScreens.kt")
            .map { File(root, it) }
            .filter { it.isFile }
            .joinToString("\n") { it.readText() }
    }
}
