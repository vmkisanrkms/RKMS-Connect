package com.majdoor.hisaab

import com.majdoor.hisaab.model.*
import org.junit.Assert.*
import org.junit.Test

class RemainingRequirementsContractTest {
    @Test fun worker_wage_history_round_trips() {
        val x=WorkerWageHistory(workerId="w",effectiveFrom="2026-09-30",rate=750.0,rateUnit="DAY",note="seasonal")
        val y=WorkerWageHistory.from(x.json())
        assertEquals(x.workerId,y.workerId); assertEquals(x.effectiveFrom,y.effectiveFrom); assertEquals(x.rate,y.rate,0.001); assertEquals(x.rateUnit,y.rateUnit); assertEquals(x.note,y.note)
    }
    @Test fun crop_variety_round_trips() {
        val x=CropVariety(cropId="c",name="CO-0238",notes="spring")
        val y=CropVariety.from(x.json())
        assertEquals(x.cropId,y.cropId); assertEquals(x.name,y.name); assertEquals(x.notes,y.notes); assertTrue(y.active)
    }
    @Test fun backup_metadata_round_trips_schema_and_operation() {
        val x=BackupMetadata(schemaVersion=4,lastOperation="RESTORE")
        val y=BackupMetadata.from(x.json())
        assertEquals(4,y.schemaVersion); assertEquals("RESTORE",y.lastOperation)
    }
}
