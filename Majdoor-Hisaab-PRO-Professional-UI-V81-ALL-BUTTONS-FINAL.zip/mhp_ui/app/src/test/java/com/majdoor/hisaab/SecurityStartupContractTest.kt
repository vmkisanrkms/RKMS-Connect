package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SecurityStartupContractTest {
    private val root = File("src/main/java/com/majdoor/hisaab")
    private val activity = File(root, "MainActivity.kt")
    private val security = File(root, "security/SecurityManager.kt")

    @Test fun splash_and_one_time_setup_are_present_and_ordered(){
        val s=activity.readText()
        assertTrue(s.contains("showSplash()"))
        assertTrue(s.contains("postDelayed({ initializeStartup() }, 650L)"))
        assertTrue(s.contains("if(!prefs.getBoolean(\"first_setup_done\", false))"))
        assertTrue(s.contains("setContentView(this)"))
        assertTrue(s.indexOf("addView(btn(\"Start App\")") < s.indexOf("setContentView(this)", s.indexOf("private fun firstTimeSetup")))
    }

    @Test fun pin_rules_lockout_and_persistent_state_are_present(){
        val s=activity.readText()
        assertTrue(s.contains("p.length !in 4..12"))
        assertTrue(s.contains("failedPinAttempts>=5"))
        assertTrue(s.contains("pin_blocked_until"))
        assertTrue(s.contains("Disable App Lock"))
        assertTrue(s.contains("security.clearPin()"))
    }

    @Test fun biometric_has_pin_fallback_and_safe_unavailable_path(){
        val s=security.readText()
        assertTrue(s.contains("setNegativeButton(\"Use PIN\""))
        assertTrue(s.contains("onAuthenticationError"))
        assertTrue(s.contains("Build.VERSION.SDK_INT >= 30"))
    }

    @Test fun auto_lock_persists_and_background_timeout_is_checked(){
        val s=activity.readText()
        assertTrue(s.contains("auto_lock_timeout"))
        assertTrue(s.contains("override fun onPause()"))
        assertTrue(s.contains("override fun onResume()"))
        assertTrue(s.contains("now-autoLockFromBackground>=timeout"))
    }
}
