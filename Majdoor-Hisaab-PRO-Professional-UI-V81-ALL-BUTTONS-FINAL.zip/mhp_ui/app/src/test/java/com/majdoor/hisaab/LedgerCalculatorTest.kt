package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*
import org.junit.Assert.assertEquals
import org.junit.Test

class LedgerCalculatorTest {
    @Test fun fullAndHalfAttendance(){
        val a=listOf(Attendance(date="2026-09-29",workerId="w",status="FULL",rate=600.0),Attendance(date="2026-09-30",workerId="w",status="HALF",rate=600.0))
        assertEquals(900.0,LedgerCalculator.attendanceEarned("w",a),0.001)
    }
    @Test fun multiWorkerWorkIsSplitEqually(){
        val x=WorkRecord(date="2026-09-29",fieldId="f",cropId="c",workType="Weeding",quantity=1.0,unit="acre",rate=900.0,workerIds=mutableListOf("a","b","c"))
        assertEquals(300.0,LedgerCalculator.workEarned("a",listOf(x)),0.001)
        assertEquals(900.0, listOf("a","b","c").sumOf{LedgerCalculator.workEarned(it,listOf(x))},0.001)
    }
    @Test fun paymentAndAdvanceAreSeparate(){
        val p=listOf(Payment(workerId="w",date="2026-09-29",amount=200.0,advance=false),Payment(workerId="w",date="2026-09-29",amount=100.0,advance=true))
        assertEquals(200.0,LedgerCalculator.paid("w",p),0.001)
        assertEquals(100.0,LedgerCalculator.advances("w",p),0.001)
        val s=LedgerCalculator.summary("w", emptyList(), emptyList(), p)
        assertEquals(300.0,s.totalPaid,0.001)
    }

    @Test fun outstandingSubtractsAdvanceExactlyOnce(){
        val a=listOf(Attendance(date="2026-09-29",workerId="w",status="FULL",rate=1000.0))
        val p=listOf(
            Payment(workerId="w",date="2026-09-29",amount=600.0,advance=false),
            Payment(workerId="w",date="2026-09-29",amount=200.0,advance=true)
        )
        val s=LedgerCalculator.summary("w",a,emptyList(),p)
        assertEquals(1000.0,s.earned,0.001)
        assertEquals(800.0,s.totalPaid,0.001)
        assertEquals(200.0,s.outstanding,0.001)
        assertEquals(0.0,s.credit,0.001)
    }

    @Test fun overpaymentBecomesCreditNotNegativeOutstanding(){
        val a=listOf(Attendance(date="2026-09-29",workerId="w",status="FULL",rate=1000.0))
        val p=listOf(Payment(workerId="w",date="2026-09-29",amount=1200.0,advance=false))
        val s=LedgerCalculator.summary("w",a,emptyList(),p)
        assertEquals(0.0,s.outstanding,0.001)
        assertEquals(200.0,s.credit,0.001)
    }
    @Test fun workRateEngineSupportsAllBlueprintRateTypes(){
        val daily=WorkRecord(workType="Harvest",quantity=2.0,rateType=WorkRateEngine.DAILY,unit="day",rate=500.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        val half=WorkRecord(workType="Harvest",quantity=2.0,rateType=WorkRateEngine.HALF_DAY,unit="half-day",rate=500.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        val hourly=WorkRecord(workType="Harvest",quantity=0.0,rateType=WorkRateEngine.HOURLY,unit="hour",rate=100.0,workerIds=mutableListOf("w"),startTime="09:00",endTime="12:30",date="2026-09-29",fieldId="f",cropId="c")
        val area=WorkRecord(workType="Harvest",quantity=3.0,rateType=WorkRateEngine.AREA_ACRE,unit="acre",rate=900.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        val qty=WorkRecord(workType="Harvest",quantity=10.0,rateType=WorkRateEngine.QUANTITY,unit="kg",rate=20.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        val piece=WorkRecord(workType="Harvest",quantity=25.0,rateType=WorkRateEngine.PIECE,unit="piece",rate=8.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        assertEquals(1000.0,WorkRateEngine.cost(daily),0.001)
        assertEquals(500.0,WorkRateEngine.cost(half),0.001)
        assertEquals(350.0,WorkRateEngine.cost(hourly),0.001)
        assertEquals(2700.0,WorkRateEngine.cost(area),0.001)
        assertEquals(200.0,WorkRateEngine.cost(qty),0.001)
        assertEquals(200.0,WorkRateEngine.cost(piece),0.001)
        assertEquals(500.0,WorkRateEngine.allocatedCost(half,"w"),0.001)
    }

    @Test fun hourlyFallsBackToEnteredQuantityWhenTimesMissing(){
        val x=WorkRecord(workType="Spraying",quantity=4.0,rateType=WorkRateEngine.HOURLY,unit="hour",rate=150.0,workerIds=mutableListOf("w"),date="2026-09-29",fieldId="f",cropId="c")
        assertEquals(600.0,WorkRateEngine.cost(x),0.001)
    }

}

