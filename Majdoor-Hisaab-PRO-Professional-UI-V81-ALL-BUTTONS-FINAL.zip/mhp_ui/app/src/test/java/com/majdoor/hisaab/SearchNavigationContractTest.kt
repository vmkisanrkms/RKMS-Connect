package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SearchNavigationContractTest {
    private val source = UiSourceContract.text()

    @Test fun searchResultsAreClickableAndNavigateToDetails() {
        assertTrue(source.contains("val results=mutableListOf<Pair<String,()->Unit>>()"))
        assertTrue(source.contains("workerProfile(w.id)"))
        assertTrue(source.contains("fieldProfile(f.id)"))
        assertTrue(source.contains("cropProfile(c.id)"))
        assertTrue(source.contains("attendanceDetail(a.id)"))
        assertTrue(source.contains("workDetail(w.id)"))
        assertTrue(source.contains("paymentDetail(x.id)"))
        assertTrue(source.contains("expenseDetail(x.id)"))
        assertTrue(source.contains("AlertDialog.Builder(this).setTitle(\"Search Results (${results.size})\").setView(scroll)"))
    }

    @Test fun paymentAndExpenseDetailsHaveEditDeleteActions() {
        assertTrue(source.contains("private fun paymentDetail(id:String)"))
        assertTrue(source.contains("private fun expenseDetail(id:String)"))
        assertTrue(source.contains("btn(\"Edit Payment\")"))
        assertTrue(source.contains("btn(\"Delete Payment\")"))
        assertTrue(source.contains("btn(\"Edit Expense\")"))
        assertTrue(source.contains("btn(\"Delete Expense\")"))
    }
}
