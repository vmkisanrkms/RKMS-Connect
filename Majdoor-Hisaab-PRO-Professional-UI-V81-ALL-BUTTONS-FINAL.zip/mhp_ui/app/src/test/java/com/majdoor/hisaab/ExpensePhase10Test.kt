package com.majdoor.hisaab

import android.content.Context
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.report.ReportEngine
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35])
class ExpensePhase10Test {
    private lateinit var store: LocalStore
    private lateinit var field: Field
    private lateinit var crop: Crop

    @Before fun setup() {
        val ctx=RuntimeEnvironment.getApplication() as Context
        java.io.File(ctx.getExternalFilesDir(null),"majdoor_hisaab").deleteRecursively()
        store=LocalStore(ctx)
        field=Field(name="Expense Field",area=5.0)
        crop=Crop(name="Wheat",fieldId=field.id)
        store.upsertField(field); store.upsertCrop(crop)
    }

    @Test fun all_required_categories_persist_and_report() {
        val cats=listOf("Labour","Fertilizer","Seed","Pesticide","Irrigation","Machinery","Diesel","Transport","Repair","Other")
        cats.forEachIndexed { i,cat ->
            store.upsertExpense(Expense(date="2026-09-${10+i}",category=cat,amount=(i+1).toDouble(),fieldId=field.id,cropId=crop.id))
        }
        assertEquals(cats.toSet(),store.expenses().map{it.category}.toSet())
        assertEquals(55.0,store.expenses().sumOf{it.amount},0.001)
        val d=ReportEngine.filter(ReportFilter("","","",field.id,crop.id), emptyList(),emptyList(),emptyList(),store.expenses(),emptyList(),emptyList())
        assertEquals(55.0,d.expenseCost(),0.001)
    }

    @Test fun edit_and_delete_recalculate_totals() {
        val a=Expense(date="2026-09-30",category="Fertilizer",amount=100.0,fieldId=field.id,cropId=crop.id)
        val b=Expense(date="2026-09-30",category="Seed",amount=50.0,fieldId=field.id,cropId=crop.id)
        store.upsertExpense(a); store.upsertExpense(b)
        assertEquals(150.0,store.expenses().sumOf{it.amount},0.001)
        store.upsertExpense(a.copy(amount=175.0))
        assertEquals(225.0,store.expenses().sumOf{it.amount},0.001)
        store.deleteExpense(b.id)
        assertEquals(175.0,store.expenses().sumOf{it.amount},0.001)
    }

    @Test fun custom_configured_category_is_allowed_but_unknown_is_rejected() {
        val ctx=RuntimeEnvironment.getApplication() as Context
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString("expense_categories", "Labour,Fertilizer,Custom Farm Cost").commit()
        store.upsertExpense(Expense(date="2026-09-30",category="Custom Farm Cost",amount=75.0))
        assertEquals("Custom Farm Cost",store.expenses().single().category)
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date="2026-09-30",category="Not Configured",amount=10.0))
        }
    }

    @Test fun category_report_totals_are_separate_and_complete() {
        val cats=listOf("Labour" to 100.0,"Fertilizer" to 200.0,"Other" to 50.0)
        cats.forEachIndexed { i,(cat,amount) ->
            store.upsertExpense(Expense(date="2026-09-${10+i}",category=cat,amount=amount,fieldId=field.id,cropId=crop.id))
        }
        val totals=store.expenses().groupBy{it.category}.mapValues{(_,items)->items.sumOf{it.amount}}
        assertEquals(100.0,totals["Labour"] ?: 0.0,0.001)
        assertEquals(200.0,totals["Fertilizer"] ?: 0.0,0.001)
        assertEquals(50.0,totals["Other"] ?: 0.0,0.001)
    }

    @Test fun field_and_crop_links_are_preserved_and_filterable() {
        val x=Expense(date="2026-09-30",category="Diesel",amount=250.0,fieldId=field.id,cropId=crop.id,notes="Tractor diesel")
        store.upsertExpense(x)
        val saved=store.expenses().single()
        assertEquals(field.id,saved.fieldId); assertEquals(crop.id,saved.cropId); assertEquals("Tractor diesel",saved.notes)
        val d=ReportEngine.filter(ReportFilter("","","",field.id,crop.id),emptyList(),emptyList(),emptyList(),store.expenses(),emptyList(),emptyList())
        assertEquals(1,d.expenses.size)
    }
}
