package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GitHubWorkflowContractTest {
    @Test fun releaseWorkflowIsPresentAndUsesRequiredVerificationSteps() {
        val workflow = File("../.github/workflows/build-release-apk.yml")
        assertTrue("Release workflow missing", workflow.exists())
        val text = workflow.readText()
        listOf(
            "actions/checkout@v4",
            "actions/setup-java@v4",
            "gradle/actions/setup-gradle@v4",
            "android-actions/setup-android@v3",
            "scripts/acceptance-gates.sh",
            "assembleRelease",
            "MH_RELEASE_KEYSTORE_BASE64",
            "MH_RELEASE_CERT_SHA256",
            "apksigner sign",
            "apksigner verify",
            "reactivecircus/android-emulator-runner@v2",
            "adb install",
            "adb shell am force-stop",
            "adb shell am start -W",
            "adb shell pidof",
            "adb uninstall",
            "cmd package resolve-activity",
            "FATAL EXCEPTION",
            "actions/upload-artifact@v4"
        ).forEach { required ->
            assertTrue("Workflow missing: $required", text.contains(required))
        }
    }
}
