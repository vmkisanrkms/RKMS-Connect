package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class DashboardContractTest {
    private val root = File("src/main/java/com/majdoor/hisaab")
    private val source = UiSourceContract.text()

    @Test fun dashboardReadsPersistedDataAndSettings() {
        listOf(
            "prefs.getString(\"farm_name\",\"My Farm\")",
            "isoToDisplay(today)",
            "prefs.getString(\"date_format\",\"dd/MM/yyyy\")",
            "security.hasPin()",
            "security.biometricEnabled()",
            "store.workers()", "store.fields()", "store.crops()",
            "store.attendance()", "store.work()", "store.payments()", "store.expenses()"
        ).forEach { assertTrue("Missing: $it", source.contains(it)) }
    }

    @Test fun dashboardMetricsUseDeterministicStoredRecords() {
        listOf(
            "it.date==today && it.workerId in activeIds",
            "it.status.equals(\"FULL\",true)",
            "it.status.equals(\"HALF\",true)",
            "activeWorkers.count{it.id !in markedIds}",
            "WorkRateEngine.cost(it)",
            "LedgerCalculator.summary(it.id,attendance,work,payments).earned",
            "LedgerCalculator.summary(it.id,attendance,work,payments).outstanding",
            "payments.filter{it.advance}",
            "it.date.startsWith(monthPrefix)",
            "it.date<=today && it.endTime.isBlank()"
        ).forEach { assertTrue("Missing calculation rule: $it", source.contains(it)) }
        assertTrue("Historical inactive workers must remain in financial totals", source.contains("val earned=workers.sumOf"))
        assertTrue("Historical payments must remain in financial totals", source.contains("val paid=payments.sumOf"))
    }

    @Test fun allShortcutsOpenRealCreateFlows() {
        listOf(
            "\"Mark Attendance\" to ::attendance",
            "\"Add Worker\" to",
            "\"Add Work\" to ::addWork",
            "\"Payment\" to {paymentForm()}",
            "\"Add Field\" to",
            "\"Add Crop\" to {cropForm()}",
            "\"Add Expense\" to {expenseForm()}",
            "\"Reports\" to ::reports",
            "\"Global Search\" to ::search"
        ).forEach { assertTrue("Missing shortcut: $it", source.contains(it)) }
    }

    @Test fun recentActivityIsMixedChronologicallyAndNavigatesToDetails() {
        assertTrue(source.contains("data class Recent"))
        assertTrue(source.contains("recent.sortedByDescending{it.date}.take(12)"))
        listOf("attendanceDetail(a.id)", "workDetail(w.id)", "paymentDetail(p.id)", "expenseDetail(e.id)").forEach { assertTrue("Missing navigation: $it", source.contains(it)) }
    }

    @Test fun globalSearchHasActualDetailNavigation() {
        listOf("workerProfile(w.id)", "fieldProfile(f.id)", "cropProfile(c.id)", "attendanceDetail(a.id)", "workDetail(w.id)", "paymentDetail(x.id)", "expenseDetail(x.id)").forEach { assertTrue("Missing search navigation: $it", source.contains(it)) }
    }
}
