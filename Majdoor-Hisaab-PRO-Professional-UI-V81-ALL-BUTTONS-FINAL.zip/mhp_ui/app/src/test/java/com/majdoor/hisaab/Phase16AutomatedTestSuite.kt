package com.majdoor.hisaab

import android.content.Context
import com.majdoor.hisaab.calculation.LedgerCalculator
import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.report.ReportEngine
import com.majdoor.hisaab.report.ReportFilter
import com.majdoor.hisaab.security.SecurityManager
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Phase 16 — explicit automated acceptance coverage for points 393-421.
 * Each test name is intentionally mapped to the checklist number so CI failures
 * identify the exact contract that regressed.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class Phase16AutomatedTestSuite {
    private lateinit var store: LocalStore
    private lateinit var worker: Worker
    private lateinit var worker2: Worker
    private lateinit var field: Field
    private lateinit var crop: Crop

    @Before fun setUp() {
        val ctx = RuntimeEnvironment.getApplication() as Context
        val root = java.io.File(ctx.getExternalFilesDir(null), "majdoor_hisaab")
        root.deleteRecursively()
        store = LocalStore(ctx)
        worker = Worker(name = "Raju", mobile = "9000000001", defaultRate = 600.0)
        worker2 = Worker(name = "Mohan", mobile = "9000000002", defaultRate = 500.0)
        field = Field(name = "Field A", area = 5.0)
        store.upsertWorker(worker); store.upsertWorker(worker2); store.upsertField(field)
        crop = Crop(name = "Wheat", variety = "HD-2967", fieldId = field.id, plantingDate = "2026-09-01", area = 5.0)
        store.upsertCrop(crop)
    }

    // 393 Worker CRUD
    @Test fun p393_worker_crud() {
        assertEquals(2, store.workers().size)
        store.upsertWorker(worker.copy(name = "Raju Updated", defaultRate = 650.0))
        assertEquals("Raju Updated", store.workers().first { it.id == worker.id }.name)
        store.deleteWorker(worker2.id)
        assertTrue(store.workers().none { it.id == worker2.id })
    }

    // 394 Field CRUD
    @Test fun p394_field_crud() {
        store.upsertField(field.copy(name = "Field B", area = 4.0))
        assertEquals("Field B", store.fields().first().name)

        // Linked crop data must prevent destructive field deletion.
        expectIllegal { store.deleteField(field.id) }
        assertTrue(store.fields().any { it.id == field.id })

        // Remove the dependent crop, then verify clean field deletion.
        store.deleteCrop(crop.id)
        store.deleteField(field.id)
        assertTrue(store.fields().isEmpty())
    }

    // 395 Crop CRUD
    @Test fun p395_crop_crud() {
        store.upsertCrop(crop.copy(name = "Rice"))
        assertEquals("Rice", store.crops().first().name)
        store.deleteCrop(crop.id)
        assertTrue(store.crops().none { it.id == crop.id })
    }

    // 396 Attendance CRUD
    @Test fun p396_attendance_crud() {
        val a = Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=600.0)
        store.upsertAttendance(a)
        assertEquals("FULL", store.attendance().single().status)
        store.upsertAttendance(a.copy(status="HALF", rate=700.0))
        assertEquals(700.0, store.attendance().single().rate, 0.001)
        store.deleteAttendance(a.id)
        assertTrue(store.attendance().isEmpty())
    }

    // 397 Work CRUD
    @Test fun p397_work_crud() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Weeding", quantity=2.0, rateType=WorkRateEngine.QUANTITY, rate=100.0, workerIds=mutableListOf(worker.id))
        store.upsertWork(w); assertEquals(2.0, store.work().single().quantity, 0.001)
        store.upsertWork(w.copy(quantity=3.0)); assertEquals(3.0, store.work().single().quantity, 0.001)
        store.deleteWork(w.id); assertTrue(store.work().isEmpty())
    }

    // 398 Payment CRUD
    @Test fun p398_payment_crud() {
        val p = Payment(workerId=worker.id, date="2026-09-30", amount=500.0, method="UPI")
        store.upsertPayment(p); assertEquals(500.0, store.payments().single().amount, 0.001)
        store.upsertPayment(p.copy(amount=600.0)); assertEquals(600.0, store.payments().single().amount, 0.001)
        store.deletePayment(p.id); assertTrue(store.payments().isEmpty())
    }

    // 399 Expense CRUD
    @Test fun p399_expense_crud() {
        val e = Expense(date="2026-09-30", category="Diesel", amount=250.0, fieldId=field.id, cropId=crop.id)
        store.upsertExpense(e); assertEquals(250.0, store.expenses().single().amount, 0.001)
        store.upsertExpense(e.copy(amount=300.0)); assertEquals(300.0, store.expenses().single().amount, 0.001)
        store.deleteExpense(e.id); assertTrue(store.expenses().isEmpty())
    }

    // 400 Worker duplicate
    @Test fun p400_worker_duplicate_rejected() {
        expectIllegal { store.upsertWorker(Worker(name="Other", mobile=worker.mobile)) }
        expectIllegal { store.upsertWorker(Worker(name=worker.name, mobile="9000000099")) }
    }

    // 401 Attendance duplicate
    @Test fun p401_attendance_duplicate_rejected() {
        store.upsertAttendance(Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=600.0))
        expectIllegal { store.upsertAttendance(Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="HALF", rate=600.0)) }
    }

    // 402 Work duplicate
    @Test fun p402_work_duplicate_rejected() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Weeding", quantity=2.0, rateType=WorkRateEngine.QUANTITY, rate=100.0, workerIds=mutableListOf(worker.id))
        store.upsertWork(w)
        expectIllegal { store.upsertWork(w.copy(id="another-id")) }
    }

    // 403 Previous Team
    @Test fun p403_previous_team_copies_workers_only() {
        val team = Team(name="Morning", workerIds=mutableListOf(worker.id, worker2.id))
        store.upsertTeam(team)
        val persisted = store.teams().single { it.id == team.id }
        val copied = AttendanceRules.copyWorkersOnly(persisted, store.workers().map { it.id }.toSet())
        assertEquals(setOf(worker.id, worker2.id), copied)
        assertEquals("NONE", AttendanceRules.statusAfterWorkerSelection(null))
        assertTrue(store.attendance().isEmpty())
    }

    // 404 Worker selection
    @Test fun p404_worker_selection_does_not_auto_mark_attendance() {
        val before = store.attendance().size
        val selected = mutableSetOf<String>()
        selected.add(worker.id)
        val status = AttendanceRules.statusAfterWorkerSelection(null)
        assertEquals("NONE", status)
        assertEquals(before, store.attendance().size)
        assertTrue(selected.contains(worker.id))
        assertEquals("FULL", AttendanceRules.statusAfterWorkerSelection("FULL"))
    }

    // 405 Full/Half/None
    @Test fun p405_full_half_none_calculation() {
        val a = listOf(
            Attendance(date="2026-09-28", workerId=worker.id, status="FULL", rate=600.0),
            Attendance(date="2026-09-29", workerId=worker.id, status="HALF", rate=600.0),
            Attendance(date="2026-09-30", workerId=worker.id, status="NONE", rate=600.0)
        )
        assertEquals(900.0, LedgerCalculator.attendanceEarned(worker.id, a), 0.001)
    }

    // 406 Daily wage
    @Test fun p406_daily_wage() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Day", quantity=1.0, rateType=WorkRateEngine.DAILY, rate=600.0, workerIds=mutableListOf(worker.id))
        assertEquals(600.0, WorkRateEngine.cost(w), 0.001)
    }

    // 407 Half-day wage
    @Test fun p407_half_day_wage() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Half", quantity=1.0, rateType=WorkRateEngine.HALF_DAY, rate=600.0, workerIds=mutableListOf(worker.id))
        assertEquals(300.0, WorkRateEngine.cost(w), 0.001)
    }

    // 408 Hourly wage
    @Test fun p408_hourly_wage() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Hourly", quantity=0.0, rateType=WorkRateEngine.HOURLY, rate=200.0, startTime="09:00", endTime="12:30", workerIds=mutableListOf(worker.id))
        assertEquals(700.0, WorkRateEngine.cost(w), 0.001)
    }

    // 409 Acre rate
    @Test fun p409_acre_rate() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Spray", quantity=2.5, rateType=WorkRateEngine.AREA_ACRE, rate=800.0, workerIds=mutableListOf(worker.id))
        assertEquals(2000.0, WorkRateEngine.cost(w), 0.001)
    }

    // 410 Quantity rate
    @Test fun p410_quantity_rate() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Loading", quantity=12.0, rateType=WorkRateEngine.QUANTITY, rate=25.0, workerIds=mutableListOf(worker.id))
        assertEquals(300.0, WorkRateEngine.cost(w), 0.001)
    }

    // 411 Piece rate
    @Test fun p411_piece_rate() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Cutting", quantity=40.0, rateType=WorkRateEngine.PIECE, rate=8.0, workerIds=mutableListOf(worker.id))
        assertEquals(320.0, WorkRateEngine.cost(w), 0.001)
    }

    // 412 Multi-worker allocation
    @Test fun p412_multi_worker_allocation_splits_evenly() {
        val w = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Weeding", quantity=3.0, rateType=WorkRateEngine.AREA_ACRE, rate=900.0, workerIds=mutableListOf(worker.id, worker2.id))
        assertEquals(1350.0, WorkRateEngine.allocatedCost(w, worker.id), 0.001)
        assertEquals(2700.0, LedgerCalculator.workEarned(worker.id, listOf(w)) + LedgerCalculator.workEarned(worker2.id, listOf(w)), 0.001)
    }

    // 413 Partial payment
    @Test fun p413_partial_payment() {
        val s = LedgerCalculator.summary(worker.id, listOf(Attendance(date="2026-09-30", workerId=worker.id, status="FULL", rate=1000.0)), emptyList(), listOf(Payment(workerId=worker.id, date="2026-09-30", amount=400.0)))
        assertEquals(600.0, s.outstanding, 0.001)
    }

    // 414 Advance
    @Test fun p414_advance_is_tracked_separately() {
        val s = LedgerCalculator.summary(worker.id, listOf(Attendance(date="2026-09-30", workerId=worker.id, status="FULL", rate=1000.0)), emptyList(), listOf(Payment(workerId=worker.id, date="2026-09-30", amount=200.0, advance=true)))
        assertEquals(200.0, s.advance, 0.001); assertEquals(200.0, s.totalPaid, 0.001); assertEquals(800.0, s.outstanding, 0.001)
    }

    // 415 Overpayment
    @Test fun p415_overpayment_becomes_credit() {
        val s = LedgerCalculator.summary(worker.id, listOf(Attendance(date="2026-09-30", workerId=worker.id, status="FULL", rate=1000.0)), emptyList(), listOf(Payment(workerId=worker.id, date="2026-09-30", amount=1200.0)))
        assertEquals(0.0, s.outstanding, 0.001); assertEquals(200.0, s.credit, 0.001)
    }

    // 416 Outstanding
    @Test fun p416_outstanding_is_deterministic_and_never_negative() {
        val payments = listOf(Payment(workerId=worker.id, date="2026-09-30", amount=700.0), Payment(workerId=worker.id, date="2026-09-30", amount=500.0, advance=true))
        val s = LedgerCalculator.summary(worker.id, listOf(Attendance(date="2026-09-30", workerId=worker.id, status="FULL", rate=1000.0)), emptyList(), payments)
        assertEquals(1200.0, s.totalPaid, 0.001); assertEquals(0.0, s.outstanding, 0.001); assertEquals(200.0, s.credit, 0.001)
    }

    // 417 Expense calculation
    @Test fun p417_expense_calculation() {
        val expenses = listOf(Expense(date="2026-09-30", category="Diesel", amount=250.0), Expense(date="2026-09-30", category="Seed", amount=750.0), Expense(date="2026-09-30", category="Other", amount=-50.0))
        val report = ReportEngine.filter(ReportFilter(from="2026-09-30", to="2026-09-30"), emptyList(), emptyList(), emptyList(), expenses, emptyList(), emptyList())
        assertEquals(1000.0, report.expenseCost(), 0.001)
        assertEquals(1000.0, report.trackedCost(), 0.001)
        expectIllegal { store.upsertExpense(Expense(date="2026-09-30", category="Diesel", amount=-1.0)) }
    }

    // 418 Report calculation
    @Test fun p418_report_calculation() {
        val a = listOf(Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=500.0))
        val w = listOf(WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Weeding", quantity=2.0, rateType=WorkRateEngine.QUANTITY, rate=100.0, workerIds=mutableListOf(worker.id)))
        val e = listOf(Expense(date="2026-09-30", category="Diesel", amount=50.0, fieldId=field.id, cropId=crop.id))
        val r = listOf(Revenue(cropId=crop.id, date="2026-09-30", amount=1000.0))
        val d = ReportEngine.filter(ReportFilter(from="2026-09-30", to="2026-09-30"), a, w, emptyList(), e, r, emptyList(), mapOf(crop.id to field.id))
        assertEquals(500.0, d.attendanceCost(), 0.001); assertEquals(200.0, d.workCost(), 0.001); assertEquals(50.0, d.expenseCost(), 0.001); assertEquals(1000.0, d.revenueTotal(), 0.001); assertEquals(250.0, d.profitLoss(), 0.001)
    }

    // 419 Backup JSON validation
    @Test fun p419_backup_json_validation() {
        val backup = store.backupToInternal()
        val result = backup.inputStream().use { store.validateBackup(it) }
        assertTrue("Valid backup rejected: ${result.second}", result.first)

        val badZip = ByteArrayOutputStream()
        ZipOutputStream(badZip).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write("{bad json".toByteArray()); z.closeEntry()
        }
        val invalid = store.validateBackup(ByteArrayInputStream(badZip.toByteArray()))
        assertFalse(invalid.first)

        val missingEntityZip = ByteArrayOutputStream()
        ZipOutputStream(missingEntityZip).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write("{\"app\":\"Majdoor Hisaab PRO\",\"formatVersion\":2,\"schemaVersion\":4,\"files\":{}}".toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("data/workers.json")); z.write("[]".toByteArray()); z.closeEntry()
        }
        assertFalse(store.validateBackup(ByteArrayInputStream(missingEntityZip.toByteArray())).first)
    }

    // 420 Restore integrity
    @Test fun p420_restore_integrity_restores_complete_dataset() {
        val original = worker.copy(name="Original")
        val attendance = Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=600.0)
        val work = WorkRecord(date="2026-09-30", fieldId=field.id, cropId=crop.id, workType="Weeding", quantity=2.0, rateType=WorkRateEngine.QUANTITY, rate=100.0, workerIds=mutableListOf(worker.id))
        val payment = Payment(workerId=worker.id, date="2026-09-30", amount=100.0, method="Cash")
        val expense = Expense(date="2026-09-30", category="Diesel", amount=50.0, fieldId=field.id, cropId=crop.id)
        val production = Production(cropId=crop.id, date="2026-09-30", quantity=10.0, unit="quintal")
        val revenue = Revenue(cropId=crop.id, date="2026-09-30", amount=1200.0)
        val team = Team(name="Restore Team", workerIds=mutableListOf(worker.id, worker2.id))
        val document = WorkerDocument(workerId=worker.id, name="ID Proof", uri="content://restore/id-proof")
        val template = WorkTemplate(name="Restore Template", workType="Weeding", unit="acre", rate=900.0, rateType=WorkRateEngine.AREA_ACRE)
        store.upsertWorker(original); store.upsertTeam(team); store.upsertWorkerDocument(document); store.upsertWorkTemplate(template)
        store.upsertAttendance(attendance); store.upsertWork(work); store.upsertPayment(payment); store.upsertExpense(expense); store.upsertProduction(production); store.upsertRevenue(revenue)
        val backup = store.backupToInternal()
        val beforeHealth = store.health().filter { it.startsWith("ERROR:") }
        store.upsertWorker(Worker(name="Temporary", mobile="9000000099"))
        backup.inputStream().use { store.restore(it) }
        assertTrue(store.workers().any { it.id == original.id && it.name == "Original" })
        assertFalse(store.workers().any { it.name == "Temporary" })
        assertEquals(1, store.attendance().count { it.id == attendance.id })
        assertEquals(1, store.work().count { it.id == work.id })
        assertEquals(1, store.payments().count { it.id == payment.id })
        assertEquals(1, store.expenses().count { it.id == expense.id })
        assertEquals(1, store.production().count { it.id == production.id })
        assertEquals(1, store.revenue().count { it.id == revenue.id })
        assertEquals(1, store.teams().count { it.id == team.id && it.workerIds.toSet() == setOf(worker.id, worker2.id) })
        assertEquals(1, store.workerDocuments().count { it.id == document.id && it.workerId == worker.id })
        assertEquals(1, store.workTemplates().count { it.id == template.id })
        assertTrue(store.workerWageHistory().any { it.workerId == worker.id && it.rate == original.defaultRate })
        assertTrue(store.cropVarieties().any { it.cropId == crop.id && it.name.equals(crop.variety, true) })
        assertTrue(store.auditLog().isNotEmpty())
        assertTrue(store.health().filter { it.startsWith("ERROR:") }.isEmpty())
        assertEquals(beforeHealth, store.health().filter { it.startsWith("ERROR:") })
        assertNotNull(store.backupMetadata())

        // Invalid restore must leave the complete live dataset untouched (rollback/no destructive partial import).
        val bad = ByteArrayOutputStream()
        ZipOutputStream(bad).use { z ->
            z.putNextEntry(ZipEntry("manifest.json")); z.write("{bad json".toByteArray()); z.closeEntry()
        }
        val workerCount = store.workers().size
        try { bad.toByteArray().inputStream().use { store.restore(it) }; fail("Expected invalid restore to fail") } catch (_: Exception) { }
        assertEquals(workerCount, store.workers().size)
        assertTrue(store.work().any { it.id == work.id })
    }

    // 421 Security/PIN
    @Test fun p421_security_pin_set_verify_and_clear() {
        val ctx = RuntimeEnvironment.getApplication() as Context
        val prefs = ctx.getSharedPreferences("security", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        val security = SecurityManager(ctx)
        assertFalse(security.hasPin())
        security.setPin("4826")
        assertTrue(security.hasPin())
        assertNotEquals("4826", prefs.getString("pin", null))
        assertTrue(security.verifyPin("4826"))
        assertFalse(security.verifyPin("4827"))
        security.clearPin()
        assertFalse(security.hasPin())
    }

    private fun expectIllegal(block: () -> Unit) {
        try { block(); fail("Expected IllegalArgumentException") } catch (_: IllegalArgumentException) { }
    }
}
