package com.majdoor.hisaab

import com.majdoor.hisaab.model.Attendance
import com.majdoor.hisaab.model.Team
import org.junit.Assert.*
import org.junit.Test

class AttendanceModuleContractTest {
    @Test fun worker_selection_never_creates_full_day() {
        assertEquals("NONE", AttendanceRules.statusAfterWorkerSelection())
        assertEquals("NONE", AttendanceRules.statusAfterWorkerSelection("garbage"))
        assertEquals("HALF", AttendanceRules.statusAfterWorkerSelection("HALF"))
    }

    @Test fun previous_team_copies_workers_only_and_valid_workers() {
        val team=Team(name="Morning",workerIds=mutableListOf("w1","w2","missing"))
        assertEquals(setOf("w1","w2"), AttendanceRules.copyWorkersOnly(team,setOf("w1","w2")))
    }

    @Test fun previous_team_has_no_attendance_status_payload() {
        val team=Team(name="Morning",workerIds=mutableListOf("w1"))
        val copied=AttendanceRules.copyWorkersOnly(team,setOf("w1"))
        assertEquals(setOf("w1"),copied)
        assertEquals("NONE",AttendanceRules.UNMARKED)
    }

    @Test fun attendance_json_round_trip_preserves_date_field_status_and_worker() {
        val a=Attendance(date="2026-09-30",workerId="w1",fieldId="f1",status="HALF",rate=600.0)
        val b=Attendance.from(a.json())
        assertEquals(a.date,b.date); assertEquals(a.workerId,b.workerId); assertEquals(a.fieldId,b.fieldId); assertEquals("HALF",b.status)
    }
}
