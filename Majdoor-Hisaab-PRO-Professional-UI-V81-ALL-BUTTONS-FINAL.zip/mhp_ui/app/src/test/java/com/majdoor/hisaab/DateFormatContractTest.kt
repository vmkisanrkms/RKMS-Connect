package com.majdoor.hisaab

import org.junit.Assert.assertEquals
import org.junit.Test
import java.text.SimpleDateFormat
import java.util.Locale

/** Regression tests for the user-facing date format contract. Storage remains ISO yyyy-MM-dd. */
class DateFormatContractTest {
    private fun display(iso:String, pattern:String):String {
        val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(iso)!!
        return SimpleDateFormat(pattern,Locale.US).format(d)
    }
    private fun parse(display:String, pattern:String):String {
        val d=SimpleDateFormat(pattern,Locale.US).apply{isLenient=false}.parse(display)!!
        return SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d)
    }
    @Test fun dd_mm_yyyy_round_trip(){ assertEquals("30/09/2026",display("2026-09-30","dd/MM/yyyy")); assertEquals("2026-09-30",parse("30/09/2026","dd/MM/yyyy")) }
    @Test fun dd_mm_dash_round_trip(){ assertEquals("30-09-2026",display("2026-09-30","dd-MM-yyyy")); assertEquals("2026-09-30",parse("30-09-2026","dd-MM-yyyy")) }
    @Test fun iso_round_trip(){ assertEquals("2026-09-30",display("2026-09-30","yyyy-MM-dd")); assertEquals("2026-09-30",parse("2026-09-30","yyyy-MM-dd")) }
}
