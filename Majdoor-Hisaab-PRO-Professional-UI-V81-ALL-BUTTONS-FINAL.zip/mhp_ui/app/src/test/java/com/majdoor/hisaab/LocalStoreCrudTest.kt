package com.majdoor.hisaab

import android.content.Context
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.RuntimeEnvironment
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/**
 * Full repository CRUD regression tests against the real JSON LocalStore.
 * This deliberately exercises create -> read -> update -> delete for every
 * persisted entity and the critical Attendance.fieldId relationship.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class LocalStoreCrudTest {
    private lateinit var store: LocalStore
    private lateinit var worker: Worker
    private lateinit var field: Field
    private lateinit var crop: Crop

    @Before fun setUp() {
        val ctx = RuntimeEnvironment.getApplication() as Context
        ctx.getSharedPreferences("crud-test-clean", Context.MODE_PRIVATE).edit().clear().commit()
        store = LocalStore(ctx)
        // LocalStore is intentionally file-backed; isolate each test by removing its data files.
        val root = java.io.File(ctx.getExternalFilesDir(null), "majdoor_hisaab")
        root.deleteRecursively()
        store = LocalStore(ctx)
        worker = Worker(name = "Raju", mobile = "9000000001", defaultRate = 600.0)
        field = Field(name = "Field A", area = 5.0)
        store.upsertWorker(worker)
        store.upsertField(field)
        crop = Crop(name = "Wheat", variety = "HD-2967", fieldId = field.id, plantingDate = "2026-11-12", area = 5.0)
        store.upsertCrop(crop)
    }

    @Test fun worker_field_crop_crud() {
        assertEquals("Raju", store.workers().single().name)
        assertEquals("Field A", store.fields().single().name)
        assertEquals(field.id, store.crops().single().fieldId)

        val updatedWorker = worker.copy(name = "Raju Updated", defaultRate = 650.0)
        store.upsertWorker(updatedWorker)
        assertEquals("Raju Updated", store.workers().single { it.id == worker.id }.name)

        val updatedField = field.copy(name = "Field B", area = 6.0)
        store.upsertField(updatedField)
        assertEquals("Field B", store.fields().single { it.id == field.id }.name)

        val updatedCrop = crop.copy(variety = "HD-3086")
        store.upsertCrop(updatedCrop)
        assertEquals("HD-3086", store.crops().single { it.id == crop.id }.variety)

        store.deleteCrop(crop.id)
        store.deleteField(field.id)
        store.deleteWorker(worker.id)
        assertTrue(store.crops().none { it.id == crop.id })
        assertTrue(store.fields().none { it.id == field.id })
        assertTrue(store.workers().none { it.id == worker.id })
    }

    @Test fun worker_all_fields_persist_and_duplicate_rules_are_enforced() {
        val rich = worker.copy(
            address = "Baboura", workerType = "Skilled", defaultRate = 750.0, rateUnit = "HOUR",
            joiningDate = "2026-09-01", referenceId = "WK-001", notes = "Morning shift",
            photoUri = "content://photo/worker-1", active = false
        )
        store.upsertWorker(rich)
        val saved = store.workers().single { it.id == worker.id }
        assertEquals("Baboura", saved.address)
        assertEquals("Skilled", saved.workerType)
        assertEquals(750.0, saved.defaultRate, 0.001)
        assertEquals("HOUR", saved.rateUnit)
        assertEquals("2026-09-01", saved.joiningDate)
        assertEquals("WK-001", saved.referenceId)
        assertEquals("Morning shift", saved.notes)
        assertEquals("content://photo/worker-1", saved.photoUri)
        assertFalse(saved.active)

        try { store.upsertWorker(Worker(name = "Another", mobile = worker.mobile)) ; fail("Duplicate mobile must fail") }
        catch (_: IllegalArgumentException) { }
        try { store.upsertWorker(Worker(name = worker.name, mobile = "9000000002")) ; fail("Duplicate name must fail") }
        catch (_: IllegalArgumentException) { }
    }

    @Test fun deactivated_worker_remains_and_linked_delete_is_blocked() {
        store.upsertWorker(worker.copy(active = false))
        assertFalse(store.workers().single { it.id == worker.id }.active)
        store.upsertAttendance(Attendance(date = "2026-09-30", workerId = worker.id, fieldId = field.id, status = "FULL", rate = 600.0))
        try { store.deleteWorker(worker.id); fail("Linked worker deletion must be blocked") }
        catch (e: IllegalArgumentException) { assertTrue(e.message!!.contains("Deactivate")) }
        assertTrue(store.workers().any { it.id == worker.id })
    }

    @Test fun worker_photo_remove_and_multiworker_work_history_are_safe() {
        val photo = worker.copy(photoUri = "content://photo/one")
        store.upsertWorker(photo)
        store.upsertWorker(photo.copy(photoUri = ""))
        assertEquals("", store.workers().single { it.id == worker.id }.photoUri)

        val second = Worker(name = "Mohan", mobile = "9000000002", defaultRate = 500.0)
        store.upsertWorker(second)
        val work = WorkRecord(date = "2026-09-30", fieldId = field.id, cropId = crop.id,
            workType = "Weeding", quantity = 2.0, rateType = "QUANTITY", unit = "acre", rate = 1000.0,
            workerIds = mutableListOf(worker.id, second.id))
        store.upsertWork(work)
        assertEquals(2, store.work().single().workerIds.distinct().size)
    }

    @Test fun payment_persists_all_fields_and_duplicate_is_rejected() {
        val p = Payment(workerId=worker.id, date="2026-09-30", amount=750.0, method="UPI", advance=true, reference="UPI-123", notes="Advance for seed")
        store.upsertPayment(p)
        val saved = store.payments().single()
        assertEquals(worker.id, saved.workerId)
        assertEquals("2026-09-30", saved.date)
        assertEquals(750.0, saved.amount, 0.001)
        assertEquals("UPI", saved.method)
        assertTrue(saved.advance)
        assertEquals("UPI-123", saved.reference)
        assertEquals("Advance for seed", saved.notes)
        try {
            store.upsertPayment(p.copy(id="different-id"))
            fail("Exact duplicate payment must be rejected")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("Duplicate payment"))
        }
    }

    @Test fun attendance_crud_preserves_field_id() {
        val a = Attendance(date = "2026-09-30", workerId = worker.id, fieldId = field.id, status = "FULL", rate = 600.0)
        store.upsertAttendance(a)
        val saved = store.attendance().single()
        assertEquals(field.id, saved.fieldId)

        val edited = saved.copy(status = "HALF", fieldId = field.id, rate = 650.0)
        store.upsertAttendance(edited)
        val reread = store.attendance().single()
        assertEquals(field.id, reread.fieldId)
        assertEquals("HALF", reread.status)
        assertEquals(650.0, reread.rate, 0.001)

        store.deleteAttendance(reread.id)
        assertTrue(store.attendance().isEmpty())
    }

    @Test fun attendance_duplicate_rule_is_date_worker_and_field() {
        val a = Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=600.0)
        store.upsertAttendance(a)
        try {
            store.upsertAttendance(Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="HALF", rate=600.0))
            fail("Exact worker + date + field attendance duplicate must fail")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("Attendance already exists"))
        }
        store.upsertAttendance(Attendance(date="2026-09-30", workerId=worker.id, fieldId="", status="FULL", rate=600.0))
        assertEquals(2, store.attendance().size)
    }

    @Test fun team_work_payment_expense_production_revenue_crud() {
        val team = Team(name = "Morning", workerIds = mutableListOf(worker.id))
        store.upsertTeam(team)
        assertEquals(worker.id, store.teams().single().workerIds.single())
        store.upsertTeam(team.copy(name = "Morning Updated"))
        assertEquals("Morning Updated", store.teams().single().name)
        store.deleteTeam(team.id)
        assertTrue(store.teams().isEmpty())

        val work = WorkRecord(date = "2026-09-30", fieldId = field.id, cropId = crop.id,
            workType = "Weeding", quantity = 2.0, rateType = "QUANTITY", unit = "acre", rate = 300.0,
            workerIds = mutableListOf(worker.id))
        store.upsertWork(work)
        assertEquals(2.0, store.work().single().quantity, 0.001)
        store.upsertWork(work.copy(quantity = 3.0))
        assertEquals(3.0, store.work().single().quantity, 0.001)
        store.deleteWork(work.id)
        assertTrue(store.work().isEmpty())

        val payment = Payment(workerId = worker.id, date = "2026-09-30", amount = 500.0)
        store.upsertPayment(payment)
        assertEquals(500.0, store.payments().single().amount, 0.001)
        store.upsertPayment(payment.copy(amount = 550.0))
        assertEquals(550.0, store.payments().single().amount, 0.001)
        store.deletePayment(payment.id)
        assertTrue(store.payments().isEmpty())

        val expense = Expense(date = "2026-09-30", category = "Diesel", amount = 250.0, fieldId = field.id, cropId = crop.id)
        store.upsertExpense(expense)
        assertEquals(field.id, store.expenses().single().fieldId)
        store.upsertExpense(expense.copy(amount = 275.0))
        assertEquals(275.0, store.expenses().single().amount, 0.001)
        store.deleteExpense(expense.id)
        assertTrue(store.expenses().isEmpty())

        val production = Production(cropId = crop.id, date = "2026-09-30", quantity = 10.0, unit = "quintal")
        store.upsertProduction(production)
        assertEquals(10.0, store.production().single().quantity, 0.001)
        store.upsertProduction(production.copy(quantity = 12.0))
        assertEquals(12.0, store.production().single().quantity, 0.001)
        store.deleteProduction(production.id)
        assertTrue(store.production().isEmpty())

        val revenue = Revenue(cropId = crop.id, date = "2026-09-30", amount = 25000.0)
        store.upsertRevenue(revenue)
        assertEquals(25000.0, store.revenue().single().amount, 0.001)
        store.upsertRevenue(revenue.copy(amount = 27000.0))
        assertEquals(27000.0, store.revenue().single().amount, 0.001)
        store.deleteRevenue(revenue.id)
        assertTrue(store.revenue().isEmpty())
    }

    @Test fun worker_document_and_work_template_crud() {
        val doc = WorkerDocument(workerId = worker.id, name = "ID", uri = "content://worker/id")
        store.upsertWorkerDocument(doc)
        assertEquals("ID", store.workerDocuments().single().name)
        store.upsertWorkerDocument(doc.copy(name = "ID Card"))
        assertEquals("ID Card", store.workerDocuments().single().name)
        store.deleteWorkerDocument(doc.id)
        assertTrue(store.workerDocuments().isEmpty())

        val template = WorkTemplate(name = "Weeding", workType = "Weeding", unit = "acre", rate = 500.0, rateType = "AREA_ACRE")
        store.upsertWorkTemplate(template)
        assertEquals(500.0, store.workTemplates().single().rate, 0.001)
        store.upsertWorkTemplate(template.copy(rate = 550.0))
        assertEquals(550.0, store.workTemplates().single().rate, 0.001)
        store.deleteWorkTemplate(template.id)
        assertTrue(store.workTemplates().isEmpty())
    }

    @Test fun backup_round_trip_keeps_attendance_field_id() {
        val a = Attendance(date = "2026-09-30", workerId = worker.id, fieldId = field.id, status = "FULL", rate = 600.0)
        store.upsertAttendance(a)
        val out = ByteArrayOutputStream()
        store.exportBackup(out)
        assertTrue(store.validateBackup(ByteArrayInputStream(out.toByteArray())).first)

        store.deleteAttendance(a.id)
        assertTrue(store.attendance().isEmpty())
        store.restore(ByteArrayInputStream(out.toByteArray()))
        assertEquals(field.id, store.attendance().single().fieldId)
    }
}
