package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class BackupPhase12Test {
    private val source = File("src/main/java/com/majdoor/hisaab/storage/LocalStore.kt")
    private val mainText = UiSourceContract.text()
    private val manifest = File("src/main/AndroidManifest.xml")

    @Test fun backup_manifest_has_schema_and_metadata() {
        val s=source.readText(); assertTrue(s.contains("schemaVersion")); assertTrue(s.contains("createdAt")); assertTrue(s.contains("storage"))
    }
    @Test fun incoming_backup_has_relational_validation_before_restore_import() {
        val s=source.readText(); assertTrue(s.contains("validateRelationalFolder(incoming)")); assertTrue(s.contains("validateRelationalFolder(incomingDir)"))
    }
    @Test fun restore_has_fail_safe_snapshot_and_post_commit_relational_validation() {
        val s=source.readText(); val m=mainText
        assertTrue(s.contains("rollback_"))
        assertTrue(s.contains("Rollback snapshot verification failed"))
        assertTrue(s.contains("Existing data was not modified"))
        assertTrue(s.contains("validateRelationalFolder(data)"))
        assertTrue(s.contains("True rollback"))
        assertTrue(UiSourceContract.text().contains("Restore backup?"))
    }
    @Test fun import_has_fail_safe_snapshot_and_relational_validation() {
        val s=source.readText()
        assertTrue(s.contains("Import rollback snapshot verification failed"))
        assertTrue(s.contains("Import aborted safely"))
        assertTrue(s.contains("validateRelationalFolder(staged)"))
        assertTrue(s.contains("validateRelationalFolder(data)"))
    }
    @Test fun auto_backup_reboot_receiver_registered() {
        val s=manifest.readText(); assertTrue(s.contains("BootCompletedReceiver")); assertTrue(s.contains("BOOT_COMPLETED")); assertTrue(s.contains("MY_PACKAGE_REPLACED"))
    }
    @Test fun invalid_import_does_not_silently_overwrite() {
        val s=source.readText(); assertTrue(s.contains("conflicting ID")); assertTrue(s.contains("Existing data was not overwritten"))
    }
    @Test fun data_health_checks_all_required_relationships() {
        val s=source.readText(); listOf("attendance", "work", "payments", "expenses", "production", "revenue", "worker_documents").forEach{assertTrue(s.contains("$it"))}; assertTrue(s.contains("Relationships checked"))
    }
}
