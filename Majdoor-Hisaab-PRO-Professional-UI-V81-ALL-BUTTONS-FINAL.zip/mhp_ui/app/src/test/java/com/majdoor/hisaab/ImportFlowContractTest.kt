package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test

class ImportFlowContractTest {
    @Test fun import_flow_contract_exists() {
        val source = java.io.File("src/main/java/com/majdoor/hisaab/storage/LocalStore.kt").readText()
        assertTrue(source.contains("fun importBackupMerge"))
        assertTrue(source.contains("Existing data was not overwritten"))
        assertTrue(source.contains("conflicting ID"))
    }
}
