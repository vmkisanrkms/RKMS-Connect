package com.majdoor.hisaab

import com.majdoor.hisaab.calculation.WorkRateEngine
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35])
class CropModuleContractTest {
    private fun store(): LocalStore {
        val ctx=RuntimeEnvironment.getApplication(); File(ctx.getExternalFilesDir(null),"majdoor_hisaab").deleteRecursively(); return LocalStore(ctx)
    }

    @Test fun crop_record_persists_all_required_fields_and_custom_name() {
        val s=store(); val f=Field(name="Field A",area=5.0); s.upsertField(f)
        val c=Crop(name="My Custom Crop",variety="Local Variety",fieldId=f.id,plantingDate="2026-10-01",area=4.5,notes="Test notes")
        s.upsertCrop(c); val x=s.crops().single()
        assertEquals(c.id,x.id); assertEquals("My Custom Crop",x.name); assertEquals("Local Variety",x.variety); assertEquals(f.id,x.fieldId); assertEquals("2026-10-01",x.plantingDate); assertEquals(4.5,x.area,0.001); assertEquals("Test notes",x.notes)
    }

    @Test fun same_field_crop_can_repeat_in_later_season_but_exact_same_date_is_rejected() {
        val s=store(); val f=Field(name="Season Field",area=5.0); s.upsertField(f)
        s.upsertCrop(Crop(name="Wheat",variety="HD",fieldId=f.id,plantingDate="2026-11-12",area=5.0))
        s.upsertCrop(Crop(name="Wheat",variety="HD",fieldId=f.id,plantingDate="2027-11-12",area=5.0))
        assertEquals(2,s.crops().size)
        assertThrows(IllegalArgumentException::class.java){s.upsertCrop(Crop(name="Wheat",variety="HD",fieldId=f.id,plantingDate="2027-11-12",area=5.0))}
    }

    @Test fun crop_field_relation_and_area_are_validated() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f)
        assertThrows(IllegalArgumentException::class.java){s.upsertCrop(Crop(name="Wheat",fieldId="missing",area=1.0))}
        assertThrows(IllegalArgumentException::class.java){s.upsertCrop(Crop(name="Wheat",fieldId=f.id,area=6.0))}
        s.upsertCrop(Crop(name="Wheat",fieldId=f.id,area=5.0)); assertEquals(f.id,s.crops().single().fieldId)
    }

    @Test fun crop_cost_categories_production_revenue_and_profit_are_deterministic() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f); val c=Crop(name="Wheat",fieldId=f.id,area=5.0); s.upsertCrop(c)
        val w=Worker(name="Worker",mobile="9999999999"); s.upsertWorker(w)
        s.upsertWork(WorkRecord(date="2026-11-12",fieldId=f.id,cropId=c.id,workType="Sowing",quantity=1.0,unit="acre",rate=1000.0,rateType=WorkRateEngine.AREA_ACRE,workerIds=mutableListOf(w.id)))
        listOf("Fertilizer" to 500.0,"Seed" to 700.0,"Pesticide" to 300.0,"Irrigation" to 200.0,"Machinery" to 400.0,"Transport" to 150.0,"Other" to 50.0).forEach{(cat,amt)->s.upsertExpense(Expense(category=cat,amount=amt,date="2026-11-12",fieldId=f.id,cropId=c.id))}
        s.upsertProduction(Production(cropId=c.id,date="2027-03-01",quantity=20.0,unit="quintal")); s.upsertRevenue(Revenue(cropId=c.id,date="2027-04-01",amount=30000.0))
        val labour=s.work().filter{it.cropId==c.id}.sumOf{WorkRateEngine.cost(it)}; val other=s.expenses().filter{it.cropId==c.id}.sumOf{it.amount}; val revenue=s.revenue().filter{it.cropId==c.id}.sumOf{it.amount}
        assertEquals(1000.0,labour,0.001); assertEquals(2300.0,other,0.001); assertEquals(30000.0,revenue,0.001); assertEquals(26700.0,revenue-labour-other,0.001); assertEquals(20.0,s.production().single().quantity,0.001)
    }

    @Test fun production_and_revenue_reject_invalid_values_and_keep_crop_link() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f); val c=Crop(name="Wheat",fieldId=f.id,area=5.0); s.upsertCrop(c)
        assertThrows(IllegalArgumentException::class.java){s.upsertProduction(Production(cropId=c.id,date="2027-01-01",quantity=0.0,unit="kg"))}
        assertThrows(IllegalArgumentException::class.java){s.upsertRevenue(Revenue(cropId=c.id,date="2027-01-01",amount=0.0))}
        assertThrows(IllegalArgumentException::class.java){s.upsertProduction(Production(cropId="missing",date="2027-01-01",quantity=1.0,unit="kg"))}
        assertThrows(IllegalArgumentException::class.java){s.upsertRevenue(Revenue(cropId="missing",date="2027-01-01",amount=1.0))}
    }
    @Test fun crop_requires_positive_area_and_planting_date() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f)
        assertThrows(IllegalArgumentException::class.java){s.upsertCrop(Crop(name="Wheat",fieldId=f.id,plantingDate="2026-11-12",area=0.0))}
        assertThrows(IllegalArgumentException::class.java){s.upsertCrop(Crop(name="Wheat",fieldId=f.id,plantingDate="",area=1.0))}
    }

    @Test fun crop_cost_categories_each_persist_and_sum() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f); val c=Crop(name="Rice",fieldId=f.id,plantingDate="2026-06-01",area=5.0); s.upsertCrop(c)
        val cats=listOf("Fertilizer","Seed","Pesticide","Irrigation","Machinery","Transport","Other")
        cats.forEachIndexed{i,cat->s.upsertExpense(Expense(category=cat,amount=(i+1).toDouble(),date="2026-06-02",fieldId=f.id,cropId=c.id))}
        assertEquals(28.0,s.expenses().filter{it.cropId==c.id}.sumOf{it.amount},0.001)
        assertEquals(cats.toSet(),s.expenses().filter{it.cropId==c.id}.map{it.category}.toSet())
    }

    @Test fun production_and_revenue_round_trip_edit_keep_crop_link() {
        val s=store(); val f=Field(name="Field",area=5.0); s.upsertField(f); val c=Crop(name="Wheat",fieldId=f.id,plantingDate="2026-11-12",area=5.0); s.upsertCrop(c)
        val p=Production(cropId=c.id,date="2027-03-01",quantity=20.0,unit="quintal",note="harvest"); s.upsertProduction(p); p.quantity=25.0; s.upsertProduction(p)
        val r=Revenue(cropId=c.id,date="2027-04-01",amount=30000.0,note="sale"); s.upsertRevenue(r); r.amount=32000.0; s.upsertRevenue(r)
        assertEquals(25.0,s.production().single().quantity,0.001); assertEquals(c.id,s.production().single().cropId); assertEquals(32000.0,s.revenue().single().amount,0.001); assertEquals(c.id,s.revenue().single().cropId)
    }

}
