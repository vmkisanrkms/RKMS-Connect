package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.ByteArrayInputStream
import java.io.File

class Phase20SecurityDataAuditTest {
 private lateinit var ctx:Context; private lateinit var store:LocalStore
 @Before fun setup(){ctx=ApplicationProvider.getApplicationContext(); File(ctx.getExternalFilesDir(null),"majdoor_hisaab").deleteRecursively(); store=LocalStore(ctx)}
 @Test fun p482_no_hardcoded_pin_and_pin_is_hashed(){ val sec=File("app/src/main/java/com/majdoor/hisaab/security/SecurityManager.kt").readText(); assertFalse(Regex("pin\\s*[:=]\\s*\\"\\d{4,}\\"",RegexOption.IGNORE_CASE).containsMatchIn(sec)); val p=ctx.getSharedPreferences("security",0); p.edit().clear().apply(); com.majdoor.hisaab.security.SecurityManager(ctx).setPin("4826"); assertNotEquals("4826",p.getString("pin",null)) }
 @Test fun p483_no_sensitive_data_plain_logs(){ val src=File("app/src/main/java").walkTopDown().filter{it.isFile&&it.extension=="kt"}.joinToString("\n"){it.readText()}; assertFalse(src.contains("android.util.Log.")); assertFalse(src.contains("println(")); assertFalse(src.contains("printStackTrace(")) }
 @Test fun p484_release_has_no_debug_logging(){ val src=File("app/src/main/java").walkTopDown().filter{it.isFile&&it.extension=="kt"}.joinToString("\n"){it.readText()}; assertFalse(src.contains("android.util.Log.")); assertFalse(src.contains("println(")) }
 @Test fun p485_backup_complete(){ val out=ByteArrayOutputStream(); store.exportBackup(out); val names=mutableSetOf<String>(); java.util.zip.ZipInputStream(ByteArrayInputStream(out.toByteArray())).use{z->var e=z.nextEntry; while(e!=null){if(e.name.startsWith("data/")) names.add(e.name.removePrefix("data/")); e=z.nextEntry}}; listOf("workers.json","worker_documents.json","worker_wage_history.json","work_templates.json","fields.json","crops.json","crop_varieties.json","attendance.json","teams.json","work.json","payments.json","expenses.json","production.json","revenue.json","backup_metadata.json").forEach{assertTrue(names.contains(it))} }
 @Test fun p486_backup_excludes_security_preferences(){ val out=ByteArrayOutputStream(); store.exportBackup(out); val names=mutableSetOf<String>(); java.util.zip.ZipInputStream(ByteArrayInputStream(out.toByteArray())).use{z->var e=z.nextEntry; while(e!=null){names.add(e.name); e=z.nextEntry}}; assertFalse(names.any{it.contains("security",true)}) }
 @Test fun p487_malformed_restore_is_rejected_without_corruption(){store.upsertWorker(Worker("w","Safe","9000000001")); assertThrows(Exception::class.java){store.restore("{bad".byteInputStream())}; assertEquals("Safe",store.workers().single().name)}
 @Test fun p488_multi_file_worker_mutation_is_atomic(){store.upsertWorker(Worker("w","Atomic","9000000002",defaultRate=500.0)); assertTrue(store.workers().any{it.id=="w"}); assertTrue(store.workerWageHistory().any{it.workerId=="w"})}
 @Test fun p489_failed_mutation_leaves_no_partial_record(){val n=store.workers().size; assertThrows(Exception::class.java){store.upsertWorker(Worker("bad","","bad"))}; assertEquals(n,store.workers().size)}
 @Test fun p490_delete_is_controlled(){val w=Worker("w","Linked","9000000003"); store.upsertWorker(w); store.upsertAttendance(Attendance(date="2026-09-30",workerId="w",status="FULL",rate=500.0)); assertThrows(Exception::class.java){store.deleteWorker("w")}; assertTrue(store.workers().any{it.id=="w"})}
 @Test fun p491_import_conflict_never_overwrites(){val w=Worker("w","Original","9000000004");store.upsertWorker(w);val o=ByteArrayOutputStream();store.exportBackup(o);store.upsertWorker(w.copy(name="Changed"));assertThrows(Exception::class.java){store.importBackupMerge(ByteArrayInputStream(o.toByteArray()))};assertEquals("Changed",store.workers().single().name)}
 @Test fun p492_duplicate_expense_rejected(){val e=Expense(date="2026-09-30",category="Other",amount=100.0,notes="same");store.upsertExpense(e);assertThrows(Exception::class.java){store.upsertExpense(e.copy(id="different"))};assertEquals(1,store.expenses().size)}
 @Test fun p493_audit_log_records_modification(){store.upsertWorker(Worker("w","Trace","9000000005"));assertTrue(store.auditLog().any{it.optString("entity")=="worker"&&it.optString("action")=="CREATE"})}
 @Test fun p494_worker_traceable(){store.upsertWorker(Worker("w","Trace","9000000006"));store.upsertWorker(Worker("w","Trace2","9000000006"));assertTrue(store.auditLog().count{it.optString("entity")=="worker"}>=2)}
 @Test fun p495_payment_traceable(){store.upsertWorker(Worker("w","Pay","9000000007"));store.upsertPayment(Payment(workerId="w",date="2026-09-30",amount=100.0,method="Cash"));assertTrue(store.auditLog().any{it.optString("entity")=="payment"})}
 @Test fun p496_attendance_traceable(){store.upsertWorker(Worker("w","Att","9000000008"));store.upsertAttendance(Attendance(date="2026-09-30",workerId="w",status="FULL",rate=500.0));assertTrue(store.auditLog().any{it.optString("entity")=="attendance"})}
 @Test fun p497_work_traceable(){store.upsertWorker(Worker("w","Work","9000000009"));store.upsertField(Field("f","F",1.0));store.upsertCrop(Crop("c","C","V1","f"));store.upsertWork(WorkRecord(date="2026-09-30",workType="Weeding",workerIds=listOf("w"),fieldId="f",cropId="c",quantity=1.0,rate=100.0,rateType="ACRE",unit="acre"));assertTrue(store.auditLog().any{it.optString("entity")=="work"})}
 @Test fun p498_backup_restore_traceable(){store.upsertWorker(Worker("w","B","9000000010"));val o=ByteArrayOutputStream();store.exportBackup(o);assertTrue(store.auditLog().any{it.optString("entity")=="backup"&&it.optString("action")=="EXPORT"});store.restore(ByteArrayInputStream(o.toByteArray()));assertTrue(store.auditLog().any{it.optString("action")=="RESTORE"})}
}
