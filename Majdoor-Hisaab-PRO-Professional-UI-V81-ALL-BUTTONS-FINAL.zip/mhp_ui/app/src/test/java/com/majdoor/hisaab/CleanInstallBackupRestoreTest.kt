package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.majdoor.hisaab.model.Crop
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.model.Attendance
import com.majdoor.hisaab.model.Payment
import com.majdoor.hisaab.model.Expense
import com.majdoor.hisaab.model.Production
import com.majdoor.hisaab.model.Revenue
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Clean-install acceptance test: export a real backup from populated local JSON,
 * wipe the app's local data directory to simulate a fresh install, restore the
 * exported backup, and verify the records are available again.
 */
class CleanInstallBackupRestoreTest {
    private lateinit var context: Context
    private lateinit var root: File

    @Before
    fun cleanBefore() {
        context = ApplicationProvider.getApplicationContext()
        root = File(context.getExternalFilesDir(null), "majdoor_hisaab")
        root.deleteRecursively()
    }

    @Test
    fun exportedBackupRestoresIntoCleanInstall() {
        val source = LocalStore(context)
        val worker = Worker(id = "worker-clean-1", name = "Clean Install Worker", mobile = "9999999999")
        val field = Field(id = "field-clean-1", name = "Clean Install Field", area = 2.0)
        val crop = Crop(id = "crop-clean-1", name = "Wheat", variety = "HD-2967", fieldId = field.id, plantingDate = "2026-11-12", area = 2.0)
        source.upsertWorker(worker)
        source.upsertField(field)
        source.upsertCrop(crop)
        source.upsertAttendance(Attendance(date="2026-09-30", workerId=worker.id, fieldId=field.id, status="FULL", rate=600.0))
        source.upsertPayment(Payment(workerId=worker.id, date="2026-09-30", amount=500.0, method="UPI", advance=false))
        source.upsertExpense(Expense(date="2026-09-30", category="Diesel", amount=250.0, fieldId=field.id, cropId=crop.id))
        source.upsertProduction(Production(cropId=crop.id, date="2026-09-30", quantity=10.0, unit="quintal"))
        source.upsertRevenue(Revenue(cropId=crop.id, date="2026-09-30", amount=25000.0))

        val expectedCounts = listOf(source.workers().size, source.fields().size, source.crops().size, source.attendance().size, source.payments().size, source.expenses().size, source.production().size, source.revenue().size)
        val expectedPaymentTotal = source.payments().sumOf { it.amount }
        val expectedExpenseTotal = source.expenses().sumOf { it.amount }
        val expectedRevenueTotal = source.revenue().sumOf { it.amount }
        val bytes = ByteArrayOutputStream().also { source.exportBackup(it) }.toByteArray()
        assertTrue("Backup must contain data", bytes.isNotEmpty())

        // Simulate uninstall/clean install local state.
        root.deleteRecursively()
        val clean = LocalStore(context)
        assertTrue(clean.workers().isEmpty())
        assertTrue(clean.fields().isEmpty())
        assertTrue(clean.crops().isEmpty())

        clean.restore(ByteArrayInputStream(bytes))

        assertEquals(1, clean.workers().count { it.id == worker.id && it.name == worker.name })
        assertEquals(1, clean.fields().count { it.id == field.id && it.name == field.name })
        assertEquals(1, clean.crops().count { it.id == crop.id && it.fieldId == field.id })
        val restoredCounts = listOf(clean.workers().size, clean.fields().size, clean.crops().size, clean.attendance().size, clean.payments().size, clean.expenses().size, clean.production().size, clean.revenue().size)
        assertEquals(expectedCounts, restoredCounts)
        assertEquals(expectedPaymentTotal, clean.payments().sumOf { it.amount }, 0.001)
        assertEquals(expectedExpenseTotal, clean.expenses().sumOf { it.amount }, 0.001)
        assertEquals(expectedRevenueTotal, clean.revenue().sumOf { it.amount }, 0.001)
        assertTrue(clean.health().none { it.startsWith("ERROR:") })
    }
}
