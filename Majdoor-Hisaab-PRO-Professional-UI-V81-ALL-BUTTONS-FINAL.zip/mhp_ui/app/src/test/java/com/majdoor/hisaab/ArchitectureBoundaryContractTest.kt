package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ArchitectureBoundaryContractTest {
    @Test fun ui_uses_app_services_boundary_not_storage_implementation() {
        val root = File("src/main/java/com/majdoor/hisaab")
        val main = File(root, "MainActivity.kt").readText()
        assertTrue("MainActivity must use AppServices", main.contains("internal lateinit var app:AppServices"))
        assertTrue("MainActivity must not import LocalStore", !main.contains("import com.majdoor.hisaab.storage.LocalStore"))
        assertTrue("MainActivity must not import repository", !main.contains("import com.majdoor.hisaab.data.repository.LocalRepository"))
        assertTrue("Repository boundary must exist", File(root, "data/repository/LocalRepository.kt").isFile)
        val services = File(root, "feature/AppServices.kt").readText()
        assertTrue("AppServices must expose AuditUseCase", services.contains("val audit = AuditUseCase(repository)"))
        assertTrue("AppServices must expose accounting module", services.contains("accountingModule"))
        assertTrue("AppServices must expose teams module", services.contains("teamsModule"))
        assertTrue("AppServices must not expose repository as audit", !services.contains("val audit = repository"))
        assertTrue("MainActivity must be a coordinator, not a 1000+ line screen monolith", main.lines().size <= 260)
        assertTrue("MainActivity screen layer must be extracted", File(root, "MainActivityScreens.kt").isFile)
        val screens = File(root, "MainActivityScreens.kt").readText()
        assertTrue("Extracted screen layer must contain real MainActivity extensions", screens.contains("fun MainActivity.dashboard"))
    }

    @Test fun repository_must_delegate_through_dao_boundary() {
        val root = File("src/main/java/com/majdoor/hisaab")
        val repo = File(root, "data/repository/LocalRepository.kt").readText()
        assertTrue(repo.contains("WorkerDao"))
        assertTrue(repo.contains("StorageDao"))
        assertTrue(!repo.contains("LocalStore("))
        assertTrue(!repo.contains("db.store"))
    }

    @Test fun feature_modules_must_be_real_boundaries() {
        val root = File("src/main/java/com/majdoor/hisaab/feature")
        val expected = listOf("dashboard","workers","fields","crops","attendance","work","payments","expenses","reports","backup","settings","security","export")
        expected.forEach { feature ->
            val text = File(root, "$feature/Module.kt").readText()
            assertTrue("$feature module must own a use case", text.contains("useCase:"))
            assertTrue("$feature module must not depend on LocalStore", !text.contains("LocalStore"))
        }
    }
}
