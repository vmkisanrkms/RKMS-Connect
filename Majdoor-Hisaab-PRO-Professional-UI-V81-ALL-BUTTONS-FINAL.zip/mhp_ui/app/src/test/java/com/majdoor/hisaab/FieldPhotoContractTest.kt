package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class FieldPhotoContractTest {
    @Test fun field_photo_flow_has_persistable_picker_and_clears_pending_on_remove() {
        val source = UiSourceContract.text()
        assertTrue(source.contains("Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION"))
        assertTrue(source.contains("pendingFieldPhoto=\"\"; store.upsertField(old!!.copy(photoUri=\"\"))"))
        assertTrue(source.contains("internal fun applySelectedFieldPhoto"))
        assertTrue(source.contains("else if(req==2201){ applySelectedFieldPhoto(uri, data); return }"))
    }
}
