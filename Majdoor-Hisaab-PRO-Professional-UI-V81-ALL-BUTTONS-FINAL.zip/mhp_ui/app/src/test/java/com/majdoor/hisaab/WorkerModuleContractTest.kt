package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class WorkerModuleContractTest {
    private val root = File("src/main/java/com/majdoor/hisaab")
    private val main = UiSourceContract.text()
    private val store = File(root, "storage/LocalStore.kt").readText()
    private val model = File(root, "model/Models.kt").readText()

    @Test fun worker_fields_and_reference_id_are_persisted() {
        listOf("name", "mobile", "address", "workerType", "defaultRate", "rateUnit", "joiningDate", "referenceId", "notes", "photoUri", "active")
            .forEach { assertTrue("Missing Worker field: $it", model.contains("$it")) }
        assertTrue(model.contains("put(\"referenceId\", referenceId)"))
        assertTrue(model.contains("optString(\"referenceId\")"))
    }

    @Test fun worker_form_validates_and_preserves_active_state() {
        assertTrue(main.contains("Mobile number must be exactly 10 digits"))
        assertTrue(main.contains("cleanUnit !in setOf(\"DAY\",\"HALF_DAY\",\"HOUR\",\"ACRE\",\"QUANTITY\",\"PIECE\")"))
        assertTrue(main.contains("old?.active ?: true"))
        assertTrue(main.contains("reference.text.toString().trim()"))
    }

    @Test fun worker_store_protects_duplicates_and_linked_history() {
        assertTrue(store.contains("A worker with this mobile number already exists."))
        assertTrue(store.contains("A worker with this name already exists."))
        assertTrue(store.contains("Deactivate the worker instead of deleting."))
    }

    @Test fun worker_navigation_covers_required_details() {
        listOf("workerProfile", "workerAttendance", "workerWork", "workerLedger", "workerPayments", "workerAdvances", "workerDocuments").forEach {
            assertTrue("Missing worker navigation: $it", main.contains("$it("))
        }
        listOf("Address:", "Worker Type:", "Default Wage:", "Joining Date:", "Reference / ID:", "Status:", "Notes:").forEach { assertTrue("Missing worker profile field: $it", main.contains(it)) }
        assertTrue(main.contains("Remove Worker Photo"))
        assertTrue(main.contains("ACTION_OPEN_DOCUMENT"))
        assertTrue(main.contains("FLAG_GRANT_PERSISTABLE_URI_PERMISSION"))
        assertTrue(main.contains("FLAG_GRANT_READ_URI_PERMISSION"))
        assertTrue(main.contains("persistUriPermission(uri, data)"))
        assertTrue(main.contains("Deactivate"))
    }

    @Test fun worker_list_has_search_filters_and_sorting() {
        listOf("Apply Search", "Active Workers Only", "Inactive Workers Only", "Wage > 0", "Wage = 0", "Outstanding > 0", "Outstanding = 0", "Sort by Name A-Z", "Sort by Name Z-A", "Sort by Wage High-Low", "Sort by Wage Low-High", "Search name/mobile/type/reference/address", "WorkerQuery")
            .forEach { assertTrue("Missing worker list action: $it", main.contains(it)) }
    }
}
