package com.majdoor.hisaab

import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class Phase13SettingsContractTest {
 private val root=File(System.getProperty("user.dir") ?: ".")
 private val main=UiSourceContract.text()
 private val store=File(root,"src/main/java/com/majdoor/hisaab/storage/LocalStore.kt")
 private val notifications=File(root,"src/main/java/com/majdoor/hisaab/notification/NotificationSettings.kt")
 @Test fun settings_persist_and_apply(){ val s=main; listOf("farm_name","default_wage","currency","date_format","theme","auto_lock_timeout","auto_backup").forEach{assertTrue(s.contains(it))}; assertTrue(s.contains("UI_MODE_NIGHT_MASK")); assertTrue(s.contains("setTheme(if(dark)")); assertTrue(s.contains("recreate()")) }
 @Test fun subsystems_have_real_actions(){ val s=main; listOf("security.setPin","AutoLockManager.shouldLock","autoLockChecker","scheduleAutoBackup","NotificationSettings.setMaster","reportSettingsDialog","backupSettingsDialog").forEach{assertTrue(s.contains(it))} }
 @Test fun date_currency_theme_are_centralized(){ val s=main; assertTrue(s.contains("selectedDatePattern")); assertTrue(s.contains("private fun money")); assertTrue(s.contains("savedThemeMode")); }
 @Test fun about_is_dynamic_and_licensed(){ val s=main; assertTrue(s.contains("BuildConfig.VERSION_NAME")); assertTrue(s.contains("BuildConfig.VERSION_CODE")); assertTrue(s.contains("License:")); assertTrue(File(root,"LICENSE").exists()) }
 @Test fun backup_metadata_is_complete_and_verified(){ val s=store.readText(); assertTrue(s.contains("fileCount")); assertTrue(s.contains("sha256")); assertTrue(s.contains("validateManifestFiles")); assertTrue(s.contains("schemaVersion")) }
 @Test fun notifications_are_rescheduled_on_setting_changes_and_reboot(){ val s=notifications.readText(); assertTrue(s.contains("reschedule(context)")); assertTrue(s.contains("setInexactRepeating")) }
}
