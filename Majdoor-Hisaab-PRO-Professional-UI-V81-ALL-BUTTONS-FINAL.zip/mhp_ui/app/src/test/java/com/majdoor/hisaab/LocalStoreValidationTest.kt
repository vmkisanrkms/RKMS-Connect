package com.majdoor.hisaab

import android.content.Context
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.assertThrows
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RuntimeEnvironment
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class LocalStoreValidationTest {
    private lateinit var store: LocalStore
    private lateinit var worker: Worker
    private lateinit var field: Field
    private lateinit var crop: Crop

    @Before fun setup() {
        val ctx = RuntimeEnvironment.getApplication() as Context
        java.io.File(ctx.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
        store = LocalStore(ctx)
        worker = Worker(name = "Validation Worker", defaultRate = 500.0)
        field = Field(name = "Validation Field", area = 1.0)
        crop = Crop(name = "Wheat", fieldId = field.id)
        store.upsertWorker(worker); store.upsertField(field); store.upsertCrop(crop)
    }

    @Test fun invalid_dates_and_numbers_are_rejected() {
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertAttendance(Attendance(date = "30/09/2026", workerId = worker.id))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertPayment(Payment(workerId = worker.id, date = "2026-02-30", amount = 10.0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date = "2026-09-30", category = "Unknown", amount = 10.0))
        }
    }

    @Test fun non_finite_money_and_area_are_rejected() {
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertWorker(worker.copy(defaultRate = Double.NaN))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertField(field.copy(area = Double.POSITIVE_INFINITY))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertRevenue(Revenue(cropId = crop.id, date = "2026-09-30", amount = Double.NaN))
        }
    }
    @Test fun worker_mobile_and_duplicate_rules_are_enforced() {
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertWorker(worker.copy(id = "bad-mobile", mobile = "123"))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertWorker(worker.copy(id = "duplicate-name", mobile = "9111111111"))
        }
        store.upsertWorker(worker.copy(id = "worker-two", name = "Another Worker", mobile = "9111111111"))
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertWorker(worker.copy(id = "worker-three", name = "Third Worker", mobile = "9111111111"))
        }
    }

    @Test fun worker_reference_id_and_active_state_persist() {
        val x = worker.copy(referenceId = "REF-123", active = false)
        store.upsertWorker(x)
        val saved = store.workers().single { it.id == x.id }
        org.junit.Assert.assertEquals("REF-123", saved.referenceId)
        org.junit.Assert.assertFalse(saved.active)
    }

    @Test fun expense_amount_and_field_crop_validation_are_enforced() {
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date = "2026-09-30", category = "Labour", amount = 0.0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date = "2026-09-30", category = "Labour", amount = -10.0))
        }
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date = "2026-09-30", category = "Labour", amount = 10.0, fieldId = "missing"))
        }
        val otherField = Field(name = "Other Field", area = 1.0)
        store.upsertField(otherField)
        assertThrows(IllegalArgumentException::class.java) {
            store.upsertExpense(Expense(date = "2026-09-30", category = "Labour", amount = 10.0, fieldId = otherField.id, cropId = crop.id))
        }
    }

}
