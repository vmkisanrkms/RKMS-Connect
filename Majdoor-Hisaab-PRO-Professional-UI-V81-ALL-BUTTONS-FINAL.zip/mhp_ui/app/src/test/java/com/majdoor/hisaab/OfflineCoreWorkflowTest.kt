package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.majdoor.hisaab.model.Attendance
import com.majdoor.hisaab.model.Crop
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Offline acceptance test: the core workflow must complete using only local JSON storage.
 * No network request, backend, or connectivity state is required for these operations.
 */
class OfflineCoreWorkflowTest {
    private lateinit var context: Context
    private lateinit var root: File

    @Before
    fun cleanBefore() {
        context = ApplicationProvider.getApplicationContext()
        root = File(context.getExternalFilesDir(null), "majdoor_hisaab")
        root.deleteRecursively()
    }

    @Test
    fun coreCrudReportAndBackupWorkWithoutNetwork() {
        val store = LocalStore(context)
        val worker = Worker(id = "offline-worker", name = "Offline Worker", mobile = "9999999999")
        val field = Field(id = "offline-field", name = "Offline Field", area = 2.0)
        val crop = Crop(id = "offline-crop", fieldId = field.id, name = "Sugarcane", variety = "CO")

        store.upsertWorker(worker)
        store.upsertField(field)
        store.upsertCrop(crop)
        store.upsertAttendance(
            Attendance(date = "2026-09-30", workerId = worker.id, fieldId = field.id, status = "FULL", rate = 600.0)
        )

        assertEquals(1, store.workers().size)
        assertEquals(1, store.fields().size)
        assertEquals(1, store.crops().size)
        assertEquals(1, store.attendance().size)
        assertTrue(store.health().none { it.startsWith("ERROR:") })

        val backup = ByteArrayOutputStream()
        store.exportBackup(backup)
        assertTrue(store.validateBackup(ByteArrayInputStream(backup.toByteArray())).first)

        // Recreate the repository exactly as a new process would; all core data remains local.
        val restarted = LocalStore(context)
        assertEquals("Offline Worker", restarted.workers().single().name)
        assertEquals("Offline Field", restarted.fields().single().name)
        assertEquals("Sugarcane", restarted.crops().single().name)
        assertEquals("FULL", restarted.attendance().single().status)
    }
}
