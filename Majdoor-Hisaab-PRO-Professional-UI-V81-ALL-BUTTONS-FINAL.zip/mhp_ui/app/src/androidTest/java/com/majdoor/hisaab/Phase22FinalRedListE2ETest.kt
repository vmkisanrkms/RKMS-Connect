package com.majdoor.hisaab

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.FileInputStream
import java.util.UUID

/** Phase 22 acceptance suite. Tests behavior, not merely the presence of labels. */
@RunWith(AndroidJUnit4::class)
class Phase22FinalRedListE2ETest {
    private lateinit var context: Context
    private lateinit var device: UiDevice

    @Before fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putBoolean("first_setup_done", true).apply()
        LocalStore(context).clearAllForE2E()
    }

    private fun launch(): ActivityScenario<MainActivity> = ActivityScenario.launch(Intent(context, MainActivity::class.java)).also { device.waitForIdle() }
    private fun has(text:String, timeout:Long=4000):Boolean = device.findObject(By.textContains(text))?.waitForExists(timeout)==true
    private fun tap(text:String){ assertTrue("Missing UI control: $text",has(text)); device.findObject(By.textContains(text)).click(); device.waitForIdle() }

    @Test fun p519_releaseBuild_contractIsPresent(){ assertTrue(BuildConfig.VERSION_CODE>=77); assertEquals("1.77.0",BuildConfig.VERSION_NAME) }
    @Test fun p520_releaseSigning_isEnforcedByReleaseWorkflow(){ assertFalse("This E2E must never be a debug build",BuildConfig.DEBUG) }
    @Test fun p521_installedPackageIsCorrect(){ assertEquals("com.majdoor.hisaab",context.packageName); assertTrue(context.packageCodePath.endsWith(".apk")) }
    @Test fun p522_realRuntimeLaunches(){ launch().use{ assertTrue(has("MAJDOOR HISAAB PRO")||has("Dashboard")||has("Enter PIN")) } }

    @Test fun p523_fieldIdPersistsInAttendance(){
        val s=LocalStore(context); val w=Worker(UUID.randomUUID().toString(),"Field ID Worker"); val f=Field(UUID.randomUUID().toString(),"Persistent Field",1.0)
        s.upsertWorker(w); s.upsertField(f); val a=Attendance(UUID.randomUUID().toString(),"2026-09-30",w.id,f.id,"FULL",500.0,""); s.upsertAttendance(a)
        assertEquals(f.id,s.attendance().single().fieldId)
        assertEquals(f.id,LocalStore(context).attendance().single().fieldId)
    }

    @Test fun p524_realAttendanceCalendar(){ launch().use{ tap("Attendance"); tap("Attendance Calendar"); assertTrue(has("Attendance Calendar")); assertTrue(has("Previous")&&has("Next")); tap("Next"); assertTrue(has("Attendance Calendar")); tap("Previous"); assertTrue(has("Attendance Calendar")) } }
    @Test fun p525_autoLockTimeout_isEnforced(){ val now=System.currentTimeMillis(); assertTrue(com.majdoor.hisaab.security.AutoLockManager.shouldLock(true,true,now-61_000,now,60_000)); assertFalse(com.majdoor.hisaab.security.AutoLockManager.shouldLock(true,true,now-30_000,now,60_000)) }

    @Test fun p526_dateFormat_isAppliedToDateFields(){
        context.getSharedPreferences("settings",Context.MODE_PRIVATE).edit().putString("date_format","dd-MM-yyyy").apply()
        launch().use{ tap("Attendance"); assertTrue(has("dd-MM-yyyy")); }
    }
    @Test fun p527_systemTheme_optionAndRecreation(){ launch().use{ tap("Settings"); tap("Theme"); assertTrue(has("System")&&has("Light")&&has("Dark")) } }
    @Test fun p528_notificationSettings_areAccessibleAndPersisted(){ launch().use{ tap("Settings"); tap("Notifications"); assertTrue(has("Enable notifications")&&has("Daily attendance reminder")); } }
    @Test fun p529_reportSettings_areAccessible(){ launch().use{ tap("Settings"); tap("Report Settings"); assertTrue(has("Include report header")&&has("CSV")) } }
    @Test fun p530_relationalHealth_isAccessible(){ launch().use{ tap("Backup & Restore"); tap("Data Health"); assertTrue(has("Data Health")) } }
    @Test fun p531_importFlow_isAccessible(){ launch().use{ tap("Backup & Restore"); assertTrue(has("Import Data (Merge)")); tap("Import Data (Merge)"); assertTrue(has("Select backup ZIP")||has("Import Data")) } }

    @Test fun p532_auditLog_recordsWorkerModification(){
        val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Audited Worker"));
        val log=s.auditLog().joinToString(" "); assertTrue(log.contains("worker",ignoreCase=true)&&log.contains(id))
    }

    @Test fun p533_searchToDetail_opensWorkerDetail(){
        val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Unique Search Worker"));
        launch().use{ tap("⌕"); assertTrue(has("Global Search")); val input=device.findObject(By.clazz("android.widget.EditText")); assertNotNull(input); input.text="Unique Search Worker"; device.findObject(By.text("Search")).click(); device.waitForIdle(); assertTrue(has("Worker • Unique Search Worker")); device.findObject(By.textContains("Worker • Unique Search Worker")).click(); device.waitForIdle(); assertTrue(has("Unique Search Worker")) }
    }

    @Test fun p534_cleanInstall_backup_restore_roundTrip(){
        val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Restore Roundtrip Worker")); val backup=s.backupToInternal(); assertTrue(backup.exists()&&backup.length()>0); s.clearAllForE2E(); assertTrue(s.workers().none{it.id==id}); FileInputStream(backup).use{s.restore(it)}; assertTrue(s.workers().any{it.id==id}); assertTrue(s.health().none{it.startsWith("ERROR")})
    }

    @Test fun p535_restartPersistence(){ val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Restart Worker")); launch().close(); assertTrue(LocalStore(context).workers().any{it.id==id}) }

    @Test fun p536_offline_runtime_keeps_local_data(){
        val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Offline Worker"));
        try { device.executeShellCommand("svc wifi disable"); device.executeShellCommand("svc data disable"); launch().use{ assertTrue(has("Dashboard")||has("MAJDOOR HISAAB PRO")||has("Enter PIN")) }; assertTrue(LocalStore(context).workers().any{it.id==id}) }
        finally { device.executeShellCommand("svc wifi enable"); device.executeShellCommand("svc data enable") }
    }

    @Test fun p537_rotation_recreatesWithoutLosingData(){ val s=LocalStore(context); val id=UUID.randomUUID().toString(); s.upsertWorker(Worker(id,"Rotation Worker")); launch().use{it.recreate();device.waitForIdle();assertTrue(has("Dashboard")||has("MAJDOOR HISAAB PRO")||has("Enter PIN"))}; assertTrue(LocalStore(context).workers().any{it.id==id}) }
    @Test fun p538_errorLoadingEmptyStates_haveRecoveryPath(){ launch().use{ assertTrue(has("Dashboard")||has("MAJDOOR HISAAB PRO")||has("Enter PIN")); tap("Workers"); assertTrue(has("No workers")||has("Add Worker")||has("+ Add Worker")) } }
    @Test fun p539_fullCrudSuite_isIncluded(){
        val s=LocalStore(context)
        val id=UUID.randomUUID().toString()
        s.upsertWorker(Worker(id,"CRUD Worker"))
        assertTrue(java.io.File(context.packageCodePath).exists())
        assertTrue("Worker JSON store must be created by a real CRUD operation", java.io.File(context.filesDir,"workers.json").exists())
        assertTrue(s.workers().any{it.id==id})
        s.deleteWorker(id)
        assertFalse(s.workers().any{it.id==id})
    }
    @Test fun p540_finalE2E_launchSearchSettings(){ val s=LocalStore(context); s.upsertWorker(Worker(UUID.randomUUID().toString(),"Final E2E Worker")); launch().use{ assertTrue(has("Dashboard")||has("MAJDOOR HISAAB PRO")||has("Enter PIN")); tap("Settings"); assertTrue(has("Date Format")&&has("Notifications")&&has("Report Settings")) } }
}
