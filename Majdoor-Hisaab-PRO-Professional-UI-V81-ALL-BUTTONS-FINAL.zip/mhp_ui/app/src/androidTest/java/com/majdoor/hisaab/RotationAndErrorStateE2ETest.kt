package com.majdoor.hisaab

import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RotationAndErrorStateE2ETest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val device get() = UiDevice.getInstance(instrumentation)

    private fun prepare() {
        context.getSharedPreferences("settings", 0).edit()
            .putBoolean("first_setup_done", true)
            .putString("farm_name", "E2E Test Farm")
            .remove("theme")
            .apply()
    }

    @Test
    fun realRotationRecreatesActivityAndPreservesRoute() {
        prepare()
        ActivityScenario.launch<MainActivity>().use { scenario ->
            device.waitForIdle()
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))
            device.findObject(androidx.test.uiautomator.By.text("Workers")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))

            device.setOrientationLeft()
            device.waitForIdle()
            Thread.sleep(700)
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))

            device.setOrientationNatural()
            device.waitForIdle()
            Thread.sleep(500)
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))
        }
    }

    @Test
    fun realErrorDialogShowsRecoveryActions() {
        prepare()
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("e2e_error_state", true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ActivityScenario.launch<MainActivity>(intent).use {
            device.waitForIdle()
            val errorTitle = device.findObject(androidx.test.uiautomator.By.text("Something went wrong"))
            assertNotNull(errorTitle)
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Home")))
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Retry")))
            device.findObject(androidx.test.uiautomator.By.text("Retry")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))

            // Re-enter the failure state and verify Home recovery as well.
            val second = Intent(context, MainActivity::class.java).apply {
                putExtra("e2e_error_state", true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ActivityScenario.launch<MainActivity>(second).use {
                device.waitForIdle()
                assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Something went wrong")))
                device.findObject(androidx.test.uiautomator.By.text("Home")).click()
                device.waitForIdle()
                assertNotNull(device.findObject(androidx.test.uiautomator.By.text("Workers")))
            }
        }
    }
}
