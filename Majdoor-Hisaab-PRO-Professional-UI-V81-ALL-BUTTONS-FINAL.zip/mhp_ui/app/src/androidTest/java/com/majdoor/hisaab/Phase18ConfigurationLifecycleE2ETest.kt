package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.model.Crop
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.time.LocalDate

/**
 * Phase 18 — real Android lifecycle/configuration coverage.
 * 451-468 are mapped one-to-one to runtime assertions. Device reboot is
 * orchestrated by the host CI gate because an instrumentation test cannot
 * reliably reboot its own emulator and continue the same test process.
 */
@RunWith(AndroidJUnit4::class)
class Phase18ConfigurationLifecycleE2ETest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context: Context get() = instrumentation.targetContext
    private val device get() = UiDevice.getInstance(instrumentation)
    private val today = LocalDate.now().toString()

    @Before fun clean() {
        context.getSharedPreferences("settings", 0).edit().clear().apply()
        context.getSharedPreferences("security", 0).edit().clear().apply()
        File(context.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
    }

    private fun prepareOpen() {
        context.getSharedPreferences("settings", 0).edit()
            .putBoolean("first_setup_done", true)
            .putString("farm_name", "Phase18 Farm")
            .apply()
    }
    private fun launch(): ActivityScenario<MainActivity> {
        prepareOpen()
        val s = ActivityScenario.launch(MainActivity::class.java)
        Thread.sleep(850)
        device.waitForIdle()
        return s
    }
    private fun visible(text: String) = device.findObject(By.text(text)) != null
    private fun visibleContains(text: String) = device.findObject(By.textContains(text)) != null
    private fun click(text: String) { device.findObject(By.text(text)).click(); device.waitForIdle() }
    private fun store() = LocalStore(context)

    @Test fun p451_screenRotation() {
        launch().use { s ->
            click("Workers")
            device.setOrientationLeft(); device.waitForIdle(); Thread.sleep(500)
            assertTrue(visible("Workers"))
            device.setOrientationNatural(); device.waitForIdle(); Thread.sleep(300)
            assertTrue(visible("Workers"))
        }
    }

    @Test fun p452_configurationChangeRecreatesAndRestoresRoute() {
        launch().use { s ->
            click("Fields")
            s.recreate(); Thread.sleep(700); device.waitForIdle()
            assertTrue(visible("Fields"))
        }
    }

    @Test fun p453_backgroundForegroundPreservesDataAndRoute() {
        store().upsertWorker(Worker("bg-w", "Background Worker", "9000000000", defaultRate = 500.0))
        launch().use {
            click("Workers")
            device.pressHome(); Thread.sleep(400)
            device.executeShellCommand("am start -n ${context.packageName}/.MainActivity")
            Thread.sleep(700); device.waitForIdle()
            assertTrue(visible("Workers")); assertTrue(visible("Background Worker"))
        }
    }

    @Test fun p454_forceStopThenLaunchPreservesData() {
        store().upsertWorker(Worker("fs-w", "Force Stop Worker", "9000000001", defaultRate = 500.0))
        device.executeShellCommand("am force-stop ${context.packageName}")
        launch().use { click("Workers"); assertTrue(visible("Force Stop Worker")) }
    }

    @Test fun p455_processRecreationPersistsLocalData() {
        store().upsertWorker(Worker("proc-w", "Process Worker", "9000000002", defaultRate = 500.0))
        launch().use { s ->
            click("Workers"); s.recreate(); Thread.sleep(700); device.waitForIdle()
            assertTrue(visible("Process Worker")); assertEquals("Process Worker", store().workers().single().name)
        }
    }

    @Test fun p456_appRestartPreservesSettingsAndData() {
        store().upsertWorker(Worker("restart-w", "Restart Worker", "9000000003", defaultRate = 500.0))
        context.getSharedPreferences("settings", 0).edit().putString("farm_name", "Restart Farm").apply()
        device.executeShellCommand("am force-stop ${context.packageName}")
        launch().use { assertTrue(visible("Restart Farm")); click("Workers"); assertTrue(visible("Restart Worker")) }
    }

    @Test fun p457_deviceRebootPersistenceContractIsHostOrchestrated() {
        // A true emulator reboot is performed by scripts/phase18-device-reboot-gate.sh.
        // The contract here verifies the persisted artifact exists before reboot.
        store().upsertWorker(Worker("reboot-w", "Reboot Worker", "9000000004", defaultRate = 500.0))
        assertEquals("Reboot Worker", LocalStore(context).workers().single().name)
    }

    @Test fun p458_dataPersistsAfterRebootContract() {
        store().upsertWorker(Worker("reboot-persist-w", "Reboot Persist Worker", "9000000005", defaultRate = 500.0))
        assertTrue(LocalStore(context).workers().any { it.id == "reboot-persist-w" })
    }

    @Test fun p459_themeChangeAndRecreation() {
        launch().use { s ->
            context.getSharedPreferences("settings", 0).edit().putString("theme", "dark").apply()
            s.recreate(); Thread.sleep(600); device.waitForIdle()
            assertEquals("dark", context.getSharedPreferences("settings", 0).getString("theme", ""))
            assertTrue(visible("Phase18 Farm"))
        }
    }

    @Test fun p460_dateFormatChangeAndRecreation() {
        launch().use { s ->
            context.getSharedPreferences("settings", 0).edit().putString("date_format", "dd-MM-yyyy").apply()
            s.recreate(); Thread.sleep(600); device.waitForIdle()
            assertEquals("dd-MM-yyyy", context.getSharedPreferences("settings", 0).getString("date_format", ""))
            assertTrue(visible("Phase18 Farm"))
        }
    }

    @Test fun p461_largeDataset() {
        val s = store()
        repeat(1000) { i -> s.upsertWorker(Worker("large-$i", "Large Worker $i", "8${i.toString().padStart(9, '0')}", defaultRate = 500.0)) }
        assertEquals(1000, s.workers().size)
        launch().use { click("Workers"); assertTrue(visibleContains("WORKER LIST (1000)")) }
    }

    @Test fun p462_emptyDatabase() {
        assertTrue(store().workers().isEmpty())
        launch().use { assertTrue(visible("No recent activity")); assertTrue(visible("WORKERS\n0")) }
    }

    @Test fun p463_invalidInputShowsValidationError() {
        launch().use {
            click("Workers"); click("+ Add Worker")
            click("Save Worker")
            assertTrue(visible("Worker name required") || visibleContains("Worker name required"))
        }
    }

    @Test fun p464_missingRelationRejected() {
        launch().use {
            click("Crops"); click("+ Add Crop")
            val edits = device.findObjects(By.clazz("android.widget.EditText"))
            assertTrue(edits.size >= 2)
            edits[0].setText("Orphan Crop")
            edits[1].setText("V1")
            click("Save Crop")
            assertTrue(visible("Select a field") || visibleContains("Select a field"))
        }
        assertTrue(store().crops().isEmpty())
    }

    @Test fun p465_errorStateUiHasRecovery() {
        val intent = android.content.Intent(context, MainActivity::class.java).putExtra("e2e_error_state", true)
        context.getSharedPreferences("settings", 0).edit().putBoolean("first_setup_done", true).apply()
        ActivityScenario.launch<MainActivity>(intent).use {
            Thread.sleep(850); device.waitForIdle()
            assertTrue(visible("Something went wrong")); assertTrue(visible("Retry")); assertTrue(visible("Home"))
        }
    }

    @Test fun p466_loadingStateUi() {
        prepareOpen()
        val s = ActivityScenario.launch<MainActivity>(MainActivity::class.java)
        try {
            Thread.sleep(80); device.waitForIdle()
            assertTrue(visible("Loading your local records…") || visibleContains("Loading your local records"))
        } finally { s.close() }
    }

    @Test fun p467_noDataStateUi() {
        launch().use { click("Crops"); assertTrue(visible("No crops added yet.")) }
    }

    @Test fun p468_offlineNoNetworkState() {
        // Production has no INTERNET permission and uses local JSON storage.
        val manifest = context.packageManager.getPackageInfo(context.packageName, android.content.pm.PackageManager.GET_PERMISSIONS)
        val internet = manifest.requestedPermissions?.any { it == android.Manifest.permission.INTERNET } == true
        assertFalse("Offline-first app must not request INTERNET", internet)
        store().upsertWorker(Worker("offline-w", "Offline Worker", "9000000006", defaultRate = 500.0))
        launch().use { click("Workers"); assertTrue(visible("Offline Worker")) }
    }
}
