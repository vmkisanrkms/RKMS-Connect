package com.majdoor.hisaab

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** Host-orchestrated two-step reboot test: seed -> real emulator reboot -> verify. */
@RunWith(AndroidJUnit4::class)
class Phase18DeviceRebootPersistenceE2ETest {
    private val context: Context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val marker get() = File(context.filesDir, "phase18-reboot-marker.txt")

    @Test fun seedBeforeDeviceReboot() {
        context.getSharedPreferences("settings", 0).edit().clear().putBoolean("first_setup_done", true).apply()
        context.getSharedPreferences("security", 0).edit().clear().apply()
        marker.writeText("phase18-reboot-ok")
        LocalStore(context).upsertWorker(Worker("phase18-reboot-worker", "Reboot Persistence Worker", "9000000010", defaultRate = 500.0))
        assertTrue(marker.exists())
        assertEquals("Reboot Persistence Worker", LocalStore(context).workers().single().name)
    }

    @Test fun verifyAfterDeviceReboot() {
        assertTrue("Reboot marker missing after device reboot", marker.exists())
        assertEquals("phase18-reboot-ok", marker.readText())
        val worker = LocalStore(context).workers().firstOrNull { it.id == "phase18-reboot-worker" }
        assertNotNull("Worker data did not persist across device reboot", worker)
        assertEquals("Reboot Persistence Worker", worker!!.name)
    }
}
