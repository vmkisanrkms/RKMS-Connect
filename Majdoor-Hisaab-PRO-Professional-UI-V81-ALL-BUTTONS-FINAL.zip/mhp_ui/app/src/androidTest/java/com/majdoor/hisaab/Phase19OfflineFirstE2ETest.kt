package com.majdoor.hisaab

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.core.app.ActivityScenario
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import com.majdoor.hisaab.report.ReportService
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/** Phase 19 — offline-first acceptance. Save-path tests use the real Android UI. */
@RunWith(AndroidJUnit4::class)
class Phase19OfflineFirstE2ETest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context: Context get() = instrumentation.targetContext
    private val device get() = UiDevice.getInstance(instrumentation)

    @Before fun clean() {
        enableNetwork()
        context.getSharedPreferences("settings",0).edit().clear().apply()
        context.getSharedPreferences("security",0).edit().clear().apply()
        File(context.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
    }

    private fun store() = LocalStore(context)
    private fun open(): ActivityScenario<MainActivity> {
        context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).apply()
        val s=ActivityScenario.launch(MainActivity::class.java)
        Thread.sleep(900); device.waitForIdle(); return s
    }
    private fun visible(t:String)=device.findObject(By.textContains(t))!=null
    private fun clickText(t:String){
        device.findObject(By.text(t)).click(); device.waitForIdle(); Thread.sleep(250)
    }
    private fun editTexts() = device.findObjects(By.clazz("android.widget.EditText"))
    private fun setEdit(index:Int,value:String){
        val edits=editTexts(); require(index < edits.size){"Missing EditText #$index; found ${edits.size}"}
        edits[index].click(); edits[index].text=value
    }
    private fun disableNetwork(){
        device.executeShellCommand("svc wifi disable")
        device.executeShellCommand("svc data disable")
        device.executeShellCommand("settings put global airplane_mode_on 1")
        device.executeShellCommand("am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true")
        Thread.sleep(700)
    }
    private fun enableNetwork(){
        device.executeShellCommand("settings put global airplane_mode_on 0")
        device.executeShellCommand("am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false")
        device.executeShellCommand("svc wifi enable")
        device.executeShellCommand("svc data enable")
        Thread.sleep(700)
    }
    private fun offlineOpen(): ActivityScenario<MainActivity>{ disableNetwork(); return open() }

    @Test fun p469_internetDisabledAppLaunches() {
        val manifest=context.packageManager.getPackageInfo(context.packageName, android.content.pm.PackageManager.GET_PERMISSIONS)
        assertFalse(manifest.requestedPermissions?.any{it==android.Manifest.permission.INTERNET}==true)
        offlineOpen().use { assertTrue(visible("OFFLINE MODE") || visible("Dashboard")) }
        enableNetwork()
    }

    @Test fun p470_existingWorkersOffline() {
        store().upsertWorker(Worker("off-w","Offline Worker","9000000000",defaultRate=500.0))
        offlineOpen().use { clickText("Workers"); assertTrue(visible("Offline Worker")) }; enableNetwork()
    }

    @Test fun p471_existingFieldsOffline() {
        store().upsertField(Field("off-f","Offline Field",2.0))
        offlineOpen().use { clickText("Global Search"); setEdit(0,"Offline Field"); clickText("Search"); assertTrue(visible("Field • Offline Field")) }; enableNetwork()
    }

    @Test fun p472_existingCropsOffline() {
        val s=store(); s.upsertField(Field("off-f","Offline Field",2.0)); s.upsertCrop(Crop("off-c","Sugarcane","CO","off-f"))
        offlineOpen().use { clickText("Global Search"); setEdit(0,"Sugarcane"); clickText("Search"); assertTrue(visible("Crop • Sugarcane")) }; enableNetwork()
    }

    @Test fun p473_attendanceSavesOffline() {
        val s=store(); s.upsertWorker(Worker("w","Offline Attendance Worker","9000000001",defaultRate=500.0)); s.upsertField(Field("f","Offline Field",1.0))
        offlineOpen().use {
            clickText("Mark Attendance"); clickText("All Full"); clickText("Save Attendance")
            assertEquals("FULL",s.attendance().single{it.workerId=="w"}.status)
        }; enableNetwork()
    }

    @Test fun p474_workSavesOffline() {
        val s=store(); s.upsertWorker(Worker("w","Offline Work Worker","9000000002")); s.upsertField(Field("f","Offline Work Field",1.0)); s.upsertCrop(Crop("c","Offline Crop","V1","f"))
        offlineOpen().use {
            clickText("Add Work")
            setEdit(1,"Weeding"); setEdit(2,"2"); setEdit(3,"acre"); setEdit(4,"300")
            clickText("Workers: 0"); clickText("Offline Work Worker"); clickText("Done"); clickText("Save Work")
            assertEquals(1,s.work().size); assertEquals(listOf("w"),s.work().single().workerIds)
        }; enableNetwork()
    }

    @Test fun p475_paymentSavesOffline() {
        val s=store(); s.upsertWorker(Worker("w","Offline Payment Worker","9000000003"))
        offlineOpen().use {
            clickText("Payment"); setEdit(1,"250"); clickText("Save")
            assertEquals(250.0,s.payments().single{it.workerId=="w"}.amount,0.001)
        }; enableNetwork()
    }

    @Test fun p476_expenseSavesOffline() {
        val s=store()
        offlineOpen().use {
            clickText("Add Expense"); setEdit(1,"125"); clickText("Save")
            assertEquals(125.0,s.expenses().single().amount,0.001)
        }; enableNetwork()
    }

    @Test fun p477_reportsGenerateOffline() {
        val s=store(); s.upsertWorker(Worker("w","Offline Report Worker","9000000004",defaultRate=500.0)); s.upsertAttendance(Attendance(date="2026-09-30",workerId="w",status="FULL",rate=500.0))
        offlineOpen().use { clickText("Reports"); clickText("Daily Labour"); assertTrue(visible("Attendance wages")); clickText("Export Daily Labour CSV"); device.pressBack() }
        val service=ReportService(context, com.majdoor.hisaab.data.repository.LocalRepository(context))
        val csv=ByteArrayOutputStream(); service.csvReport("Offline Report",csv); assertTrue(csv.toByteArray().isNotEmpty())
        val pdf=ByteArrayOutputStream(); service.pdfReport("Offline Report",pdf); assertTrue(pdf.toByteArray().isNotEmpty())
        enableNetwork()
    }

    @Test fun p478_backupBuildsOffline() {
        val s=store(); s.upsertWorker(Worker("w","Offline Backup Worker","9000000005"))
        offlineOpen().use { clickText("Backup & Restore"); clickText("Create Local Backup"); assertTrue(visible("Backup & Restore")) }
        assertTrue(File(context.getExternalFilesDir(null),"majdoor_hisaab/backups").listFiles()?.any{it.extension=="zip"}==true)
        enableNetwork()
    }

    @Test fun p479_restoreWorksOffline() {
        val s=store(); s.upsertWorker(Worker("w","Restore Worker","9000000006")); val out=ByteArrayOutputStream(); s.exportBackup(out)
        s.upsertWorker(Worker("extra","Extra Worker","9000000007"))
        disableNetwork()
        // Restore itself is a local storage operation; validate + replace is exercised on Android runtime.
        s.restore(ByteArrayInputStream(out.toByteArray()))
        assertTrue(s.workers().any{it.id=="w"}); assertFalse(s.workers().any{it.id=="extra"}); assertTrue(s.health().none{it.startsWith("ERROR:")})
        open().use { clickText("Backup & Restore"); assertTrue(visible("Restore Backup (Replace)")) }
        enableNetwork()
    }

    @Test fun p480_noNetworkDoesNotCrash() {
        disableNetwork()
        try { offlineOpen().use { assertTrue(visible("Dashboard") || visible("OFFLINE MODE")) } }
        finally { enableNetwork() }
    }

    @Test fun p481_networkRecoveryKeepsLocalData() {
        val s=store(); s.upsertWorker(Worker("persist","Network Recovery Worker","9000000008"))
        disableNetwork()
        try { offlineOpen().use { clickText("Workers"); assertTrue(visible("Network Recovery Worker")) } }
        finally { enableNetwork() }
        open().use { clickText("Workers"); assertTrue(visible("Network Recovery Worker")) }
        assertEquals("Network Recovery Worker",LocalStore(context).workers().single().name)
    }
}
