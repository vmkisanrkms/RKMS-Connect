package com.majdoor.hisaab

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.feature.AppServices
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.security.SecurityManager
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayOutputStream
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.BufferedReader
import java.io.StringReader
import java.time.LocalDate
import java.util.UUID

/**
 * Phase 17: real Android instrumentation coverage. These tests execute against
 * the Android framework/emulator, not Robolectric. UI navigation is exercised
 * where the workflow is user-facing; use-cases are exercised in the same
 * process for persistence/export flows that depend on Android storage APIs.
 */
@RunWith(AndroidJUnit4::class)
class Phase17RealAndroidRuntimeE2ETest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context: Context get() = instrumentation.targetContext
    private val device: UiDevice get() = UiDevice.getInstance(instrumentation)
    private val today = LocalDate.now().toString()

    @Before fun clean() {
        context.getSharedPreferences("settings", 0).edit().clear().apply()
        context.getSharedPreferences("security", 0).edit().clear().apply()
        File(context.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
        device.executeShellCommand("am force-stop ${context.packageName}")
    }

    private fun launch() {
        ActivityScenario.launch<MainActivity>().use { Thread.sleep(850); device.waitForIdle() }
    }
    private fun launchOpen(): ActivityScenario<MainActivity> {
        val s = ActivityScenario.launch<MainActivity>(); Thread.sleep(850); device.waitForIdle(); return s
    }
    private fun services() = AppServices(context)
    private fun store() = LocalStore(context)
    private fun seedCore() {
        val s = store()
        s.upsertWorker(Worker("e2e-w", "Runtime Worker", "9999999999", defaultRate = 500.0))
        s.upsertField(Field("e2e-f", "Runtime Field", 2.0))
        s.upsertCrop(Crop("e2e-c", "Sugarcane", "CO", "e2e-f", today, 2.0))
    }
    private fun click(text: String) { device.findObject(By.text(text)).click(); device.waitForIdle() }
    private fun clickContains(text: String) { device.findObject(By.textContains(text)).click(); device.waitForIdle() }
    private fun visible(text: String) = device.findObject(By.text(text)) != null
    private fun visibleContains(text: String) = device.findObject(By.textContains(text)) != null

    @Test fun p422_freshInstallSmoke() {
        device.executeShellCommand("pm clear ${context.packageName}")
        launch()
        assertTrue(visible("Welcome to Majdoor Hisaab PRO"))
    }
    @Test fun p423_firstLaunch() { launch(); assertTrue(visible("Welcome to Majdoor Hisaab PRO")) }
    @Test fun p424_firstTimeSetup() {
        launchOpen().use { assertTrue(visible("Start App")); click("Start App"); assertTrue(visible("Workers")) }
    }
    @Test fun p425_pinSetup() {
        launchOpen().use {
            val fields = device.findObjects(By.clazz("android.widget.EditText")); assertTrue(fields.size >= 2)
            fields[1].setText("1234"); click("Start App")
        }
        assertTrue(SecurityManager(context).hasPin())
    }
    @Test fun p426_pinUnlock() {
        context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).apply()
        SecurityManager(context).setPin("1234")
        launchOpen().use { val e=device.findObject(By.hint("Enter PIN")); assertNotNull(e); e.setText("1234"); click("Unlock") }
        assertTrue(visible("Workers"))
    }
    @Test fun p427_wrongPin() {
        context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).apply(); SecurityManager(context).setPin("1234")
        launchOpen().use { device.findObject(By.hint("Enter PIN")).setText("9999"); click("Unlock"); Thread.sleep(150); assertTrue(visible("Incorrect PIN (4 attempts remaining)")) }
    }
    @Test fun p428_biometric() {
        val sm=SecurityManager(context); assumeTrue("Biometric enrollment is required on this emulator", sm.biometricAvailable())
        sm.setPin("1234"); sm.setBiometricEnabled(true); context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).apply()
        launchOpen().use { assertTrue(visible("Unlock Majdoor Hisaab PRO")) }
    }
    @Test fun p429_biometricCancelFallsBackToPin() {
        val sm=SecurityManager(context); assumeTrue(sm.biometricAvailable()); sm.setPin("1234"); sm.setBiometricEnabled(true); context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).apply()
        launchOpen().use { device.pressBack(); device.waitForIdle(); assertTrue(visible("Majdoor Hisaab PRO Locked")) }
    }
    @Test fun p430_autoLock() {
        context.getSharedPreferences("settings",0).edit().putBoolean("first_setup_done",true).putString("auto_lock_timeout","1 minute").apply(); SecurityManager(context).setPin("1234")
        launchOpen().use { val e=device.findObject(By.hint("Enter PIN")); e.setText("1234"); click("Unlock"); Thread.sleep(61_500); device.waitForIdle(); assertTrue(visible("Majdoor Hisaab PRO Locked")) }
    }
    @Test fun p431_dashboardRuntime() { launchOpen().use { assertTrue(visible("Workers")); assertTrue(visible("Fields")); assertTrue(visible("Reports")); assertTrue(visible("Settings")) } }
    @Test fun p432_workerCreateEditDeleteDeactivate() {
        launchOpen().use {
            click("Workers"); click("+ Add Worker"); val e=device.findObjects(By.clazz("android.widget.EditText")); e[0].setText("Runtime CRUD Worker"); click("Save Worker"); assertTrue(visible("Runtime CRUD Worker"))
            click("Open"); click("Edit"); val edit=device.findObjects(By.clazz("android.widget.EditText")); edit[0].setText("Runtime CRUD Edited"); click("Save Worker"); assertTrue(visible("Runtime CRUD Edited"))
            click("Deactivate Worker"); assertTrue(visible("Status: Inactive"))
        }
        // Delete is a data-layer operation; verify the same runtime database can delete the record.
        val remaining = store().workers().firstOrNull { it.name == "Runtime CRUD Edited" }
        if (remaining != null) services().workers.delete(remaining.id)
        assertTrue(store().workers().none { it.name == "Runtime CRUD Edited" })
    }
    @Test fun p433_workerPhotoRuntimePersistence() {
        store().upsertWorker(Worker("photo-w","Photo Worker", photoUri="content://runtime/photo")); launchOpen().use { click("Workers"); click("Open"); assertTrue(visible("Photo Worker")) }; assertEquals("content://runtime/photo", store().workers().single().photoUri)
    }
    @Test fun p434_fieldCreateEdit() { seedCore(); launchOpen().use { click("Fields"); clickContains("Runtime Field"); click("Edit Field"); val e=device.findObjects(By.clazz("android.widget.EditText")); e[0].setText("Runtime Field Edited"); click("Save Field"); assertTrue(visibleContains("Runtime Field Edited")) } }
    @Test fun p435_cropCreateEdit() { seedCore(); launchOpen().use { click("Crops"); click("+ Add Crop"); val e=device.findObjects(By.clazz("android.widget.EditText")); e[0].setText("Runtime Crop"); e[1].setText("V1"); click("Save Crop"); assertTrue(visibleContains("Runtime Crop V1")) } }
    @Test fun p436_attendanceCompleteWorkflow() { seedCore(); launchOpen().use { click("Mark Attendance"); assertTrue(visible("Runtime Worker")); device.findObject(By.text("Runtime Worker")).click(); click("Save Attendance") }; assertEquals(1, store().attendance().size) }
    @Test fun p437_previousTeamRuntime() { seedCore(); store().upsertTeam(Team("e2e-team","Runtime Team", mutableListOf("e2e-w"))); launchOpen().use { click("Mark Attendance"); click("Previous Team — copy workers only"); assertTrue(device.findObject(By.text("Runtime Worker")).isChecked) } }
    @Test fun p438_fieldIdPersistence() { seedCore(); val id=store().crops().single().fieldId; device.executeShellCommand("am force-stop ${context.packageName}"); launchOpen().use { click("Crops"); click("Sugarcane CO") }; assertEquals("e2e-f", id); assertEquals(id, store().crops().single().fieldId) }
    @Test fun p439_workCompleteWorkflow() { seedCore(); services().work.save(WorkRecord("e2e-work",today,"e2e-f","e2e-c","Planting",2.0,"ACRE","acre",900.0, mutableListOf("e2e-w"))); launchOpen().use { click("Work"); assertTrue(visible("Planting")); click("Today's Work"); assertTrue(visible("Planting")) }; assertEquals(1800.0, services().calculation.workCost(services().work.list().single()),0.001) }
    @Test fun p440_paymentCompleteWorkflow() { seedCore(); services().payments.save(Payment("e2e-pay","e2e-w",today,300.0,"UPI")); launchOpen().use { click("Payments"); assertTrue(visibleContains("Runtime Worker")) }; assertEquals(300.0, store().payments().single().amount,0.001) }
    @Test fun p441_expenseCompleteWorkflow() { seedCore(); services().expenses.save(Expense("e2e-exp",today,"Fertilizer",1250.0,"e2e-f","e2e-c")); launchOpen().use { click("Expenses"); assertTrue(visibleContains("Fertilizer")) }; assertEquals(1250.0, store().expenses().single().amount,0.001) }
    @Test fun p442_reportsRuntime() { seedCore(); services().work.save(WorkRecord("rw",today,"e2e-f","e2e-c","Planting",1.0,"ACRE","acre",500.0, mutableListOf("e2e-w"))); launchOpen().use { click("Reports"); assertTrue(visible("Daily Labour")); click("Daily Labour"); assertTrue(visible("Total labour cost")) } }
    @Test fun p443_csvExportRuntime() {
        seedCore(); val out=ByteArrayOutputStream(); services().export.csvWorkers(out); val text=out.toString("UTF-8")
        assertTrue(text.contains("Runtime Worker")); assertTrue(text.isNotBlank())
        BufferedReader(StringReader(text)).use { reader -> assertNotNull("CSV output must be readable", reader.readLine()); assertTrue(reader.readLine()?.contains("Runtime Worker") == true) }
    }
    @Test fun p444_pdfExportRuntime() {
        seedCore(); val out=ByteArrayOutputStream(); services().export.pdfSummary(out); val bytes=out.toByteArray()
        assertTrue(bytes.size>100); assertEquals('%'.code.toByte(),bytes[0]); assertTrue(String(bytes,0,minOf(bytes.size,5),Charsets.US_ASCII).startsWith("%PDF"))
        val file=File(context.cacheDir,"runtime-report.pdf"); file.writeBytes(bytes)
        ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY).use { pfd -> PdfRenderer(pfd).use { renderer -> assertTrue("Generated PDF must open in PdfRenderer",renderer.pageCount>=1); renderer.openPage(0).use { page -> assertTrue(page.width>0 && page.height>0) } } }
        assertTrue(file.delete())
    }
    @Test fun p445_backupRuntime() { seedCore(); val f=services().backup.create(); assertTrue(f.exists()); assertTrue(f.length()>0); assertTrue(f.extension=="zip") }
    @Test fun p446_restoreRuntime() { seedCore(); services().backup.create().inputStream().use { services().backup.restore(it) }; assertEquals(1,store().workers().size); assertEquals(1,store().crops().size) }
    @Test fun p447_importRuntime() { seedCore(); val backup=services().backup.create(); val result=backup.inputStream().use { services().backup.merge(it) }; assertTrue(result.isNotBlank()); assertEquals(1,store().workers().size) }
    @Test fun p448_searchDetailNavigation() { seedCore(); launchOpen().use { click("Global Search"); val e=device.findObject(By.hint("Search workers, fields, crops, attendance, work, payments, expenses")); e.setText("Runtime Worker"); click("Search"); assertTrue(visible("Worker • Runtime Worker • 9999999999")); click("Worker • Runtime Worker • 9999999999"); assertTrue(visible("Worker Profile")) } }
    @Test fun p449_settingsRuntime() { launchOpen().use { click("Settings"); click("Farm Profile"); assertNotNull(device.findObject(By.hint("Farm / business name"))); device.pressBack(); click("Wage Settings"); assertTrue(visible("Default daily wage")); device.pressBack(); click("Theme"); assertTrue(visible("Light")) } }
    @Test fun p450_notificationSettingsRuntime() { launchOpen().use { click("Settings"); click("Notifications"); assertTrue(visible("Enable notifications")); assertTrue(visible("Daily attendance reminder")); assertTrue(visible("Daily payment reminder")); assertTrue(visible("Send Test Notification")) } }
}
