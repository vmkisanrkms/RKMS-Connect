package com.majdoor.hisaab

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Real Android clean-data restore: creates a backup, clears the target package data,
 * recreates LocalStore exactly as a fresh install would, restores the backup, and
 * verifies records and financial totals. */
@RunWith(AndroidJUnit4::class)
class CleanInstallBackupRestoreE2ETest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val device get() = UiDevice.getInstance(instrumentation)

    @Test fun cleanInstallRestorePreservesRecordsAndTotals() {
        context.getSharedPreferences("settings", 0).edit().clear().putBoolean("first_setup_done", true).apply()
        val source = LocalStore(context)
        source.clearAllForE2E()
        val worker = Worker("clean-e2e-worker", "Clean Install Worker", defaultRate = 600.0)
        val field = Field("clean-e2e-field", "Clean Install Field", 2.0)
        val crop = Crop("clean-e2e-crop", "Wheat", "HD", field.id, "2026-09-30", 2.0)
        source.upsertWorker(worker); source.upsertField(field); source.upsertCrop(crop)
        source.upsertAttendance(Attendance("clean-e2e-att", "2026-09-30", worker.id, field.id, "FULL", 600.0, ""))
        source.upsertPayment(Payment("clean-e2e-pay", worker.id, "2026-09-30", 250.0, "UPI"))
        source.upsertExpense(Expense("clean-e2e-exp", "2026-09-30", "Diesel", 125.0, field.id, crop.id))
        source.upsertRevenue(Revenue("clean-e2e-rev", crop.id, "2026-09-30", 5000.0))
        val expectedPayment = source.payments().sumOf { it.amount }
        val expectedExpense = source.expenses().sumOf { it.amount }
        val expectedRevenue = source.revenue().sumOf { it.amount }
        val backup = ByteArrayOutputStream().also { source.exportBackup(it) }.toByteArray()
        assertTrue(backup.isNotEmpty())

        device.executeShellCommand("am force-stop ${context.packageName}")
        device.executeShellCommand("pm clear ${context.packageName}")
        val clean = LocalStore(context)
        assertTrue(clean.workers().isEmpty())
        clean.restore(ByteArrayInputStream(backup))
        assertEquals("Clean Install Worker", clean.workers().single().name)
        assertEquals("Clean Install Field", clean.fields().single().name)
        assertEquals(expectedPayment, clean.payments().sumOf { it.amount }, 0.001)
        assertEquals(expectedExpense, clean.expenses().sumOf { it.amount }, 0.001)
        assertEquals(expectedRevenue, clean.revenue().sumOf { it.amount }, 0.001)
        assertTrue(clean.health().none { it.startsWith("ERROR:") })
    }
}
