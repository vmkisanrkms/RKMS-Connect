package com.majdoor.hisaab

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import com.majdoor.hisaab.model.Worker
import com.majdoor.hisaab.model.Field
import com.majdoor.hisaab.model.Crop
import com.majdoor.hisaab.storage.LocalStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Real device E2E coverage for the two highest-risk local workflows:
 * worker CRUD across a process restart and attendance selection/status separation.
 */
@RunWith(AndroidJUnit4::class)
class RealCoreWorkflowE2ETest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private val device get() = UiDevice.getInstance(instrumentation)
    private val packageName = "com.majdoor.hisaab"

    @Before
    fun prepareCleanLocalState() {
        context.getSharedPreferences("settings", 0).edit()
            .clear()
            .putBoolean("first_setup_done", true)
            .putString("farm_name", "E2E Test Farm")
            .apply()
        java.io.File(context.getExternalFilesDir(null), "majdoor_hisaab").deleteRecursively()
        LocalStore(context)
        device.executeShellCommand("am force-stop $packageName")
    }

    private fun launch() {
        device.executeShellCommand("am start -W -n $packageName/.MainActivity")
        device.waitForIdle()
        Thread.sleep(300)
    }

    @Test
    fun workerCrudSurvivesRealForceStopAndRelaunch() {
        ActivityScenario.launch<MainActivity>().use {
            device.waitForIdle()
            device.findObject(By.text("Workers")).click()
            device.waitForIdle()
            device.findObject(By.text("+ Add Worker")).click()
            device.waitForIdle()

            val edits = device.findObjects(By.clazz("android.widget.EditText"))
            assertTrue("Worker form should expose editable fields", edits.isNotEmpty())
            edits[0].setText("E2E Worker")
            if (edits.size > 1) edits[1].setText("9999999999")
            device.findObject(By.text("Save Worker")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("E2E Worker")))
        }

        device.executeShellCommand("am force-stop $packageName")
        launch()
        device.findObject(By.text("Workers")).click()
        device.waitForIdle()
        assertNotNull("Worker must survive real process restart", device.findObject(By.textContains("E2E Worker")))

        val workers = LocalStore(context).workers()
        assertEquals(1, workers.size)
        assertEquals("E2E Worker", workers.single().name)
    }

    @Test
    fun selectingWorkerDoesNotAutomaticallyMarkFullDay() {
        LocalStore(context).upsertWorker(
            Worker(id = "e2e-worker", name = "E2E Worker", mobile = "9999999999")
        )
        ActivityScenario.launch<MainActivity>().use {
            device.waitForIdle()
            device.findObject(By.text("Mark Attendance")).click()
            device.waitForIdle()

            val checkbox = device.findObject(By.text("E2E Worker"))
            assertNotNull("Worker checkbox must be visible", checkbox)
            checkbox.click()
            device.waitForIdle()

            // Selecting the worker only selects the row; the status remains NONE/Unmarked.
            assertNotNull(device.findObject(By.text("NONE")))
            assertTrue(LocalStore(context).attendance().isEmpty())

            device.findObject(By.text("Save Attendance")).click()
            device.waitForIdle()
        }

        val attendance = LocalStore(context).attendance()
        assertEquals(1, attendance.size)
        assertEquals("NONE", attendance.single().status)
    }
    @Test
    fun previousTeamCopiesWorkersButNotAttendanceStatuses() {
        val store = LocalStore(context)
        store.upsertWorker(Worker(id="prev-w1", name="Previous One", mobile="8888888888"))
        store.upsertWorker(Worker(id="prev-w2", name="Previous Two", mobile="8888888887"))
        store.upsertTeam(com.majdoor.hisaab.model.Team(id="prev-team", name="Previous", workerIds=mutableListOf("prev-w1","prev-w2")))

        // Seed an earlier attendance record with FULL so the test can prove that the
        // Previous Team UI does not copy that status into the newly selected date.
        store.upsertAttendance(
            com.majdoor.hisaab.model.Attendance(
                date="2026-09-29", workerId="prev-w1", fieldId="", status="FULL", rate=500.0
            )
        )

        ActivityScenario.launch<MainActivity>().use {
            device.waitForIdle()
            device.findObject(By.text("Mark Attendance")).click()
            device.waitForIdle()

            // Exercise the actual Previous Team UI action, not just the Team JSON model.
            device.findObject(By.text("Previous Team — copy workers only")).click()
            device.waitForIdle()

            val worker1 = device.findObject(By.text("Previous One"))
            val worker2 = device.findObject(By.text("Previous Two"))
            assertTrue("Previous One must be selected", worker1.isChecked)
            assertTrue("Previous Two must be selected", worker2.isChecked)

            // The previous FULL status must not appear after copying the team.
            // Both rows must remain NONE/Unmarked until the user explicitly chooses a status.
            assertEquals(2, device.findObjects(By.text("NONE")).size)

            // Save the UI state and verify the newly created records are NONE.
            device.findObject(By.text("Save Attendance")).click()
            device.waitForIdle()
        }

        val today = java.time.LocalDate.now().toString()
        val saved = store.attendance().filter { it.date == today }
        assertEquals("Both Previous Team workers must be saved for the selected date", 2, saved.size)
        assertTrue(saved.all { it.workerId == "prev-w1" || it.workerId == "prev-w2" })
        assertTrue("Previous attendance status must not be copied", saved.all { it.status == "NONE" })

        // The original historical FULL record must remain unchanged.
        val historical = store.attendance().single { it.date == "2026-09-29" && it.workerId == "prev-w1" }
        assertEquals("FULL", historical.status)

        // Team persistence itself contains only workers, never attendance state.
        assertEquals(listOf("prev-w1", "prev-w2"), store.teams().last().workerIds)
        assertFalse(store.teams().last().json().has("attendance"))
    }

    @Test
    fun workAddEditDetailAndTodayHistoryAreRealUiFlows() {
        val store = LocalStore(context)
        val worker = Worker(id="work-e2e-worker", name="Work Worker", mobile="7777777777")
        val field = Field(id="work-e2e-field", name="Work Field", area=2.0)
        val crop = Crop(id="work-e2e-crop", name="Sugarcane", variety="CO", fieldId=field.id, area=2.0)
        store.upsertWorker(worker); store.upsertField(field); store.upsertCrop(crop)

        ActivityScenario.launch<MainActivity>().use {
            device.waitForIdle()
            device.findObject(By.text("Work")).click()
            device.waitForIdle()
            device.findObject(By.text("+ Add Work")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.text("Work Type Presets")))
            device.findObject(By.text("Workers: 0")).click()
            device.waitForIdle()
            device.findObject(By.text("Work Worker")).click()
            device.findObject(By.text("Done")).click()
            device.waitForIdle()

            val edits=device.findObjects(By.clazz("android.widget.EditText"))
            assertTrue("Work form must expose editable fields", edits.size >= 5)
            // Form order: date, work type, quantity, unit, rate, start, end, notes.
            edits[1].setText("Planting")
            edits[2].setText("2")
            edits[3].setText("acre")
            edits[4].setText("900")
            edits[5].setText("08:00")
            edits[6].setText("12:00")
            edits[7].setText("E2E work note")
            device.findObject(By.text("Save Work")).click()
            device.waitForIdle()

            assertNotNull(device.findObject(By.textContains("Planting")))
            device.findObject(By.text("Today's Work")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("Planting")))
            device.findObject(By.textContains("Planting")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("E2E work note")))
            assertNotNull(device.findObject(By.text("Work Audit History")))
            device.findObject(By.text("Work Audit History")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("CREATE")))
            device.pressBack()
            device.waitForIdle()
            assertNotNull(device.findObject(By.text("Edit")))
            device.findObject(By.text("Edit")).click()
            device.waitForIdle()
            val editFields=device.findObjects(By.clazz("android.widget.EditText"))
            assertTrue(editFields.size >= 5)
            editFields[4].setText("1000")
            device.findObject(By.text("Save Work")).click()
            device.waitForIdle()
        }

        val saved=store.work().single()
        assertEquals("Planting",saved.workType)
        assertEquals(1000.0,saved.rate,0.001)
        assertEquals("E2E work note",saved.notes)
        assertEquals(java.time.LocalDate.now().toString(),saved.date)
        assertEquals(1800.0,com.majdoor.hisaab.calculation.WorkRateEngine.cost(saved),0.001)
    }

    @Test
    fun fieldPhotoAddChangeRemoveRealUiFlowWorks() {
        val store = LocalStore(context)
        ActivityScenario.launch<MainActivity>().use { scenario ->
            device.waitForIdle()
            device.findObject(By.text("Fields")).click()
            device.waitForIdle()
            device.findObject(By.text("+ Add Field")).click()
            device.waitForIdle()
            val edits = device.findObjects(By.clazz("android.widget.EditText"))
            edits[0].setText("Photo E2E Field")
            edits[1].setText("2")
            edits[2].setText("acre")

            val first = android.net.Uri.parse("content://e2e/field-photo-1")
            scenario.onActivity { it.applySelectedFieldPhoto(first) }
            device.waitForIdle()
            device.findObject(By.text("Save Field")).click()
            device.waitForIdle()
            var saved = store.fields().single()
            assertEquals(first.toString(), saved.photoUri)

            device.findObject(By.textContains("Photo E2E Field")).click()
            device.waitForIdle()
            device.findObject(By.text("Edit Field")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.text("Change Field Photo")))

            val second = android.net.Uri.parse("content://e2e/field-photo-2")
            scenario.onActivity { it.applySelectedFieldPhoto(second) }
            device.waitForIdle()
            device.findObject(By.text("Save Field")).click()
            device.waitForIdle()
            saved = store.fields().single()
            assertEquals("Change Field Photo must replace the previous URI", second.toString(), saved.photoUri)

            device.findObject(By.textContains("Photo E2E Field")).click()
            device.waitForIdle()
            device.findObject(By.text("Edit Field")).click()
            device.waitForIdle()
            device.findObject(By.text("Remove Field Photo")).click()
            device.waitForIdle()
            saved = store.fields().single()
            assertEquals("Remove Field Photo must persist an empty URI", "", saved.photoUri)
            assertNotNull(device.findObject(By.text("Add Field Photo")))
        }
    }

    @Test
    fun fieldAddEditAndProfileFlowWorks() {
        ActivityScenario.launch<MainActivity>().use {
            device.waitForIdle()
            device.findObject(By.text("Fields")).click()
            device.waitForIdle()
            device.findObject(By.text("+ Add Field")).click()
            device.waitForIdle()
            val edits = device.findObjects(By.clazz("android.widget.EditText"))
            assertTrue("Field form should expose editable fields", edits.size >= 7)
            edits[0].setText("E2E Field")
            edits[1].setText("4.5")
            edits[2].setText("acre")
            edits[3].setText("Baboura")
            edits[4].setText("Loam")
            edits[5].setText("Tube Well")
            edits[6].setText("Field notes")
            device.findObject(By.text("Save Field")).click()
            device.waitForIdle()
            device.findObject(By.textContains("E2E Field")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("4.5 acre")))
            device.findObject(By.text("Edit Field")).click()
            device.waitForIdle()
            val editFields = device.findObjects(By.clazz("android.widget.EditText"))
            editFields[0].setText("E2E Field Updated")
            editFields[1].setText("5.5")
            device.findObject(By.text("Save Field")).click()
            device.waitForIdle()
            assertNotNull(device.findObject(By.textContains("E2E Field Updated")))
        }
        val saved = LocalStore(context).fields().single()
        assertEquals("E2E Field Updated", saved.name)
        assertEquals(5.5, saved.area, 0.0001)
        assertEquals("Baboura", saved.location)
        assertEquals("Loam", saved.soilType)
        assertEquals("Tube Well", saved.irrigation)
        assertEquals("Field notes", saved.notes)
    }

}
