#!/usr/bin/env bash
set -euo pipefail
APP=app/src/main/java/com/majdoor/hisaab
MAIN="$APP/MainActivity.kt"
SRC="$APP"
SEC="$APP/security/SecurityManager.kt"
AUTO="$APP/security/AutoLockManager.kt"
TEST=app/src/test/java/com/majdoor/hisaab/SecurityStartupContractTest.kt
fail(){ echo "ERROR: Phase 2 security/startup gate failed: $*" >&2; exit 1; }
test -f "$MAIN" || fail "MainActivity missing"
test -f "$SEC" || fail "SecurityManager missing"
test -f "$AUTO" || fail "AutoLockManager missing"
test -f "$TEST" || fail "security startup contract test missing"
grep -R -q --include='*.kt' 'showSplash()' "$SRC" || fail "splash not invoked"
grep -R -q --include='*.kt' 'postDelayed({ initializeStartup() }, 650L)' "$SRC" || fail "startup delay/splash transition missing"
grep -R -q --include='*.kt' 'first_setup_done' "$SRC" || fail "first-time setup state missing"
grep -R -q --include='*.kt' 'addView(btn("Start App")' "$SRC" || fail "setup completion action missing"
grep -R -q --include='*.kt' 'p.length !in 4..12' "$SRC" || fail "PIN length validation missing"
grep -R -q --include='*.kt' 'failedPinAttempts>=5' "$SRC" || fail "PIN lockout threshold missing"
grep -R -q --include='*.kt' 'pin_blocked_until' "$SRC" || fail "PIN lockout persistence missing"
grep -R -q --include='*.kt' 'Disable App Lock' "$SRC" || fail "App Lock disable action missing"
grep -q 'setNegativeButton' "$SEC" || fail "biometric PIN fallback missing"
grep -q 'Use PIN' "$SEC" || fail "biometric PIN fallback label missing"
grep -q 'onAuthenticationError' "$SEC" || fail "biometric error fallback missing"
grep -R -q --include='*.kt' 'auto_lock_timeout' "$SRC" || fail "auto-lock persistence missing"
grep -q 'override fun onPause()' "$MAIN" || fail "background timestamp missing"
grep -q 'override fun onResume()' "$MAIN" || fail "resume timeout check missing"
grep -R -q --include='*.kt' 'AutoLockManager.shouldLock' "$SRC" || fail "auto-lock policy missing"
chmod +x "$TEST" 2>/dev/null || true
echo 'PHASE2_SECURITY_STARTUP_GATE=PASS'
