#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

FAIL=0
fail(){ echo "DEPENDENCY_HEALTH_FAIL: $*" >&2; FAIL=1; }

# Direct declarations: production builds must not use pre-release or legacy dependency coordinates.
if grep -RInE "SNAPSHOT|-[0-9]*(alpha|beta|rc)[0-9]*([\"\x27)]|$)|jcenter\\(|com\\.android\\.support:|android\\.arch\\.|kotlin-android-extensions" app build.gradle.kts settings.gradle.kts 2>/dev/null; then
  fail "pre-release/legacy dependency declaration found"
fi

# The project must use centrally controlled repositories only.
grep -q 'RepositoriesMode.FAIL_ON_PROJECT_REPOS' settings.gradle.kts || fail "project repositories are not centrally controlled"
grep -q 'google()' settings.gradle.kts || fail "Google Maven repository missing"
grep -q 'mavenCentral()' settings.gradle.kts || fail "Maven Central repository missing"

# Resolve every build/test configuration from a clean dependency graph.
configs=(debugRuntimeClasspath releaseRuntimeClasspath e2eReleaseRuntimeClasspath testRuntimeClasspath)
for cfg in "${configs[@]}"; do
  echo "Resolving $cfg"
  OUT=$(mktemp)
  if ! ./gradlew --no-daemon --stacktrace --refresh-dependencies dependencies --configuration "$cfg" >"$OUT" 2>&1; then
    cat "$OUT"
    fail "$cfg did not resolve"
    rm -f "$OUT"
    continue
  fi
  if grep -Eqi 'Could not resolve|Could not find|FAILED|unresolved dependency|No matching variant' "$OUT"; then
    cat "$OUT"
    fail "$cfg contains a resolution error"
  fi
  if grep -Eqi 'SNAPSHOT|-[0-9]*(alpha|beta|rc)[0-9]*([ +]|$)' "$OUT"; then
    grep -Ei 'SNAPSHOT|-[0-9]*(alpha|beta|rc)[0-9]*([ +]|$)' "$OUT" || true
    fail "$cfg resolved a pre-release dependency"
  fi
  rm -f "$OUT"
done

# Explicit stable-version contract for direct test dependencies.
grep -q 'junit:junit:4.13.2' app/build.gradle.kts || fail 'JUnit 4.13.2 missing'
grep -q 'org.robolectric:robolectric:4.15' app/build.gradle.kts || fail 'Robolectric 4.15 missing'
grep -q 'androidx.test:core:1.7.0' app/build.gradle.kts || fail 'AndroidX Test Core 1.7.0 missing'
grep -q 'androidx.test.ext:junit:1.3.0' app/build.gradle.kts || fail 'AndroidX Test ext.junit 1.3.0 missing'
grep -q 'androidx.test:runner:1.7.0' app/build.gradle.kts || fail 'AndroidX Test Runner 1.7.0 missing'
grep -q 'androidx.test:rules:1.7.0' app/build.gradle.kts || fail 'AndroidX Test Rules 1.7.0 missing'
grep -q 'androidx.test.uiautomator:uiautomator:2.4.0' app/build.gradle.kts || fail 'UiAutomator 2.4.0 missing'

if (( FAIL != 0 )); then exit 1; fi
echo 'DEPENDENCY_HEALTH=PASS'
