#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail(){ echo "DEBUG_BUILD_GATE_FAIL: $*" >&2; exit 1; }
test -x ./gradlew || fail "Gradle wrapper missing/not executable"
test -f app/build.gradle.kts || fail "app build script missing"
grep -q 'versionCode = 77' app/build.gradle.kts || fail "unexpected project version"
grep -q 'versionName = "1.77.0"' app/build.gradle.kts || fail "unexpected project version name"
./gradlew --no-daemon --stacktrace :app:compileDebugKotlin
./gradlew --no-daemon --stacktrace :app:assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK" || fail "Debug APK was not produced"
apkanalyzer manifest application-id "$APK" | grep -Fx 'com.majdoor.hisaab' || fail "Debug APK package mismatch"
apkanalyzer manifest version-name "$APK" | grep -Fx '1.77.0' || fail "Debug APK version mismatch"
apkanalyzer manifest version-code "$APK" | grep -Fx '77' || fail "Debug APK versionCode mismatch"
echo 'DEBUG_BUILD_GATE=PASS'
