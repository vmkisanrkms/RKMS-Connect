#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
T="$ROOT/app/src/test/java/com/majdoor/hisaab/FieldModuleContractTest.kt"
for n in "Fields" "+ Add Field" "Field Profile" "Edit Field" "Field Crops" "Field Work" "Field Expenses" "Field Labour Cost" "Field Reports" "Add Field Photo" "Change Field Photo" "Remove Field Photo" "Location" "Soil type" "Irrigation" "Notes"; do grep -Fq "$n" "$A" || { echo "FAIL missing: $n" >&2; exit 1; }; done
grep -Fq 'forcedFieldId' "$A"
grep -Fq 'reportView("Field Report", id)' "$A"
grep -Fq 'base.copy(fieldId=forcedFieldId)' "$A"
grep -Fq 'multiple_crop_records_can_exist_for_one_field_over_time' "$T"
grep -Fq 'field_round_trip_preserves_all_required_fields' "$T"
grep -Fq 'field_edit_preserves_id_and_updates_values' "$T"
grep -Fq 'field_delete_is_blocked_when_linked_records_exist' "$T"
echo 'PHASE8_FIELD_STATIC_GATE=PASS'
