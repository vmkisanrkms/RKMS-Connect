#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
L="$ROOT/app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
T="$ROOT/app/src/test/java/com/majdoor/hisaab/ExpensePhase10Test.kt"
for p in 'private fun expenses()' 'private fun expenseForm' 'private fun expenseDetail' 'expenseCategoriesDialog' 'upsertExpense' 'deleteExpense' 'Expense Report' 'Category totals'; do grep -q "$p" "$A" "$L" 2>/dev/null || { echo "FAIL missing $p"; exit 1; }; done
for c in Labour Fertilizer Seed Pesticide Irrigation Machinery Diesel Transport Repair Other; do grep -q '"'$c'"' "$L" || { echo "FAIL category $c"; exit 1; }; done
for t in all_required_categories_persist_and_report edit_and_delete_recalculate_totals field_and_crop_links_are_preserved_and_filterable custom_configured_category_is_allowed_but_unknown_is_rejected category_report_totals_are_separate_and_complete; do grep -q "$t" "$T" || { echo "FAIL test $t"; exit 1; }; done
grep -q 'x.amount.isFinite() && x.amount>0' "$L"
echo 'PHASE10_EXPENSE_STATIC_GATE=PASS'
