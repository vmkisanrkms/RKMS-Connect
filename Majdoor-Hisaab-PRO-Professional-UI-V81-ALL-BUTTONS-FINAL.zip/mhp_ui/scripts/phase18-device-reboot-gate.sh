#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_NAME="com.majdoor.hisaab"
./gradlew --no-daemon --stacktrace connectedE2eReleaseAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.majdoor.hisaab.Phase18DeviceRebootPersistenceE2ETest#seedBeforeDeviceReboot
adb reboot
adb wait-for-device
for i in $(seq 1 60); do
  if adb shell getprop sys.boot_completed | tr -d '\r' | grep -q '^1$'; then break; fi
  sleep 2
done
adb shell getprop sys.boot_completed | tr -d '\r' | grep -q '^1$'
./gradlew --no-daemon --stacktrace connectedE2eReleaseAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.majdoor.hisaab.Phase18DeviceRebootPersistenceE2ETest#verifyAfterDeviceReboot
mkdir -p artifacts/release-e2e/markers
printf 'PHASE18_DEVICE_REBOOT_PERSISTENCE=PASS\n'
touch artifacts/release-e2e/markers/561_reboot_persistence.pass
