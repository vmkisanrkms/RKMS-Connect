#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_FILE="$ROOT/build.gradle.kts"
WRAPPER="$ROOT/gradle/wrapper/gradle-wrapper.properties"
WORKFLOW="$ROOT/.github/workflows/build-release-apk.yml"
ROOT_BUILD="$ROOT/build.gradle.kts"

AGP="$(sed -nE 's/.*id\("com\.android\.application"\) version "([0-9.]+)".*/\1/p' "$BUILD_FILE" | head -1)"
GRADLE="$(sed -nE 's/.*gradle-([0-9.]+)-(bin|all)\.zip.*/\1/p' "$WRAPPER" | head -1)"

[ "$AGP" = "8.9.1" ] || { echo "ERROR: expected AGP 8.9.1, found ${AGP:-missing}"; exit 1; }
[ "$GRADLE" = "8.11.1" ] || { echo "ERROR: expected Gradle 8.11.1, found ${GRADLE:-missing}"; exit 1; }

case "$AGP" in
  8.9|8.9.*) REQUIRED="8.11.1" ;;
  *) echo "ERROR: unsupported AGP policy pair: $AGP"; exit 1 ;;
esac
[ "$GRADLE" = "$REQUIRED" ] || { echo "ERROR: AGP $AGP requires Gradle $REQUIRED, found $GRADLE"; exit 1; }

# The release workflow must explicitly provision JDK 17. Do not depend on the
# developer machine's installed Java version for this source-level contract.
grep -Eq 'distribution:.*temurin|java-version:.*17|java-version:.*17\.' "$WORKFLOW" || {
  echo "ERROR: GitHub Actions workflow does not explicitly provision JDK 17"; exit 1;
}

grep -q 'distributionSha256Sum=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6' "$WRAPPER" || { echo "ERROR: Gradle 8.11.1 distribution checksum is not pinned"; exit 1; }
grep -q '\./gradlew --no-daemon' "$WORKFLOW" || { echo "ERROR: workflow does not build through repository Gradle Wrapper"; exit 1; }
if grep -E '^[[:space:]]*gradle --' "$WORKFLOW" | grep -v 'gradle --version' >/dev/null; then echo "ERROR: workflow invokes system Gradle directly for build tasks"; exit 1; fi
echo "PASS: AGP $AGP + Gradle $GRADLE + JDK 17 + pinned distribution + repository wrapper contract"
