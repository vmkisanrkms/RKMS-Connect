#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
M="$ROOT/app/src/main/java/com/majdoor/hisaab/model/Models.kt"
S="$ROOT/app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
L="$ROOT/app/src/main/java/com/majdoor/hisaab/calculation/LedgerCalculator.kt"
R="$ROOT/app/src/main/java/com/majdoor/hisaab/report/ReportEngine.kt"
req(){ grep -q "$1" "$2" || { echo "FAIL: $1"; exit 1; }; }
req 'data class Worker' "$M"; req 'data class WorkerWageHistory' "$M"; req 'data class WorkerDocument' "$M"
req 'data class Field' "$M"; req 'data class Crop' "$M"; req 'data class CropVariety' "$M"; req 'data class Team' "$M"
req 'data class Attendance' "$M"; req 'data class WorkRecord' "$M"; req 'data class Payment' "$M"; req 'data class Expense' "$M"
req 'data class Production' "$M"; req 'data class Revenue' "$M"; req 'data class BackupMetadata' "$M"; req 'var cropId:String' "$M"; req 'fun wageFor' "$S"; req 'schemaVersion = 4' "$S"
req 'worker_wage_history.json' "$S"; req 'crop_varieties.json' "$S"; req 'backup_metadata.json' "$S"; req 'migrateLocalModelIfNeeded' "$S"
req 'worker_wage_history' "$S"; req 'Cash\",\"Bank\",\"UPI' "$S"; req 'Worker not found' "$S"
req 'LedgerCalculator.summary' "$R"; req 'fun summary' "$L"; req 'validateRelationalFolder' "$S"
echo 'PHASE14_DATA_MODEL_GATE=PASS'
