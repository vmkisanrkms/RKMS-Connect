#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "PRODUCTION_SIGNING_GATE=FAIL: $*" >&2; exit 1; }
APK="${1:-artifacts/Majdoor-Hisaab-PRO-release.apk}"
test -s "$APK" || fail "signed Release APK missing"
command -v apksigner >/dev/null || fail "apksigner missing"
command -v zipalign >/dev/null || fail "zipalign missing"
command -v unzip >/dev/null || fail "unzip missing"
EXPECTED="${MH_RELEASE_CERT_SHA256:-}"
test -n "$EXPECTED" || fail "MH_RELEASE_CERT_SHA256 missing"
EXPECTED=$(printf '%s' "$EXPECTED" | tr -d ' ' | tr '[:lower:]' '[:upper:]')
# Signature validity, not merely presence.
apksigner verify --verbose --print-certs "$APK" | tee artifacts/production-signing-gate.txt
ACTUAL=$(apksigner verify --print-certs "$APK" | awk -F': ' '/Signer #1 certificate SHA-256 digest:/{print $2; exit}' | tr -d ' ' | tr '[:lower:]' '[:upper:]')
test -n "$ACTUAL" || fail "no signer certificate found"
test "$ACTUAL" = "$EXPECTED" || fail "APK signer is not the pinned production certificate"
# APK must be aligned and a valid ZIP.
unzip -t "$APK" >/dev/null || fail "APK ZIP integrity failed"
zipalign -c -v 4 "$APK" || fail "APK alignment failed"
# Reject obvious debug/test artifacts by package/signature contract.
PACKAGE="$(apkanalyzer manifest application-id "$APK")"
VERSION="$(apkanalyzer manifest version-name "$APK")"
VERSION_CODE="$(apkanalyzer manifest version-code "$APK")"
test "$PACKAGE" = "com.majdoor.hisaab" || fail "wrong package: $PACKAGE"
test "$VERSION" = "1.77.0" || fail "wrong versionName: $VERSION"
test "$VERSION_CODE" = "77" || fail "wrong versionCode: $VERSION_CODE"
echo "PRODUCTION_SIGNING_GATE=PASS"
