#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST="$ROOT/app/src/test/java/com/majdoor/hisaab/Phase16AutomatedTestSuite.kt"
[[ -f "$TEST" ]] || { echo "PHASE16_GATE=FAIL missing test suite"; exit 1; }
for n in $(seq 393 421); do
  grep -q "p${n}_" "$TEST" || { echo "PHASE16_GATE=FAIL missing p${n}"; exit 1; }
done
for anchor in 'ReportEngine.filter' 'store.upsertTeam' 'store.deleteCrop' 'expectIllegal { store.deleteField(field.id) }' 'store.health()' 'store.restore' 'security.verifyPin'; do grep -Fq "$anchor" "$TEST" || { echo "PHASE16_GATE=FAIL missing behavioral assertion anchor: $anchor"; exit 1; }; done
printf '%s\n' 'PHASE16_GATE=PASS' 'Coverage: 393-421 explicit automated tests with behavioral assertions present'
