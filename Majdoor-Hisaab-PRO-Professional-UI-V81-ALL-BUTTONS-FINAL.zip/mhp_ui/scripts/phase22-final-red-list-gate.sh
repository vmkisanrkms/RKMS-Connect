#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "PHASE22_RED_LIST_GATE=FAIL: $*" >&2; exit 1; }
TEST="app/src/androidTest/java/com/majdoor/hisaab/Phase22FinalRedListE2ETest.kt"
MAIN="app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
SOURCES="app/src/main/java/com/majdoor/hisaab"
BUILD="app/build.gradle.kts"
WORKFLOW=".github/workflows/build-release-apk.yml"
for f in "$TEST" "$MAIN" "$BUILD" "$WORKFLOW"; do test -s "$f" || fail "missing $f"; done
for n in $(seq 519 540); do grep -q "p${n}_" "$TEST" || fail "missing runtime/acceptance test p${n}_"; done
grep -q 'assembleRelease' "$WORKFLOW" || fail "Release APK assembly not wired"
grep -q 'apksigner sign' "$WORKFLOW" || fail "Release signing not wired"
grep -q 'adb install' "$WORKFLOW" || fail "APK installation not wired"
grep -q 'connectedE2eReleaseAndroidTest' "$WORKFLOW" || fail "real Android runtime test not wired"
grep -q 'production-signing-gate.sh' "$WORKFLOW" || fail "production signing gate not wired"
grep -q 'Phase22FinalRedListE2ETest' "$WORKFLOW" || fail "Phase 22 E2E test not wired"
if grep -qE 'assertTrue\([^)]*\|\| *true\)' "$TEST"; then fail 'trivial always-true assertion detected'; fi
if grep -q 'coreLocalStoreSmokeOnly' "$TEST"; then fail 'direct-store-only smoke test detected'; fi
grep -q 'phase22-final-red-list-gate.sh' "$WORKFLOW" || fail "Phase 22 gate not wired"
# Feature implementation anchors
for needle in 'fieldId' 'attendanceCalendar' 'auto_lock_timeout' 'selectedDatePattern' 'NotificationSettings' 'report_include_header' 'health()' 'openImport' 'auditLogScreen' 'Global Search'; do grep -R -q --include='*.kt' "$needle" "$SOURCES" || fail "implementation anchor missing: $needle"; done
# Release contract
 grep -q 'versionCode = 77' "$BUILD" || fail "versionCode not 77"
for f in scripts/debug-build-gate.sh scripts/release-build-gate.sh scripts/production-signing-gate.sh; do grep -qE 'version-code.*77|VERSION_CODE.*77|= "77"' "$f" || fail "stale versionCode in $f"; done
 grep -q 'versionName = "1.77.0"' "$BUILD" || fail "versionName not 1.77.0"
# Never accept the debug signing path for production.
if grep -qE 'signingConfig.*debug|assembleDebug.*production|debug\.keystore' "$WORKFLOW"; then fail "debug signing path detected"; fi
echo 'PHASE22_TESTS=22'
echo 'PHASE22_RED_LIST_GATE=PASS 519-540'
