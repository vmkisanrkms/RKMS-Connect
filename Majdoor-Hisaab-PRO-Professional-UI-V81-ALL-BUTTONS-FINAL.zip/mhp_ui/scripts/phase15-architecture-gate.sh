#!/usr/bin/env bash
set -euo pipefail
ROOT="app/src/main/java/com/majdoor/hisaab"
MAIN="$ROOT/MainActivity.kt"
fail=0
req=(
  "$ROOT/data/database/LocalDatabase.kt"
  "$ROOT/data/database/dao/Daos.kt"
  "$ROOT/data/repository/LocalRepository.kt"
  "$ROOT/domain/usecase/UseCases.kt"
  "$ROOT/domain/usecase/CrossCuttingUseCases.kt"
  "$ROOT/feature/AppServices.kt"
  "$ROOT/feature/Modules.kt"
  "$ROOT/feature/dashboard" "$ROOT/feature/workers" "$ROOT/feature/fields" "$ROOT/feature/crops"
  "$ROOT/feature/attendance" "$ROOT/feature/work" "$ROOT/feature/payments" "$ROOT/feature/expenses"
  "$ROOT/feature/reports" "$ROOT/feature/backup" "$ROOT/feature/settings" "$ROOT/feature/security" "$ROOT/feature/export"
  "$ROOT/feature/teams" "$ROOT/feature/accounting"
)
for p in "${req[@]}"; do [[ -e "$p" ]] || { echo "FAIL missing $p"; fail=1; }; done
if grep -Eq 'import com\.majdoor\.hisaab\.(storage|data\.repository\.LocalRepository)' "$MAIN"; then echo 'FAIL MainActivity imports storage/repository'; fail=1; fi
if grep -Eq 'LocalStore|LocalRepository|LocalDatabase|Dao\(' "$MAIN"; then echo 'FAIL MainActivity contains data-layer access'; fail=1; fi
if grep -Eq 'ReportService\(' "$MAIN"; then echo 'FAIL MainActivity constructs report service'; fail=1; fi
if grep -Eq 'execSQL|SQLiteDatabase|JSONObject\(|LedgerCalculator|WorkRateEngine|ReportEngine\.' "$MAIN"; then echo 'FAIL MainActivity contains persistence logic'; fail=1; fi
if grep -R -n 'import com\.majdoor\.hisaab\.storage\.LocalStore' app/src/main/java --exclude='LocalDatabase.kt' --exclude='LocalStore.kt' >/dev/null; then echo 'FAIL storage implementation bypass outside database boundary'; fail=1; fi
if grep -Eq 'LocalStore\(' app/src/main/java/com/majdoor/hisaab/data/repository/LocalRepository.kt; then echo 'FAIL Repository bypasses DAO'; fail=1; fi
if grep -qE '(private|internal) lateinit var app:AppServices' "$MAIN"; then echo 'PASS coordinator dependency boundary'; else echo 'FAIL AppServices boundary'; fail=1; fi
[[ $fail -eq 0 ]] || exit 1
if [[ $(wc -l < "$MAIN") -gt 260 ]]; then echo 'FAIL MainActivity remains a monolith'; fail=1; fi
[[ -s "$ROOT/MainActivityScreens.kt" ]] || { echo 'FAIL extracted screen layer missing'; fail=1; }
if grep -Eq 'val audit = repository|val teams = TeamUseCases\(repository\)|val accountingUseCases' "$ROOT/feature/AppServices.kt"; then echo 'FAIL AppServices exposes raw repository-backed objects'; fail=1; fi
if grep -R -n 'import com\.majdoor\.hisaab\.data\.repository\.LocalRepository' "$ROOT/feature" --include='*.kt' | grep -v 'feature/AppServices.kt' >/dev/null; then echo 'FAIL feature module bypasses composition root'; fail=1; fi
[[ $fail -eq 0 ]] || exit 1
echo 'PHASE15_ARCHITECTURE_GATE=PASS'
