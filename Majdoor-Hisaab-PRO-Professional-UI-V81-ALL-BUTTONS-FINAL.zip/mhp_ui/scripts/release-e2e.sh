#!/usr/bin/env bash
set -Eeuo pipefail
APK="${1:?signed APK path required}"
PKG="com.majdoor.hisaab"
ACT="com.majdoor.hisaab.MainActivity"
LOG="artifacts/release-e2e"
mkdir -p "$LOG/markers"
adb wait-for-device
adb shell getprop sys.boot_completed | grep -q '^1$'
adb logcat -c
adb uninstall "$PKG" >/dev/null 2>&1 || true
adb install "$APK"
touch "$LOG/markers/547_signed_apk_install.pass"
adb shell am start -W -n "$PKG/$ACT" | tee "$LOG/launch.txt"
sleep 2
adb shell pidof "$PKG" | grep -Eq '[0-9]+'
adb shell dumpsys activity activities | grep -q "$PKG"
touch "$LOG/markers/548_fresh_launch.pass"
# Real configuration change through Android's window manager/user rotation setting.
adb shell settings put system accelerometer_rotation 0 || true
adb shell settings put system user_rotation 1 || true
sleep 2
adb shell dumpsys activity activities | grep -q "$PKG"
touch "$LOG/markers/562_rotation.pass"
adb shell settings put system user_rotation 0 || true
sleep 2
adb shell dumpsys activity activities | grep -q "$PKG"
# Force-stop/relaunch.
adb shell am force-stop "$PKG"
sleep 1
if adb shell pidof "$PKG" >/dev/null 2>&1; then echo 'force-stop did not stop process' >&2; exit 1; fi
touch "$LOG/markers/560_force_stop.pass"
adb shell am start -W -n "$PKG/$ACT" | tee "$LOG/relaunch.txt"
sleep 2
adb shell pidof "$PKG" | grep -Eq '[0-9]+'
touch "$LOG/markers/549_relaunch_persistence.pass"
adb logcat -d -t 10000 > "$LOG/logcat.txt"
if grep -E 'FATAL EXCEPTION|AndroidRuntime.*FATAL|Process: com\.majdoor\.hisaab.*FATAL' "$LOG/logcat.txt"; then exit 1; fi
touch "$LOG/markers/563_crash_scan.pass"
adb shell dumpsys activity activities > "$LOG/activity.txt"
