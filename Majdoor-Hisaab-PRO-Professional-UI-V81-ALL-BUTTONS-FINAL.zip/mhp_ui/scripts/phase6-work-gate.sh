#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
SRC="$ROOT/app/src/main/java/com/majdoor/hisaab"
R="$ROOT/app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
M="$ROOT/app/src/main/java/com/majdoor/hisaab/model/Models.kt"
E="$ROOT/app/src/main/java/com/majdoor/hisaab/calculation/WorkRateEngine.kt"
T="$ROOT/app/src/test/java/com/majdoor/hisaab/WorkModuleContractTest.kt"
C="$ROOT/app/src/test/java/com/majdoor/hisaab/WorkCrudTest.kt"
U="$ROOT/app/src/androidTest/java/com/majdoor/hisaab/RealCoreWorkflowE2ETest.kt"
for f in "$A" "$R" "$M" "$E" "$T" "$C" "$U"; do test -s "$f" || { echo "Missing Phase 6 file: $f" >&2; exit 1; }; done
for needle in "Today's Work" "Work History" "+ Add Work" "Work Templates" "Work Detail" "Field:" "Crop:" "Workers:" "Work Type Presets" "Pick Start Time" "Pick End Time" "Save Work" "Edit"; do grep -RFq --include="*.kt" "$needle" "$SRC" || { echo "Missing UI capability: $needle" >&2; exit 1; }; done
for needle in Planting Sowing Weeding Harvesting Cutting Loading Irrigation Spraying Fertilizing Custom; do grep -Fq "\"$needle\"" "$E" || { echo "Missing work type: $needle" >&2; exit 1; }; done
for needle in DAILY HALF_DAY HOURLY AREA_ACRE QUANTITY PIECE; do grep -Fq "$needle" "$E" || { echo "Missing rate mode: $needle" >&2; exit 1; }; done
grep -RFq --include='*.kt' 'app.calculation.workCost(it)' "$SRC"
grep -RFq --include='*.kt' 'app.calculation.workCost(w)' "$SRC"
grep -Fq 'it.fingerprint()==x.fingerprint()' "$R"
grep -Fq 'audit(if(i>=0) "UPDATE" else "CREATE", "work"' "$R"
grep -Fq '"DELETE","work"' "$R"
grep -Fq 'work_json_round_trip_preserves_all_work_fields' "$T"
grep -Fq 'daily_rate_calculation' "$T"
grep -Fq 'half_day_calculation' "$T"
grep -Fq 'hourly_calculation_from_time' "$T"
grep -Fq 'acre_area_rate_calculation' "$T"
grep -Fq 'quantity_rate_calculation' "$T"
grep -Fq 'piece_rate_calculation' "$T"
grep -Fq 'multi_worker_allocation_preserves_total_cost' "$T"
grep -Fq 'duplicate_work_protection_is_deterministic' "$C"
grep -Fq 'work_create_read_update_delete_persists_every_field_and_audit' "$C"
grep -Fq 'work_template_create_update_delete_is_functional' "$C"
grep -Fq 'workAddEditDetailAndTodayHistoryAreRealUiFlows' "$U"
grep -Fq 'workType' "$M"
echo 'PHASE6_WORK_STATIC_GATE=PASS'
