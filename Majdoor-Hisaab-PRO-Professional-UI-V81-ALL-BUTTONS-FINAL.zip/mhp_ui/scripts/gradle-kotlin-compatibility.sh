#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROOT_BUILD="$ROOT/build.gradle.kts"
APP_BUILD="$ROOT/app/build.gradle.kts"
WORKFLOW="$ROOT/.github/workflows/build-release-apk.yml"
KOTLIN="$(sed -nE 's/.*org\.jetbrains\.kotlin\.android.*version "([0-9.]+)".*/\1/p' "$ROOT_BUILD" | head -1)"
[ "$KOTLIN" = "2.1.21" ] || { echo "ERROR: expected Kotlin 2.1.21, found ${KOTLIN:-missing}"; exit 1; }
grep -q 'jvmTarget = "17"' "$APP_BUILD" || { echo "ERROR: Kotlin JVM target 17 missing"; exit 1; }
grep -q 'compileDebugKotlin' "$WORKFLOW" || { echo "ERROR: Debug Kotlin compilation is not an explicit CI gate"; exit 1; }
grep -q 'compileE2eReleaseKotlin' "$WORKFLOW" || { echo "ERROR: E2E Release Kotlin compilation is not an explicit CI gate"; exit 1; }
grep -q 'compileReleaseKotlin' "$WORKFLOW" || { echo "ERROR: Release Kotlin compilation is not an explicit CI gate"; exit 1; }
echo "PASS: Kotlin 2.1.21 + JVM 17 + Debug/E2E/Release Kotlin compilation gates"
