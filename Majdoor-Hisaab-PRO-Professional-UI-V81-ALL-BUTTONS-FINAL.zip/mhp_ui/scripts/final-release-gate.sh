#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FINAL_RELEASE_GATE=FAIL: $*" >&2; exit 1; }
pass(){ echo "FINAL_RELEASE_GATE=$*"; }

TEST="app/src/androidTest/java/com/majdoor/hisaab/Phase22FinalRedListE2ETest.kt"
WORKFLOW=".github/workflows/build-release-apk.yml"
MAIN="app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
SOURCES="app/src/main/java/com/majdoor/hisaab"
STORE="app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
REPORT="app/src/main/java/com/majdoor/hisaab/report/ReportService.kt"
SEC="app/src/main/java/com/majdoor/hisaab/security/SecurityManager.kt"

for f in "$TEST" "$WORKFLOW" "$MAIN" "$STORE" "$REPORT" "$SEC"; do test -s "$f" || fail "missing $f"; done

# 541: all critical red points are represented and the Phase 22 gate is invoked.
for n in $(seq 519 540); do grep -q "p${n}_" "$TEST" || fail "missing p${n}"; done
./scripts/phase22-final-red-list-gate.sh >/dev/null || fail "Phase 22 red-list gate failed"
pass "541_RED_POINTS_STATIC=PASS"

# 542: orange/verification contracts for build, lifecycle, offline, security, reports and data safety.
for f in scripts/phase17-real-android-runtime-gate.sh scripts/phase18-configuration-lifecycle-gate.sh scripts/phase19-offline-first-gate.sh scripts/phase20-security-data-gate.sh scripts/phase11-reports-gate.sh; do test -x "$f" || fail "missing executable verification gate $f"; done
pass "542_ORANGE_VERIFICATION_GATES=READY"

# 543: reject trivial always-true assertions and obvious fake/stub UI handlers.
if grep -REn 'assert(True|False)\([^\n]*(\|\|[[:space:]]*true|true[[:space:]]*\|\|)' app/src/androidTest app/src/test; then fail "trivial always-true assertion found"; fi
if grep -REn 'TODO[[:space:]]*[:;]|throw[[:space:]]+NotImplementedException|onClick[[:space:]]*=.*TODO' app/src/main; then fail "known fake/unimplemented UI marker found"; fi
pass "543_NO_FAKE_STATIC_BUTTON_CONTRACT=PASS"

# 544: relational model must have health validation and linked-record validation.
grep -q 'fun health()' "$STORE" || fail "relational health missing"
grep -q 'references missing worker' "$STORE" || fail "worker relation validation missing"
grep -q 'references missing field' "$STORE" || fail "field relation validation missing"
grep -q 'fieldId' "$STORE" || fail "fieldId relation missing"
pass "544_RELATIONAL_DATA_HEALTH=PASS"
MAIN_LINES=$(wc -l < "$MAIN")
test "$MAIN_LINES" -le 260 || fail "MainActivity remains a monolith: ${MAIN_LINES} lines"
test -s app/src/main/java/com/majdoor/hisaab/MainActivityScreens.kt || fail "screen/coordinator extraction missing"
pass "544A_MAINACTIVITY_COORDINATOR_ARCHITECTURE=PASS"

# Runtime evidence from the signed-APK smoke and real emulator suites must exist before this final gate.
# The workflow creates these markers only after the corresponding command has completed successfully.
if [[ "${FINAL_GATE_STATIC_ONLY:-0}" == "1" ]]; then
  fail "FINAL release gate cannot pass in STATIC_ONLY mode; execute the signed APK runtime suite"
else
  for m in \
    artifacts/release-e2e/markers/547_signed_apk_install.pass \
    artifacts/release-e2e/markers/548_fresh_launch.pass \
    artifacts/release-e2e/markers/549_relaunch_persistence.pass \
    artifacts/release-e2e/markers/560_force_stop.pass \
    artifacts/release-e2e/markers/561_reboot_persistence.pass \
    artifacts/release-e2e/markers/562_rotation.pass \
    artifacts/release-e2e/markers/563_crash_scan.pass \
    artifacts/release-e2e/markers/550_offline_runtime.pass \
    artifacts/release-e2e/markers/552_553_clean_install_restore_totals.pass \
    artifacts/release-e2e/markers/554_security_runtime.pass \
    artifacts/release-e2e/markers/555_556_557_558_559_runtime.pass; do
    test -s "$m" || fail "runtime evidence missing: $m"
  done
  test -s artifacts/Majdoor-Hisaab-PRO-release.apk || fail "final signed APK missing"
  test -s artifacts/Majdoor-Hisaab-PRO-release.sha256 || fail "final APK SHA-256 missing"
  sha256sum -c artifacts/Majdoor-Hisaab-PRO-release.sha256 || fail "final APK SHA-256 does not match recorded checksum"
  command -v apksigner >/dev/null 2>&1 || fail "apksigner unavailable for final runtime gate"
  apksigner verify --verbose artifacts/Majdoor-Hisaab-PRO-release.apk >/dev/null || fail "signed APK verification failed"
  pass "RUNTIME_EVIDENCE_MARKERS=PASS"
fi

# 545: critical automated suites are wired into CI.
for t in Phase22FinalRedListE2ETest Phase18ConfigurationLifecycleE2ETest Phase19OfflineFirstE2ETest; do grep -q "$t" "$WORKFLOW" || fail "critical test suite $t not wired"; done
test -s app/src/androidTest/java/com/majdoor/hisaab/RotationAndErrorStateE2ETest.kt || fail "rotation/error E2E source missing"
test -s app/src/androidTest/java/com/majdoor/hisaab/RealCoreWorkflowE2ETest.kt || fail "core workflow E2E source missing"
test -s app/src/androidTest/java/com/majdoor/hisaab/CleanInstallBackupRestoreE2ETest.kt || fail "clean-install restore E2E source missing"
grep -q 'CleanInstallBackupRestoreE2ETest' "$WORKFLOW" || fail "clean-install restore E2E not wired"
grep -q './gradlew --no-daemon.*test' "$WORKFLOW" || fail "unit test execution missing"
pass "545_CRITICAL_AUTOMATED_TESTS_WIRED=PASS"

# 546-548: actual Release assembly, install, clean-install and launch must be CI hard requirements.
grep -q 'assembleRelease' "$WORKFLOW" || fail "assembleRelease missing"
grep -q 'apksigner sign' "$WORKFLOW" || fail "apksigner sign missing"
grep -q 'assembleReleaseAndroidTest' "$WORKFLOW" || fail "release instrumentation APK build missing"
grep -q 'Majdoor-Hisaab-PRO-release-androidTest.apk' "$WORKFLOW" || fail "signed release instrumentation artifact missing"
grep -q 'adb uninstall' scripts/release-e2e.sh || fail "clean install uninstall missing"
grep -q 'adb install.*APK' scripts/release-e2e.sh || fail "release APK install missing"
grep -q 'am start -W' scripts/release-e2e.sh || fail "fresh launch missing"
grep -q 'adb install' scripts/signed-release-reboot-gate.sh || fail "signed release install missing"
grep -q 'adb reboot' scripts/signed-release-reboot-gate.sh || fail "signed release reboot missing"
grep -q 'am instrument' scripts/signed-release-reboot-gate.sh || fail "signed release reboot instrumentation verification missing"
grep -q 'verifyAfterDeviceReboot' scripts/signed-release-reboot-gate.sh || fail "signed release reboot persistence verification missing"
pass "546_547_548_RELEASE_BUILD_INSTALL_FRESH_LAUNCH=WIRED"

# 549-550: persistence and offline runtime are explicit in the release workflow.
grep -q 'force-stop' scripts/release-e2e.sh || fail "force-stop/relaunch missing"
grep -q 'svc wifi disable' "$WORKFLOW" || fail "offline runtime switch missing"
grep -q 'svc data disable' "$WORKFLOW" || fail "mobile-data offline switch missing"
pass "549_550_RESTART_OFFLINE=WIRED"

# 551-553: backup/restore and totals are real implementation + automated contract requirements.
grep -q 'backupToInternal' "$STORE" || fail "backup creation missing"
grep -q 'restore(input' "$STORE" || fail "restore missing"
grep -q 'expectedPaymentTotal' app/src/test/java/com/majdoor/hisaab/CleanInstallBackupRestoreTest.kt || fail "restored totals contract missing"
grep -q 'expectedExpenseTotal' app/src/test/java/com/majdoor/hisaab/CleanInstallBackupRestoreTest.kt || fail "restored expense total contract missing"
grep -q 'expectedRevenueTotal' app/src/test/java/com/majdoor/hisaab/CleanInstallBackupRestoreTest.kt || fail "restored revenue total contract missing"
pass "551_552_553_BACKUP_RESTORE_TOTALS=PASS"

# 554: security runtime paths must exist and be exercised by unit/runtime contracts.
grep -q 'verifyPin' "$SEC" || fail "PIN verification missing"
grep -q 'BiometricPrompt' "$SEC" || fail "biometric prompt missing"
grep -R -q --include='*.kt' 'AutoLockManager.shouldLock' "$SOURCES" || fail "auto-lock runtime check missing"
grep -R -q --include='*.kt' 'Auto-Lock' "$SOURCES" || fail "auto-lock UI missing"
grep -R -q --include='*.kt' 'Security / PIN' "$SOURCES" || fail "PIN UI missing"
grep -R -q --include='*.kt' 'Biometric Unlock' "$SOURCES" || fail "biometric UI missing"
test -s app/src/test/java/com/majdoor/hisaab/AutoLockManagerTest.kt || fail "auto-lock unit test missing"
pass "554_PIN_BIOMETRIC_AUTOLOCK_CONTRACT=WIRED"

# 555-556: reports must derive from stored repository data and produce real CSV/PDF bytes.
grep -q 'store.workers()' "$REPORT" || fail "CSV worker report not data-backed"
grep -q 'LedgerCalculator.summary' "$REPORT" || fail "ledger report not data-backed"
grep -q 'PdfDocument' "$REPORT" || fail "PDF generation missing"
grep -q 'ByteArrayOutputStream' app/src/test/java/com/majdoor/hisaab/CleanInstallBackupRestoreTest.kt || fail "test infrastructure missing"
grep -q 'csvReport' app/src/main/java/com/majdoor/hisaab/domain/usecase/CrossCuttingUseCases.kt || fail "CSV export use case missing"
grep -q 'pdfReport' app/src/main/java/com/majdoor/hisaab/domain/usecase/CrossCuttingUseCases.kt || fail "PDF export use case missing"
grep -R -q --include='*.kt' 'Export .*CSV' "$SOURCES" || fail "CSV UI export missing"
grep -R -q --include='*.kt' 'Export .*PDF' "$SOURCES" || fail "PDF UI export missing"
pass "555_556_REPORT_DATA_AND_EXPORT=WIRED"

# 557-559: theme/date/search behavior is in real UI E2E coverage.
grep -q 'p527_' "$TEST"; grep -q 'p526_' "$TEST"; grep -q 'p533_' "$TEST"
grep -q 'p443_csvExportRuntime' app/src/androidTest/java/com/majdoor/hisaab/Phase17RealAndroidRuntimeE2ETest.kt || fail "real CSV runtime test missing"
grep -q 'p444_pdfExportRuntime' app/src/androidTest/java/com/majdoor/hisaab/Phase17RealAndroidRuntimeE2ETest.kt || fail "real PDF runtime test missing"
grep -q 'PdfRenderer' app/src/androidTest/java/com/majdoor/hisaab/Phase17RealAndroidRuntimeE2ETest.kt || fail "PDF open verification missing"
grep -R -q --include='*.kt' 'arrayOf("Light","Dark","System")' "$SOURCES" || fail "all theme modes missing"
pass "557_558_559_THEME_DATE_SEARCH=WIRED"

# 560-562: force-stop, reboot and rotation are CI contracts.
grep -q 'am force-stop' scripts/release-e2e.sh || fail "force-stop missing"
test -x scripts/phase18-device-reboot-gate.sh || fail "reboot gate missing"
test -x scripts/signed-release-reboot-gate.sh || fail "signed release reboot gate missing"
grep -q 'signed-release-reboot-gate.sh' "$WORKFLOW" || fail "signed release reboot gate not wired"
grep -q 'setOrientationLeft' app/src/androidTest/java/com/majdoor/hisaab/Phase18ConfigurationLifecycleE2ETest.kt || fail "rotation test missing"
pass "560_561_562_LIFECYCLE=WIRED"

# 563: critical crash signatures are hard failures in release/debug runtime smoke.
grep -q 'FATAL EXCEPTION' scripts/release-e2e.sh || fail "release crash scan missing"
grep -q 'FATAL EXCEPTION' "$WORKFLOW" || fail "workflow crash scan missing"
pass "563_CRASH_LOGCAT_AUDIT=WIRED"

# 564: clean GitHub-hosted runner, clean dependency resolution and full build are mandatory.
grep -q 'CLEAN_RUNNER=github-hosted-ubuntu-latest' "$WORKFLOW" || fail "clean runner assertion missing"
grep -q -- '--refresh-dependencies' "$WORKFLOW" || fail "fresh dependency resolution missing"
grep -q 'assembleRelease' "$WORKFLOW" || fail "clean runner release build missing"
pass "564_CLEAN_GITHUB_ACTIONS=WIRED"

# 565: final APK checksum must be generated and uploaded.
grep -q 'sha256sum "\$APK"' "$WORKFLOW" || fail "final SHA-256 generation missing"
grep -q 'sha256sum "\$APK"' "$WORKFLOW" || fail "final SHA-256 generation missing"
grep -q 'sha256sum "\$APK"' "$WORKFLOW" || fail "final SHA-256 generation missing"
grep -q 'Majdoor-Hisaab-PRO-release.sha256' "$WORKFLOW" || fail "final SHA-256 artifact missing"
pass "565_FINAL_APK_SHA256=WIRED"

# 566: final gate itself must be the last release blocker and must fail on unresolved red/orange conditions.
grep -q 'final-release-gate.sh' "$WORKFLOW" || fail "final 541-566 gate not invoked"
# Prevent CI from calling the final gate only after a command that is allowed to fail.
if grep -n 'final-release-gate.sh' "$WORKFLOW" | grep -q '|| true'; then fail "final gate is non-blocking"; fi
pass "566_NO_UNRESOLVED_RELEASE_BLOCKERS_STATIC=PASS"

pass "541_566_FINAL_GATE=PASS_RUNTIME_EVIDENCE"
echo "NOTE: Runtime PASS (APK build/install/device/reboot/signature/CSV-PDF open) is granted only by a green GitHub Actions run with production secrets; this local gate intentionally does not fake those results."
