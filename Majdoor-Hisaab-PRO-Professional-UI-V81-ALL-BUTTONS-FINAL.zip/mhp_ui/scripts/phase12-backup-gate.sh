#!/bin/sh
set -eu
fail(){ echo "FAIL: $1" >&2; exit 1; }
test -f app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt || fail "LocalStore missing"
test -f app/src/main/java/com/majdoor/hisaab/backup/AutoBackupReceiver.kt || fail "AutoBackupReceiver missing"
test -f app/src/main/java/com/majdoor/hisaab/backup/BootCompletedReceiver.kt || fail "BootCompletedReceiver missing"
grep -q 'fun backupToInternal' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'schemaVersion' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'createdAt' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'validateRelationalFolder' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'rollback_' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'Rollback snapshot verification failed' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'Existing data was not modified' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'validateRelationalFolder(data)' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'fun importBackupMerge' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'conflicting ID' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'Import rollback snapshot verification failed' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -R -q --include='*.kt' 'Restore backup?' app/src/main/java/com/majdoor/hisaab
grep -R -q --include='*.kt' 'Data Health' app/src/main/java/com/majdoor/hisaab
grep -q 'BOOT_COMPLETED' app/src/main/AndroidManifest.xml
grep -q 'MY_PACKAGE_REPLACED' app/src/main/AndroidManifest.xml
grep -q 'last_auto_backup' app/src/main/java/com/majdoor/hisaab/backup/BootCompletedReceiver.kt
grep -q 'setInexactRepeating' app/src/main/java/com/majdoor/hisaab/backup/BootCompletedReceiver.kt
test -f app/src/test/java/com/majdoor/hisaab/CleanInstallBackupRestoreTest.kt
test -f app/src/test/java/com/majdoor/hisaab/BackupPhase12Test.kt
echo 'PHASE12_BACKUP_STATIC_GATE=PASS'

grep -q 'validateManifestFiles' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
grep -q 'sha256' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt
echo PHASE12_BACKUP_METADATA_INTEGRITY_GATE=PASS
