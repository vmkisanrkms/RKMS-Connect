#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
A="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
R="$ROOT/app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt"
T="$ROOT/app/src/test/java/com/majdoor/hisaab/AttendanceModuleContractTest.kt"
C="$ROOT/app/src/test/java/com/majdoor/hisaab/LocalStoreCrudTest.kt"
for f in "$A" "$R" "$T" "$C"; do test -s "$f" || { echo "Missing required attendance source/test: $f" >&2; exit 1; }; done
grep -q 'DatePickerDialog' "$A"
grep -q 'fieldId' "$R"
grep -q 'it.date==x.date && it.workerId==x.workerId && it.fieldId==x.fieldId' "$R"
grep -q 'copyWorkersOnly' "$A"
grep -q 'statusAfterWorkerSelection' "$A"
grep -q 'All Full' "$A"
grep -q 'All Half' "$A"
grep -q 'Clear All' "$A"
grep -q 'Select All' "$A"
grep -q 'Save Current Team' "$A"
grep -q 'Apply Filters' "$A"
grep -q 'Confirm attendance change' "$A"
grep -q 'attendance_duplicate_rule_is_date_worker_and_field' "$C"
echo 'PHASE5_ATTENDANCE_STATIC_GATE=PASS'
