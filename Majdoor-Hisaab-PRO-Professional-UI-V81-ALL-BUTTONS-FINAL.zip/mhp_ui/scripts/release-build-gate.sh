#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail(){ echo "RELEASE_BUILD_GATE=FAIL: $*" >&2; exit 1; }
command -v unzip >/dev/null || fail "unzip missing"
test -x ./gradlew || fail "Gradle wrapper missing/executable bit not set"
test -f app/build.gradle.kts || fail "app build file missing"

grep -q 'versionCode = 77' app/build.gradle.kts || fail "unexpected versionCode"
grep -q 'versionName = "1.77.0"' app/build.gradle.kts || fail "unexpected versionName"
grep -q 'isMinifyEnabled = false' app/build.gradle.kts || fail "release minify configuration changed unexpectedly"

echo "[1/5] Release Kotlin compilation"
./gradlew --no-daemon --stacktrace :app:compileReleaseKotlin

echo "[2/5] Release APK assembly"
./gradlew --no-daemon --stacktrace :app:assembleRelease

APK="app/build/outputs/apk/release/app-release-unsigned.apk"
test -s "$APK" || fail "unsigned Release APK missing or empty"

command -v apkanalyzer >/dev/null || fail "apkanalyzer missing"
command -v zipalign >/dev/null || fail "zipalign missing"

PACKAGE="$(apkanalyzer manifest application-id "$APK")"
VERSION="$(apkanalyzer manifest version-name "$APK")"
VERSION_CODE="$(apkanalyzer manifest version-code "$APK")"
[ "$PACKAGE" = "com.majdoor.hisaab" ] || fail "wrong applicationId: $PACKAGE"
[ "$VERSION_CODE" = "77" ] || fail "wrong versionCode: $VERSION_CODE"
[ "$VERSION" = "1.77.0" ] || fail "wrong versionName: $VERSION"

# Ensure the APK is a valid ZIP/APK and has a manifest before signing.
unzip -t "$APK" >/dev/null || fail "unsigned Release APK ZIP integrity check failed"
unzip -l "$APK" | grep -q 'AndroidManifest.xml' || fail "AndroidManifest.xml missing"

mkdir -p artifacts/release-build
cp "$APK" artifacts/release-build/app-release-unsigned.apk
sha256sum "$APK" | tee artifacts/release-build/app-release-unsigned.sha256
printf 'applicationId=%s\nversionCode=%s\nversionName=%s\n' "$PACKAGE" "$VERSION_CODE" "$VERSION" > artifacts/release-build/release-build-metadata.txt

echo "[3/5] Release APK metadata and ZIP integrity verified"
echo "[4/5] Release output is ready for production signing"
echo "[5/5] Release build gate complete"
echo "RELEASE_BUILD_GATE=PASS"
