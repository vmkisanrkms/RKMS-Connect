#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAIN="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
SOURCES="$ROOT/app/src/main/java/com/majdoor/hisaab"
SCREENS="$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivityScreens.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
[[ -f "$MAIN" && -f "$MANIFEST" ]] || { echo "PHASE21_UI_GATE=FAIL missing sources"; exit 1; }
grep -R -q --include='*.kt' 'dd-MM-yyyy' "$SOURCES" && true || { echo "PHASE21_UI_GATE=FAIL date format"; exit 1; }
grep -q 'android:windowSoftInputMode="adjustResize"' "$MANIFEST" || { echo "PHASE21_UI_GATE=FAIL keyboard resize"; exit 1; }
grep -q 'fun MainActivity.dp(v:Int)' "$SCREENS" || { echo "PHASE21_UI_GATE=FAIL dp helper"; exit 1; }
grep -q 'override fun onBackPressed' "$MAIN" || { echo "PHASE21_UI_GATE=FAIL back navigation"; exit 1; }
grep -R -q --include='*.kt' 'minHeight=dp(48)' "$SOURCES" || { echo "PHASE21_UI_GATE=FAIL button touch target"; exit 1; }
# Reject the known raw header dimensions that previously caused density-dependent layouts.
if grep -Eq 'LayoutParams\((55|58|110|48|52|55),[0-9]+' "$MAIN"; then echo "PHASE21_UI_GATE=FAIL raw interactive dimensions"; exit 1; fi
# Require explicit long-number auto sizing and meaningful error/empty/loading primitives.
grep -R -q --include='*.kt' 'setAutoSizeTextTypeUniformWithConfiguration' "$SOURCES" || { echo "PHASE21_UI_GATE=FAIL number/text autosize"; exit 1; }
grep -R -q --include='*.kt' 'showErrorState' "$SOURCES" || { echo "PHASE21_UI_GATE=FAIL error state"; exit 1; }
grep -R -q --include='*.kt' 'Loading your local records' "$SOURCES" || { echo "PHASE21_UI_GATE=FAIL loading state"; exit 1; }
echo "PHASE21_UI_GATE=PASS 499-518 structural checks"
