#!/usr/bin/env bash
set -Eeuo pipefail
APK="${1:?signed release APK path required}"
TEST_APK="${2:?signed release androidTest APK path required}"
PKG="com.majdoor.hisaab"
TEST_PKG="com.majdoor.hisaab.test"
RUNNER="androidx.test.runner.AndroidJUnitRunner"
CLASS="com.majdoor.hisaab.Phase18DeviceRebootPersistenceE2ETest"
LOG="artifacts/release-e2e"
mkdir -p "$LOG/markers"
test -s "$APK"
test -s "$TEST_APK"
adb wait-for-device
adb shell getprop sys.boot_completed | tr -d '\r' | grep -q '^1$'
adb uninstall "$TEST_PKG" >/dev/null 2>&1 || true
adb uninstall "$PKG" >/dev/null 2>&1 || true
adb install "$APK" >/dev/null
adb install "$TEST_APK" >/dev/null
adb shell pm path "$PKG" | grep -q 'base.apk'
adb shell pm path "$TEST_PKG" | grep -q 'base.apk'

# Seed the production-signed app through its instrumentation APK, so the app data
# is created by the exact same signed release that will survive the reboot.
adb shell am instrument -w -e class "${CLASS}#seedBeforeDeviceReboot" "$TEST_PKG/$RUNNER" | tee "$LOG/reboot-seed.txt"

adb shell am force-stop "$PKG"
adb shell am start -W -n "$PKG/com.majdoor.hisaab.MainActivity" | tee "$LOG/signed-before-reboot.txt"
sleep 2
adb shell pidof "$PKG" | grep -Eq '[0-9]+'

adb reboot
adb wait-for-device
for i in $(seq 1 90); do
  if adb shell getprop sys.boot_completed | tr -d '\r' | grep -q '^1$'; then break; fi
  sleep 2
done
adb shell getprop sys.boot_completed | tr -d '\r' | grep -q '^1$'
adb shell am start -W -n "$PKG/com.majdoor.hisaab.MainActivity" | tee "$LOG/signed-after-reboot.txt"
sleep 3
adb shell pidof "$PKG" | grep -Eq '[0-9]+'

# The instrumentation test reads the target application's persisted LocalStore after reboot.
adb shell am instrument -w -e class "${CLASS}#verifyAfterDeviceReboot" "$TEST_PKG/$RUNNER" | tee "$LOG/reboot-verify.txt"

touch "$LOG/markers/561_reboot_persistence.pass"
adb logcat -d -t 15000 > "$LOG/signed-reboot-logcat.txt"
if grep -E 'FATAL EXCEPTION|AndroidRuntime.*FATAL|Process: com\.majdoor\.hisaab.*FATAL' "$LOG/signed-reboot-logcat.txt"; then exit 1; fi
echo 'SIGNED_RELEASE_REBOOT_PERSISTENCE=PASS'
