#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEST="$ROOT/app/src/androidTest/java/com/majdoor/hisaab/Phase18ConfigurationLifecycleE2ETest.kt"
for n in $(seq 451 468); do
  grep -q "p${n}_" "$TEST" || { echo "PHASE18_MISSING_TEST=$n"; exit 1; }
done
# Production must remain offline-first.
! grep -Rqs 'android.permission.INTERNET' "$ROOT/app/src/main/AndroidManifest.xml"
# Loading/no-data/error recovery and lifecycle persistence must remain implemented.
grep -R -q --include='*.kt' 'Loading your local records' "$ROOT/app/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'No recent activity' "$ROOT/app/src/main/java/com/majdoor/hisaab"
grep -R -q --include='*.kt' 'Something went wrong' "$ROOT/app/src/main/java/com/majdoor/hisaab"
grep -q 'onSaveInstanceState' "$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
grep -q 'override fun onResume' "$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
grep -q 'override fun onPause' "$ROOT/app/src/main/java/com/majdoor/hisaab/MainActivity.kt"
echo 'PHASE18_TESTS=18'
echo 'PHASE18_CONFIGURATION_LIFECYCLE_GATE=PASS'
