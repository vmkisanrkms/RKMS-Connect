#!/usr/bin/env bash
set -euo pipefail
A=app/src/main/java/com/majdoor/hisaab/MainActivity.kt
SRC=app/src/main/java/com/majdoor/hisaab
E=app/src/main/java/com/majdoor/hisaab/report/ReportEngine.kt
S=app/src/main/java/com/majdoor/hisaab/report/ReportService.kt
T=app/src/test/java/com/majdoor/hisaab/ReportEngineTest.kt
for x in "$A" "$E" "$S" "$T"; do test -f "$x" || { echo "FAIL missing $x"; exit 1; }; done
for x in 'Reports Home' 'Daily Labour' 'Weekly Labour' 'Monthly Labour' 'Worker Report' 'Field Report' 'Crop Report' 'Attendance Report' 'Payment Report' 'Expense Report' 'Outstanding Report' 'Labour Cost Report' 'Profit/Loss Report' 'Custom Report' 'Report Filters'; do grep -RFq "$x" "$SRC" || { echo "FAIL missing report $x"; exit 1; }; done
for x in 'workerId' 'fieldId' 'cropId' 'from' 'to'; do grep -Fq "$x" "$E" || { echo "FAIL missing filter $x"; exit 1; }; done
for x in 'periodFilter' 'Daily Labour' 'Weekly Labour' 'Monthly Labour'; do grep -Fq "$x" "$E" || { echo "FAIL missing period logic $x"; exit 1; }; done
for x in 'csvReport' 'pdfReport' 'report_csv_bom'; do grep -Fq "$x" "$S" || { echo "FAIL missing export $x"; exit 1; }; done
for x in 'report_periods_are_deterministic' 'report_profit_loss_is_revenue_minus_labour_minus_expense' 'report_entity_filters_are_combined'; do grep -Fq "$x" "$T" || { echo "FAIL missing test $x"; exit 1; }; done
echo 'PHASE11_REPORTS_STATIC_GATE=PASS'
