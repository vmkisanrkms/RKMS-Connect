#!/usr/bin/env bash
set -Eeuo pipefail
fail(){ echo "PHASE1_POINTS_18_25=FAIL: $*" >&2; exit 1; }
APK="${1:-artifacts/Majdoor-Hisaab-PRO-release.apk}"
command -v sha256sum >/dev/null || fail "sha256sum missing"
test -s "$APK" || fail "Release APK missing: $APK"
mkdir -p "$(dirname "$APK")"
sha256sum "$APK" | tee "${APK}.sha256"
test -s "${APK}.sha256" || fail "SHA-256 file was not generated"
command -v apkanalyzer >/dev/null || fail "apkanalyzer missing"
command -v adb >/dev/null || fail "adb missing"
PKG="$(apkanalyzer manifest application-id "$APK")"
test "$PKG" = "com.majdoor.hisaab" || fail "wrong package: $PKG"
echo "PHASE1_POINTS_18_25=PASS: SHA-256 generated; APK ready for install/launch verification"
