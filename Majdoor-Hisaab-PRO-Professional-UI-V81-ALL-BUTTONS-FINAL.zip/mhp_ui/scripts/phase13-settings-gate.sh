#!/bin/sh
set -eu
MAIN=app/src/main/java/com/majdoor/hisaab/MainActivity.kt
SRC=app/src/main/java/com/majdoor/hisaab
fail(){ echo "ERROR: Phase 13 settings gate failed: $*" >&2; exit 1; }
test -f "$MAIN" || fail "MainActivity missing"
grep -R -q --include='*.kt' 'Farm Profile' "$SRC" || fail "Farm Profile missing"
grep -R -q --include='*.kt' 'wageSettingsDialog' "$SRC" || fail "Wage Settings missing"
grep -R -q --include='*.kt' 'putString("currency"' "$SRC" || fail "Currency persistence missing"
grep -R -q --include='*.kt' 'putString("date_format"' "$SRC" || fail "Date format persistence missing"
grep -R -q --include='*.kt' 'setTheme(if(dark)' "$SRC" || fail "Theme application missing"
grep -R -q --include='*.kt' 'putString("theme"' "$SRC" || fail "Theme persistence missing"
grep -R -q --include='*.kt' 'UI_MODE_NIGHT_MASK' "$SRC" || fail "System theme detection missing"
grep -R -q --include='*.kt' 'Security / PIN' "$SRC" || fail "Security settings missing"
grep -R -q --include='*.kt' 'AutoLockManager.shouldLock' "$SRC" || fail "Auto-lock missing"
grep -R -q --include='*.kt' 'backupSettingsDialog' "$SRC" || fail "Backup Settings missing"
grep -R -q --include='*.kt' 'notificationSettingsDialog' "$SRC" || fail "Notification Settings missing"
grep -R -q --include='*.kt' 'reportSettingsDialog' "$SRC" || fail "Report Settings missing"
grep -R -q --include='*.kt' 'BuildConfig.VERSION_NAME' "$SRC" || fail "Dynamic version missing"
grep -R -q --include='*.kt' 'License:' "$SRC" || fail "License info missing"
test -f LICENSE || fail "LICENSE missing"
echo PHASE13_SETTINGS_STATIC_GATE=PASS

grep -R -q --include='*.kt' 'autoLockChecker' "$SRC" || fail "foreground auto-lock checker missing"
grep -R -q --include='*.kt' 'selectedDatePattern' "$SRC" || fail "central date format helper missing"
grep -R -q --include='*.kt' 'logSettingChange' "$SRC" || fail "settings audit logging missing"
grep -q 'validateManifestFiles' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt || fail "backup metadata validation missing"
grep -q 'fileCount' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt || fail "backup metadata file count missing"
echo PHASE13_HARDENED_SETTINGS_AND_DATA_SAFETY_GATE=PASS
