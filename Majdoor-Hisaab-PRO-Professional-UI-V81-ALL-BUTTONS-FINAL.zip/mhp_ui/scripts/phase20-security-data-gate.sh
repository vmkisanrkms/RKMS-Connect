#!/usr/bin/env bash
set -euo pipefail
fail(){ echo "PHASE20_SECURITY_DATA_GATE=FAIL: $1"; exit 1; }
grep -q 'atomicMutation' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt || fail "atomic helper missing"
grep -q 'Duplicate expense detected' app/src/main/java/com/majdoor/hisaab/storage/LocalStore.kt || fail "expense duplicate guard missing"
! grep -RInE 'android\.util\.Log\.|println\(|printStackTrace\(' app/src/main/java >/dev/null || fail "production logging found"
! grep -RInE 'pin[[:space:]]*[:=][[:space:]]*"[0-9]{4,}"|password[[:space:]]*[:=][[:space:]]*"' app/src/main >/dev/null || fail "hard-coded secret found"
grep -q 'android:allowBackup="false"' app/src/main/AndroidManifest.xml || fail "platform backup not controlled"
for n in {482..498}; do grep -q "p${n}_" app/src/test/java/com/majdoor/hisaab/Phase20SecurityDataAuditTest.kt || fail "missing test p${n}"; done
echo 'PHASE20_SECURITY_DATA_GATE=PASS'
