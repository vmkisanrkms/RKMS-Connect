#!/usr/bin/env bash
set -Eeuo pipefail
TEST="app/src/androidTest/java/com/majdoor/hisaab/Phase17RealAndroidRuntimeE2ETest.kt"
test -s "$TEST"
for n in $(seq 422 450); do grep -q "p${n}_" "$TEST" || { echo "PHASE17_MISSING=$n"; exit 1; }; done
count=$(grep -c '@Test fun p4[2-5][0-9]_' "$TEST")
test "$count" -eq 29
grep -q 'connectedE2eReleaseAndroidTest' .github/workflows/build-release-apk.yml
printf 'PHASE17_REAL_ANDROID_RUNTIME_GATE=PASS\nPHASE17_TESTS=%s\n' "$count"
