# Auto-backup reboot fix

- Added `RECEIVE_BOOT_COMPLETED` permission.
- Added `BootCompletedReceiver` for `BOOT_COMPLETED` and `MY_PACKAGE_REPLACED`.
- When automatic backup is enabled, the receiver restores the 24-hour alarm after reboot/app replacement.
- If the previous backup is overdue by 24 hours or more, one backup is attempted immediately before scheduling the next alarm.
- Existing alarm is cancelled before rescheduling to prevent duplicate alarms.
- Manual backup remains unchanged.
