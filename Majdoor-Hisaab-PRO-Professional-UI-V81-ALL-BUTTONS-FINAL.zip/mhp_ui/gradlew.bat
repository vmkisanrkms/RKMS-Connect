@echo off
setlocal
set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"
for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionUrl=" "%PROPS%"') do set "DIST_URL=%%B"
set "DIST_URL=%DIST_URL:\:=:%"
for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionSha256Sum=" "%PROPS%"') do set "EXPECTED_SHA=%%B"
for /f "tokens=1,* delims=-" %%A in ("%DIST_URL%") do set "VERSION=%%B"
set "VERSION=%VERSION:-bin.zip=%"
if "%VERSION%"=="" set "VERSION=8.11.1"
set "GRADLE_HOME=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\bootstrap"
if exist "%GRADLE_HOME%\gradle-dist\bin\gradle.bat" goto run
mkdir "%GRADLE_HOME%" 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='%DIST_URL%'; $z='%GRADLE_HOME%\gradle.zip'; $expected='%EXPECTED_SHA%'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $z; $actual=(Get-FileHash -Algorithm SHA256 $z).Hash.ToLower(); if($actual -ne $expected.ToLower()){Remove-Item $z -Force; throw 'Gradle distribution SHA-256 mismatch'}; Expand-Archive -Force $z '%GRADLE_HOME%\unpacked'; Remove-Item $z; $d=Get-ChildItem '%GRADLE_HOME%\unpacked' -Directory | Select-Object -First 1; Move-Item $d.FullName '%GRADLE_HOME%\gradle-dist'; Remove-Item '%GRADLE_HOME%\unpacked' -Recurse -Force"
:run
call "%GRADLE_HOME%\gradle-dist\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
