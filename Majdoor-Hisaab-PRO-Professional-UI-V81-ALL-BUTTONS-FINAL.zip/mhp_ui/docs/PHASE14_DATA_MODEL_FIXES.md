# Phase 14 Data Model Fixes

Added first-class persisted entities for WorkerWageHistory, CropVariety and BackupMetadata; wired them into LocalStore, backup/restore, import, relational validation and migration. Added Phase14DataModelTest and phase14-data-model-gate.sh.
