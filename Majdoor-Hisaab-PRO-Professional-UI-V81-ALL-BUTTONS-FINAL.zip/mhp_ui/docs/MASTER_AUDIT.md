# Master Audit Gates

## Architecture
- No SQLite / Room / Realm / Supabase / Firebase database.
- JSON storage gateway is the only persistence path.
- IDs are UUIDs.
- Modules use repositories/services instead of UI-only state.

## Critical
- Worker CRUD + ID stability
- Attendance persistence/editing
- Full/Half/None explicit status
- All Full / All Half / Clear All
- Previous Team workers-only copy
- Duplicate attendance prevention
- Wage calculation
- Worker ledger / advances / outstanding
- Work↔Worker / Field / Crop IDs
- Work edit/delete + duplicate protection
- Backup/restore + import validation

## Extended
- Expenses
- Crop/Field costing
- Production
- Revenue
- Profitability
- Reports
- PDF/CSV export
- Search/filter/sort
- PIN/biometric
- Theme
- Notifications
- Professional UI

## Release gates
1. Gradle compile
2. Unit tests
3. Clean install
4. Restart persistence
5. Offline operation
6. Backup -> uninstall -> reinstall -> restore
7. Attendance scenario tests
8. Ledger calculation tests
9. APK artifact validation
10. Final end-to-end audit
