# Phase 6 — Work — V60 Re-audit

## Audit result
Static source/gate audit completed for points 148–188.

### Fixes found during re-audit
1. Work History filters were using only active fields/crops/workers, which could hide historical Work records after a linked entity was deactivated. Filters now use all stored entities so historical records remain discoverable.
2. Work Detail had no direct per-record audit-history navigation. Added `Work Audit History`, showing CREATE/UPDATE/DELETE events for that exact Work record.
3. Calculation tests were strengthened with hourly quantity fallback and overnight-shift cases.
4. CRUD tests were strengthened for invalid HH:mm and crop/field relationship validation.
5. Real Android Work E2E now opens Work Audit History and verifies a CREATE event before editing.

## Point audit
148 Today's Work — source PASS
149 Add Work — source PASS
150 Work Detail — source PASS
151 Edit Work — source PASS
152 Work History — source PASS; historical inactive-linked records remain filterable after V60 fix
153 Field Work — source PASS
154 Crop Work — source PASS
155 Worker Work — source PASS
156 Work Templates — source + CRUD test PASS
157 Date save — persistence test PASS
158 Field save — persistence test PASS
159 Crop save — persistence test PASS
160 Workers save — persistence test PASS
161 Work Type save — persistence test PASS
162 Quantity save — persistence test PASS
163 Unit save — persistence test PASS
164 Rate save — persistence test PASS
165 Labour Cost calculation — centralized engine + tests PASS
166 Start Time save — round-trip + CRUD test PASS
167 End Time save — round-trip + CRUD test PASS
168 Notes save — round-trip + CRUD test PASS
169 Planting — preset PASS
170 Sowing — preset PASS
171 Weeding — preset PASS
172 Harvesting — preset PASS
173 Cutting — preset PASS
174 Loading — preset PASS
175 Irrigation — preset PASS
176 Spraying — preset PASS
177 Fertilizing — preset PASS
178 Custom — preset/free-text PASS
179 Daily rate — automated test PASS
180 Half-day — automated test PASS
181 Hourly — automated tests PASS, including explicit time and quantity fallback
182 Acre/area rate — automated test PASS
183 Quantity rate — automated test PASS
184 Piece rate — automated test PASS
185 Multi-worker allocation — automated test PASS
186 Duplicate protection — deterministic CRUD test PASS
187 Work edit audit/history — audit log + per-record UI history + E2E check PASS at source/test level
188 Work calculation automated tests — source suite PASS; actual execution remains CI-dependent

## Verification
- `scripts/phase6-work-gate.sh`: PASS
- `scripts/acceptance-gates.sh`: PASS through all static gates
- Actual Gradle/emulator execution was attempted locally but could not start because Gradle 8.11.1 could not be downloaded: DNS resolution for `services.gradle.org` failed.
