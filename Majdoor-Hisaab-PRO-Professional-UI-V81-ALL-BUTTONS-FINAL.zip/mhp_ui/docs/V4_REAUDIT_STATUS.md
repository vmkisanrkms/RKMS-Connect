# Majdoor Hisaab PRO V4 — Re-audit status

This revision is based on the uploaded Master Blueprint and the later explicit requirement for JSON/local phone storage instead of SQLite/Room.

Implemented in this revision:
- Worker documents persisted in `worker_documents.json`.
- Work templates persisted in `work_templates.json` and can be applied to work entry.
- Worker, field and crop profile navigation.
- Attendance history/detail/calendar navigation.
- Payment ledger and outstanding views.
- Custom date report and differentiated report calculations.
- Auto-backup preference performs a once-per-24-hours local backup when the app starts.
- Backup allow-list includes all new JSON stores.
- Previous Team continues to copy workers only and resets copied attendance to NONE.
- Worker selection and attendance status remain separate.

Not claimed as device-verified: Android release compilation and installation on a physical device were not executed in this environment. GitHub Actions remains the authoritative release-build gate.
