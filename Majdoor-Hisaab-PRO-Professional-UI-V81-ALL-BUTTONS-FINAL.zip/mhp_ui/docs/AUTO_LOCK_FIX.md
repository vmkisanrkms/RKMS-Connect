# Auto-Lock Fix — V16

Implemented real inactivity-based app auto-lock.

- Settings → Auto-Lock: Off / 1 / 5 / 10 / 15 / 30 / 60 minutes.
- Requires an app PIN; no PIN means Auto-Lock cannot lock the app.
- User touch/activity resets the inactivity timer.
- Going to background starts the background lock timer.
- Returning after the selected timeout locks the app.
- Lock requires PIN or configured biometric.
- Manual lock state is in-memory; records remain in local storage.
- Unit tests cover timeout mapping, lock threshold, PIN requirement, unlocked state and Off mode.
