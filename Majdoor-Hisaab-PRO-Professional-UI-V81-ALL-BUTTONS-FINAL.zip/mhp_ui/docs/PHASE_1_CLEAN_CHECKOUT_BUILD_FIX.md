# Phase 1 — Clean Checkout Build & Release Gate Fix

## Requirement
A fresh GitHub checkout must build the project without any manual file modification.

## Fix
- GitHub Actions provisions Gradle 8.11.1 directly with `gradle/actions/setup-gradle@v4`.
- The workflow no longer depends on a repository-local `gradlew` bootstrap script.
- Clean checkout runs unit tests plus `assembleDebug`, `assembleE2eRelease`, and `assembleRelease`.
- Android SDK/API 35 and Build Tools 35.0.0 are provisioned by the workflow.
- The acceptance gate verifies the pinned Gradle version and exact clean-checkout build command.

## Important
This proves the repository is configured for an unattended clean-checkout CI build. Actual GitHub execution must still complete successfully before claiming runtime/build PASS.
