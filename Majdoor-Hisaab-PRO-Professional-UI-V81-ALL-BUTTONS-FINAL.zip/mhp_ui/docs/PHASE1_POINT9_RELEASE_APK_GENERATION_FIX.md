# Phase 1 Point 9 — Release APK वास्तव में generate होना

## Required evidence
1. `:app:compileReleaseKotlin` succeeds.
2. `:app:assembleRelease` succeeds.
3. `app/build/outputs/apk/release/app-release-unsigned.apk` exists and is non-empty.
4. APK ZIP integrity and AndroidManifest are verified.
5. applicationId and versionName are verified.
6. Production signing creates `artifacts/Majdoor-Hisaab-PRO-release.apk`.
7. `apksigner verify` succeeds on the signed APK.
8. Signed APK is installed and launched on API 35 emulator.
9. SHA-256 checksum is emitted as a build artifact.

Point 9 is not considered fully runtime-verified until the GitHub Actions run produces all of the above artifacts successfully.
