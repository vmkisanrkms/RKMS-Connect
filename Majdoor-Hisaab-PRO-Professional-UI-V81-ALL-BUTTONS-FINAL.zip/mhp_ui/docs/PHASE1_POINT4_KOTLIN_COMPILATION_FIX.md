# Phase 1 Point 4 — Kotlin compilation

- Kotlin plugin pinned to 2.1.21.
- JVM target pinned to 17.
- GitHub Actions explicitly runs compileDebugKotlin, compileE2eReleaseKotlin and compileReleaseKotlin before packaging.
- Static compatibility gate rejects missing/mismatched Kotlin version, JVM target, or compilation tasks.
- Actual compilation requires a GitHub Actions runner with dependency/network access; source-side gate must not be reported as a runtime build PASS.
