# CRUD + Attendance Field-ID Fix

## Fixed
- Attendance screen now has an explicit optional **Field** selector.
- Saving attendance persists the selected `fieldId` for every selected worker.
- Existing attendance edits preserve/change `fieldId` through the Edit Attendance screen.
- Attendance detail can edit and delete the record.
- Added `LocalStore.deleteTeam()` and worker validation for saved teams.
- Added repository-level automated CRUD tests using the real JSON `LocalStore`.
- CRUD coverage includes workers, fields, crops, attendance, teams, work, payments, expenses, production, revenue, worker documents and work templates.
- Added backup/restore regression proving an attendance record keeps its `fieldId` after a round trip.

## Required CI command
`gradle :app:testDebugUnitTest`

The tests are designed to fail if the attendance field ID is dropped during save, update, JSON serialization or backup/restore.
