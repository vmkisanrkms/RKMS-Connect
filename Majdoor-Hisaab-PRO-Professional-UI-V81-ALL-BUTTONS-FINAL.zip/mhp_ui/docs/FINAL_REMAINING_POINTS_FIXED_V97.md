# Majdoor Hisaab PRO — Remaining Points Fix Record

## Scope
This revision addresses the remaining source-level gaps identified in the V96 end-to-end audit.

## Fixed in source
- Release target upgraded to Android API 36 / compileSdk 36 / targetSdk 36 / Build Tools 36.0.0.
- Worker wage history is now exposed as a real UI module with add/list/delete flows and repository/DAO/use-case write path.
- Crop Variety Master is now a real UI CRUD surface backed by crop-variety storage.
- Custom Report now uses the app's actual date picker/date-format pipeline and rejects an inverted date range.
- Global Search now searches worker reference/address/notes and field irrigation/notes in addition to existing fields, with detail navigation.
- Existing notification settings, report settings, auto-lock, date format, theme, backup/restore, relational health and audit-log implementations remain wired to real storage/services.
- Release CI is configured for API 36 emulator/build packages.
- CI release workflow retains signed-APK install, clean-install, offline, rotation, force-stop/relaunch, reboot, crash scan, backup/restore and final 541–566 gating.

## Verification performed in this environment
- Shell syntax: PASS.
- API 36 configuration scan: PASS.
- Phase 15 architecture gate: PASS.
- Phase 16 automated-test gate: PASS.
- Phase 20 security/data gate: PASS.
- Phase 21 UI gate: PASS.
- Phase 22 red-list gate: PASS.
- Final 541–566 static wiring gate: PASS.

## Runtime limitation
A local Gradle build could not be executed because the environment could not resolve `services.gradle.org` while downloading Gradle 8.11.1. Runtime release PASS therefore remains dependent on a successful GitHub Actions run with the production signing secrets and Android emulator.
