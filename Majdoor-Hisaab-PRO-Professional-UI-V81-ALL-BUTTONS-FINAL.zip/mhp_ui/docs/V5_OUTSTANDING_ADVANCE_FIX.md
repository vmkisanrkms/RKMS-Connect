# V5 Outstanding / Advance Calculation Fix

## Rule
For a worker:
- Earned = attendance earned + allocated work earned
- Normal Paid = payments where advance=false
- Advance = payments where advance=true
- Total Paid = Normal Paid + Advance
- Outstanding = max(0, Earned - Total Paid)
- Credit/Overpaid = max(0, Total Paid - Earned)

Advance is a real cash payment and therefore reduces outstanding exactly once. It is displayed separately for transparency.

## Changes
- Added a single `LedgerSummary` calculation model in `LedgerCalculator`.
- Worker profile, worker ledger, payment ledger, outstanding screen, CSV ledger and PDF summary now consume the same summary.
- Removed direct duplicated `earned-paid-advance` formulas from UI/report code.
- Outstanding no longer becomes negative; overpayment is shown as Credit / Overpaid.
- Added unit tests for exact advance subtraction and overpayment behavior.

## Verification
Static source scan confirms no remaining direct `earned-paid-adv` formula in main/report code.
Full Android/Gradle build is not claimed here because the current environment has no Android Gradle toolchain available.
