# V6 Work Rate Engine Fix

Implemented a single `WorkRateEngine` used by ledger and work-cost displays.

Supported modes:
- DAILY: quantity × rate
- HALF_DAY: quantity × rate × 0.5
- HOURLY: duration from start/end time × rate; falls back to entered quantity when times are absent
- AREA_ACRE: area quantity × rate
- QUANTITY: quantity × rate
- PIECE: piece count × rate

Multi-worker work cost is allocated equally after the total record cost is calculated.
Work records now persist `rateType` and fingerprints include rate type/time so changing the rate mode is not mistaken for a duplicate.

Backwards compatibility: old records without `rateType` default to QUANTITY and can be inferred from the unit.
