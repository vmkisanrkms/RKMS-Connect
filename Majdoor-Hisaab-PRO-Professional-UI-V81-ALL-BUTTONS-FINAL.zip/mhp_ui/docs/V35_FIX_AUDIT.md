# V35 Fix Audit

This revision addresses the source-level issues identified in the V34 audit without changing the user's local-JSON/no-database requirement.

## Fixed

1. **Repository boundary** — `MainActivity` now depends on `data/repository/LocalRepository`; direct UI dependency on `LocalStore` was removed.
2. **Input validation** — dates are validated as real `yyyy-MM-dd` calendar dates; money/rates/areas reject NaN/infinity/negative values where applicable.
3. **Controlled expense categories** — expense writes accept only the blueprint categories.
4. **Backup/import hardening** — import record equality uses canonical JSON key ordering instead of raw object-string ordering.
5. **Backup archive hardening** — extraction rejects duplicate entries, unsafe paths, excessive entry counts and backups over 100 MB.
6. **Additional regression tests** — repository-boundary and validation tests were added.
7. **Static acceptance gate** — architecture and validation contracts are now required by `scripts/acceptance-gates.sh`.

## Still requires GitHub CI/device evidence

The local environment cannot honestly certify the final Release APK, signed installation, emulator/device E2E, reboot behavior, or logcat results because Gradle dependency resolution requires external network access. The GitHub workflow remains the authoritative execution path for those gates.
