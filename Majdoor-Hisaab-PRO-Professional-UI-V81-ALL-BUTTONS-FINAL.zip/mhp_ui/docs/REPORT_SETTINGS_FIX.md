# Report Settings Fix

Implemented Report Settings as real persisted settings and connected them to report exports.

Settings:
- PDF page size: A4 / Letter
- PDF orientation: Portrait / Landscape
- Include report header
- Include filter/date summary
- Include page footer
- Include CSV column headers
- Excel-compatible CSV UTF-8 BOM
- Reset Defaults

Effects:
- PDF exports use the selected size/orientation and header/filter/footer options.
- CSV exports respect the column-header setting and optional UTF-8 BOM.
- Worker, ledger, and report CSV exports use UTF-8 output.
- Settings persist in local SharedPreferences and are read at export time.
- Settings is reachable from Settings -> Report Settings.
