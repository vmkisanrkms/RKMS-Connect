# Search Result → Actual Detail Navigation Fix

## What changed
- Global Search results are now real clickable result rows instead of plain text in a message dialog.
- Worker results open Worker Profile.
- Field results open Field Profile.
- Crop results open Crop Profile.
- Attendance results open Attendance Detail.
- Work results open Work Detail.
- Payment results open Payment Detail.
- Expense results open Expense Detail.
- Payment Detail provides Edit/Delete actions.
- Expense Detail provides Edit/Delete actions.
- Empty search input is rejected.
- Search results are shown in a scrollable panel for large result sets.

## Acceptance contract
`SearchNavigationContractTest` verifies that each supported search entity is wired to a real detail/navigation action and that payment/expense detail screens expose edit/delete paths.

## Runtime note
A real Android Gradle/emulator run must still be performed in GitHub Actions/device environment; this source-level fix does not by itself constitute runtime PASS.
