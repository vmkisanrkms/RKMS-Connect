# Restart Persistence Fix

## Goal
Records created before an app process stop/relaunch must remain available after the next `LocalStore` instance is created.

## Implementation
- Core records remain in the app's local JSON storage under `majdoor_hisaab/data`.
- `LocalStore` initialization recreates only missing JSON files; it does not clear existing files.
- JSON writes now use a temporary file, write/flush, `FileDescriptor.sync()`, then atomic rename where supported.
- A fallback copy is used when rename is unavailable.
- No SQLite/Room/Firebase/backend was introduced.

## Acceptance test
`RestartPersistenceTest` creates real Worker and Field records, discards the first repository instance to model process death, creates a new repository instance, and verifies the records and Data Health state.

This is a persistence/repository test. A real device/emulator force-stop/relaunch still belongs to the GitHub/runtime verification workflow and must not be claimed from source-only testing.
