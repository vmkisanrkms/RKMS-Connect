# Phase 1 — Point 7: Debug Build Fix

The Debug build is now an explicit acceptance gate.

Required CI sequence:
1. compileDebugKotlin
2. assembleDebug
3. verify app-debug.apk exists and is non-empty
4. verify package `com.majdoor.hisaab`
5. verify versionName `1.42.0`
6. install the actual Debug APK on an API 35 emulator
7. launch MainActivity
8. verify the process stays alive
9. scan logcat for fatal exceptions

A source-only/static PASS is not treated as a real Debug-build PASS. Actual CI execution is required for final verification.
