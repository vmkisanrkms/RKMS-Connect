# V27 — Rotation / Configuration / Error-State Fix

## Rotation/configuration
- MainActivity now saves the current top-level route in `onSaveInstanceState`.
- Activity recreation restores the last top-level screen instead of always returning to Dashboard.
- Worker/attendance/work/field editing references are also retained in instance state for configuration recreation.
- The app does not use `configChanges` to hide configuration changes; normal Android recreation remains possible.
- Light/Dark/System theme recreation therefore has a route restoration path.

## Error-state handling
- Visible Button actions are wrapped in a common exception boundary.
- Unexpected action failures show a user-facing error state rather than propagating directly to the UI thread.
- The error state offers Home recovery and a Retry action.
- Errors are logged with the action label for diagnosis.
- The message explicitly avoids claiming that local data was deleted when an action fails.

## Acceptance
- `ConfigurationAndErrorStateTest` checks source-level contracts for route restoration and error recovery.
- Android emulator rotation and real configuration-change execution still require a GitHub/device runtime environment.
