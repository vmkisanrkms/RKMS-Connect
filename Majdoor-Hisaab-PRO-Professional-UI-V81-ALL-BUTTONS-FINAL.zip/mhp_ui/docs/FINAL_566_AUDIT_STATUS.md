# Majdoor Hisaab PRO — Final Release Gate 541-566

## Status
Static final-release wiring is hardened. Runtime FINAL PASS is intentionally gated on a green GitHub Actions run with the production signing secrets and Android emulator evidence.

## Hardening in V94
- Removed the V93 p539 always-true assertion and replaced it with real worker create/read/delete assertions.
- Added `scripts/final-release-gate.sh` covering points 541-566.
- Final workflow now invokes the 541-566 gate as a blocking step before artifact publication.
- Final gate rejects trivial always-true test assertions and obvious fake/unimplemented UI markers.
- Final gate checks release assembly/signing/install/fresh launch wiring, restart/offline, backup/restore/totals, security paths, report generation, theme/date/search, reboot/rotation, crash-log scanning, clean GitHub runner, and SHA-256 artifact generation.

## Runtime rule
The following cannot honestly be marked PASS from this local environment: actual clean-runner Gradle build, production signing, APK installation on Android, full runtime E2E, biometric interaction, reboot continuation, CSV/PDF opening by a real Android document provider, and final logcat audit. The workflow is configured to fail if those runtime steps fail.

## Final decision rule
`541-566 FINAL PASS` is valid only after a green GitHub Actions run completes all blocking steps and the uploaded signed APK + SHA-256 + runtime logs are inspected.
