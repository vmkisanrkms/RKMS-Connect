# Audit status — V2 correction pass

This project must not be described as “50/50 audited” unless 50 independent end-to-end executions have actually been performed and evidence exists.

Current source-level fixes in this revision include:
- deterministic multi-worker work-cost allocation;
- stronger duplicate and linked-record protection;
- transactional/staged JSON restore with validation and rollback attempt;
- report-specific calculations instead of one generic report view;
- worker/field/crop selection controls in work/payment/production/revenue/expense flows;
- dashboard financial/work summaries;
- broader global search;
- real local settings for farm name, wage preference, currency and theme mode;
- strict GitHub database-dependency check;
- signed APK workflow with apksigner verification;
- expanded unit tests for attendance/work/payment ledger rules.

Not claimed here: successful Android compilation or physical-device testing. Those require the GitHub Actions run and an actual Android device/install test.
