# Phase 1 — Point 3: Gradle / Android Gradle Plugin Compatibility

Pinned build toolchain:
- Android Gradle Plugin: 8.9.1
- Gradle Wrapper: 8.11.1
- GitHub Actions JDK: 17
- compileSdk/targetSdk: 35

The acceptance gate rejects a mismatched AGP/Gradle pair and verifies that the release workflow explicitly provisions JDK 17.

AGP 8.9 requires Gradle 8.11.1 or newer; this project pins the compatible 8.11.1 pair.
