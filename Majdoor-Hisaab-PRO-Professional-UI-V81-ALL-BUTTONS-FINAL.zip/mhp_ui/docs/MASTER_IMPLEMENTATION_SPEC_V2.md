# Majdoor Hisaab PRO — Master Implementation & Acceptance Specification V2

## Source of truth
The attached **Majdoor Hisaab PRO — New Project — Master Product & Development Blueprint** is the baseline. Its screen map, module terminology, attendance rules, reports, backup/safety requirements and release gates are retained. The later explicit product decision for this project overrides the blueprint's SQLite/Room storage line: **this build uses local JSON files only and no database/backend**.

## Product contract
- Offline-first core operation.
- All lists, totals, balances and reports are derived from stored records.
- No static/fake production data and no hotspot-only UI.
- Every visible action has a real handler and persistence path.
- Duplicate protection for workers, attendance, work and applicable payments.
- Local JSON persistence; manual backup/export and validated restore.
- Light/Dark/System theme preference.
- Optional PIN; biometric availability check.
- GitHub Actions builds the Release APK.

## Screen contract
Startup/Security: Splash, first-time setup, app lock/PIN, biometric.
Home: dashboard, notifications, global search.
Workers: all workers, add/edit, profile, ledger, attendance, work history, payments, advances, documents.
Fields: all fields, add/edit, field profile, crops, work, expenses, labour cost, reports.
Crops: all crops, add/edit, calendar, work, expenses, labour cost, production, profitability.
Attendance: today's attendance, calendar/history/detail, team selection, save team, previous team, bulk actions.
Work: today's work, add/edit/detail/history, field/crop/worker views, templates.
Payments: pay worker, payment detail/history, advances, outstanding, ledger.
Expenses: all/add/edit/detail/categories.
Reports: daily, weekly, monthly, worker, field, crop, attendance, payment, expense, outstanding, labour cost, profit/loss, custom.
Data: backup, restore, export, import, data health.
Settings: farm profile, wage settings, currency, date format, theme, security, backup, notifications, reports, about.

## Attendance acceptance rules
1. Worker selection and status are separate.
2. Selecting a worker never changes status to Full.
3. States are Full, Half, None/Unmarked.
4. All Full, All Half and Clear All work deterministically.
5. Save Team stores only worker IDs.
6. Previous Team copies only workers and resets status to None for the new attendance session.
7. Existing attendance is loaded by selected date.
8. Duplicate date+worker attendance is rejected.
9. Saving attendance does not create records for unselected workers.
10. Editing a saved attendance changes only the selected record.

## Work and wage contract
- Work stores date, field, crop, workers, work type, quantity, unit, rate, time and notes.
- Supported work concepts: daily, half-day, hourly, area/acre, quantity and piece-based rates.
- A work record has one labour cost = quantity × rate.
- If multiple workers are linked and no per-worker allocation is explicitly stored, labour cost is divided equally among linked workers. This prevents multiplying one work cost by every worker in the ledger.
- Duplicate work fingerprints are rejected.

## Ledger contract
Worker ledger = attendance earnings + allocated work earnings - non-advance payments - advances.
Partial payments are supported. Advance and payment remain separate transaction types.

## Farm/crop cost contract
Field/crop cost includes recorded labour plus linked expense records. Revenue minus tracked costs is shown as profitability, with a note that unrecorded costs/revenue are outside the calculation.

## Backup contract
- Backup contains manifest + JSON records + schema/format version.
- Restore validates manifest, paths and every JSON file before changing live data.
- Restore is confirmed by the user.
- Live files are staged for rollback; stale live JSON files are removed only after validation.
- No silent overwrite.
- Data Health validates every JSON file.

## Acceptance test matrix
### CRUD
- Worker create/edit/deactivate/delete protection.
- Field create/edit/deactivate/delete protection.
- Crop create/edit/deactivate/delete protection.
- Work create/edit/delete and duplicate rejection.
- Payment create/edit/delete and duplicate rejection.
- Expense create/edit/delete.
- Production create/edit/delete.
- Revenue create/edit/delete.

### Cross-module consistency
- Worker profile totals match worker ledger.
- Field/crop reports use the same stored work/expense/revenue records.
- Dashboard totals equal underlying records.
- Restart preserves all JSON data.
- Offline operation remains functional.

### Reports
Every named report produces a report-specific calculation/view; report buttons do not all open the same generic screen.
CSV/PDF exports are generated from stored data.

### Security
PIN validation is 4–12 digits. Biometric availability is checked. Lock state must not bypass PIN when PIN is configured.

### Release gates
1. Source/static inspection passes.
2. No forbidden database/backend dependency.
3. Unit tests pass.
4. Release APK builds through GitHub Actions.
5. APK is signed and apksigner verification passes.
6. APK installs on supported Android devices.
7. End-to-end smoke test passes: setup → worker → field → crop → attendance → work → payment → expense → production → revenue → report → backup → restore → restart.
8. No known critical broken button.
9. No known silent data loss.
10. Final audit is based on actual test evidence, not a claimed number of audit rounds.
