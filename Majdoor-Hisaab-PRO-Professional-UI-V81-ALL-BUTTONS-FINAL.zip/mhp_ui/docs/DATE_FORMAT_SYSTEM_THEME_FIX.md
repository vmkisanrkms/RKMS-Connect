# V17 — Date Format + Real System Theme Fix

## Date Format
- Stored dates remain canonical `yyyy-MM-dd` so sorting/filtering/calculations do not change.
- Every user-facing date uses the selected Settings → Date Format value.
- Date input fields show the selected format and convert back to ISO before saving.
- Existing ISO records are rendered in the selected format.
- Dashboard, worker history, work, payments, expenses, production, revenue, reports, attendance detail/history/calendar and search results use the selected format.
- Changing the date format recreates the activity so the whole UI is refreshed immediately.

## Theme
- Light, Dark and System are real Activity themes, not only text/color changes.
- System mode selects the Android system light/dark configuration at startup/recreation.
- Theme resources define status bar, navigation bar and window background for both modes.
- Changing Theme recreates the Activity immediately.
