# Phase 7 — Payment / Ledger Re-audit

## Points 189–212

189 Pay Worker: implemented by Payment form and persisted through LocalStore.
190 Payment Detail: worker, date, amount, method, type/advance, reference, notes, edit/delete.
191 Payment History: persisted payments listed newest-first and each opens Payment Detail.
192 Advance: explicit Advance toggle and separate advance ledger bucket.
193 Outstanding: deterministic `max(0, earned - paid - advance)`.
194 Payment Ledger: per-worker earned/paid/advance/outstanding.
195 Worker link: Payment.workerId validated against stored workers.
196 Date: real date picker and ISO date validation.
197 Amount: finite and strictly > 0 validation.
198 Cash: explicit UI choice and validation.
199 Bank: explicit UI choice and validation.
200 UPI: explicit UI choice and validation.
201 Advance flag: persisted boolean and represented separately in ledger/detail.
202 Reference: persisted in JSON and displayed in detail/search.
203 Notes: persisted in JSON and displayed in detail/search.
204 Total Earned: attendance + allocated work cost.
205 Paid: non-advance payments only.
206 Advance: advance payments only.
207 Outstanding: never negative; credit is reported separately.
208 Partial payment: covered by deterministic ledger tests.
209 Overpayment/credit: credit is tracked without negative outstanding.
210 Ledger deterministic: centralized LedgerCalculator; no UI-side arithmetic.
211 Payment edit/delete: calculations derive from current payment list, so replacement/removal immediately recalculates ledger.
212 Automated tests: Phase 7 tests cover partial payment, methods, edit replacement, deletion, overpayment, worker isolation; existing LocalStore CRUD/validation tests cover persistence and validation.

## Re-audit result

- Static acceptance gates: PASS.
- Phase 6 regression gate: PASS.
- Payment method UI was tightened during re-audit: free-text method entry was replaced by an explicit Cash/Bank/UPI selector.
- Amount field no longer defaults to a misleading zero; blank/invalid amounts are rejected by LocalStore validation.
- Actual Gradle/emulator runtime execution remains an external CI/device evidence requirement in this environment; no runtime PASS is claimed without execution evidence.
