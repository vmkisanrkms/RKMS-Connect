# Clean-install Backup → Restore Fix

## Scope
The backup/restore flow now has a dedicated clean-install acceptance test and a stronger transactional restore path.

## Acceptance scenario
1. Create real Worker, Field and Crop records in local JSON storage.
2. Export a real ZIP backup.
3. Delete the complete local data directory to simulate a clean install.
4. Construct a fresh `LocalStore`.
5. Restore the exported ZIP.
6. Verify Worker, Field and Crop records are recovered.
7. Run relational Data Health and require no `ERROR:` result.

## Restore safety
- Backup manifest/version and every required JSON collection are validated before replacement.
- Existing data is snapshotted before destructive replacement.
- The restored live set is validated after copying.
- If any copy/validation step fails, the live directory is cleared and the complete previous snapshot is restored.
- No newly introduced partial file is allowed to remain after a failed restore.

## Verification limitation
The current environment does not contain a usable Android SDK/Gradle runtime, so the Android test suite and emulator execution are not claimed as runtime-passed here. The acceptance test is included in source for GitHub/CI execution.
