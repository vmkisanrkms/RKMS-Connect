# Import Flow Fix

Implemented a real offline import flow for the JSON/ZIP storage model.

- `Import Data (Merge)` is separate from `Restore Backup (Replace)`.
- Import validates app, format version and all required JSON collections before touching live data.
- Existing identical IDs are skipped.
- Existing IDs with different content are treated as conflicts and the import stops safely.
- No live data is changed when validation/conflict detection fails.
- Merge writes are staged and the complete merged set is validated before commit.
- Restore remains an explicit replacement operation with rollback handling.
- The user receives a clear result count for added/skipped records.
