# Phase 14 Re-Audit & Fix — V76

Date: 2026-09-30

## Result

Phase 14 was independently re-audited from source rather than trusting the previous audit report.
Two real model/data-integrity issues were found and fixed.

### Fix 1 — Crop Variety foreign key
Previous model stored `CropVariety.cropName`, which was a name-based relationship and could become ambiguous when two crops shared the same name.

Fixed:
- `CropVariety.cropId` is now the authoritative relationship.
- Create/update/delete validation uses crop ID.
- Backup relational validation checks `cropId` exists.
- Duplicate variety detection uses `(cropId, variety name)`.
- Schema-3 legacy backups are migrated from `cropName` to matching crop IDs.
- Existing local legacy variety data is migrated on startup.

### Fix 2 — Worker wage history effective dates
Previous worker updates could reuse the worker's joining date when a wage changed, preventing a new wage-history event from being recorded.

Fixed:
- Initial worker wage history uses joining date when available, otherwise today.
- Subsequent wage/rate-unit changes create a history event effective today.
- Wage history rejects duplicate `(workerId, effectiveFrom)` records.
- Wage history validates worker reference, date, finite non-negative rate and allowed rate unit.
- Attendance creation now resolves the effective historical wage for the attendance date instead of always using the worker's current default wage.

### Schema
- Schema version advanced from 3 to 4.
- Schema 2 and 3 backups remain accepted and migrated.
- Backup metadata is rewritten to schema 4 during migration.

## Re-audit gates

- Phase 12 backup static gate: PASS
- Phase 12 metadata integrity gate: PASS
- Phase 13 settings static gate: PASS
- Phase 13 hardened settings/data-safety gate: PASS
- Phase 14 data-model gate: PASS
- Current CropVariety uses cropId FK: PASS
- Current wage-history effective-date logic: PASS
- Legacy schema migration path: PASS
- No current-model cropName reference outside legacy migration: PASS

## Runtime limitation

Gradle 8.11.1 could not be downloaded in this execution environment because DNS/network access to `services.gradle.org` failed. Therefore runtime Android build/test execution is not claimed as PASS here.
