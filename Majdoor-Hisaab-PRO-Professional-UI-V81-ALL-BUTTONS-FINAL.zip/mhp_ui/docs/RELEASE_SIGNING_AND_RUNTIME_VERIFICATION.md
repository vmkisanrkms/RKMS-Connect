# Release Signing + Runtime Verification

The release pipeline requires a persistent production keystore supplied through GitHub Secrets.

Required secrets:
- `MH_RELEASE_KEYSTORE_BASE64`
- `MH_RELEASE_KEYSTORE_PASSWORD`
- `MH_RELEASE_KEY_PASSWORD`
- `MH_RELEASE_KEY_ALIAS`
- `MH_RELEASE_CERT_SHA256`

The certificate fingerprint is checked before signing and the resulting APK is verified with `apksigner`.
No temporary/generated release keystore is permitted.

Runtime sequence:
1. `assembleRelease`
2. restore persistent keystore
3. certificate fingerprint check
4. zipalign
5. apksigner sign
6. apksigner verify
7. install the signed Release APK on API 35 emulator
8. clean launch
9. force-stop and relaunch
10. collect logcat and fail on `FATAL EXCEPTION`
11. verify package/version/path
12. upload signed APK + SHA-256 + runtime log

A successful workflow run is required before claiming an actual Release Build PASS.
