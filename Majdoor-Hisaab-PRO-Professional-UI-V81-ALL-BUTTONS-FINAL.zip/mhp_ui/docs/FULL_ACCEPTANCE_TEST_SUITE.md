# Majdoor Hisaab PRO — Full Acceptance Test Suite

This suite is aligned to the Master Blueprint release gates. It separates checks that can run as pure JVM tests from checks that require a real Android runtime.

## A. Build/source gates
- Project root contains Gradle settings and app module.
- No SQLite/Room/Firebase/Supabase backend dependency.
- Release and debug APK compile.
- APK package is `com.majdoor.hisaab`.
- Release APK is zip-aligned and `apksigner verify` passes.

## B. Attendance gates
- Worker selection never changes attendance status.
- Full / Half / None are independent states.
- All Full changes only status.
- All Half changes only status.
- Clear All changes only status to None/Unmarked.
- Previous Team copies workers only.
- Previous Team never copies previous attendance statuses.
- Duplicate date + worker attendance is rejected.
- Attendance can be edited and deleted without creating duplicates.

## C. Work/rate gates
- Daily rate calculation.
- Half-day rate calculation.
- Hourly duration calculation.
- Hourly fallback to entered quantity when times are absent.
- Area/Acre calculation.
- Quantity calculation.
- Piece calculation.
- Multi-worker work total is not duplicated.
- Work duplicate fingerprint protection.
- Work edits recalculate downstream ledger/report values.

## D. Worker ledger/payment gates
- Attendance earnings are deterministic.
- Work earnings are deterministic.
- Normal payment is counted once.
- Advance is counted once.
- Outstanding never becomes negative.
- Overpayment becomes Credit.
- Partial payment is supported.
- Worker ledger, Outstanding, dashboard and reports use the same calculation source.

## E. Farm/crop/expense/finance gates
- Field CRUD and duplicate protection.
- Crop CRUD and field relationship validation.
- Expense CRUD and field/crop validation.
- Production CRUD.
- Revenue CRUD.
- Profit/Loss = Revenue - Labour Cost - tracked non-labour costs.
- Field and crop totals respect selected date/entity filters.

## F. Reports/export gates
- Daily report respects selected date.
- Weekly report respects selected date range.
- Monthly report respects selected month.
- Worker report respects worker/date filters.
- Field report respects field/date filters.
- Crop report respects crop/date filters.
- Attendance report respects filters.
- Payment report respects filters.
- Expense report respects filters.
- Outstanding report uses central ledger.
- Labour Cost report uses attendance + work engines.
- Profit/Loss report uses revenue - tracked costs.
- Custom report respects date/worker/field/crop filters.
- CSV contains report-specific columns/data.
- PDF contains report-specific title/data/totals.

## G. Data safety gates
- JSON is persisted locally.
- App restart preserves records.
- Backup contains required JSON stores and metadata/schema version.
- Corrupt JSON is rejected.
- Missing required backup store is rejected.
- Restore requires confirmation.
- Restore does not silently merge/overwrite unrelated live data.
- Restore failure attempts rollback.
- Data Health detects malformed JSON and relational integrity problems.

## H. Security/settings gates
- First-time setup works.
- PIN set/verify works.
- Biometric unlock path is available when supported.
- Auto-lock behavior follows configured setting.
- Theme setting is applied.
- Currency/date-format settings affect presentation.
- Notification setting controls notification behavior.

## I. Runtime/device gates
- Fresh install launches without fatal exception.
- App can be force-stopped and relaunched.
- Records survive process restart.
- Photo URI remains readable after restart/reboot when provider supports persistable permission.
- Auto-backup alarm is restored after `BOOT_COMPLETED` / package replacement.
- Release APK installs on Android API 35 emulator.
- Release APK signature verifies.

## J. Evidence rule
A gate is only marked PASS when the corresponding test actually ran. Source-code presence alone is not runtime evidence.
