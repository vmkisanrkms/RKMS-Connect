# Phase 1 Points 18-25 — Fix

18. Release APK SHA-256 is generated and stored as an artifact.
19. Workflow uses `runs-on: ubuntu-latest`, with checkout/setup on the GitHub-hosted clean runner.
20. `workflow_dispatch` is enabled for manual execution.
21. `push` to `main` triggers the workflow.
22. `set -Eeuo pipefail` plus an ERR trap and explicit gate messages make failures visible; failing commands stop the job.
23. `actions/upload-artifact@v4` publishes the signed APK, SHA-256, signature, logs and runtime evidence.
24. `release-e2e.sh` performs a real `adb install` of the signed Release APK.
25. The same E2E script launches the installed APK with `am start -W`, checks the process/activity, relaunches after force-stop, and scans logcat for fatal exceptions.

Static source gates are not runtime proof. Actual GitHub Actions execution is required for final 🟢 FULLY VERIFIED status.
