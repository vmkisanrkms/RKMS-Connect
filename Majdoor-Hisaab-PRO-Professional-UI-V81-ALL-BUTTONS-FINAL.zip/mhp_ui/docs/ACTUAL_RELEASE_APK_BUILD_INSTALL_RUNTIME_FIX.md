# Actual Release APK Build + Install + Launch + Force-stop/Relaunch Fix — V30

The GitHub Actions release workflow is now the authoritative runtime verification path.

## Build
- Uses JDK 17.
- Uses Android SDK API 35 and Build Tools 35.0.0.
- Uses the pinned Gradle wrapper (`./gradlew`).
- Runs static acceptance gates and unit tests before Release assembly.
- Builds both Debug and Release APKs.

## Release signing
- Restores the production keystore only from GitHub Secrets.
- Pins the expected certificate with `MH_RELEASE_CERT_SHA256`.
- Runs `zipalign` and `apksigner verify`.
- Never generates a temporary release key.

## Runtime verification
On an API 35 Google APIs emulator the workflow now:
1. waits for Android boot completion;
2. clears logcat;
3. uninstalls any old package;
4. installs the signed Release APK;
5. verifies the installed package and launcher activity;
6. launches `MainActivity` with `am start -W`;
7. verifies the process is running and the package is active;
8. scans fresh logcat for fatal exceptions;
9. force-stops the app and verifies the process is gone;
10. launches it again and repeats the fatal-exception check;
11. verifies version metadata;
12. uninstalls and performs a clean install;
13. launches again and performs a final fatal-exception sweep.

Runtime logs, activity/package dumps, APK and checksum are uploaded as workflow artifacts, including on a failed runtime step.

## Release claim rule
A true Actual Release Build/Install/Runtime PASS may only be claimed after a successful GitHub Actions run completes these steps. Source/static verification alone is not runtime proof.
