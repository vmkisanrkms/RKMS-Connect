# Phase 5 Point 146 — Real Previous Team UI E2E Fix

Point 146 previously had only a data-model test. This fix changes the Android instrumentation test to execute the actual UI flow:

1. Create two workers.
2. Save a Previous Team containing both workers.
3. Seed historical FULL attendance for one worker on an earlier date.
4. Launch Attendance UI.
5. Tap `Previous Team — copy workers only`.
6. Assert both workers are actually selected in the UI.
7. Assert both displayed attendance states are `NONE`.
8. Tap `Save Attendance`.
9. Assert two records are created for the selected current date with `NONE` status.
10. Assert the historical FULL attendance remains FULL.
11. Assert Team JSON contains workers only and no attendance state.

This is the intended runtime/UI test for Point 146; source-only Team serialization checks are retained as secondary assertions.
