# Phase 1 — Point 5: Dependency Resolution Fix

## Contract

A clean checkout must resolve every declared runtime/test/plugin dependency before Kotlin compilation and APK packaging.

### Enforced
- All direct dependency versions are explicit; dynamic and SNAPSHOT versions are rejected by acceptance gates.
- Repository resolution is centralized in `settings.gradle.kts`.
- `google()` and `mavenCentral()` are required.
- GitHub Actions runs fresh `--refresh-dependencies` resolution for debug, test, e2eRelease, release runtime classpaths and build environment.
- The normal compile/test/assemble step runs only after those resolution checks succeed.
- A missing artifact, unavailable repository, checksum/network failure, or unresolved transitive dependency fails the job.

## Verification limitation
The local environment cannot perform external Gradle dependency downloads when DNS/network access is unavailable. Therefore the repository contains the required CI resolution gate, but an actual GitHub Actions run is required to claim runtime dependency-resolution PASS.
