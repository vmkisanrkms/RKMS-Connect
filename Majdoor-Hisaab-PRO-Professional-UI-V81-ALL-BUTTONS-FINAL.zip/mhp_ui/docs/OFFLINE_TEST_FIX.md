# Offline Test Fix

## Acceptance requirement
Majdoor Hisaab PRO is offline-first: core work must function without internet. The master blueprint explicitly lists a restart/offline test as a release audit gate.

## V26 changes
- Added `OfflineCoreWorkflowTest`.
- The test creates Worker, Field, Crop and Attendance records using `LocalStore` only.
- It validates local data health and creates/validates a real local backup.
- It recreates `LocalStore` to verify the records remain available from phone-local JSON storage.
- Static gate rejects `android.permission.INTERNET` and common network/backend implementations in production source/build files.
- No SQLite/Room/Firebase/Supabase/network dependency was introduced.

## Important runtime limitation
The current build environment does not contain a usable Android SDK/Gradle installation, so a physical airplane-mode/emulator-network-disabled run cannot be honestly reported as executed here. GitHub Actions should run the JVM tests and the Release APK workflow; an emulator/device offline run remains a runtime verification step.
