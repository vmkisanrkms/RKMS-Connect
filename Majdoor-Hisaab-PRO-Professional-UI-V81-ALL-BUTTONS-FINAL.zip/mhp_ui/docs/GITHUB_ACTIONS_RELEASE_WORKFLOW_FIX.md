# GitHub Actions Release Workflow Fix

V28 restores the repository's actual `.github/workflows/build-release-apk.yml`.

The workflow performs:

1. Checkout
2. JDK 17 setup
3. Gradle 8.11.1 setup
4. Android SDK/API 35 and build-tools 35.0.0 setup
5. Static acceptance gates
6. Unit tests
7. Debug and Release Gradle builds
8. Release APK metadata verification
9. Production keystore restore from GitHub Secrets
10. Stable certificate SHA-256 pin check
11. zipalign + `apksigner` signing
12. Signed APK verification
13. API 35 emulator install
14. clean launch + force-stop/relaunch
15. package/version and fatal-exception checks
16. uninstall + clean-install + relaunch verification
17. APK, checksum and runtime logs uploaded as artifacts

Required secrets:
- `MH_RELEASE_KEYSTORE_BASE64`
- `MH_RELEASE_KEYSTORE_PASSWORD`
- `MH_RELEASE_KEY_PASSWORD`
- `MH_RELEASE_KEY_ALIAS`
- `MH_RELEASE_CERT_SHA256`

No temporary release keystore is generated.

A successful GitHub Actions run is required before claiming actual Release Build/runtime PASS.
