# V20 — Relational Data Health Fix

Data Health now performs relational integrity validation across the local JSON store instead of only checking whether each JSON file can be parsed.

Checks include duplicate/blank IDs, duplicate master records, worker/field/crop references, field↔crop consistency, attendance validity and duplicates, work fingerprints, positive amounts, required dates/names, unresolved relationships, and inactive-worker warnings.

Settings → Data Health now displays the relational result, counts, relationships checked, errors and warnings, with Refresh.
