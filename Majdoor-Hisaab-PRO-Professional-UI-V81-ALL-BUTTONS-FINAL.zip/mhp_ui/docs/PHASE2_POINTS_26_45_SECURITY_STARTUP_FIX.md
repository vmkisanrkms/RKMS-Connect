# Phase 2 — Security / Startup Points 26–45

Re-audit of V47 found three concrete source defects:
1. There was no visible startup splash screen.
2. First-time setup called `setContentView()` before adding the Start App button, so the completion button was not reliably attached to the displayed view.
3. App Lock had no user-facing disable action, despite having PIN creation/change support.

V48 fixes these and hardens security state:
- startup splash is displayed before initialization;
- first-time setup completion button is added before `setContentView`;
- PIN remains hashed and persisted;
- PIN validity is 4–12 digits;
- five consecutive wrong PIN attempts trigger a 30-second lockout;
- failed-attempt/block state persists across process restart;
- correct PIN resets failed-attempt state;
- App Lock can be enabled, PIN changed, or disabled after current-PIN verification;
- disabling App Lock also disables biometric and turns Auto-Lock off;
- biometric success unlocks; cancellation/error falls back to PIN;
- unavailable biometric never blocks startup and falls back to PIN;
- Auto-Lock setting persists and is checked both by inactivity timer and background/resume elapsed time;
- force-stop/relaunch preserves PIN/App-Lock state through SharedPreferences.

## Verification level
Source gates and contract tests are included. Actual device/emulator execution of every security path still requires a GitHub Actions/device run; no runtime PASS is claimed without that evidence.
