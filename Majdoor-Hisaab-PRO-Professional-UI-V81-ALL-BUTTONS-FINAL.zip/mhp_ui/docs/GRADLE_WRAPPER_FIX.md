# Gradle Wrapper Fix — V29

The project now includes a reproducible Gradle bootstrap entry point:

- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`
- Gradle distribution pinned to 8.11.1

GitHub Actions now invokes `./gradlew` instead of a globally installed Gradle command.

The wrapper bootstrap downloads the pinned Gradle distribution on first use and caches it under the user's Gradle wrapper directory. No private signing material is stored in the repository.
