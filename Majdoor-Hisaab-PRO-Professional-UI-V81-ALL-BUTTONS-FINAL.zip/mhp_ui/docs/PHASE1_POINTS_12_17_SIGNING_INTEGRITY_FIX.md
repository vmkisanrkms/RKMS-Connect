# Phase 1 Points 12-17 — Release identity and signing integrity

12. versionName is pinned and checked from the built APK: `1.48.0`.
13. Release APK is signed only after restoring the configured production keystore from GitHub Secrets.
14. No temporary/debug keystore fallback exists; the workflow fails if production keystore/certificate secrets are absent or certificate fingerprint mismatches.
15. `apksigner verify --verbose --print-certs` is required, and the signer SHA-256 must equal `MH_RELEASE_CERT_SHA256`.
16. `unzip -t` validates the final signed APK as a valid ZIP/APK.
17. `zipalign -c -v 4` validates alignment of both the aligned pre-sign artifact and final signed APK.

Actual cryptographic/runtime PASS still requires a successful GitHub Actions run with the production signing secrets configured. Source gates alone are not runtime evidence.
