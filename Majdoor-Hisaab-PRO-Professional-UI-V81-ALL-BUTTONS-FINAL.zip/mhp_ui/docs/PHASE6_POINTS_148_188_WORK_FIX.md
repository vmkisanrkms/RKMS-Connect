# Phase 6 — Work — Points 148–188

## Implemented
- Today's Work dedicated screen with date, record count and total labour cost.
- Add/Edit/Delete Work using local JSON repository.
- Work Detail shows date, field, crop, workers, work type, rate type, quantity, unit, rate, total labour cost, start/end time and notes.
- Work History with Field, Crop, Worker and Date filters.
- Field Work, Crop Work and Worker Work History navigation remain linked to Work Detail.
- Work Templates create/update/delete and Apply Template flow.
- Work form persists date, field, crop, workers, work type, rate type, quantity, unit, rate, start/end time and notes.
- Standard work-type presets: Planting, Sowing, Weeding, Harvesting, Cutting, Loading, Irrigation, Spraying, Fertilizing, Custom.
- Start/End Time picker buttons plus HH:mm validation at repository level.
- Central WorkRateEngine covers Daily, Half-Day, Hourly, Area/Acre, Quantity and Piece rates.
- Multi-worker allocation uses total-cost-preserving equal allocation.
- Duplicate work protection uses a normalized fingerprint.
- Create/Update/Delete Work audit records are written to audit_log.

## Automated coverage
- WorkRateEngine calculation tests: daily, half-day, hourly, acre/area, quantity, piece.
- Multi-worker allocation test.
- Work JSON round-trip test for all persisted fields.
- Local JSON Work CRUD test with create/read/update/delete and audit verification.
- Duplicate Work protection test.
- Work Template CRUD test.
- Real Android UI E2E test covering Add → Today’s Work → Work Detail → Edit and persistence.
- Static Phase 6 gate: `scripts/phase6-work-gate.sh`.

## Verification status
Static acceptance gates pass in the supplied environment. Actual Gradle compilation and emulator/device execution still require the GitHub Actions runner because this environment does not have a usable Gradle distribution/network path for a clean Android build.
