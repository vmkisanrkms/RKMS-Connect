# Build / Runtime Verification Contract

This is a CI verification contract, not a claim that the build has already run in this source environment.

1. Gradle 8.11.1 runs `test`, `assembleDebug`, and `assembleRelease`.
2. Unsigned release APK package/version are checked.
3. Production keystore secrets are mandatory.
4. Release APK is zipaligned and signed with the stable production keystore.
5. `apksigner verify --verbose --print-certs` must pass.
6. The signed Release APK, not Debug APK, is installed on an API 35 emulator.
7. App launch, force-stop/relaunch, package/version and fatal logcat checks must pass.
8. Signed APK and SHA-256 are uploaded as workflow artifacts.
