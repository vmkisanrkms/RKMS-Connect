# Audit Log Fix

## Implemented
- Persistent local JSON `audit_log.json` with up to 2,000 events.
- CREATE / UPDATE / DELETE logging for workers, documents, templates, fields, crops, attendance, teams, work, payments, expenses, production and revenue.
- IMPORT / RESTORE / BACKUP / EXPORT events.
- Timestamp, action, entity, entity ID, summary and source are stored.
- Audit logging is non-blocking: a logging failure cannot fail a successful business-data write.
- Audit Log screen in Settings with refresh and controlled clear action.
- Audit log is included in newly created backups and preserved through import/restore where present.
- Older backups without `audit_log.json` remain importable because the audit log file is optional for backup compatibility.
