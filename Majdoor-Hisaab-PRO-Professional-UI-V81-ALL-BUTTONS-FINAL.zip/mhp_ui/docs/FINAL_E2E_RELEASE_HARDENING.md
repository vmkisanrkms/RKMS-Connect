# Final E2E Release Hardening

V32 closes the remaining release-test gaps identified during the V31 final audit.

## Release variants
- `release`: production build; `E2E_ERROR_TEST=false`.
- `e2eRelease`: release-like instrumentation variant; `E2E_ERROR_TEST=true` solely so Android E2E can exercise the production error-recovery UI without shipping a test hook in the production APK.

## Device E2E
GitHub Actions now:
1. runs unit/static tests;
2. builds Debug, e2eRelease and production Release;
3. runs `connectedE2eReleaseAndroidTest` on API 35;
4. signs the production Release APK with repository secrets and certificate pinning;
5. installs the signed production APK on API 35;
6. performs real Android orientation/configuration changes;
7. verifies launch, force-stop and relaunch;
8. runs an offline launch smoke test with Wi-Fi/data disabled;
9. captures logcat and fails on fatal Android runtime exceptions.

Production Release does not contain the E2E error injection hook.
