# Notification Settings Fix

Implemented real notification preferences rather than a test-only notification button.

- Master notification enable/disable switch.
- Daily attendance reminder enable/disable.
- Daily payment reminder enable/disable.
- Configurable reminder time for each reminder.
- AlarmManager schedules are cancelled/recreated when settings change.
- Android 13+ POST_NOTIFICATIONS permission is checked before sending.
- Android app notification settings can be opened directly.
- Separate General and Reminders notification channels.
- Test notification button verifies the configured notification path.
- NotificationReceiver respects the saved master/category switches before posting.
