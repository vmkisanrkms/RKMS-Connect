# Phase 1 — Points 2 & 3

## Point 2 — Gradle wrapper reproducibility
- Repository wrapper entrypoint: `./gradlew` and `gradlew.bat`.
- Gradle distribution pinned to `8.11.1`.
- Distribution SHA-256 pinned to `f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6`.
- The wrapper verifies the downloaded distribution before extraction.
- GitHub Actions invokes `./gradlew`, not a separately installed system Gradle.
- The acceptance gate rejects direct `gradle --...` workflow commands.

> Note: this project currently uses a repository wrapper script rather than the binary `gradle-wrapper.jar`. A standard Gradle-generated wrapper JAR should be added before claiming full standard-wrapper compliance.

## Point 3 — Gradle / AGP compatibility
- Android Gradle Plugin: `8.9.1`.
- Gradle: `8.11.1`.
- JDK: `17`.
- compileSdk/targetSdk: `35`.
- Compatibility is enforced by `scripts/gradle-agp-compatibility.sh`.
- The workflow provisions JDK 17 and builds through `./gradlew`.
