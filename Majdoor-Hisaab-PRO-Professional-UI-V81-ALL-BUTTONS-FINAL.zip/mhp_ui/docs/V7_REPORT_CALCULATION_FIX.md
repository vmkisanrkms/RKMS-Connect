# V7 Report Calculation Fix

Implemented a single ReportEngine/ReportFilter source of truth for report calculations.

Fixed:
- Daily Labour no longer forces current date when a report filter date is supplied.
- Weekly/Monthly Labour use the selected report filter period instead of silently using current week/month.
- Worker and Outstanding reports use filtered attendance/work/payment data.
- Field reports calculate field labour, expenses, revenue and profit/loss from filtered data.
- Crop reports calculate crop work labour, crop expenses, production and revenue.
- Attendance report uses earned wage from status.
- Expense report totals filtered expenses.
- Labour Cost report uses central attendance + WorkRateEngine work cost.
- Profit/Loss report uses revenue - labour cost - other tracked expenses.
- Custom Report now produces a real aggregate report instead of the old text-search/count output.
- CSV report export now follows the same report-specific calculations and saved filters.
- Added ReportEngine unit test covering date/entity filters and totals.

Important: crop labour intentionally uses work records for crop attribution because attendance records are linked to fields, not crop instances; field attendance labour remains in Field reports.
