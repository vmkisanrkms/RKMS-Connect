# Phase 5 — Attendance Critical — Points 117–147

Implemented hardening:
- date picker is a real Android DatePickerDialog and all attendance dates persist as ISO yyyy-MM-dd;
- optional field selection persists `Attendance.fieldId` and validates the referenced field;
- explicit saved-team selection and Previous Team copy worker IDs only;
- selecting a worker initializes/retains only NONE unless an existing saved attendance is being loaded;
- Select All, All Full, All Half and Clear All are distinct actions;
- Save Team stores only selected worker IDs;
- saved attendance edit has explicit confirmation;
- attendance history has independent worker, field, date and status filters;
- attendance detail displays worker, date, field, status and rate;
- exact duplicate rule is date + worker + field;
- unit tests cover critical rules and JSON persistence; Android E2E covers worker selection and Previous Team contract.
