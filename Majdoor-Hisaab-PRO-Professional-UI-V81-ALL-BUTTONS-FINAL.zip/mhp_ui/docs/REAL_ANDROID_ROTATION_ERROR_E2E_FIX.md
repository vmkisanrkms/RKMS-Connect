# Real Android Rotation + Error-State E2E Fix

## Rotation
- MainActivity is no longer permanently locked to portrait.
- Android is allowed to recreate the Activity for orientation changes.
- Existing route/edit state is restored through `onSaveInstanceState`.
- A real API 35 emulator E2E test uses UiAutomator `setOrientationLeft()` and `setOrientationNatural()` and verifies the Workers route remains visible after recreation.

## Error state
- Debug-only E2E intent hook intentionally opens the existing user-facing error recovery dialog.
- The test verifies `Something went wrong`, `Home`, and `Retry` are visible.
- It exercises the Home recovery action and verifies the dashboard is restored.
- The hook is guarded by `BuildConfig.DEBUG` and is not active in the signed Release runtime.

## CI gate
GitHub Actions runs `connectedDebugAndroidTest` on an API 35 emulator before Release signing. The existing signed Release install/launch/force-stop/relaunch job remains in place.
