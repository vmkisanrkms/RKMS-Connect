# Phase 1 — Point 6: Dependency health

## Requirement
No deprecated/legacy/pre-release/unresolved dependency may silently affect the build.

## Fixes
- AndroidX Test Core: 1.7.0
- AndroidX Test ext.junit: 1.3.0
- AndroidX Test Runner: 1.7.0
- AndroidX Test Rules: 1.7.0
- UiAutomator: 2.4.0
- Robolectric: 4.15, which supports Android API 35; Robolectric documents API 21→35 support for 4.15.
- JUnit 4.13.2 retained.
- Added `scripts/dependency-health.sh`.

## CI gate
The script resolves debug, release, e2eRelease and test runtime classpaths with `--refresh-dependencies`, fails on unresolved artifacts, legacy coordinates, SNAPSHOT/prerelease versions, and checks the direct stable-version contract.

## Verification
Static/source gate: PASS. Remote Maven resolution requires the GitHub Actions runner because this environment has no external dependency-download access.
