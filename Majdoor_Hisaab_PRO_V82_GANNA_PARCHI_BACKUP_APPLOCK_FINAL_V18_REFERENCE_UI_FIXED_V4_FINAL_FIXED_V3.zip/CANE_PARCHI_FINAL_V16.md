# Majdoor Hisaab PRO V82 — Cane Parchi + Backup/App Lock V16

- Ganna Parchi: name, father name, 6–7 digit code, date, weight, photo, optional remark.
- Rate is captured into each parchi at save time, so later rate changes do not alter old parchis.
- Rate changes require Android device credential verification.
- Season list is derived dynamically from saved parchis/rate history plus current season.
- Manual backup includes cane parchi and cane price history.
- Android Auto Backup includes the app SharedPreferences store and managed photos directory.
- Restore requires device credential verification.
- Backup photo entries use unique ZIP names to avoid same-filename collisions.
