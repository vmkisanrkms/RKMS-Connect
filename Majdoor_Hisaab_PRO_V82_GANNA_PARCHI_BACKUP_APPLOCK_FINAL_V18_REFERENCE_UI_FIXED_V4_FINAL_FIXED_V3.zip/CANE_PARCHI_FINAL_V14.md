# Majdoor Hisaab PRO — Cane Parchi Final V14

- Separate Ganna Parchi module on Home.
- Fields: Name, Father Name, 6–7 digit Parchi Code, Date, Weight, Photo, optional Remark.
- Per-season cane price history with effective date.
- Parchi stores the applicable rate permanently, so later rate increases do not change old records.
- Search by name, father name or parchi code.
- Current season, previous season and all-years list.
- Summary: total parchis, total weight, total estimated amount.
- Edit/Delete protected by Android device credential.
- Manual backup and Android Auto Backup include cane price history and parchis/photos.
