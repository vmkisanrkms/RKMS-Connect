# Majdoor Hisaab PRO V82 — V8 Final Audit

## Source
- Package: `com.majdoor.hisaabpro`
- Version: `1.82.0`
- Version code: `82`
- compileSdk/targetSdk: 36
- minSdk: 23
- Java target: 17

## Fixed
- Removed exact invalid import `androidx.compose.foundation.lazy.item`.
- Verified `androidx.compose.foundation.lazy.items`.
- Verified attendance, labour, field, crop, expense, sale, payment, wage history and report-related source symbols.
- Verified FileProvider uses `cache-path` `reports/`.
- Release workflow no longer uses setup-java Gradle cache before ZIP extraction.
- Workflow uses exact V8 ZIP filename.
- Temporary signing keystore generation removed.
- Permanent production keystore is required through GitHub Secrets.
- SHA-256 production certificate is required and verified.
- Final APK package/version/signature/alignment are verified.

## Required GitHub Secrets
`RELEASE_KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`, `RELEASE_CERT_SHA256`.

## Important
Use the same production signing key as the existing published app when this build is intended as an update.
