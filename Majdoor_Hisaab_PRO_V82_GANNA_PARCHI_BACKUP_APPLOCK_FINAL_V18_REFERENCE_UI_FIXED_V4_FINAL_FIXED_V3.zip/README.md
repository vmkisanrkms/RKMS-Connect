# Majdoor Hisaab PRO

Professional, simple, offline-first Android starter implementation based on the locked Master Final Structure.

## Locked main structure

Dashboard has five main options only:
- Labour
- Field
- Kharch
- Sale
- Crop

Attendance and Payment stay inside Labour. Profit is calculated inside Field/Crop. Labour cost comes from attendance and is not manually entered again as an expense.

## Professional UI rules

- Android safe drawing area is used so content does not collide with status/navigation bars.
- Consistent top header and bottom navigation.
- Large touch targets and simple Hindi labels.
- Loading/empty/error/offline states can be expanded without changing the core navigation.
- Secondary actions stay inside the relevant record screen.

## Icon / logo

The supplied farmer-with-plough image is used to create `majdoor_logo.png`, which is used in the launcher icon and inside the app header/dashboard.

## Local data

This v1 stores records locally with SharedPreferences/JSON so the basic app works without internet. The data model is designed around Field + Crop/Season + Labour + Attendance + Expense + Sale + Payment + Wage Rate History.

## Build

- Android API 36
- minSdk 23
- targetSdk 36
- Java 17
- Gradle 8.11.1
- Android Gradle Plugin 8.10.0
- Kotlin 2.1.20

GitHub Actions is included at `.github/workflows/build-debug.yml` and produces a debug APK artifact.

## Important

This source package is the implementation scaffold based on the locked specification. A release APK still needs a real Android build environment and, for a signed release, the user's signing key/secrets.
