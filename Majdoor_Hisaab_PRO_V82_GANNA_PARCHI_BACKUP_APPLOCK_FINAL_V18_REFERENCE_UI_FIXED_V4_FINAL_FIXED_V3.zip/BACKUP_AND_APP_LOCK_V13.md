# Majdoor Hisaab PRO V82 — Backup + App Lock V13

## Security
- Android device credential is required when opening the app.
- Android device credential is required for edit/delete operations already protected in the source.
- Android device credential is required before restoring a manual backup.

## Backup
- Android Auto Backup is enabled with shared preferences and app photo files included.
- Manual backup creates a portable `.mhbackup` ZIP through Android Storage Access Framework.
- Manual restore validates the backup schema/app identity and refreshes in-memory data after restore.
- Restored worker/field photo paths are remapped to the current device's internal photos directory.
- Cache/report files are excluded from Android Auto Backup.

## UI location
- Profile is opened from the account-circle icon at the top-right of Home.
- Profile → Backup & Restore contains Android Auto Backup information and manual Backup/Restore buttons.
- The Home dashboard is kept clean; the dedicated backup module is removed from Home.

## Build note
Local Gradle compilation could not be completed in this restricted environment because the Gradle wrapper attempted to reach raw.githubusercontent.com. GitHub Actions should be used for final compilation/signing verification.
