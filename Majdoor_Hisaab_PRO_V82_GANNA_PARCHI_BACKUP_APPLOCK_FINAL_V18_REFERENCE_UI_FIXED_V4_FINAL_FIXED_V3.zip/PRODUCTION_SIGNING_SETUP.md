# Production signing setup

This project does not generate a new signing key on every GitHub Actions run. Release APKs are signed with one permanent PKCS#12 keystore supplied through GitHub Actions Secrets.

Required repository secrets:

- `RELEASE_KEYSTORE_BASE64` — Base64 of the existing production `.p12` keystore.
- `KEYSTORE_PASSWORD` — keystore password.
- `KEY_ALIAS` — production key alias.
- `KEY_PASSWORD` — production key password.
- `RELEASE_CERT_SHA256` — optional but recommended SHA-256 certificate fingerprint; when supplied, the workflow refuses to sign with a different certificate.

Important: use the same signing key that was used for the existing production/Play Store app. Do not create a new key if this APK must update an existing installation.

The workflow:

1. Decodes the permanent keystore only into the ephemeral GitHub runner.
2. Verifies the keystore and alias.
3. Optionally verifies the pinned SHA-256 certificate fingerprint.
4. Passes the keystore to Gradle through environment variables.
5. Builds the release APK signed by that key.
6. Verifies the APK signature and package/version.
7. Deletes the temporary keystore from the runner.

The keystore/passwords are never committed to the repository.
