# Majdoor Hisaab PRO V82 — V10 Final Changes

## Screen-lock protection
Android device credential confirmation is now required before protected modifications:
- Labour edit/delete
- Field edit/delete
- Crop edit/delete
- Expense edit/delete
- Sale edit/delete
- Attendance Full/Half change after an attendance already exists
- Attendance delete
- Payment delete
- Wage-rate change

The app uses the phone's Android PIN/Pattern/Password confirmation. If no secure screen lock exists, the protected operation is refused and the user is told to enable one.

## Attendance entry screen
Photo/PDF export buttons were removed from the **नई हाजिरी / हाजिरी लगाने** screen. Export remains available where reporting is appropriate, especially **हाजिरी सूची**.

## Attendance-list PDF
Monthly attendance PDF now groups records by date. Each date gets:
- Date heading
- Number of workers
- Daily wage total
- Individual worker rows
- Extra spacing/separator before the next date

This makes it clear which work belongs to which date.

## Release signing
The bundled workflow now uses the four existing repository secrets:
- RELEASE_KEYSTORE_BASE64
- RELEASE_KEYSTORE_PASSWORD
- RELEASE_KEY_ALIAS
- RELEASE_KEY_PASSWORD

The certificate fingerprint is read directly from the permanent production keystore, so a separate RELEASE_CERT_SHA256 secret is not required.

No temporary signing key is generated.
