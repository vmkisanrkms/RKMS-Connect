# Majdoor Hisaab PRO - no custom rules required for v1.
