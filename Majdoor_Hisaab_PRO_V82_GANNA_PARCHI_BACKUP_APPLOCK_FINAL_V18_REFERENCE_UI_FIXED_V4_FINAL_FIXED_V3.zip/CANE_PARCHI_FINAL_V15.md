# Ganna Parchi FINAL V15

- Cane price changes require Android device screen-lock confirmation.
- The price editor never saves a rate under `ALL`; it always uses a real cane season.
- Year/season filter is built dynamically from saved cane receipts and price history, plus the current season.
- Manual restore replaces the managed app photo directory to prevent stale/orphan photos from remaining after a restore.
- Existing receipt rate is immutable when a later price is added; each receipt keeps the rate effective on its date.
- V14 functionality retained: name/father/code search, 6–7 digit code validation, date, weight, photo, optional remark, yearly summary, edit/delete screen lock, backup inclusion.
