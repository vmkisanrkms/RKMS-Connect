# Majdoor Hisaab PRO V82 — Final Audit V9

The GitHub Actions failure was traced to `android-actions/setup-android@v3` attempting to install the obsolete SDK package `tools` on the Ubuntu runner. V9 removes that action completely.

The workflow now locates the Android SDK preinstalled on the GitHub-hosted runner, finds `sdkmanager` directly, accepts licenses, and installs only `platform-tools`, `platforms;android-36`, and `build-tools;36.0.0`. It verifies adb, aapt2, apksigner and zipalign before the build.

The workflow also keeps Java 17, Gradle 8.11.1, package `com.majdoor.hisaabpro`, version `1.82.0`/82, V8 ZIP extraction, FileProvider report-path verification, Kotlin import checks, permanent production signing, certificate SHA-256 verification, and final APK package/version/signature/alignment verification.

Required GitHub Secrets:
- RELEASE_KEYSTORE_BASE64
- KEYSTORE_PASSWORD
- KEY_ALIAS
- KEY_PASSWORD
- RELEASE_CERT_SHA256

No temporary release keystore is generated.
