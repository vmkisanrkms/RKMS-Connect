# Majdoor Hisaab PRO V12

- App opening is protected by Android device credential.
- Existing edit/delete credential gates remain in place.
- Manual Backup creates a `.mhbackup` ZIP through Android Storage Access Framework.
- Manual Restore requires Android device credential and replaces the app data collections.
- Backup includes labour, fields, crops, expenses, sales, attendance, payments, rate history and stored worker/field photos.
- Android Auto Backup is explicitly configured for `mhpro_store.xml` and `files/photos/` for cloud backup and device transfer.
- Cache/report files are excluded from Android backup.
