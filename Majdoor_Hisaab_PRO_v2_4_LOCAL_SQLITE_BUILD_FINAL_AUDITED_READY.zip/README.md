# Majdoor Hisaab PRO

Professional offline farm labour, attendance, wage and payment management.

## Main workflow
- Select a field/crop
- Select today's team
- Mark each worker Full / Half / None
- Previous Team copies only the team, never attendance
- Each worker has an independent daily wage
- Historical wage is preserved
- Worker and field reports with date range
- Payment ledger and balance
- Multi-page PDF and CSV export
- Share summary and WhatsApp text sharing
- ZIP backup and validated restore
- Local SQLite; no server required

## UI
- English-only interface
- Majdoor Hisaab logo in the app header and launcher
- Professional dashboard cards
- Quick actions
- Searchable workers, fields and today's team
- Full / Half / None attendance buttons
- Worker and field detail screens
- Bottom navigation

## Database
SQLite schema V5:
workers, fields, work_entries, payments, settings, team_members.

The team_members table separates team selection from attendance.

## Build
Android SDK 36, Java 17, Gradle 8.11.1, minSdk 26, targetSdk 36.


## Final build requirements
- Android compileSdk/targetSdk: 36
- Android Build Tools: 36.0.0
- Java: 17
- Gradle: 8.11.1 (configured by GitHub Actions)
- Final APK is signed with the permanent release keystore supplied through GitHub Secrets.
- Required GitHub Secrets: `MAJDOOR_KEYSTORE_BASE64`, `MAJDOOR_KEYSTORE_PASSWORD`, `MAJDOOR_KEY_ALIAS`, `MAJDOOR_KEY_PASSWORD`.
- The workflow uploads only the signed release APK; debug APK and AAB are not uploaded.
