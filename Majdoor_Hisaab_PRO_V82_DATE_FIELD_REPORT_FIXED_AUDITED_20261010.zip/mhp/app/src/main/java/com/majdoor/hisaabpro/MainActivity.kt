package com.majdoor.hisaabpro

import android.app.Activity
import android.app.DatePickerDialog
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.content.ContentResolver
import android.accounts.Account
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.concurrent.Executors
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.UserRecoverableAuthException
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Green = Color(0xFF0B6B4A)
private val GreenDark = Color(0xFF064C36)
private val Bg = Color(0xFFF6FAF8)
private val CardBg = Color.White

private data class Labour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
private data class FandiLabour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
private data class Field(val id:String,val name:String,val address:String,val area:String,val photo:String)
private data class Crop(val id:String,val fieldId:String,val name:String,val variety:String,val sowingDate:String,val season:String)
private data class Expense(val id:String,val fieldId:String,val cropId:String,val type:String,val item:String,val qty:String,val unit:String,val amount:Double,val date:String)
private data class Sale(val id:String,val fieldId:String,val cropId:String,val qty:Double,val unit:String,val rate:Double,val total:Double,val buyer:String,val date:String)
private data class Attendance(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val fraction:Double,val rate:Double)
private data class Payment(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val amount:Double)
private data class LabourClosure(val id:String,val labourId:String,val throughDate:String,val wage:Double,val paid:Double,val closedAt:Long)
private data class WageRate(val id:String,val labourId:String,val effectiveDate:String,val rate:Double)
private data class CanePrice(val id:String,val season:String,val effectiveDate:String,val rate:Double)
private data class CaneParchi(val id:String,val name:String,val fatherName:String,val code:String,val date:String,val weight:Double,val rate:Double,val photo:String,val remark:String,val season:String)
private data class CanePeeling(val id:String,val labourId:String,val fieldId:String,val date:String,val fandi:Double,val rate:Double,val total:Double)
private data class CanePeelingPayment(val id:String,val labourId:String,val date:String,val amount:Double,val method:String,val note:String)

private sealed class Screen {
    data object Home:Screen()
    data object LabourList:Screen()
    data object DailyLabourHome:Screen()
    data object DailyLabourAccounts:Screen()
    data object AllLabourReport:Screen()
    data object AttendanceFields:Screen()
    data object FieldList:Screen()
    data class ExpenseList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class SaleList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class CropList(val fieldId:String?=null):Screen()
    data class LabourDetail(val id:String):Screen()
    data class FieldDetail(val id:String):Screen()
    data class CropDetail(val id:String):Screen()
    data class Attendance(val fieldId:String?=null):Screen()
    data object AttendanceHistory:Screen()
    data object TodayAttendance:Screen()
    data object Backup:Screen()
    data object Profile:Screen()
    data object CaneParchi:Screen()
    data object CanePeeling:Screen()
}


private const val DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
private const val DRIVE_FOLDER_NAME = "Majdoor Hisaab PRO"

private class NeedRemoteConsent(val consentIntent: Intent, message: String) : IllegalStateException(message)

private class GoogleDriveDirect(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_drive",Context.MODE_PRIVATE)
    private fun signInOptions():GoogleSignInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestScopes(Scope(DRIVE_FILE_SCOPE))
        .build()
    fun signInIntent():Intent = GoogleSignIn.getClient(context,signInOptions()).signInIntent
    fun prepareFreshSignIn(onReady:()->Unit){
        prefs.edit().remove("email").apply()
        GoogleSignIn.getClient(context,signInOptions()).signOut().addOnCompleteListener { onReady() }
    }
    fun lastAccount():GoogleSignInAccount? = GoogleSignIn.getLastSignedInAccount(context)
    fun saveAccount(account:GoogleSignInAccount){ prefs.edit().putString("email",account.email.orEmpty()).apply() }
    fun accountLabel():String = lastAccount()?.email ?: prefs.getString("email",null) ?: "Google Account नहीं जुड़ा"

    private fun token(account:GoogleSignInAccount):String{
        val acc:Account=account.account ?: throw IllegalStateException("Google Account उपलब्ध नहीं है।")
        return try {
            GoogleAuthUtil.getToken(context,acc,"oauth2:$DRIVE_FILE_SCOPE")
        } catch (consent:UserRecoverableAuthException) {
            // Do not launch UI from this IO-thread token request. Return the SDK-provided
            // consent intent to the Compose Activity Result handler, which owns retry policy.
            val consentIntent = consent.intent
            if (consentIntent != null) {
                throw NeedRemoteConsent(
                    consentIntent,
                    "Google Drive की अतिरिक्त अनुमति आवश्यक है। अनुमति स्क्रीन खोलें और फिर कार्रवाई जारी रखें।"
                )
            } else {
                throw IllegalStateException(
                    "Google Drive consent Intent उपलब्ध नहीं है। कृपया Backup/Restore दोबारा शुरू करें।"
                )
            }
        }
    }
    private fun request(method:String,url:String,token:String,body:ByteArray?=null,contentType:String?=null):ByteArray{
        val c=(URL(url).openConnection() as HttpURLConnection).apply{
            requestMethod=method
            setRequestProperty("Authorization","Bearer $token")
            connectTimeout=30000; readTimeout=60000
            if(body!=null){doOutput=true; setRequestProperty("Content-Type",contentType ?: "application/octet-stream")}
        }
        if(body!=null) c.outputStream.use{it.write(body)}
        val code=c.responseCode
        val stream=if(code in 200..299)c.inputStream else (c.errorStream ?: c.inputStream)
        val bytes=stream.use{it.readBytes()}
        if(code !in 200..299) throw IllegalStateException("Google Drive error $code: ${bytes.toString(Charsets.UTF_8).take(300)}")
        return bytes
    }
    private fun jsonGet(url:String,token:String):JSONObject=JSONObject(request("GET",url,token).toString(Charsets.UTF_8))

    private fun ensureFolder(token:String):String{
        val q=URLEncoder.encode("name='$DRIVE_FOLDER_NAME' and mimeType='application/vnd.google-apps.folder' and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&pageSize=10&fields=files(id,name)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files!=null && files.length()>0) return files.getJSONObject(0).getString("id")
        val meta=JSONObject().apply{put("name",DRIVE_FOLDER_NAME);put("mimeType","application/vnd.google-apps.folder")}
        return JSONObject(request("POST","https://www.googleapis.com/drive/v3/files?fields=id",token,meta.toString().toByteArray(Charsets.UTF_8),"application/json").toString(Charsets.UTF_8)).getString("id")
    }
    fun upload(account:GoogleSignInAccount,zip:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val boundary="mhpro_${System.currentTimeMillis()}"
        val meta=JSONObject().apply{
            put("name",zip.name)
            put("mimeType","application/octet-stream")
            put("parents",org.json.JSONArray().put(folder))
        }.toString()
        val head=("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: application/octet-stream\r\n\r\n").toByteArray()
        val tail="\r\n--$boundary--\r\n".toByteArray()
        val bytes=zip.readBytes()
        val payload=ByteArray(head.size+bytes.size+tail.size)
        System.arraycopy(head,0,payload,0,head.size);System.arraycopy(bytes,0,payload,head.size,bytes.size);System.arraycopy(tail,0,payload,head.size+bytes.size,tail.size)
        val result=request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name",token,payload,"multipart/related; boundary=$boundary")
        return JSONObject(result.toString(Charsets.UTF_8)).optString("name",zip.name)
    }
    fun downloadLatest(account:GoogleSignInAccount,out:File):String{
        val token=token(account)
        val folder=ensureFolder(token)
        val q=URLEncoder.encode("'$folder' in parents and trashed=false","UTF-8")
        val url="https://www.googleapis.com/drive/v3/files?q=$q&orderBy=createdTime desc&pageSize=20&fields=files(id,name,createdTime,mimeType)"
        val files=jsonGet(url,token).optJSONArray("files")
        if(files==null || files.length()==0) throw IllegalStateException("Google Drive में कोई backup नहीं मिला।")
        var chosen:JSONObject?=null
        for(i in 0 until files.length()){
            val f=files.getJSONObject(i)
            if(f.optString("name").endsWith(".mhbackup",true)){chosen=f;break}
        }
        val file=chosen ?: files.getJSONObject(0)
        val id=file.getString("id")
        val data=request("GET","https://www.googleapis.com/drive/v3/files/$id?alt=media",token)
        out.outputStream().use{it.write(data)}
        return file.optString("name","backup.mhbackup")
    }
}

private class Store(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
    var labours by mutableStateOf(loadLabours()); private set
    var fandiLabours by mutableStateOf(loadFandiLabours()); private set
    var fields by mutableStateOf(loadFields()); private set
    var crops by mutableStateOf(loadCrops()); private set
    var expenses by mutableStateOf(loadExpenses()); private set
    var sales by mutableStateOf(loadSales()); private set
    var attendances by mutableStateOf(loadAttendance()); private set
    var payments by mutableStateOf(loadPayments()); private set
    var labourClosures by mutableStateOf(loadLabourClosures()); private set
    var lockedLabourMonths by mutableStateOf(loadLockedLabourMonths()); private set
    var rates by mutableStateOf(loadRates()); private set
    var fandiRate by mutableStateOf(prefs.getString("fandiRate","5")?.toDoubleOrNull() ?: 5.0); private set
    var canePrices by mutableStateOf(loadCanePrices()); private set
    var caneParchis by mutableStateOf(loadCaneParchis()); private set
    var canePeelings by mutableStateOf(loadCanePeelings()); private set
    var canePeelingPayments by mutableStateOf(loadCanePeelingPayments()); private set

    init {
        // One-time compatibility migration: only workers already referenced by old
        // Fandi records are copied into the new independent Fandi labour list.
        // Daily labour records are never copied wholesale.
        if(fandiLabours.isEmpty() && canePeelings.isNotEmpty()){
            val ids=canePeelings.map{it.labourId}.distinct()
            val migrated=ids.mapNotNull{id->labours.firstOrNull{it.id==id}?.let{l->FandiLabour(l.id,l.name,l.address,l.rate,l.mobile,l.photo)}}
            if(migrated.isNotEmpty()){
                fandiLabours=migrated.distinctBy{it.id}
                write("fandiLabour",fandiLabours,::obj)
            }
        }
        normalizeFandiData()
    }

    private fun normalizeFandiData(){
        fun nameKey(v:String)=v.trim().lowercase(Locale.ROOT).replace(Regex("\\s+")," ")
        fun phoneKey(v:String)=v.filter{it.isDigit()}
        val canonical=mutableListOf<FandiLabour>()
        val idMap=mutableMapOf<String,String>()
        fandiLabours.forEach{worker->
            val nk=nameKey(worker.name)
            val ph=phoneKey(worker.mobile)
            // Product rule: a normalized worker name must be unique. For legacy data,
            // map same-name profiles to the first profile and preserve their linked history.
            // A matching valid phone also identifies the same profile even if the name changed.
            val prior=canonical.firstOrNull{old->
                (nk.isNotBlank() && nameKey(old.name)==nk) || (ph.length>=7 && phoneKey(old.mobile).length>=7 && ph==phoneKey(old.mobile))
            }
            if(prior==null){canonical.add(worker);idMap[worker.id]=worker.id}
            else{
                idMap[worker.id]=prior.id
                val merged=prior.copy(
                    address=prior.address.ifBlank{worker.address},
                    mobile=prior.mobile.ifBlank{worker.mobile},
                    photo=prior.photo.ifBlank{worker.photo}
                )
                canonical[canonical.indexOfFirst{it.id==prior.id}]=merged
            }
        }
        val mappedRows=canePeelings.map{row->row.copy(labourId=idMap[row.labourId]?:row.labourId)}
        // Consolidate legacy duplicate rows by ADDING their quantities, never replacing 10 with 15.
        val uniqueRows=linkedMapOf<String,CanePeeling>()
        mappedRows.forEach{row->
            val key="${row.labourId}|${row.fieldId}|${row.date}"
            val old=uniqueRows[key]
            uniqueRows[key]=if(old==null) row else {
                val f=old.fandi+row.fandi
                val amount=old.total+row.total
                old.copy(fandi=f,total=amount,rate=if(f>0) amount/f else old.rate)
            }
        }
        val cleanRows=uniqueRows.values.toList()
        val cleanPayments=canePeelingPayments.map{payment->payment.copy(labourId=idMap[payment.labourId]?:payment.labourId)}
        if(canonical!=fandiLabours){fandiLabours=canonical;write("fandiLabour",fandiLabours,::obj)}
        if(cleanRows!=canePeelings){canePeelings=cleanRows;write("canePeeling",canePeelings,::obj)}
        if(cleanPayments!=canePeelingPayments){canePeelingPayments=cleanPayments;write("canePeelingPayment",canePeelingPayments,::obj)}
    }

    private fun read(key:String)=JSONArray(prefs.getString(key,"[]") ?: "[]")
    private fun str(o:JSONObject,k:String)=o.optString(k,"")
    private fun num(o:JSONObject,k:String)=o.optDouble(k,0.0)
    private fun save(key:String,a:JSONArray){prefs.edit().putString(key,a.toString()).apply()}
    private fun <T> JSONArray.mapList(mapper:(JSONObject)->T): List<T> = (0 until length()).map { mapper(getJSONObject(it)) }

    private fun loadLabours()=read("labour").mapList{Labour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFandiLabours()=read("fandiLabour").mapList{FandiLabour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFields():List<Field>{
        val raw=read("field").mapList{Field(str(it,"id"),str(it,"name"),str(it,"address"),str(it,"area"),str(it,"photo"))}
        val order=prefs.getString("fieldOrder","").orEmpty().split('|').filter{it.isNotBlank()}
        if(order.isEmpty()) return raw
        val byId=raw.associateBy{it.id}
        return order.mapNotNull{byId[it]} + raw.filter{it.id !in order}
    }
    private fun loadCrops()=read("crop").mapList{Crop(str(it,"id"),str(it,"fieldId"),str(it,"name"),str(it,"variety"),str(it,"sowingDate"),str(it,"season"))}
    private fun loadExpenses()=read("expense").mapList{Expense(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),str(it,"type"),str(it,"item"),str(it,"qty"),str(it,"unit"),num(it,"amount"),str(it,"date"))}
    private fun loadSales()=read("sale").mapList{Sale(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),num(it,"qty"),str(it,"unit"),num(it,"rate"),num(it,"total"),str(it,"buyer"),str(it,"date"))}
    private fun loadAttendance():List<Attendance>{
        val raw=read("attendance").mapList{Attendance(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"fraction"),num(it,"rate"))}
        // Backward compatibility: an old attendance without cropId can be safely
        // attached to the only crop in that field. If multiple crops exist, keep
        // it field-level because assigning it to a crop would be guesswork.
        return raw.map{a->
            if(a.cropId.isBlank()){
                val matches=crops.filter{it.fieldId==a.fieldId}
                if(matches.size==1) a.copy(cropId=matches.first().id) else a
            } else a
        }
    }
    private fun loadPayments()=read("payment").mapList{Payment(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"amount"))}
    private fun loadLabourClosures()=read("labourClosure").mapList{LabourClosure(str(it,"id"),str(it,"labourId"),str(it,"throughDate"),num(it,"wage"),num(it,"paid"),it.optLong("closedAt",0L))}
    private fun loadLockedLabourMonths():List<String> = read("lockedLabourMonths").mapList{str(it,"month")}.filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    private fun loadRates()=read("rateHistory").mapList{WageRate(str(it,"id"),str(it,"labourId"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCanePrices()=read("canePriceHistory").mapList{CanePrice(str(it,"id"),str(it,"season"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCaneParchis()=read("caneParchi").mapList{CaneParchi(str(it,"id"),str(it,"name"),str(it,"fatherName"),str(it,"code"),str(it,"date"),num(it,"weight"),num(it,"rate"),str(it,"photo"),str(it,"remark"),str(it,"season"))}
    private fun loadCanePeelings()=read("canePeeling").mapList{CanePeeling(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"date"),num(it,"fandi"),num(it,"rate"),num(it,"total"))}
    private fun loadCanePeelingPayments()=read("canePeelingPayment").mapList{CanePeelingPayment(str(it,"id"),str(it,"labourId"),str(it,"date"),num(it,"amount"),str(it,"method"),str(it,"note"))}

    private fun obj(x:Labour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:FandiLabour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:Field)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("area",x.area);put("photo",x.photo)}
    private fun obj(x:Crop)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("name",x.name);put("variety",x.variety);put("sowingDate",x.sowingDate);put("season",x.season)}
    private fun obj(x:Expense)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("type",x.type);put("item",x.item);put("qty",x.qty);put("unit",x.unit);put("amount",x.amount);put("date",x.date)}
    private fun obj(x:Sale)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("qty",x.qty);put("unit",x.unit);put("rate",x.rate);put("total",x.total);put("buyer",x.buyer);put("date",x.date)}
    private fun obj(x:Attendance)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("fraction",x.fraction);put("rate",x.rate)}
    private fun obj(x:Payment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("amount",x.amount)}
    private fun obj(x:LabourClosure)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("throughDate",x.throughDate);put("wage",x.wage);put("paid",x.paid);put("closedAt",x.closedAt)}
    private fun obj(x:WageRate)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CanePrice)=JSONObject().apply{put("id",x.id);put("season",x.season);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CaneParchi)=JSONObject().apply{put("id",x.id);put("name",x.name);put("fatherName",x.fatherName);put("code",x.code);put("date",x.date);put("weight",x.weight);put("rate",x.rate);put("photo",x.photo);put("remark",x.remark);put("season",x.season)}
    private fun obj(x:CanePeeling)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("date",x.date);put("fandi",x.fandi);put("rate",x.rate);put("total",x.total)}
    private fun obj(x:CanePeelingPayment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("date",x.date);put("amount",x.amount);put("method",x.method);put("note",x.note)}
    private fun <T> write(key:String,list:List<T>,mapper:(T)->JSONObject){save(key,JSONArray(list.map(mapper)))}

    private val backupKeys = listOf("labour","fandiLabour","field","crop","expense","sale","attendance","payment","labourClosure","rateHistory","canePriceHistory","caneParchi","canePeeling","canePeelingPayment")

    fun createBackupZip(output:File){
        output.parentFile?.mkdirs()
        val root=JSONObject().apply{
            put("schemaVersion",2)
            put("app","Majdoor Hisaab PRO")
            put("appVersion",BuildConfig.VERSION_NAME)
            put("createdAt",System.currentTimeMillis())
            put("fandiRate",fandiRate)
            backupKeys.forEach{put(it,read(it))}
        }
        val photoPaths=(labours.map{it.photo}+fandiLabours.map{it.photo}+fields.map{it.photo}+caneParchis.map{it.photo}).filter{it.isNotBlank()}
            .map{File(it)}.filter{it.isFile}.distinctBy{it.absolutePath}
        val photoMap=JSONObject()
        photoPaths.forEachIndexed{index,file->
            val safeBase=file.name.replace(Regex("[^A-Za-z0-9._-]"),"_")
            photoMap.put(file.absolutePath,"${index}_${safeBase}")
        }
        root.put("photoMap",photoMap)
        ZipOutputStream(FileOutputStream(output)).use{zos->
            zos.putNextEntry(ZipEntry("backup.json"))
            zos.write(root.toString().toByteArray(Charsets.UTF_8))
            zos.closeEntry()
            photoPaths.forEach{file->
                val safe=photoMap.optString(file.absolutePath)
                if(safe.isBlank()) return@forEach
                zos.putNextEntry(ZipEntry("photos/$safe"))
                file.inputStream().use{it.copyTo(zos)}
                zos.closeEntry()
            }
        }
    }

    fun validateBackupZip(input:File){
        var backupJson:String?=null
        var total=0L
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry ?: break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                val name=entry.name.replace('\\','/')
                if(name.contains("..") || name.startsWith("/")) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(!entry.isDirectory){
                    val bytes=zis.readBytes(); total+=bytes.size
                    if(total>100L*1024L*1024L) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
                    if(name=="backup.json") backupJson=bytes.toString(Charsets.UTF_8)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson ?: throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO") throw IllegalArgumentException("Backup app match नहीं करता।")
        if(root.optInt("schemaVersion",0) !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
    }

    fun restoreBackupZip(input:File):String{
        var backupJson:String?=null
        val photoEntries=mutableListOf<Pair<String,ByteArray>>()
        var total=0L
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry?:break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                if(entry.isDirectory){zis.closeEntry();continue}
                val name=entry.name.replace('\\','/')
                if(name.contains("..") || name.startsWith("/")) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(name.startsWith("photos/") && name.removePrefix("photos/").isBlank()) throw IllegalArgumentException("Backup photo entry गलत है।")
                val bytes=zis.readBytes()
                total+=bytes.size
                if(total>100L*1024L*1024L) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
                when{
                    name=="backup.json" -> backupJson=bytes.toString(Charsets.UTF_8)
                    name.startsWith("photos/") -> photoEntries.add(name.removePrefix("photos/") to bytes)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson?:throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO")
            throw IllegalArgumentException("Backup app match नहीं करता।")
        val schema=root.optInt("schemaVersion",0)
        if(schema !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        val photoMap=root.optJSONObject("photoMap") ?: JSONObject()
        val restoredPhotoNames=mutableMapOf<String,String>()
        fun restoredPath(original:String):String{
            if(original.isBlank()) return ""
            val backupName=photoMap.optString(original,"")
            if(backupName.isNotBlank()) return restoredPhotoNames[File(backupName).name].orEmpty()
            // Backward compatibility for schema v1 backups: match by original basename.
            val legacy=File(original).name
            val candidate=photoEntries.firstOrNull{File(it.first).name.endsWith("_$legacy") || File(it.first).name==legacy}
            return candidate?.let{restoredPhotoNames[File(it.first).name].orEmpty()} ?: ""
        }
        backupKeys.forEach{key->
            val arr=root.optJSONArray(key) ?: JSONArray()
            prefs.edit().putString(key,arr.toString()).apply()
        }
        root.optDouble("fandiRate", Double.NaN).takeIf{it.isFinite() && it>0}?.let{prefs.edit().putString("fandiRate",it.toString()).apply();fandiRate=it}
        // Restore is a full data replacement. Remove the managed photo folder first so
        // photos from an older backup/device cannot remain as orphan files.
        val photoDir=File(context.filesDir,"photos")
        if(photoDir.exists()) photoDir.deleteRecursively()
        photoDir.mkdirs()
        photoEntries.forEach{(name,bytes)->
            if(name.isBlank()) return@forEach
            val safe=File(name).name
            File(photoDir,safe).outputStream().use{it.write(bytes)}
            restoredPhotoNames[safe]=File(photoDir,safe).absolutePath
        }
        labours=loadLabours().map{l->if(l.photo.isBlank()) l else l.copy(photo=restoredPath(l.photo))}
        fandiLabours=loadFandiLabours().map{l->if(l.photo.isBlank()) l else l.copy(photo=restoredPath(l.photo))}
        fields=loadFields().map{f->if(f.photo.isBlank()) f else f.copy(photo=restoredPath(f.photo))}
        // Persist restored photo paths so the restored database remains portable on this device.
        write("labour",labours,::obj); write("fandiLabour",fandiLabours,::obj); write("field",fields,::obj)
        crops=loadCrops(); expenses=loadExpenses()
        sales=loadSales(); attendances=loadAttendance(); payments=loadPayments(); labourClosures=loadLabourClosures(); rates=loadRates(); canePrices=loadCanePrices(); caneParchis=loadCaneParchis(); canePeelings=loadCanePeelings(); canePeelingPayments=loadCanePeelingPayments()
        caneParchis=caneParchis.map{x->if(x.photo.isBlank()) x else x.copy(photo=restoredPath(x.photo))}
        write("caneParchi",caneParchis,::obj)
        return root.optString("createdAt","")
    }

    fun addCanePrice(x:CanePrice){
        canePrices=canePrices.filterNot{it.season==x.season && it.effectiveDate==x.effectiveDate}+x
        write("canePriceHistory",canePrices,::obj)
    }
    fun caneRateFor(season:String,date:String):Double=
        canePrices.filter{it.season==season && validDate(it.effectiveDate) && it.effectiveDate<=date}
            .maxByOrNull{it.effectiveDate}?.rate ?: 400.0
    fun canePricesFor(season:String)=canePrices.filter{it.season==season}.sortedByDescending{it.effectiveDate}.distinctBy{it.effectiveDate}
    fun addCaneParchi(x:CaneParchi){caneParchis=caneParchis+x;write("caneParchi",caneParchis,::obj)}
    fun updateCaneParchi(x:CaneParchi){caneParchis=caneParchis.map{if(it.id==x.id)x else it};write("caneParchi",caneParchis,::obj)}
    fun deleteCaneParchi(id:String){caneParchis=caneParchis.filterNot{it.id==id};write("caneParchi",caneParchis,::obj)}
    fun addCanePeeling(x:CanePeeling):Boolean{
        // Never silently overwrite/accumulate an existing worker + date + field entry.
        // Return the result so callers can keep the form open and explain a duplicate.
        val duplicate=canePeelings.any{it.labourId==x.labourId&&it.fieldId==x.fieldId&&it.date==x.date}
        if(duplicate) return false
        canePeelings=canePeelings+x
        write("canePeeling",canePeelings,::obj)
        return true
    }
    fun updateCanePeeling(x:CanePeeling){canePeelings=canePeelings.map{if(it.id==x.id)x else it};write("canePeeling",canePeelings,::obj)}
    fun deleteCanePeeling(id:String){canePeelings=canePeelings.filterNot{it.id==id};write("canePeeling",canePeelings,::obj)}
    fun addCanePeelingPayment(x:CanePeelingPayment){canePeelingPayments=canePeelingPayments+x;write("canePeelingPayment",canePeelingPayments,::obj)}
    fun updateCanePeelingPayment(x:CanePeelingPayment){canePeelingPayments=canePeelingPayments.map{if(it.id==x.id)x else it};write("canePeelingPayment",canePeelingPayments,::obj)}
    fun deleteCanePeelingPayment(id:String){canePeelingPayments=canePeelingPayments.filterNot{it.id==id};write("canePeelingPayment",canePeelingPayments,::obj)}

    fun persistPhoto(uriString:String, owner:String):String {
        if(uriString.isBlank() || uriString.startsWith("file://")) return uriString
        return try {
            val uri=Uri.parse(uriString)
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return ""
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun persistBitmapPhoto(bitmap:Bitmap, owner:String):String {
        return try {
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG,90,out) }
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    private fun normalizedLabourName(value:String)=value.trim().replace(Regex("\\s+")," ").lowercase(java.util.Locale.ROOT)
    fun labourNameExists(name:String,excludeId:String?=null):Boolean{
        val normalized=normalizedLabourName(name)
        return normalized.isNotBlank() && labours.any{it.id!=excludeId && normalizedLabourName(it.name)==normalized}
    }
    @Synchronized fun addLabour(x:Labour):Boolean{
        if(x.name.isBlank() || labourNameExists(x.name)) return false
        labours=labours+x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        write("labour",labours,::obj)
        if(x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
        return true
    }
    @Synchronized fun updateLabour(x:Labour):Boolean{
        if(x.name.isBlank() || labourNameExists(x.name,x.id)) return false
        val normalized=x.copy(name=x.name.trim().replace(Regex("\\s+")," "))
        val old=labours.firstOrNull{it.id==x.id}
        labours=labours.map{if(it.id==x.id)normalized else it}
        write("labour",labours,::obj)
        if(old!=null && old.rate!=x.rate && x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
        return true
    }
    @Synchronized fun deleteLabour(id:String):Boolean{
        // Preserve wage/payment history; hard-delete only unused workers.
        val hasHistory=attendances.any{it.labourId==id} || payments.any{it.labourId==id} || rates.any{it.labourId==id} || canePeelings.any{it.labourId==id} || canePeelingPayments.any{it.labourId==id}
        if(hasHistory) return false
        labours=labours.filterNot{it.id==id};write("labour",labours,::obj);return true
    }

    fun updateFandiRate(value:Double){ if(value.isFinite() && value>0){ fandiRate=value; prefs.edit().putString("fandiRate",value.toString()).apply() } }
    fun addFandiLabour(x:FandiLabour){fandiLabours=fandiLabours+x;write("fandiLabour",fandiLabours,::obj)}
    fun updateFandiLabour(x:FandiLabour){fandiLabours=fandiLabours.map{if(it.id==x.id)x else it};write("fandiLabour",fandiLabours,::obj)}
    fun deleteFandiLabour(id:String){fandiLabours=fandiLabours.filterNot{it.id==id};canePeelings=canePeelings.filterNot{it.labourId==id};canePeelingPayments=canePeelingPayments.filterNot{it.labourId==id};write("fandiLabour",fandiLabours,::obj);write("canePeeling",canePeelings,::obj);write("canePeelingPayment",canePeelingPayments,::obj)}

    private fun persistFieldOrder(){prefs.edit().putString("fieldOrder",fields.joinToString("|"){it.id}).apply()}
    fun moveField(id:String,delta:Int){
        val from=fields.indexOfFirst{it.id==id}; val to=from+delta
        if(from<0 || to !in fields.indices) return
        val reordered=fields.toMutableList(); val item=reordered.removeAt(from); reordered.add(to,item)
        fields=reordered; persistFieldOrder()
    }
    fun addField(x:Field){fields=fields+x;write("field",fields,::obj);persistFieldOrder()}
    fun updateField(x:Field){fields=fields.map{if(it.id==x.id)x else it};write("field",fields,::obj)}
    @Synchronized fun deleteField(id:String):Boolean{
        // Preserve field-linked financial and crop history.
        val cropIds=crops.filter{it.fieldId==id}.map{it.id}.toSet()
        val hasHistory=expenses.any{it.fieldId==id || it.cropId in cropIds} || sales.any{it.fieldId==id || it.cropId in cropIds} || attendances.any{it.fieldId==id || it.cropId in cropIds} || payments.any{it.fieldId==id || it.cropId in cropIds} || canePeelings.any{it.fieldId==id}
        if(hasHistory) return false
        fields=fields.filterNot{it.id==id};persistFieldOrder();crops=crops.filterNot{it.fieldId==id};write("field",fields,::obj);write("crop",crops,::obj);return true
    }

    fun addCrop(x:Crop){crops=crops+x;write("crop",crops,::obj)}
    fun updateCrop(x:Crop){crops=crops.map{if(it.id==x.id)x else it};write("crop",crops,::obj)}
    @Synchronized fun deleteCrop(id:String):Boolean{
        // Do not silently erase expenses, sales, wages or payments linked to a crop.
        val hasHistory=expenses.any{it.cropId==id} || sales.any{it.cropId==id} || attendances.any{it.cropId==id} || payments.any{it.cropId==id}
        if(hasHistory) return false
        crops=crops.filterNot{it.id==id};write("crop",crops,::obj);return true
    }

    fun addExpense(x:Expense){expenses=expenses+x;write("expense",expenses,::obj)}
    fun updateExpense(x:Expense){expenses=expenses.map{if(it.id==x.id)x else it};write("expense",expenses,::obj)}
    fun deleteExpense(id:String){expenses=expenses.filterNot{it.id==id};write("expense",expenses,::obj)}

    fun addSale(x:Sale){sales=sales+x;write("sale",sales,::obj)}
    fun updateSale(x:Sale){sales=sales.map{if(it.id==x.id)x else it};write("sale",sales,::obj)}
    fun deleteSale(id:String){sales=sales.filterNot{it.id==id};write("sale",sales,::obj)}

    fun isClosedDate(labourId:String,date:String)=latestClosure(labourId)?.throughDate?.let{date<=it}?:false
    fun isMonthLocked(date:String):Boolean = date.length>=7 && date.substring(0,7) in lockedLabourMonths
    fun setLabourMonthLocked(month:String,locked:Boolean):Boolean {
        if(!month.matches(Regex("\\d{4}-\\d{2}"))) return false
        lockedLabourMonths=(if(locked) (lockedLabourMonths+month) else lockedLabourMonths.filterNot{it==month}).distinct().sortedDescending()
        save("lockedLabourMonths",JSONArray().apply{lockedLabourMonths.forEach{put(JSONObject().put("month",it))}})
        return true
    }
    @Synchronized fun addPayment(x:Payment):Boolean{if(isClosedDate(x.labourId,x.date)||payments.any{it.id==x.id})return false;payments=payments+x;write("payment",payments,::obj);return true}
    fun updatePayment(x:Payment):Boolean{if(isClosedDate(x.labourId,x.date))return false;payments=payments.map{if(it.id==x.id)x else it};write("payment",payments,::obj);return true}
    fun deletePayment(id:String):Boolean{val row=payments.firstOrNull{it.id==id}?:return false;if(isClosedDate(row.labourId,row.date))return false;payments=payments.filterNot{it.id==id};write("payment",payments,::obj);return true}
    fun latestClosure(labourId:String):LabourClosure? = labourClosures.filter{it.labourId==labourId}.maxByOrNull{it.throughDate}
    fun closeLabourAccount(labourId:String,throughDate:String,wage:Double,paid:Double):Boolean {
        if(!validDate(throughDate)) return false
        val old=latestClosure(labourId)
        if(old!=null && throughDate<=old.throughDate) return false
        val closure=LabourClosure(UUID.randomUUID().toString(),labourId,throughDate,wage,paid,System.currentTimeMillis())
        labourClosures=labourClosures+closure
        write("labourClosure",labourClosures,::obj)
        return true
    }
    fun closureHistory(labourId:String?=null)=labourClosures.filter{labourId==null||it.labourId==labourId}.sortedByDescending{it.throughDate}
    fun setRate(x:WageRate){rates=rates.filterNot{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}+x;write("rateHistory",rates,::obj)}
    fun attendanceConflict(x:Attendance):String?{
        val existingSame=attendances.firstOrNull{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.date==x.date
        }
        val otherTotal=attendances.filter{
            it.labourId==x.labourId &&
            it.date==x.date &&
            it.id!=existingSame?.id
        }.sumOf{it.fraction}
        if(otherTotal+x.fraction>1.0001){
            return if(otherTotal>=0.9999) "इस तारीख में इस मजदूर की पूरी 1 दिन की हाजिरी पहले से लगी है।" else "इस तारीख में इस मजदूर की ${if(otherTotal>=0.5) "आधी" else "कुछ"} हाजिरी पहले से लगी है। बाकी जगह केवल बची हुई हाजिरी लग सकती है।"
        }
        return null
    }
    @Synchronized fun upsertAttendance(x:Attendance):String?{
        if(isMonthLocked(x.date)) return "${monthTitle(x.date.take(7))} का हिसाब लॉक है। पुरानी हाजिरी सुरक्षित है; नई हाजिरी चालू महीने में दर्ज करें।"
        val closedThrough=latestClosure(x.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && x.date<=closedThrough) return "इस मजदूर का ${closedThrough} तक का हिसाब फाइनल है। पुरानी तारीख में बदलाव नहीं हो सकता।"
        val conflict=attendanceConflict(x)
        if(conflict!=null) return conflict
        val existing=attendances.firstOrNull{it.labourId==x.labourId && it.fieldId==x.fieldId && it.date==x.date}
        val safeRow=if(existing!=null) x.copy(id=existing.id) else x
        attendances=attendances.filterNot{it.labourId==safeRow.labourId && it.fieldId==safeRow.fieldId && it.date==safeRow.date}+safeRow
        write("attendance",attendances,::obj)
        return null
    }
    fun deleteAttendance(id:String):Boolean{
        val row=attendances.firstOrNull{it.id==id}?:return false
        if(isMonthLocked(row.date)) return false
        val closedThrough=latestClosure(row.labourId)?.throughDate.orEmpty()
        if(closedThrough.isNotBlank() && row.date<=closedThrough) return false
        attendances=attendances.filterNot{it.id==id};write("attendance",attendances,::obj);return true
    }
    fun rateFor(labourId:String,date:String):Double{
        val l=labours.firstOrNull{it.id==labourId}?:return 0.0
        val applicable=rates.filter{it.labourId==labourId && validDate(it.effectiveDate) && it.effectiveDate<=date}
        return applicable.maxByOrNull{it.effectiveDate}?.rate ?: l.rate
    }
    fun rateHistoryFor(labourId:String)=rates.filter{it.labourId==labourId}.sortedByDescending{it.effectiveDate}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{MajdoorApp()}
    }

}

private fun driveErrorMessage(action:String,error:Throwable):String{
    val causes=generateSequence(error){it.cause}.toList()
    val root=causes.lastOrNull() ?: error
    val detail=(causes.mapNotNull{it.message}.joinToString(" | ").ifBlank{"Unknown error"}).take(500)
    val developerError=causes.any{(it as? ApiException)?.statusCode==10} || detail.contains("DEVELOPER_ERROR",ignoreCase=true) || detail.contains("status=10",ignoreCase=true)
    return when {
        developerError ->
            "$action असफल: Google OAuth configuration गलत है (status 10)। Package com.majdoor.hisaabpro और इसी Release APK की signing SHA-1 वाला Android OAuth client बनाएं/जाँचें, Google Drive API enable करें, फिर उसी stable keystore से APK rebuild करें।"
        detail.contains("PERMISSION_DENIED",ignoreCase=true) || detail.contains("insufficient",ignoreCase=true) ->
            "$action असफल: Google Drive permission नहीं मिली। Account दोबारा चुनें और Drive file access अनुमति दें। विवरण: $detail"
        else -> "$action असफल: $detail"
    }
}

@Composable private fun MajdoorApp(){
    val context=LocalContext.current
    val activity=context as? Activity
    val store=remember{Store(context)}
    val drive=remember{GoogleDriveDirect(context)}
    val scope=rememberCoroutineScope()
    var driveAccount by remember{mutableStateOf(drive.lastAccount())}
    var driveBusy by remember{mutableStateOf(false)}
    var pendingDriveAction by rememberSaveable{mutableStateOf("")}
    var consentRetryInProgress by rememberSaveable{mutableStateOf(false)}
    val stack=remember{mutableStateListOf<Screen>(Screen.Home)}
    val screen=stack.last()
    var appUnlocked by rememberSaveable{mutableStateOf(false)}
    var backupStatus by remember{mutableStateOf("")}
    var restorePending by remember{mutableStateOf(false)}
    var restoreFile by remember{mutableStateOf<File?>(null)}
    val driveSignInLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        // Google Sign-In may return useful Status data even when resultCode is not RESULT_OK.
        // Always inspect the returned intent so OAuth/configuration failures are not hidden as cancellation.
        val returnedIntent=result.data
        if(returnedIntent==null){
            driveAccount=null
            backupStatus="Google Sign-In पूरा नहीं हुआ (resultCode=${result.resultCode}, data=null). दोबारा कोशिश करें; अगर बार-बार हो तो Release SHA-1/OAuth configuration जाँचें।"
        } else {
            runCatching{GoogleSignIn.getSignedInAccountFromIntent(returnedIntent).getResult(ApiException::class.java)}
                .onSuccess{account->
                    driveAccount=account
                    drive.saveAccount(account)
                    backupStatus="Google Account जुड़ गया: ${account.email ?: ""}"
                }
                .onFailure{error->
                    driveAccount=null
                    val code=(error as? ApiException)?.statusCode
                    val codeText=code?.let { "$it (${CommonStatusCodes.getStatusCodeString(it)})" } ?: "unknown"
                    val resultText=if(result.resultCode==Activity.RESULT_OK) "OK" else "${result.resultCode}"
                    backupStatus=if(code==10) "Google Sign-In failed: status=10 (DEVELOPER_ERROR). यह आम तौर पर Google Cloud OAuth configuration mismatch है। Android OAuth client में package com.majdoor.hisaabpro और इसी Release keystore का SHA-1 दर्ज करें; Google Drive API enable करें। फिर नया APK बनाकर दोबारा कोशिश करें।" else "Google Sign-In failed: status=$codeText, resultCode=$resultText. ${error.message ?: "Google account/Drive permission पूरी नहीं हुई"}"
                }
        }
    }
    var startDriveAction: (String, Boolean) -> Unit = { _, _ -> }
    val driveConsentLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        val action=pendingDriveAction
        pendingDriveAction="" // consume before any retry; duplicate results cannot repeat the operation
        if(action.isBlank()) return@rememberLauncherForActivityResult
        if(result.resultCode==Activity.RESULT_OK){
            consentRetryInProgress=true
            driveBusy=false
            startDriveAction(action, true)
        }else{
            consentRetryInProgress=false
            driveBusy=false
            backupStatus=if(action=="backup") "Google Drive Backup रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Backup दबाएँ।" else "Google Drive Restore रद्द: अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए Restore दबाएँ।"
        }
    }
    val createBackupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->
        if(uri==null){
            backupStatus="Backup save नहीं किया गया। Google Drive चुनकर फिर Backup बनाएं।"
        } else {
            val temp=File(context.cacheDir,"mhpro_backup_${System.currentTimeMillis()}.zip")
            runCatching{
                store.createBackupZip(temp)
                context.contentResolver.openOutputStream(uri)?.use{out->
                    temp.inputStream().use{it.copyTo(out)}
                } ?: throw IllegalStateException("Backup location open नहीं हुई।")
                backupStatus="Backup Google Drive/चुनी हुई जगह पर सफलतापूर्वक save हो गया।"
            }.onFailure{
                backupStatus="Backup failed: ${it.message ?: "Unknown error"}"
            }
            temp.delete()
        }
    }
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            runCatching{
                val temp=File(context.cacheDir,"mhpro_restore_${System.currentTimeMillis()}.zip")
                context.contentResolver.openInputStream(uri)?.use{input->temp.outputStream().use{input.copyTo(it)}}
                    ?: throw IllegalStateException("Backup file open नहीं हुई।")
                restoreFile=temp
                restorePending=true
            }.onFailure{backupStatus="Restore file नहीं खुली: ${it.message ?: "Unknown error"}"}
        }
    }
    startDriveAction = start@{ action, isConsentRetry ->
        // A fresh user action starts a new one-shot consent cycle; the automatic retry does not.
        if(driveBusy || pendingDriveAction.isNotBlank()) return@start
        if(!isConsentRetry) consentRetryInProgress=false
        val account=driveAccount
        if(account==null){
            driveSignInLauncher.launch(drive.signInIntent())
            return@start
        }
        driveBusy=true
        scope.launch{
            val result=runCatching{withContext(Dispatchers.IO){
                if(action=="backup"){
                    val temp=File(context.cacheDir,"mhpro_drive_upload_${System.currentTimeMillis()}.mhbackup")
                    try{
                        store.createBackupZip(temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Backup खाली बना है; Drive पर upload नहीं किया गया।")
                        drive.upload(account,temp)
                    }finally{temp.delete()}
                }else{
                    val temp=File(context.cacheDir,"mhpro_drive_restore_${System.currentTimeMillis()}.mhbackup")
                    try{
                        val name=drive.downloadLatest(account,temp)
                        if(!temp.isFile || temp.length()==0L) throw IllegalStateException("Drive से खाली backup मिला।")
                        store.validateBackupZip(temp)
                        name to temp
                    }catch(e:Throwable){temp.delete();throw e}
                }
            }}
            result.onSuccess{value->
                if(action=="backup") backupStatus="Google Drive पर backup upload हो गया: $value"
                else {
                    @Suppress("UNCHECKED_CAST")
                    val pair=value as Pair<String,File>
                    restoreFile=pair.second
                    restorePending=true
                    backupStatus="Drive backup '${pair.first}' सत्यापित है। Restore दबाकर पुष्टि करें।"
                }
                consentRetryInProgress=false
                driveBusy=false
            }.onFailure{error->
                if(error is NeedRemoteConsent && !consentRetryInProgress){
                    pendingDriveAction=action
                    // Launch the exact recoverable consent intent once, on the foreground UI.
                    runCatching{driveConsentLauncher.launch(error.consentIntent)}.onFailure{launchError->
                        pendingDriveAction=""
                        backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",launchError)
                        driveBusy=false
                    }
                }else{
                    consentRetryInProgress=false
                    pendingDriveAction=""
                    backupStatus=driveErrorMessage(if(action=="backup")"Backup" else "Restore",error)
                    driveBusy=false
                }
            }
        }
    }
    if(!appUnlocked){
        DeviceCredentialGate("Majdoor Hisaab PRO खोलें","App का data देखने के लिए Android screen lock से पुष्टि करें।",{appUnlocked=true},{activity?.finish()})
        Box(Modifier.fillMaxSize().background(Bg),contentAlignment=Alignment.Center){
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Text("🔐",fontSize=42.sp); Text("Majdoor Hisaab PRO",fontWeight=FontWeight.ExtraBold,fontSize=22.sp); Text("App खोलने के लिए phone screen lock जरूरी है।",color=Color.Gray)
                }
            }
        }
        return
    }
    fun go(s:Screen){
        if(stack.lastOrNull()==s) return
        stack.add(s)
    }
    fun goRoot(s:Screen){
        stack.clear(); stack.add(s)
    }
    fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }
    val isRoot=screen is Screen.Home||screen is Screen.LabourList||screen is Screen.FieldList||screen is Screen.ExpenseList&&screen.fieldId==null&&screen.cropId==null||screen is Screen.SaleList&&screen.fieldId==null&&screen.cropId==null||(screen is Screen.CropList&&screen.fieldId==null)
    restoreFile?.let{file->
        DeviceCredentialGate("Backup Restore करें","Backup data से app का मौजूदा data replace होगा। Android screen lock से पुष्टि करें।",{
            runCatching{store.restoreBackupZip(file);backupStatus="Backup सफलतापूर्वक restore हो गया।"}.onFailure{backupStatus="Restore failed: ${it.message ?: "Unknown error"}"}
            file.delete();restoreFile=null;restorePending=false
        },{file.delete();restoreFile=null;restorePending=false})
    }
    BackHandler(enabled=true){
        when {
            stack.size > 1 -> back()
            screen !is Screen.Home -> goRoot(Screen.Home)
            else -> (context as? Activity)?.finish()
        }
    }
    Surface(Modifier.fillMaxSize(),color=Bg){Column(Modifier.fillMaxSize()){
        TopBar(title="MAJDOOR HISAAB PRO",subtitle="खेत • मजदूर • खर्च • बिक्री • फसल",canBack=!isRoot,onBack={if(isRoot) goRoot(Screen.Home) else back()},onProfile={goRoot(Screen.Profile)})
        Box(Modifier.weight(1f).fillMaxWidth().imePadding()){when(val s=screen){
            Screen.Home->Dashboard(store){key->goRoot(when(key){"attendance"->Screen.DailyLabourHome;"daily_labour"->Screen.DailyLabourHome;"attendance_history"->Screen.AttendanceHistory;"today_attendance"->Screen.TodayAttendance;"backup"->Screen.Backup;"labour"->Screen.DailyLabourHome;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();"cane"->Screen.CaneParchi;"cane_peeling"->Screen.CanePeeling;else->Screen.CropList()})}
            Screen.DailyLabourHome->DailyLabourHomeScreen(onAttendance={go(Screen.AttendanceFields)},onAccounts={go(Screen.DailyLabourAccounts)})
            Screen.DailyLabourAccounts->DailyLabourAccountsScreen(store,onWorkers={go(Screen.LabourList)},onFieldReport={go(Screen.FieldList)},onAttendanceHistory={go(Screen.AttendanceHistory)},onToday={go(Screen.TodayAttendance)},onAllReport={go(Screen.AllLabourReport)},onPayments={go(Screen.LabourList)},onBack={back()})
            Screen.AllLabourReport->AllLabourReportScreen(store,onBack={back()},onWorker={go(Screen.LabourDetail(it))},onAttendance={go(Screen.AttendanceFields)})
            Screen.AttendanceFields->AttendanceFieldPickerScreen(store,onSelect={go(Screen.Attendance(it))},onBack={back()})
            Screen.LabourList->LabourScreen(store,{go(Screen.LabourDetail(it))},{go(Screen.AttendanceFields)})
            Screen.FieldList->FieldScreen(store){go(Screen.FieldDetail(it))}
            is Screen.ExpenseList->ExpenseScreen(store,s.fieldId,s.cropId){goRoot(Screen.ExpenseList(s.fieldId,s.cropId))}
            is Screen.SaleList->SaleScreen(store,s.fieldId,s.cropId)
            is Screen.CropList->CropScreen(store,s.fieldId){go(Screen.CropDetail(it))}
            is Screen.LabourDetail->LabourDetail(store,s.id,{back()})
            is Screen.FieldDetail->FieldDetail(store,s.id,{back()},{go(Screen.CropDetail(it))},{go(Screen.Attendance(s.id))},{go(Screen.ExpenseList(s.id,null))},{go(Screen.SaleList(s.id,null))},{go(Screen.CropList(s.id))})
            is Screen.CropDetail->CropDetail(store,s.id,{back()},{go(Screen.ExpenseList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))},{go(Screen.SaleList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))})
            is Screen.Attendance->AttendanceScreen(store,s.fieldId,{back()})
            Screen.AttendanceHistory->AttendanceHistoryScreen(store,{back()})
            Screen.TodayAttendance->TodayAttendanceScreen(store,{back()})
            Screen.Backup->BackupScreen(store,backupStatus,{msg->backupStatus=msg},{createBackupLauncher.launch("Majdoor_Hisaab_PRO_Backup_${today()}.mhbackup")},{restoreLauncher.launch(arrayOf("application/zip","application/octet-stream"))},driveAccount?.email ?: "Google Account नहीं जुड़ा",driveBusy || pendingDriveAction.isNotBlank(),{driveAccount=null;drive.prepareFreshSignIn{driveSignInLauncher.launch(drive.signInIntent())}},{startDriveAction("backup", false)},{startDriveAction("restore", false)})
            Screen.Profile->ProfileScreen(onBackup={goRoot(Screen.Backup)})
            Screen.CaneParchi->CaneParchiDashboardScreen(store)
            Screen.CanePeeling->CanePeelingScreen(store,{back()})
        }}
        if(isRoot) BottomBar(screen){key->goRoot(when(key){"home"->Screen.Home;"attendance"->Screen.DailyLabourHome;"attendance_history"->Screen.AttendanceHistory;"today_attendance"->Screen.TodayAttendance;"backup"->Screen.Backup;"labour"->Screen.DailyLabourHome;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();else->Screen.CropList()})}
    }}
}

@Composable private fun TopBar(title:String,subtitle:String?=null,canBack:Boolean=true,onBack:()->Unit,onProfile:(()->Unit)?=null){
    Surface(color=GreenDark,shadowElevation=4.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack,modifier=Modifier.size(44.dp)){Icon(imageVector=if(canBack) Icons.Default.ArrowBack else Icons.Default.Home,contentDescription=if(canBack) "Back" else "Home",tint=Color.White)}
            Image(painterResource(R.drawable.majdoor_logo_small),null,Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)),contentScale=ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)){
                Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1)
                if(!subtitle.isNullOrBlank()) Text(subtitle,color=Color.White.copy(alpha=.82f),fontSize=10.sp,maxLines=1)
            }
            if(onProfile!=null){
                IconButton(onClick=onProfile,modifier=Modifier.size(44.dp)){
                    Icon(Icons.Default.AccountCircle,contentDescription="Profile",tint=Color.White,modifier=Modifier.size(29.dp))
                }
            }
        }
    }
}

@Composable private fun BottomBar(screen:Screen,onTab:(String)->Unit){val current=when(screen){Screen.LabourList->"labour";Screen.FieldList->"field";is Screen.ExpenseList->"expense";is Screen.SaleList->"sale";is Screen.CropList->"crop";else->"home"};Surface(shadowElevation=8.dp){Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceAround){listOf("home" to Icons.Default.Home,"labour" to Icons.Default.Groups,"field" to Icons.Default.Landscape,"expense" to Icons.Default.Payments,"sale" to Icons.Default.ShoppingCart,"crop" to Icons.Default.Spa).forEach{(k,ic)->Column(Modifier.clickable{onTab(k)}.padding(horizontal=7.dp,vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(imageVector=ic,contentDescription=null,modifier=Modifier.size(22.dp),tint=if(current==k)Green else Color.Gray);Text(when(k){"home"->"Home";"labour"->"Labour";"field"->"Field";"expense"->"Kharch";"sale"->"Sale";else->"Crop"},fontSize=10.sp,color=if(current==k)Green else Color.Gray)}}}}}

@Composable private fun DailyLabourHomeScreen(onAttendance:()->Unit,onAccounts:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        Text("दिहाड़ी मजदूर",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Text("सामान्य मजदूरों की हाजिरी और हिसाब",fontSize=14.sp,color=Color.Gray)
        Card(Modifier.fillMaxWidth().heightIn(min=145.dp).clickable{onAttendance()},shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
            Row(Modifier.fillMaxWidth().padding(22.dp),verticalAlignment=Alignment.CenterVertically){
                Icon(Icons.Default.HowToReg,null,tint=Color.White,modifier=Modifier.size(46.dp));Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)){Text("हाजिरी लगाएँ",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Color.White);Text("पहले खेत चुनें, फिर मजदूर और तारीख",fontSize=13.sp,color=Color.White.copy(alpha=.9f))}
                Icon(Icons.Default.ChevronRight,null,tint=Color.White,modifier=Modifier.size(30.dp))
            }
        }
        Card(Modifier.fillMaxWidth().heightIn(min=145.dp).clickable{onAccounts()},shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){
            Row(Modifier.fillMaxWidth().padding(22.dp),verticalAlignment=Alignment.CenterVertically){
                Icon(Icons.Default.AccountBalanceWallet,null,tint=Green,modifier=Modifier.size(46.dp));Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)){Text("हिसाब देखें",fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark);Text("मजदूरवार हिसाब, भुगतान और हाजिरी रिपोर्ट",fontSize=13.sp,color=Color.Gray)}
                Icon(Icons.Default.ChevronRight,null,tint=Green,modifier=Modifier.size(30.dp))
            }
        }
    }
}

@Composable private fun DailyLabourAccountsScreen(store:Store,onWorkers:()->Unit,onFieldReport:()->Unit,onAttendanceHistory:()->Unit,onToday:()->Unit,onAllReport:()->Unit,onPayments:()->Unit,onBack:()->Unit){
    var selectedMonth by rememberSaveable { mutableStateOf("") }
    var lockConfirm by rememberSaveable { mutableStateOf(false) }
    val monthKeys=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}).filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    val months=(monthKeys+store.lockedLabourMonths).distinct().sortedDescending()
    if(selectedMonth.isNotBlank()){
        val month=selectedMonth
        val monthAttendance=store.attendances.filter{it.date.startsWith(month)}
        val monthPayments=store.payments.filter{it.date.startsWith(month)}
        val rows=store.labours.mapNotNull{l->
            val a=monthAttendance.filter{it.labourId==l.id}
            val p=monthPayments.filter{it.labourId==l.id}
            if(a.isEmpty()&&p.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},p.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=GreenDark); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",rows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान",rows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",rows.sumOf{it.wage-it.paid})} }
                    if(month !in store.lockedLabourMonths) Button(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={lockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                items(rows,key={it.labour.id}) { r->
                    val days=monthAttendance.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                            Text(r.labour.name,fontWeight=FontWeight.Bold,color=GreenDark,fontSize=16.sp)
                            Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                            Text("इस महीने भुगतान ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=GreenDark)
                        }
                    } }
                }
                if(rows.isEmpty()) item { Text("इस महीने कोई हिसाब दर्ज नहीं है।",color=Color.Gray) }
            }
        }
        if(lockConfirm) AlertDialog(onDismissRequest={lockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "इस महीने की हाजिरी में बदलाव फिर से किया जा सकेगा। पुरानी जानकारी सुरक्षित रहेगी।" else "इस महीने की हाजिरी और हिसाब सुरक्षित हो जाएगा। महीना खोलकर जानकारी देख सकते हैं; बाद के महीनों का काम जारी रहेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);lockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={lockConfirm=false}){Text("रद्द करें")}})
        return
    }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        DetailTopBar("हिसाब देखें",onBack)
        SmallAction("👷 मजदूरवार हिसाब",onWorkers)
        SmallAction("💸 भुगतान दर्ज करें",onPayments)
        SmallAction("🌾 खेतवार हिसाब",onFieldReport)
        SmallAction("📅 तारीखवार हाजिरी रिपोर्ट",onAttendanceHistory)
        SmallAction("📋 आज की हाजिरी",onToday)
        SmallAction("📑 सभी मजदूरों की संयुक्त रिपोर्ट / PDF",onAllReport)
        if(months.isNotEmpty()) {
            Text("महीने का हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=GreenDark)
            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                items(months,key={it}) { month ->
                    Card(Modifier.fillMaxWidth().clickable{selectedMonth=month},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                        Row(Modifier.padding(horizontal=14.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
                            Text(monthTitle(month),Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=16.sp,color=GreenDark)
                            Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,contentDescription=null,tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                        }
                    }
                }
            }
        } else Text("अभी कोई महीने का हिसाब नहीं है।",fontSize=12.sp,color=Color.Gray)
    }
}

private data class LabourReportRow(val labour:Labour,val wage:Double,val paid:Double,val workDays:Double,val halfDays:Int)

@Composable private fun AllLabourReportScreen(store:Store,onBack:()->Unit,onWorker:(String)->Unit,onAttendance:()->Unit){
    val context=LocalContext.current
    val firstDate=store.attendances.map{it.date}.minOrNull() ?: today()
    var startDate by rememberSaveable{mutableStateOf(firstDate)}
    var endDate by rememberSaveable{mutableStateOf(today())}
    var multiDateMode by rememberSaveable{mutableStateOf(false)}
    val selectedDates= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var allFields by rememberSaveable{mutableStateOf(true)}
    val selectedFields= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val selectedWorkers= remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var selectedLockMonth by rememberSaveable{mutableStateOf("")}
    var showCustomReport by rememberSaveable{mutableStateOf(false)}
    var monthLockConfirm by rememberSaveable{mutableStateOf(false)}
    var validation by remember{mutableStateOf("")}
    val lockMonths=(store.attendances.map{it.date.take(7)}+store.payments.map{it.date.take(7)}+store.lockedLabourMonths).filter{it.matches(Regex("\\d{4}-\\d{2}"))}.distinct().sortedDescending()
    val reportDates=(store.attendances.map{it.date}+store.payments.map{it.date}).distinct().sortedDescending()
    if(showCustomReport) {
        val reportFields=store.fields
        val chosenDates=if(selectedDates.isEmpty()) emptySet() else selectedDates.toSet()
        val chosenFieldIds=if(allFields) reportFields.map{it.id}.toSet() else selectedFields.toSet()
        val matchingAttendance=store.attendances.filter{(chosenDates.isEmpty() || it.date in chosenDates) && (allFields || it.fieldId in chosenFieldIds)}
        val matchingPayments=store.payments.filter{(chosenDates.isEmpty() || it.date in chosenDates) && (allFields || it.fieldId in chosenFieldIds)}
        val matchingLabourIds=(matchingAttendance.map{it.labourId}+matchingPayments.map{it.labourId}).toSet()
        val reportRows=store.labours.filter{it.id in matchingLabourIds}.map{labour->
            val a=matchingAttendance.filter{it.labourId==labour.id}
            val payments=matchingPayments.filter{it.labourId==labour.id}
            LabourReportRow(labour,a.sumOf{it.fraction*it.rate},payments.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        val totalWage=reportRows.sumOf{it.wage}; val totalPaid=reportRows.sumOf{it.paid}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar("तारीख और खेत के अनुसार रिपोर्ट",{showCustomReport=false})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Text("रिपोर्ट की तारीखें चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Text("एक या अधिक तारीखें चुनें। तारीख खाली छोड़ने पर सभी तारीखें शामिल होंगी।",fontSize=12.sp,color=Color.Gray)
                item { OutlinedButton(onClick={selectedDates.clear()},modifier=Modifier.fillMaxWidth()) { Text("सभी तारीखें शामिल करें / चयन हटाएँ") } } }
                items(reportDates,key={"date_"+it}) { date ->
                    Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).clickable{if(date in selectedDates) selectedDates.remove(date) else selectedDates.add(date)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=date in selectedDates,onCheckedChange={v->if(v){if(date !in selectedDates)selectedDates.add(date)}else selectedDates.remove(date)})
                        Text(displayDate(date),color=GreenDark,fontWeight=FontWeight.Medium)
                    }
                }
                item { Divider(); Text("खेत चुनें",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,color=GreenDark) }
                item { Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically) { Checkbox(checked=allFields,onCheckedChange={allFields=it;if(it)selectedFields.clear()});Text("सभी खेत",fontWeight=FontWeight.Bold,color=GreenDark) } }
                items(reportFields,key={"field_"+it.id}) { field ->
                    Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).clickable{allFields=false;if(field.id in selectedFields)selectedFields.remove(field.id)else selectedFields.add(field.id)}.padding(horizontal=12.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(checked=allFields || field.id in selectedFields,onCheckedChange={v->allFields=false;if(v){if(field.id !in selectedFields)selectedFields.add(field.id)}else selectedFields.remove(field.id)})
                        Text(field.name.ifBlank{"नाम रहित खेत"},color=GreenDark,fontWeight=FontWeight.Medium)
                    }
                }
                item {
                    Card(colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        Text("चुनी रिपोर्ट का सार",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Text("मजदूर ${reportRows.size} • हाजिरी ${quantity(matchingAttendance.sumOf{it.fraction})} दिन")
                        Text("मजदूरी ₹${money(totalWage)} • भुगतान ₹${money(totalPaid)} • बकाया ₹${money(totalWage-totalPaid)}")
                        Button(onClick={
                            val selectedAttendance=matchingAttendance.sortedWith(compareBy<Attendance>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            val selectedPayments=matchingPayments.sortedWith(compareBy<Payment>{it.date}.thenBy{store.fields.firstOrNull{f->f.id==it.fieldId}?.name.orEmpty()}.thenBy{store.labours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})
                            if(selectedAttendance.isEmpty()&&selectedPayments.isEmpty()) validation="चुनी तारीख/खेत में कोई हाजिरी या भुगतान नहीं मिला।" else {
                                val detailLines=buildList {
                                    add("हाजिरी और मजदूरी का खेतवार विवरण")
                                    selectedAttendance.forEach{a->val labour=store.labours.firstOrNull{it.id==a.labourId}?.name?:"मजदूर हटाया गया";val field=store.fields.firstOrNull{it.id==a.fieldId}?.name?:"खेत हटाया गया";val attendance=if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी / अनुपस्थित" else "${quantity(a.fraction)} दिन";add("${displayDate(a.date)} • खेत $field • $labour • $attendance • मजदूरी ₹${money(a.fraction*a.rate)}")}
                                    add("भुगतान का विवरण")
                                    selectedPayments.forEach{pay->val labour=store.labours.firstOrNull{it.id==pay.labourId}?.name?:"मजदूर हटाया गया";val field=store.fields.firstOrNull{it.id==pay.fieldId}?.name?:"खेत हटाया गया";add("${displayDate(pay.date)} • खेत $field • $labour • भुगतान ₹${money(pay.amount)}")}
                                    add("कुल हाजिरी: ${quantity(selectedAttendance.sumOf{it.fraction})} दिन")
                                    add("कुल मजदूरी: ₹${money(selectedAttendance.sumOf{it.fraction*it.rate})}")
                                    add("चुने रिकॉर्ड के भुगतान: ₹${money(selectedPayments.sumOf{it.amount})}")
                                }
                                exportReportPdf(context,"तारीख_खेत_वार_रिपोर्ट_${System.currentTimeMillis()}","तारीख: ${if(chosenDates.isEmpty())"सभी तारीखें" else chosenDates.sorted().joinToString(", "){displayDate(it)}} • खेत: ${if(allFields)"सभी खेत" else reportFields.filter{it.id in chosenFieldIds}.joinToString(", "){it.name}} • मजदूर ${(matchingAttendance.map{it.labourId}+selectedPayments.map{it.labourId}).distinct().size} • हाजिरी मजदूरी ₹${money(selectedAttendance.sumOf{it.fraction*it.rate})} • भुगतान ₹${money(selectedPayments.sumOf{it.amount})}",detailLines,background=true)
                            }
                        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Text("चुनी तारीख और खेत की PDF बनाएँ") }
                        if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                    } }
                }
            }
        }
        return
    }
    if(selectedLockMonth.isNotBlank()) {
        val month=selectedLockMonth
        val ma=store.attendances.filter{it.date.startsWith(month)}
        val mp=store.payments.filter{it.date.startsWith(month)}
        val monthRows=store.labours.mapNotNull{l->
            val a=ma.filter{it.labourId==l.id}; val pay=mp.filter{it.labourId==l.id}
            if(a.isEmpty()&&pay.isEmpty()) null else LabourReportRow(l,a.sumOf{it.fraction*it.rate},pay.sumOf{it.amount},a.sumOf{it.fraction},a.count{it.fraction==0.5})
        }.sortedBy{it.labour.name.lowercase(Locale.ROOT)}
        Column(Modifier.fillMaxSize().background(Bg)) {
            DetailTopBar(monthTitle(month),{selectedLockMonth=""})
            LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item { Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) { Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=GreenDark); Spacer(Modifier.width(8.dp)); Text(monthTitle(month),fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f)) }
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth()) { Box(Modifier.weight(1f)){Stat("मजदूरी",monthRows.sumOf{it.wage})};Box(Modifier.weight(1f)){Stat("भुगतान",monthRows.sumOf{it.paid})};Box(Modifier.weight(1f)){Stat("बकाया",monthRows.sumOf{it.wage-it.paid})} }
                    if(month !in store.lockedLabourMonths) Button(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text("महीना लॉक करें")}
                    else OutlinedButton(onClick={monthLockConfirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LockOpen,null);Spacer(Modifier.width(8.dp));Text("महीना अनलॉक करें")}
                } } }
                items(monthRows,key={it.labour.id}) { r ->
                    val days=ma.filter{it.labourId==r.labour.id}.sumOf{it.fraction}
                    val checked = r.labour.id in selectedWorkers
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically) {
                            androidx.compose.material3.Checkbox(
                                checked = checked,
                                onCheckedChange = { value ->
                                    if (value) { if (r.labour.id !in selectedWorkers) selectedWorkers.add(r.labour.id) }
                                    else selectedWorkers.remove(r.labour.id)
                                }
                            )
                            Column(Modifier.weight(1f).padding(start=6.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                                Text(r.labour.name,fontWeight=FontWeight.Bold,color=GreenDark,fontSize=16.sp)
                                Text("हाजिरी ${quantity(days)} दिन • मजदूरी ₹${money(r.wage)}",fontSize=12.sp)
                                Text("इस महीने भुगतान ₹${money(r.paid)} • बकाया ₹${money(r.wage-r.paid)}",fontSize=12.sp,color=GreenDark)
                            }
                        }
                    }
                }
                item {
                    val picked = monthRows.filter { it.labour.id in selectedWorkers }
                    val wage = picked.sumOf { it.wage }; val paid = picked.sumOf { it.paid }
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Text("PDF / फोटो रिपोर्ट के लिए मजदूर चुनें",fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("चुने गए ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",fontSize=12.sp,color=Color.Gray)
                            ExportButtons(onPhoto={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportReportPhoto(context,"महीने_${month}_${System.currentTimeMillis()}","${monthTitle(month)} • चुने मजदूर ${picked.size} • मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बकाया ₹${money(wage-paid)}",picked.map{"${it.labour.name} • काम ${quantity(it.workDays)} दिन • मजदूरी ₹${money(it.wage)} • भुगतान ₹${money(it.paid)} • बकाया ₹${money(it.wage-it.paid)}"})},onPdf={if(picked.isEmpty()) validation="पहले मजदूर चुनें।" else exportAllWorkersLedgerPdf(context,"${month}_chune_mazdoor",monthTitle(month),"सभी खेत",picked,wage,paid,background=true)})
                            if(validation.isNotBlank()) Text(validation,color=Color(0xFFB3261E),fontSize=12.sp)
                        }
                    }
                }
                if(monthRows.isEmpty()) item { Text("इस महीने कोई हिसाब दर्ज नहीं है।",color=Color.Gray) }
            }
        }
        if(monthLockConfirm) AlertDialog(onDismissRequest={monthLockConfirm=false},title={Text(if(month in store.lockedLabourMonths) "महीना अनलॉक करें?" else "महीना लॉक करें?")},text={Text(if(month in store.lockedLabourMonths) "पुरानी जानकारी सुरक्षित रहेगी। अनलॉक करने पर इस महीने की हाजिरी में बदलाव किया जा सकेगा।" else "इस महीने का हिसाब सुरक्षित रहेगा। पुराना हिसाब देखने के लिए महीना हमेशा खुल सकेगा।")},confirmButton={TextButton(onClick={store.setLabourMonthLocked(month,month !in store.lockedLabourMonths);monthLockConfirm=false}){Text(if(month in store.lockedLabourMonths) "अनलॉक करें" else "लॉक करें")}},dismissButton={TextButton(onClick={monthLockConfirm=false}){Text("रद्द करें")}})
        return
    }
    // Main entry for the joint report: show only month names and lock icons.
    // Tapping a month opens its full month ledger above; keep report filters off this landing screen.
    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("सभी मजदूरों का हिसाब", onBack)
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Button(onClick={showCustomReport=true;selectedDates.clear();selectedFields.clear();allFields=true;validation=""},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=GreenDark)) { Icon(Icons.Default.PictureAsPdf,null); Spacer(Modifier.width(8.dp)); Text("तारीख और खेत के अनुसार PDF रिपोर्ट") } }
            item { Text("महीने का हिसाब", fontWeight=FontWeight.ExtraBold, fontSize=20.sp, color=GreenDark) }
            items(lockMonths, key={it}) { month ->
                Card(Modifier.fillMaxWidth().clickable { selectedLockMonth = month }, shape=RoundedCornerShape(14.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.padding(horizontal=16.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(monthTitle(month), Modifier.weight(1f), fontWeight=FontWeight.Bold, fontSize=17.sp, color=GreenDark)
                        Icon(if(month in store.lockedLabourMonths) Icons.Default.Lock else Icons.Default.LockOpen, contentDescription=null, tint=if(month in store.lockedLabourMonths) Color(0xFF6B4FB3) else Green)
                    }
                }
            }
            if(lockMonths.isEmpty()) item { Text("अभी कोई महीने का हिसाब नहीं है।", color=Color.Gray) }
        }
    }
    return

}


@Composable private fun AttendanceFieldPickerScreen(store:Store,onSelect:(String)->Unit,onBack:()->Unit){
    var addField by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("हाजिरी के लिए खेत चुनें",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Button(onClick={addField=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("नया खेत जोड़ें")}}
            items(store.fields,key={it.id}){f->
                val cropNames=store.crops.filter{it.fieldId==f.id}.joinToString(" • "){it.name}.ifBlank{"फसल नहीं जोड़ी गई"}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Row(Modifier.fillMaxWidth().clickable{onSelect(f.id)}.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Icon(Icons.Default.Landscape,null,tint=Green,modifier=Modifier.size(34.dp));Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)){Text(f.name.ifBlank{"नाम रहित खेत"},fontSize=18.sp,fontWeight=FontWeight.Bold,color=GreenDark);Text("${f.area.ifBlank{"रकबा नहीं दिया"}} • $cropNames",fontSize=12.sp,color=Color.Gray)}
                        Icon(Icons.Default.ChevronRight,null,tint=Green)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),horizontalArrangement=Arrangement.End){
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,null);Text("ऊपर")}
                        TextButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,null);Text("नीचे")}
                    }
                }
            }
            if(store.fields.isEmpty()) item{Text("अभी कोई खेत नहीं है। पहले नया खेत जोड़ें।",color=Color.Gray)}
        }
    }
    if(addField) FieldDialog(store,null){addField=false}
}

@Composable
private fun Dashboard(store:Store,onGo:(String)->Unit){
    val today=today()
    val wage=store.attendances.filter{it.date==today}.sumOf{it.fraction*it.rate}
    val exp=store.expenses.filter{it.date==today}.sumOf{it.amount}
    val sale=store.sales.filter{it.date==today}.sumOf{it.total}
    val workerCount=store.attendances.filter{it.date==today}.map{it.labourId}.distinct().size
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){Box(Modifier.fillMaxWidth().height(185.dp)){Image(painterResource(R.drawable.dashboard_hero),null,Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,GreenDark.copy(alpha=.9f)))));Column(Modifier.align(Alignment.BottomStart).padding(18.dp)){Text("मेहनत का सही हिसाब",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text("किसान की सही ताकत",color=Color(0xFFD5F4E6),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("खेत का हर काम • हर खर्च • हर कमाई",color=Color.White.copy(alpha=.92f),fontSize=12.sp)}}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CalendarMonth,null,tint=Green,modifier=Modifier.size(27.dp));Spacer(Modifier.width(8.dp));Text("आज का हिसाब • ${displayDate(today)}",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f));AssistChip(onClick={onGo("expense")},label={Text("विवरण देखें")})};Spacer(Modifier.height(9.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){DashboardStat("👷","मजदूरी",wage,"$workerCount मजदूर",Color(0xFFE8F3FF),Modifier.weight(1f)){onGo("labour")};DashboardStat("💰","खर्च",exp,"आज का खर्च",Color(0xFFFFF2DF),Modifier.weight(1f)){onGo("expense")};DashboardStat("🧺","बिक्री",sale,"आज की बिक्री",Color(0xFFE8F7EA),Modifier.weight(1f)){onGo("sale")} }}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.width(5.dp).height(58.dp).clip(RoundedCornerShape(5.dp)).background(Green));Spacer(Modifier.width(11.dp));Text("👷",fontSize=30.sp);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text("आज की हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Text("जल्दी से मजदूरों की हाजिरी लगाएँ",fontSize=12.sp,color=Color.Gray)};OutlinedButton(onClick={onGo("attendance_history")}){Text("हाजिरी सूची  ›")}};Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){Button(onClick={onGo("daily_labour")},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Fingerprint,null);Spacer(Modifier.width(8.dp));Column{Text("हाजिरी लगाएँ",fontWeight=FontWeight.Bold);Text("पहले खेत चुनें, फिर मजदूरों की हाजिरी दर्ज करें",fontSize=10.sp)}}}}}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("▦  मुख्य काम",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,modifier=Modifier.weight(1f));Text("सभी मॉड्यूल  ›",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("👷","दिहाड़ी मजदूर","हाजिरी • हिसाब","मजदूर • भुगतान • रिपोर्ट",Color(0xFFDCEBFF),Modifier.weight(1f)){onGo("daily_labour")};DashboardModule("🌾","Field","खेत प्रबंधन","खेत • काम • गतिविधि",Color(0xFFE0F3D9),Modifier.weight(1f)){onGo("field")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("💰","Kharch","खर्च प्रबंधन","बीज • खाद • दवा",Color(0xFFFFEBD4),Modifier.weight(1f)){onGo("expense")};DashboardModule("🧺","Sale","बिक्री प्रबंधन","फसल • उपज • बिक्री",Color(0xFFFFE3E1),Modifier.weight(1f)){onGo("sale")}}}
        item{DashboardModule("🌾","गन्ना पर्ची","गन्ने की पर्ची और तौल","पर्ची • वजन • भाव • फोटो",Color(0xFFDFF5E7),Modifier.fillMaxWidth()){onGo("cane")}}
        item{DashboardModule("🌿","गन्ना छिलाई","फांदी का पूरा दैनिक हिसाब","फांदी • खेत • रेट • भुगतान • बाकी",Color(0xFFE2F6E9),Modifier.fillMaxWidth()){onGo("cane_peeling")}}
        item{DashboardModule("🌱","Crop","फसल प्रबंधन","फसल चक्र • बुवाई • कटाई",Color(0xFFEAE2FF),Modifier.fillMaxWidth()){onGo("crop")}}
    }
}


@Composable private fun DashboardStat(icon:String,label:String,value:Double,sub:String,bgColor:Color,modifier:Modifier=Modifier,onClick:()->Unit={}){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(icon,fontSize=21.sp);Text(label,fontSize=11.sp,color=GreenDark);Text("₹${money(value)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold);Text(sub,fontSize=9.sp,color=Color.Gray,maxLines=1)}}}

@Composable private fun DashboardModule(icon:String,title:String,subtitle:String,detail:String,bgColor:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.fillMaxWidth().padding(13.dp).heightIn(min=125.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.62f)),contentAlignment=Alignment.Center){Text(icon,fontSize=27.sp)};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=19.sp,fontWeight=FontWeight.ExtraBold);Text(subtitle,fontSize=10.sp,color=Color.DarkGray)};Icon(Icons.Default.ChevronRight,null,tint=GreenDark)};Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.72f)){Text(detail,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=9.sp,fontWeight=FontWeight.SemiBold,color=GreenDark,maxLines=1)}}}}

@Composable
private fun SummaryMoneyCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.heightIn(min = 82.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, fontSize = 10.sp, color = Color.Gray, maxLines = 1)
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = accent, maxLines = 1)
        }
    }
}

@Composable private fun Stat(label:String,value:Double){
    val icon=when(label){"मजदूरी","Labour"->"👷";"खर्च","लागत","खेती खर्च"->"💰";"बिक्री","Sale"->"🧺";"भुगतान"->"💵";"बाकी"->"📌";"लाभ"->"📈";"कुल काम","कुल दिन","पूरा दिन","आधा दिन","मजदूर","कुल मजदूर","कुल खेत","कुल रिकॉर्ड","रिकॉर्ड","फांदी","कुल फांदी"->"📊";else->"📊"}
    val unit=when(label){"कुल काम","कुल दिन","पूरा दिन","आधा दिन"->" दिन";"मजदूर","कुल मजदूर"->" मजदूर";"कुल खेत"->" खेत";"कुल रिकॉर्ड","रिकॉर्ड"->" रिकॉर्ड";"फांदी","कुल फांदी"->" फांदी";else->null}
    val display=if(unit!=null) "${quantity(value)}$unit" else "₹${money(value)}"
    Card(Modifier.fillMaxWidth().heightIn(min=78.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=11.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=15.sp);Spacer(Modifier.width(5.dp));Text(label,fontSize=11.sp,color=Color.Gray,maxLines=1)}
            Text(display,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}
private fun money(v:Double)=String.format(Locale.US,"%.0f",v)
private fun quantity(v:Double)=String.format(Locale.US,"%.2f",v).trimEnd('0').trimEnd('.')
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
private fun validDate(v:String):Boolean{
    val value=v.trim()
    if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false
    return try{
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        f.isLenient=false
        val parsed=f.parse(value) ?: return false
        f.format(parsed)==value
    }catch(_:Exception){false}
}
private fun monthTitle(value:String):String{
    return try{
        val f=SimpleDateFormat("yyyy-MM",Locale.US).apply{isLenient=false}
        val d=f.parse(value) ?: return value
        SimpleDateFormat("MMMM yyyy",Locale("hi","IN")).format(d)
    }catch(_:Exception){value}
}
private fun displayDate(v:String):String{
    val value=v.trim()
    if(!validDate(value)) return value
    return try{
        val input=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
        val output=SimpleDateFormat("dd/MM/yyyy",Locale.US)
        output.format(input.parse(value)!!)
    }catch(_:Exception){value}
}

@Composable
private fun PhotoThumb(path:String,modifier:Modifier=Modifier.size(52.dp)){
    val bitmap=remember(path){if(path.isNotBlank()) runCatching{BitmapFactory.decodeFile(path)?.asImageBitmap()}.getOrNull() else null}
    if(bitmap!=null){
        Image(bitmap=bitmap,contentDescription=null,modifier=modifier.clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)
    }else{
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=22.sp)}
    }
}

@Composable
private fun LabourScreen(store:Store,onOpen:(String)->Unit,onAttendance:()->Unit){
    var edit by remember{mutableStateOf<Labour?>(null)}
    var delete by remember{mutableStateOf<Labour?>(null)}
    var protectedEdit by remember{mutableStateOf<Labour?>(null)}
    var protectedDelete by remember{mutableStateOf<Labour?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("👷 Labour","मजदूरों की सूची") { edit=Labour("","","",0.0,"","") }
        Spacer(Modifier.height(10.dp))
        SmallAction("📅 हाजिरी / तारीख चुनें",onAttendance)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.labours.asReversed(),key={it.id}){l->
                Card(Modifier.fillMaxWidth().clickable{onOpen(l.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo);Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold)
                            Text("₹${money(store.rateFor(l.id,today()))}/दिन",fontSize=12.sp,color=Color.Gray)
                        }
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(edit!=null) LabourDialog(store,edit!!.takeIf{it.id.isNotBlank()}){edit=null}
    protectedEdit?.let{item->
        DeviceCredentialGate("मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})
    }
    protectedDelete?.let{item->
        DeviceCredentialGate("मजदूर हटाएँ","मजदूर और उससे जुड़े attendance, payment तथा rate history हटाने के लिए Android screen lock से पुष्टि करें।",{delete=item;protectedDelete=null},{protectedDelete=null})
    }
    val deleteContext=LocalContext.current
    if(delete!=null) ConfirmDialog("मजदूर हटाएँ?","यदि इस मजदूर की हाजिरी, भुगतान, दिहाड़ी इतिहास या फांडी रिकॉर्ड है, तो रिकॉर्ड सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteLabour(delete!!.id);delete=null;if(!ok)android.widget.Toast.makeText(deleteContext,"इस मजदूर का पुराना हिसाब मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{delete=null})
}
@Composable private fun LabourDialog(store:Store,existing:Labour?,onClose:()->Unit){
    var name by remember{mutableStateOf(existing?.name?:"")}
    var address by remember{mutableStateOf(existing?.address?:"")}
    var rate by remember{mutableStateOf(if(existing==null||existing.rate==0.0)"" else money(existing.rate))}
    var mobile by remember{mutableStateOf(existing?.mobile?:"")}
    var photo by remember{mutableStateOf(existing?.photo?:"")}
    var error by remember{mutableStateOf("")}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank()) photo=persisted}
    }
    SimpleDialog(if(existing==null)"मजदूर जोड़ें" else "मजदूर बदलें",onClose){
        OutlinedTextField(value=name,onValueChange={name=it;error=""},label={Text("मजदूर का नाम *")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true)
        OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("रुपये/दिन (Optional)")},singleLine=true)
        OutlinedTextField(value=mobile,onValueChange={mobile=it},label={Text("मोबाइल (Optional)")},singleLine=true)
        OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")}
        Button(onClick={
            when {
                name.isBlank()->error="मजदूर का नाम लिखना जरूरी है।"
                store.labourNameExists(name,existing?.id)->error="इस नाम का मजदूर पहले से मौजूद है। नाम में फर्क करके ही सेव करें।"
                else->{
                    val x=Labour(ownerId,name.trim().replace(Regex("\\s+")," "),address,rate.toDoubleOrNull()?:0.0,mobile,photo)
                    val saved=if(existing==null)store.addLabour(x) else store.updateLabour(x)
                    if(saved) onClose() else error="मजदूर सेव नहीं हुआ। नाम जाँचें।"
                }
            }
        },modifier=Modifier.fillMaxWidth()){Text("मजदूर सेव करें")}
    }
}

@Composable
private fun FieldScreen(store:Store,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Field?>(null)}
    var del by remember{mutableStateOf<Field?>(null)}
    var protectedEdit by remember{mutableStateOf<Field?>(null)}
    var protectedDelete by remember{mutableStateOf<Field?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌾 Field","खेतों की सूची") {add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.fields,key={it.id}){f->
                Card(Modifier.fillMaxWidth().clickable{onOpen(f.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(f.photo);Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(f.name.ifBlank{"खेत का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=17.sp)
                            Text(listOf(f.area.ifBlank{"रकबा नहीं दिया"},f.address).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)
                        }
                        Column(horizontalAlignment=Alignment.CenterHorizontally){
                            IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}>0,onClick={store.moveField(f.id,-1)}){Icon(Icons.Default.ArrowUpward,null,tint=Green)}
                            IconButton(enabled=store.fields.indexOfFirst{it.id==f.id}<store.fields.lastIndex,onClick={store.moveField(f.id,1)}){Icon(Icons.Default.ArrowDownward,null,tint=Green)}
                        }
                        IconButton(onClick={protectedEdit=f}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=f}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FieldDialog(store,null){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("खेत बदलें","खेत की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खेत हटाएँ","खेत और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FieldDialog(store,edit!!){edit=null}
    val fieldContext=LocalContext.current
    if(del!=null)ConfirmDialog("खेत हटाएँ?","यदि इस खेत से फसल, खर्च, बिक्री, हाजिरी, भुगतान या फांडी रिकॉर्ड जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteField(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(fieldContext,"इस खेत का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun FieldDialog(store:Store,existing:Field?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var addr by remember{mutableStateOf(existing?.address?:"")};var area by remember{mutableStateOf(existing?.area?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"खेत जोड़ें" else "खेत बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("खेत का नाम (Optional)")},singleLine=true);OutlinedTextField(value=addr,onValueChange={addr=it},label={Text("पता/स्थान (Optional)")},singleLine=true);OutlinedTextField(value=area,onValueChange={area=it},label={Text("रकबा (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"खेत की फोटो (Optional)" else "✓ फोटो चुनी गई")};Button(onClick={val x=Field(ownerId,name,addr,area,photo);if(existing==null)store.addField(x) else store.updateField(x);onClose()},modifier=Modifier.fillMaxWidth()){Text("सेव करें")}}}

@Composable
private fun CropScreen(store:Store,preField:String?,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Crop?>(null)}
    var del by remember{mutableStateOf<Crop?>(null)}
    var protectedEdit by remember{mutableStateOf<Crop?>(null)}
    var protectedDelete by remember{mutableStateOf<Crop?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌱 Crop","फसल सूची"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.crops,key={it.id}){c->
                val f=store.fields.firstOrNull{it.id==c.fieldId}
                Card(Modifier.fillMaxWidth().clickable{onOpen(c.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(c.name.ifBlank{"फसल का नाम नहीं दिया"},fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${c.season}",fontSize=12.sp,color=Color.Gray)
                        }
                        IconButton(onClick={protectedEdit=c}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=c}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)CropDialog(store,null,preField){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("फसल बदलें","फसल की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("फसल हटाएँ","फसल और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)CropDialog(store,edit!!,null){edit=null}
    val cropContext=LocalContext.current
    if(del!=null)ConfirmDialog("फसल हटाएँ?","यदि इस फसल से खर्च, बिक्री, हाजिरी या भुगतान जुड़े हैं, तो इतिहास सुरक्षित रखने के लिए हटाना रोक दिया जाएगा।",{val ok=store.deleteCrop(del!!.id);del=null;if(!ok)android.widget.Toast.makeText(cropContext,"इस फसल का पुराना रिकॉर्ड मौजूद है। डेटा सुरक्षित रखने के लिए हटाना रोका गया।",android.widget.Toast.LENGTH_LONG).show()},{del=null})
}
@Composable private fun CropDialog(store:Store,existing:Crop?,preField:String?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var field by remember{mutableStateOf(existing?.fieldId?:preField?:store.fields.firstOrNull()?.id?:"")};var variety by remember{mutableStateOf(existing?.variety?:"")};var sow by remember{mutableStateOf(existing?.sowingDate?:"")};var season by remember{mutableStateOf(existing?.season?:SimpleDateFormat("yyyy",Locale.US).format(Date()))};var error by remember{mutableStateOf("")};SimpleDialog(if(existing==null)"फसल जोड़ें" else "फसल बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("फसल का नाम")},singleLine=true);ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it};OutlinedTextField(value=variety,onValueChange={variety=it},label={Text("किस्म (Optional)")},singleLine=true);OutlinedTextField(value=sow,onValueChange={sow=it},label={Text("बुवाई तारीख YYYY-MM-DD (Optional)")},singleLine=true);OutlinedTextField(value=season,onValueChange={season=it},label={Text("Season")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={when{ name.isBlank()->error="फसल का नाम डालें"; field.isBlank()->error="खेत चुनें"; !sow.isBlank()&&!validDate(sow)->error="सही बुवाई तारीख डालें: YYYY-MM-DD"; else->{error="";val x=Crop(existing?.id?:UUID.randomUUID().toString(),field,name,variety,sow,season);if(existing==null)store.addCrop(x) else store.updateCrop(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun ExpenseScreen(store:Store,preField:String?,preCrop:String?,onSaved:()->Unit){
    var edit by remember{mutableStateOf<Expense?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Expense?>(null)}
    var protectedEdit by remember{mutableStateOf<Expense?>(null)}
    var protectedDelete by remember{mutableStateOf<Expense?>(null)}
    val list=store.expenses.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("💰 Kharch","खेती का खर्च"){add=true}
        if(preField==null&&preCrop==null)Text("सभी खर्च",fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){e->
                val f=store.fields.firstOrNull{it.id==e.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(e.type+if(e.item.isNotBlank())" • ${e.item}" else "",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(e.date)}",fontSize=12.sp,color=Color.Gray)
                            Text("₹${money(e.amount)}",fontWeight=FontWeight.Bold)
                        }
                        IconButton(onClick={protectedEdit=e}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=e}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)ExpenseDialog(store,edit?:Expense(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),"बीज","","","",0.0,today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("खर्च बदलें","खर्च की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खर्च हटाएँ","खर्च रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)ExpenseDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("खर्च हटाएँ?","यह खर्च रिकॉर्ड हट जाएगा.",{store.deleteExpense(del!!.id);del=null},{del=null})
}
@Composable private fun ExpenseDialog(store:Store,existing:Expense,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var type by remember{mutableStateOf(existing.type)};var item by remember{mutableStateOf(existing.item)};var qty by remember{mutableStateOf(existing.qty)};var unit by remember{mutableStateOf(existing.unit)};var amount by remember{mutableStateOf(if(existing.amount==0.0)"" else money(existing.amount))};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"खर्च बदलें" else "खर्च जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};ChoiceField("खर्च का प्रकार",listOf("बीज" to "बीज","उर्वरक/खाद" to "उर्वरक/खाद","दवा/कीटनाशक" to "दवा/कीटनाशक","डीजल" to "डीजल","सिंचाई" to "सिंचाई","ट्रैक्टर/मशीन" to "ट्रैक्टर/मशीन","ढुलाई" to "ढुलाई","अन्य" to "अन्य"),type){type=it};OutlinedTextField(value=item,onValueChange={item=it},label={Text("नाम (Optional)")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value=qty,onValueChange={qty=it},modifier=Modifier.weight(1f),label={Text("मात्रा (Optional)")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},modifier=Modifier.weight(1f),label={Text("इकाई (Optional)")},singleLine=true)};OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("रकम")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=amount.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";n==null||n<=0||!n.isFinite()->error="सही रकम दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,type=type,item=item,qty=qty,unit=unit,amount=n,date=date.trim());if(isEdit)store.updateExpense(x) else store.addExpense(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun SaleScreen(store:Store,preField:String?,preCrop:String?){
    var edit by remember{mutableStateOf<Sale?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Sale?>(null)}
    var protectedEdit by remember{mutableStateOf<Sale?>(null)}
    var protectedDelete by remember{mutableStateOf<Sale?>(null)}
    val list=store.sales.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🧺 Sale","बिक्री"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){s->
                val f=store.fields.firstOrNull{it.id==s.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("${s.qty} ${s.unit} × ₹${money(s.rate)}",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(s.date)}",fontSize=12.sp)
                            Text("₹${money(s.total)}",fontWeight=FontWeight.Bold,color=Green)
                        }
                        IconButton(onClick={protectedEdit=s}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=s}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)SaleDialog(store,edit?:Sale(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),0.0,"क्विंटल",0.0,0.0,"",today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("बिक्री बदलें","बिक्री की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("बिक्री हटाएँ","बिक्री रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)SaleDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("बिक्री हटाएँ?","यह बिक्री रिकॉर्ड हट जाएगा.",{store.deleteSale(del!!.id);del=null},{del=null})
}
@Composable private fun SaleDialog(store:Store,existing:Sale,onClose:()->Unit,isEdit:Boolean){
    var field by remember{mutableStateOf(existing.fieldId)}
    var crop by remember{mutableStateOf(existing.cropId)}
    var qty by remember{mutableStateOf(if(existing.qty==0.0)"" else quantity(existing.qty))}
    var unit by remember{mutableStateOf(existing.unit)}
    var rate by remember{mutableStateOf(if(existing.rate==0.0)"" else quantity(existing.rate))}
    var buyer by remember{mutableStateOf(existing.buyer)}
    var date by remember{mutableStateOf(existing.date)}
    var error by remember{mutableStateOf("")}
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""}
    val q=qty.toDoubleOrNull(); val r=rate.toDoubleOrNull()
    val total=(q?:0.0)*(r?:0.0)
    fun saveSale(){
        when {
            field.isBlank()->error="खेत चुनें"
            q==null||q<=0||!q.isFinite()->error="सही मात्रा दर्ज करें"
            unit.isBlank()->error="इकाई दर्ज करें"
            r==null||r<=0||!r.isFinite()->error="सही दर दर्ज करें"
            !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
            else->{
                val x=existing.copy(fieldId=field,cropId=crop,qty=q,unit=unit.trim(),rate=r,total=q*r,buyer=buyer.trim(),date=date.trim())
                runCatching { if(isEdit) store.updateSale(x) else store.addSale(x) }
                    .onSuccess { error=""; onClose() }
                    .onFailure { error="बिक्री सेव नहीं हुई: ${it.message?:"दोबारा कोशिश करें"}" }
            }
        }
    }
    AlertDialog(
        onDismissRequest={},
        title={Text(if(isEdit)"बिक्री बदलें" else "बिक्री जोड़ें",fontWeight=FontWeight.Bold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
            ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""}
            ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it}
            OutlinedTextField(value=qty,onValueChange={qty=it},label={Text("मात्रा")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=unit,onValueChange={unit=it},label={Text("इकाई (क्विंटल/किलो/टन आदि)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("दर प्रति इकाई (₹)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=buyer,onValueChange={buyer=it},label={Text("खरीदार (वैकल्पिक)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Text("कुल रकम: ₹${money(total)}",fontWeight=FontWeight.Bold,color=GreenDark)
            if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        }},
        confirmButton={Button(onClick={saveSale()},modifier=Modifier.fillMaxWidth()){Text(if(isEdit)"बिक्री सेव करें" else "बिक्री सेव करें",fontWeight=FontWeight.Bold)}},
        dismissButton={TextButton(onClick=onClose){Text("रद्द करें")}}
    )
}

@Composable
private fun DeviceCredentialGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
){
    val context=LocalContext.current
    var noLock by remember{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        if(result.resultCode==Activity.RESULT_OK) onUnlocked() else onCancel()
    }
    LaunchedEffect(Unit){
        val km=context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(!km.isKeyguardSecure){
            noLock=true
        }else{
            val intent=km.createConfirmDeviceCredentialIntent(title,message)
            if(intent!=null) launcher.launch(intent) else onCancel()
        }
    }
    if(noLock){
        AlertDialog(
            onDismissRequest=onCancel,
            title={Text("Android Screen Lock जरूरी है")},
            text={Text("इस रिकॉर्ड को बदलने या हटाने के लिए फोन में PIN, Pattern या Password screen lock चालू होना चाहिए।")},
            confirmButton={Button(onClick=onCancel){Text("ठीक है")}}
        )
    }
}

@Composable
private fun DeviceCredentialDeleteGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
)=DeviceCredentialGate(title,message,onUnlocked,onCancel)

private fun isNotFutureDate(value:String):Boolean{
    return validDate(value) && value<=today()
}

@Composable
private fun AttendanceDateButton(value:String,onDateSelected:(String)->Unit){
    val context=LocalContext.current
    val parsed=try{
        SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value)
    }catch(_:Exception){Date()}
    OutlinedButton(
        onClick={
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(
                context,
                {_,year,month,day->
                    val selected=Calendar.getInstance().apply{
                        set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                    }
                    val formatted=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time)
                    if(formatted<=today()) onDateSelected(formatted)
                },
                cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)
            ).apply{
                datePicker.maxDate=System.currentTimeMillis()
            }.show()
        },
        modifier=Modifier.fillMaxWidth()
    ){
        Icon(Icons.Default.CalendarMonth,null)
        Spacer(Modifier.width(7.dp))
        Text("हाजिरी तारीख: ${displayDate(value)}")
    }
}

@Composable
private fun AttendanceScreen(store:Store,preField:String?,onBack:()->Unit){
    val context=LocalContext.current
    var selectedDate by remember{mutableStateOf(today())}
    var activeField by remember{mutableStateOf(preField?:store.fields.firstOrNull()?.id?:"")}
    var activeCrop by remember{mutableStateOf("")}
    var attendanceError by remember{mutableStateOf("")}
    var addLabour by remember{mutableStateOf(false)}
    var deleteAttendance by remember{mutableStateOf<Attendance?>(null)}
    var protectedAttendanceEdit by remember{mutableStateOf<Pair<Attendance,Double>?>(null)}
    val field=store.fields.firstOrNull{it.id==activeField}
    val crops=store.crops.filter{it.fieldId==activeField}
    LaunchedEffect(activeField){activeCrop=if(crops.size==1)crops.first().id else ""}

    val credentialDelete=deleteAttendance

    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📅 हाजिरी • ${displayDate(selectedDate)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.item{
                Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(15.dp)){
                        Text("🌾 ${field?.name ?: "खेत चुनें"}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Spacer(Modifier.height(8.dp))
                        AttendanceDateButton(selectedDate){selectedDate=it;attendanceError=""}
                        Spacer(Modifier.height(6.dp))
                        Text("आज या पिछली तारीख की हाजिरी लगाएँ। आगे की तारीख की हाजिरी नहीं लगेगी।",fontSize=11.sp,color=Color.Gray)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick={addLabour=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("+ मजदूर जोड़ें",fontWeight=FontWeight.Bold)}
                    }
                }
            }
            if(preField.isNullOrBlank()) this.item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(14.dp)){
                        Text("🌾 खेत चुनें",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            store.fields.forEach{f->
                                val fieldName=f.name.ifBlank { "खेत" }
                                FilterChip(
                                    selected=f.id==activeField,
                                    onClick={activeField=f.id;attendanceError=""},
                                    label={Text("🌾 $fieldName")}
                                )
                            }
                        }
                        if(field!=null&&crops.size>1){
                            Spacer(Modifier.height(8.dp))
                            ChoiceField("फसल",crops.map{it.id to it.name},activeCrop){activeCrop=it;attendanceError=""}
                        }
                    }
                }
            }
            if(attendanceError.isNotBlank()) this.item{
                val isSuccess=attendanceError.contains("सफलतापूर्वक") || attendanceError.contains("सेव हो गई")
                Card(colors=CardDefaults.cardColors(containerColor=if(isSuccess)Color(0xFFE5F5EA) else Color(0xFFFFE8E6)),shape=RoundedCornerShape(14.dp)){
                    Text((if(isSuccess)"✓ " else "⚠ ")+attendanceError,Modifier.padding(12.dp),color=if(isSuccess)GreenDark else Color(0xFFB3261E),fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                }
            }
            if(field!=null){
                this.item{
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("मजदूरों की हाजिरी",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                        Text("${displayDate(selectedDate)}",fontSize=11.sp,color=Color.Gray)
                    }
                }
                this.items(store.labours.asReversed(),key={it.id}){l->
                    val a=store.attendances.firstOrNull{it.labourId==l.id&&it.fieldId==activeField&&it.date==selectedDate}
                    val totalForLabour=store.attendances.filter{it.labourId==l.id&&it.date==selectedDate}.sumOf{it.fraction}
                    val remaining=(1.0-totalForLabour+(a?.fraction?:0.0)).coerceAtLeast(0.0)
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                        Column(Modifier.padding(13.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=24.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp)
                                    Text("दिहाड़ी ₹${money(store.rateFor(l.id,selectedDate))}/दिन",fontSize=11.sp,color=Color.Gray)
                                }
                                if(a!=null) Text(if(a.fraction==1.0)"✓ पूरा दिन" else if(a.fraction==0.5)"✓ आधा दिन" else if(a.fraction==0.0)"✓ भांजी (नहीं आया)" else "✓ ${money(a.fraction)} दिन",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                val fullSelected = a?.fraction == 1.0
                                val halfSelected = a?.fraction == 0.5
                                val bhanjiSelected = a?.fraction == 0.0
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.9999 || fullSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,1.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,1.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(fullSelected) Green else Color.White,
                                        contentColor=if(fullSelected) Color.White else Green
                                    ),
                                    border=if(fullSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Green)
                                ){Text(if(fullSelected)"✓ पूरा दिन" else "पूरा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.5 || halfSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.5)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.5,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"हाजिरी सेव हो गई।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(halfSelected) Color(0xFF6B4BC1) else Color.White,
                                        contentColor=if(halfSelected) Color.White else Color(0xFF6B4BC1)
                                    ),
                                    border=if(halfSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFF6B4BC1))
                                ){Text(if(halfSelected)"✓ आधा दिन" else "आधा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:"भांजी दर्ज हो गई। इस दिन मजदूरी ₹0 रहेगी।"
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(bhanjiSelected) Color(0xFFB3261E) else Color.White,
                                        contentColor=if(bhanjiSelected) Color.White else Color(0xFFB3261E)
                                    ),
                                    border=if(bhanjiSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFFB3261E))
                                ){Text(if(bhanjiSelected)"✓ भांजी" else "भांजी",fontWeight=FontWeight.Bold)}
                                if(a!=null){
                                    IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                }
                            }
                        }
                    }
                }
            }
            if(store.fields.isEmpty()) this.item{Text("पहले Field में खेत जोड़ें।",color=Color.Gray)}
            if(store.labours.isEmpty()) this.item{Text("पहले Labour में मजदूर जोड़ें।",color=Color.Gray)}

            this.item{
                Text("इस तारीख की लगी हुई हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
            }
            this.items(store.attendances.filter{it.date==selectedDate&&it.fraction>0.0}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}),key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}",fontSize=11.sp,color=Color.Gray)
                        }
                        IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }

        if(addLabour) LabourDialog(store,null){addLabour=false}

    protectedAttendanceEdit?.let{pending->
            DeviceCredentialGate(
                "हाजिरी बदलें",
                "हाजिरी का पूरा दिन, आधा दिन या भांजी बदलने के लिए Android screen lock से पुष्टि करें।",
                {
                    val a=pending.first
                    val result=store.upsertAttendance(a.copy(fraction=pending.second,rate=store.rateFor(a.labourId,a.date)))
                    attendanceError=result?:"हाजिरी सफलतापूर्वक बदली गई।"
                    protectedAttendanceEdit=null
                },
                {protectedAttendanceEdit=null}
            )
        }

        credentialDelete?.let{a->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                {val deleted=store.deleteAttendance(a.id);deleteAttendance=null;attendanceError=if(deleted)"हाजिरी सफलतापूर्वक हटाई गई।" else "इस मजदूर का हिसाब फाइनल है; पुरानी हाजिरी नहीं हटाई जा सकती।"},
                {deleteAttendance=null}
            )
        }
    }
}

@Composable private fun FieldDetail(store:Store,id:String,onBack:()->Unit,onCrop:(String)->Unit,onAttendance:(String)->Unit,onExpense:()->Unit,onSale:()->Unit,onAddCrop:()->Unit){val f=store.fields.firstOrNull{it.id==id}?:return;val crops=store.crops.filter{it.fieldId==id};val labourCost=store.attendances.filter{it.fieldId==id}.sumOf{it.fraction*it.rate};val exp=store.expenses.filter{it.fieldId==id}.sumOf{it.amount};val sale=store.sales.filter{it.fieldId==id}.sumOf{it.total};val total=labourCost+exp;Column(Modifier.fillMaxSize()){DetailTopBar("🌾 ${f.name.ifBlank{"खेत"}}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",total)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-total)}}};this.item{SmallAction("👷 Labour / हाजिरी",{onAttendance(id)})};this.item{SmallAction("💰 खेती का खर्च",onExpense)};this.item{SmallAction("🧺 Sale",onSale)};this.item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("🌱 फसल",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp);IconButton(onClick=onAddCrop){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}};this.items(crops,key={it.id}){c->Card(Modifier.fillMaxWidth().clickable{onCrop(c.id)},RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)}}};this.item{Text("कुल मजदूरी: ₹${money(labourCost)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल खेती खर्च: ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल लागत: ₹${money(total)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल बिक्री: ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{Text("लाभ: ₹${money(sale-total)}",fontWeight=FontWeight.Bold,color=Green)}}}}

@Composable
private fun TodayAttendanceScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val day=today()
    val rows=store.attendances.filter{it.date==day}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId})
    val total=rows.sumOf{it.fraction*it.rate}
    val workerCount=rows.filter{it.fraction>0.0}.map{it.labourId}.distinct().size
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 आज की हाजिरी • ${displayDate(day)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){Stat("कुल मजदूर",workerCount.toDouble())}
                    Box(Modifier.weight(1f)){Stat("कुल मजदूरी",total)}
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"})},
                    onPdf={exportReportPdf(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.filter{it.fraction>0.0}.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"},background=true)}
                )
            }
            items(rows.filter{it.fraction>0.0},key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}; val f=store.fields.firstOrNull{it.id==a.fieldId}; val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("👷",fontSize=24.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""}",fontSize=11.sp,color=Color.Gray)}
                        Surface(shape=RoundedCornerShape(10.dp),color=if(a.fraction==1.0) Color(0xFFE0F5E8) else Color(0xFFE9E0FF)){Text(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",Modifier.padding(horizontal=9.dp,vertical=6.dp),fontSize=11.sp,fontWeight=FontWeight.Bold,color=if(a.fraction==1.0)Green else Color(0xFF6B4BC1))}
                        Spacer(Modifier.width(8.dp));Text("₹${money(a.fraction*a.rate)}",fontWeight=FontWeight.Bold)
                    }
                }
            }
            if(rows.none{it.fraction>0.0}) item{Text("आज कोई मजदूर काम पर नहीं आया।",color=Color.Gray)}
        }
    }
}

@Composable
private fun AttendanceHistoryScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val months=store.attendances.map{it.date.take(7)}.distinct().sortedDescending()
    var monthIndex by remember { mutableStateOf(0) }
    val month=months.getOrNull(monthIndex) ?: today().take(7)
    val allMonthRows=store.attendances.filter{it.date.startsWith(month)}.sortedByDescending{it.date}
    val rows=allMonthRows.filter{it.fraction>0.0}
    val total=allMonthRows.sumOf{it.fraction*it.rate}
    val dayGroups=rows.groupBy{it.date}.toList().sortedByDescending{it.first}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 हाजिरी सूची",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
            item{
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(14.dp)){
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            IconButton(enabled=monthIndex < months.lastIndex,onClick={if(monthIndex < months.lastIndex) monthIndex++}){Icon(Icons.Default.ChevronLeft,null)}
                            Text(if(month.isBlank())"हाजिरी सूची" else monthTitle(month),Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.ExtraBold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(enabled=monthIndex>0,onClick={if(monthIndex>0) monthIndex--}){Icon(Icons.Default.ChevronRight,null)}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल दिन",dayGroups.size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूर",rows.map{it.labourId}.distinct().size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूरी",total)}
                        }
                    }
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportAttendanceHistoryPhoto(context,"हाजिरी_सूची_$month",month,dayGroups,store)},
                    onPdf={exportAttendanceHistoryPdf(context,"हाजिरी_सूची_$month",month,dayGroups,store)}
                )
            }
            dayGroups.forEach{(date,dayRows)->
                item{
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                        Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(date),fontWeight=FontWeight.Bold,fontSize=16.sp);Text("${dayRows.map{it.labourId}.distinct().size} मजदूर काम पर आए",fontSize=11.sp,color=Color.Gray)};Text("₹${money(dayRows.sumOf{it.fraction*it.rate})}",fontWeight=FontWeight.ExtraBold,color=Green)}
                        Column(Modifier.padding(horizontal=4.dp)){dayRows.filter{it.fraction>0.0}.forEach{a->val l=store.labours.firstOrNull{it.id==a.labourId};Text("${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else "${money(a.fraction)} दिन"}",fontSize=11.sp)}}
                    }
                }
            }
            if(rows.isEmpty()) item{Text("इस महीने कोई हाजिरी रिकॉर्ड नहीं है।",color=Color.Gray)}
        }
    }
}

@Composable
private fun LabourDetail(
    store: Store,
    id: String,
    onBack: () -> Unit
) {
    val l = store.labours.firstOrNull { it.id == id } ?: return
    val context=LocalContext.current

    var edit by remember { mutableStateOf(false) }
    var payment by remember { mutableStateOf(false) }
    var editPayment by remember { mutableStateOf<Payment?>(null) }
    var rate by remember { mutableStateOf(false) }
    var protectedRateEdit by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var delAttendance by remember { mutableStateOf<Attendance?>(null) }

    val lastClosedThrough=store.latestClosure(id)?.throughDate.orEmpty()
    val currentAttendance=store.attendances.filter{it.labourId==id&&it.date>lastClosedThrough}
    val currentPayments=store.payments.filter{it.labourId==id&&it.date>lastClosedThrough}
    val wage = currentAttendance.sumOf { it.fraction * it.rate }
    val paid = currentPayments.sumOf { it.amount }

    Column(Modifier.fillMaxSize()) {
        DetailTopBar(
            "👷 ${l.name.ifBlank { "मजदूर" }}",
            onBack
        )

        LazyColumn(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            this.item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(1f)) { Stat("मजदूरी", wage) }
                    Box(Modifier.weight(1f)) { Stat("भुगतान", paid) }
                    Box(Modifier.weight(1f)) { Stat("बाकी", wage - paid) }
                }
            }

            this.item {
                store.latestClosure(id)?.let { closed ->
                    Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                            Text("पुराना हिसाब फाइनल",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                            Text("${displayDate(closed.throughDate)} तक • मजदूरी ₹${money(closed.wage)} • भुगतान ₹${money(closed.paid)} • बाकी ₹${money(closed.wage-closed.paid)}",fontSize=12.sp)
                            Text("ऊपर और PDF में केवल नए हिसाब की रकम दिखाई जाएगी। पुराना रिकॉर्ड रिपोर्ट में सुरक्षित है।",fontSize=11.sp,color=Color.Gray)
                        }
                    }
                }
            }

            this.item {
                Button(
                    onClick = { payment = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("₹ Cash+ भुगतान जोड़ें")
                }
            }

            this.item {
                Button(
                    onClick = { protectedRateEdit = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
                ) {
                    Text("दिहाड़ी बदलें")
                }
            }

            this.item {
                val allAttendanceRows=store.attendances.filter{it.labourId==id}.sortedByDescending{it.date}
                val allPaymentRows=store.payments.filter{it.labourId==id}.sortedByDescending{it.date}
                val attendanceRows=allAttendanceRows.filter{it.date>lastClosedThrough}
                val paymentRows=allPaymentRows.filter{it.date>lastClosedThrough}
                val report=attendanceRows.filter{it.fraction>0.0}.map{a->val f=store.fields.firstOrNull{it.id==a.fieldId};"${displayDate(a.date)} • ${f?.name?:"खेत"} • ${if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • ₹${money(a.fraction*a.rate)}"} + listOf("","भुगतान") + paymentRows.map{p->"${displayDate(p.date)} • भुगतान • ₹${money(p.amount)}"}
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"${l.name}_हिसाब","कुल मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बाकी ₹${money(wage-paid)}",report)},
                    onPdf={exportWorkerLedgerPdf(context,l,store,attendanceRows,paymentRows,wage,paid,background=true)}
                )
            }

            this.item {
                Text(
                    "वर्तमान दिहाड़ी: ₹${money(store.rateFor(id, today()))}/दिन",
                    fontWeight = FontWeight.Bold,
                    color = Green
                )
            }

            this.item {
                Text(
                    "दिहाड़ी इतिहास",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(store.rateHistoryFor(id), key = { it.id }) { r ->
                Text(
                    "${displayDate(r.effectiveDate)} से ₹${money(r.rate)}/दिन",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            this.item {
                val labourRows = currentAttendance
                val fullDays = labourRows.count { it.fraction == 1.0 }
                val halfDays = labourRows.count { it.fraction == 0.5 }
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(12.dp)){
                        Text("📊 काम का सार",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल काम",labourRows.sumOf{it.fraction})}
                            Box(Modifier.weight(1f)){Stat("पूरा दिन",fullDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("आधा दिन",halfDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("कुल मजदूरी",wage)}
                        }
                    }
                }
            }

            this.item {
                Text(
                    "हाजिरी",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                currentAttendance.sortedByDescending { it.date },
                key = { it.id }
            ) { a ->
                val f = store.fields.firstOrNull { it.id == a.fieldId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(
                            "${displayDate(a.date)} • ${f?.name ?: "खेत"} • " +
                                "${store.crops.firstOrNull { it.id == a.cropId }?.name?.let { "$it • " } ?: ""}" +
                                "${if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (काम पर नहीं आया)" else "अन्य (${money(a.fraction)})"} • " +
                                "₹${money(a.fraction * a.rate)}",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick={delAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }

            this.item {
                Text(
                    "भुगतान",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                currentPayments.sortedByDescending { it.date },
                key = { it.id }
            ) { p ->
                val f = store.fields.firstOrNull { it.id == p.fieldId }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${displayDate(p.date)} • ${f?.name ?: "सामान्य"}" +
                            "${store.crops.firstOrNull { it.id == p.cropId }?.name?.let { " • $it" } ?: ""}" +
                            " • ₹${money(p.amount)}",
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { editPayment = p }) { Icon(Icons.Default.Edit,contentDescription="भुगतान बदलें",tint=Green) }
                    IconButton(onClick = { delPay = p }) {
                        Icon(imageVector = Icons.Default.Delete,contentDescription = "भुगतान हटाएँ",tint = Color(0xFFB3261E))
                    }
                }
            }
        }

        if (edit) {
            LabourDialog(store, l) {
                edit = false
            }
        }

        if (payment) {
            PaymentDialog(store, id, null, "", onClose={payment = false})
        }
        editPayment?.let { item ->
            PaymentDialog(store, id, item.fieldId, item.cropId, onClose={editPayment=null}, existing=item)
        }
        protectedRateEdit.takeIf{it}?.let{
            DeviceCredentialGate(
                "दिहाड़ी बदलें",
                "मजदूर की दिहाड़ी बदलने के लिए Android screen lock से पुष्टि करें।",
                {rate=true;protectedRateEdit=false},
                {protectedRateEdit=false}
            )
        }

        if (rate) {
            RateDialog(store, id) {
                rate = false
            }
        }

        delAttendance?.let { attendanceItem ->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deleteAttendance(attendanceItem.id); delAttendance = null; if(!deleted) android.widget.Toast.makeText(context,"यह हाजिरी फाइनल हिसाब में है, इसलिए नहीं हटाई गई।",android.widget.Toast.LENGTH_LONG).show() },
                { delAttendance = null }
            )
        }

        delPay?.let { paymentItem ->
            DeviceCredentialDeleteGate(
                "भुगतान हटाएँ",
                "गलत payment entry हटाने के लिए Android screen lock से पुष्टि करें।",
                { val deleted=store.deletePayment(paymentItem.id); delPay = null; if(!deleted) android.widget.Toast.makeText(context,"यह भुगतान फाइनल हिसाब में है, इसलिए नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show() },
                { delPay = null }
            )
        }
        /*
        delPay?.let { paymentItem ->
            ConfirmDialog(
                "भुगतान हटाएँ?",
                "यह payment record हट जाएगा।",
                {
                    val deleted=store.deletePayment(paymentItem.id)
                    delPay = null
                    if(!deleted) android.widget.Toast.makeText(context,"यह भुगतान फाइनल हिसाब में है, इसलिए नहीं हटाया गया।",android.widget.Toast.LENGTH_LONG).show()
                },
                {
                    delPay = null
                }
            )
        }
        */
    }
}


@Composable
private fun ExportButtons(onPhoto:()->Unit,onPdf:()->Unit){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
        Button(onClick=onPhoto,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4BC1))){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(6.dp));Text("Photo",fontWeight=FontWeight.Bold)}
        Button(onClick=onPdf,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(6.dp));Text("PDF",fontWeight=FontWeight.Bold)}
    }
}

private fun safeFileName(value:String):String=value.replace(Regex("[^A-Za-z0-9_-]+"),"_").trim('_').ifBlank{"report"}

private fun shareFile(context:Context,file:File,mime:String,title:String){
    val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file)
    val intent=Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
    context.startActivity(Intent.createChooser(intent,title))
}

private fun wrapReportText(text:String, paint:Paint, maxWidth:Float):List<String>{
    val words=text.trim().split(Regex("\\s+"))
    if(words.isEmpty()) return listOf("")
    val out=mutableListOf<String>(); var line=""
    for(word in words){
        val candidate=if(line.isBlank()) word else "$line $word"
        if(paint.measureText(candidate)<=maxWidth){line=candidate}else{
            if(line.isNotBlank()) out.add(line)
            line=word
        }
    }
    if(line.isNotBlank()) out.add(line)
    return out.ifEmpty{listOf("")}
}

private fun exportReportPhoto(context:Context,title:String,summary:String,lines:List<String>){
    try{
        val width=1200; val side=45f; val contentW=width-side*2; val lineH=38f; val headerH=255f
        val textPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;typeface=Typeface.DEFAULT;textSize=27f}
        val wrapped=lines.flatMapIndexed{idx,line->wrapReportText("${idx+1}. $line",textPaint,contentW)}
        val height=(headerH+wrapped.size*lineH+70f).toInt().coerceAtLeast(500)
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=Typeface.DEFAULT_BOLD;textSize=46f}
        canvas.drawText("MAJDOOR HISAAB PRO",side,65f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=30f;paint.color=android.graphics.Color.DKGRAY
        canvas.drawText(title,side,115f,paint)
        paint.textSize=26f;paint.color=android.graphics.Color.rgb(11,107,74)
        wrapReportText(summary,paint,contentW).take(2).forEachIndexed{i,t->canvas.drawText(t,side,165f+i*32f,paint)}
        paint.color=android.graphics.Color.LTGRAY;canvas.drawRect(side,205f,width-side,207f,paint)
        paint.color=android.graphics.Color.BLACK;paint.textSize=27f;paint.typeface=Typeface.DEFAULT
        var y=250f
        wrapped.forEach{line->canvas.drawText(line,side,y,paint);y+=lineH}
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}; val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}; bitmap.recycle(); shareFile(context,file,"image/png","Photo साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Photo report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun exportAttendanceHistoryPhoto(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
) {
    try {
        val width = 1400
        val side = 50f
        val contentW = width - side * 2
        val lineH = 42f
        val days = dayGroups.sortedByDescending { it.first }
        val totalRecords = days.sumOf { it.second.size }
        val uniqueWorkers = days.flatMap { it.second.filter { a -> a.fraction > 0.0 }.map { a -> a.labourId } }.distinct().size
        val totalWage = days.sumOf { group -> group.second.sumOf { a -> a.fraction * a.rate } }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            typeface = Typeface.DEFAULT
            textSize = 28f
        }

        var height = 330f
        days.forEach { (_, rows) ->
            height += 110f + 72f + rows.size * lineH + 58f
        }
        height += 170f

        val bitmap = Bitmap.createBitmap(width, height.toInt().coerceAtLeast(700), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)

        val darkGreen = android.graphics.Color.rgb(6, 76, 54)
        val green = android.graphics.Color.rgb(11, 107, 74)
        val lightGreen = android.graphics.Color.rgb(234, 248, 241)
        val lightBlue = android.graphics.Color.rgb(235, 245, 255)
        val lightYellow = android.graphics.Color.rgb(255, 249, 225)

        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkGreen
            typeface = Typeface.DEFAULT_BOLD
            textSize = 48f
        }
        canvas.drawRoundRect(side, 25f, width - side, 145f, 24f, 24f, headerPaint)

        headerPaint.color = android.graphics.Color.WHITE
        headerPaint.textSize = 44f
        canvas.drawText("MAJDOOR HISAAB PRO", side + 28f, 78f, headerPaint)
        headerPaint.textSize = 31f
        canvas.drawText("हाजिरी सूची • ${monthTitle(month)}", side + 28f, 120f, headerPaint)

        fun summaryCard(left: Float, top: Float, right: Float, label: String, value: String, bg: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
            canvas.drawRoundRect(left, top, right, top + 125f, 20f, 20f, p)
            p.color = darkGreen
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 25f
            canvas.drawText(label, left + 22f, top + 40f, p)
            p.textSize = 42f
            canvas.drawText(value, left + 22f, top + 94f, p)
        }

        val gap = 14f
        val cardW = (contentW - gap * 3) / 4f
        val sy = 170f
        summaryCard(side, sy, side + cardW, "कुल कार्य दिवस", days.size.toString(), lightBlue)
        summaryCard(side + cardW + gap, sy, side + cardW * 2 + gap, "अलग मजदूर", uniqueWorkers.toString(), lightYellow)
        summaryCard(side + cardW * 2 + gap * 2, sy, side + cardW * 3 + gap * 2, "कुल हाजिरी", totalRecords.toString(), lightGreen)
        summaryCard(side + cardW * 3 + gap * 3, sy, width - side, "कुल मजदूरी", "₹${money(totalWage)}", android.graphics.Color.rgb(255, 237, 237))

        var y = 325f

        days.forEachIndexed { dayIndex, pair ->
            val date = pair.first
            val rows = pair.second
            val dayTotal = rows.sumOf { it.fraction * it.rate }
            val workers = rows.filter { it.fraction > 0.0 }.map { it.labourId }.distinct().size
            val sectionBg = if (dayIndex % 2 == 0) lightGreen else lightYellow

            val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sectionBg }
            canvas.drawRoundRect(side, y, width - side, y + 82f + rows.size * lineH + 65f, 22f, 22f, sectionPaint)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = darkGreen
                typeface = Typeface.DEFAULT_BOLD
                textSize = 34f
            }
            canvas.drawText(displayDate(date), side + 25f, y + 43f, titlePaint)

            titlePaint.typeface = Typeface.DEFAULT
            titlePaint.textSize = 23f
            canvas.drawText("कुल मजदूर: $workers", side + 330f, y + 42f, titlePaint)
            canvas.drawText("कुल हाजिरी: ${rows.size}", side + 570f, y + 42f, titlePaint)
            titlePaint.typeface = Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}", side + 830f, y + 42f, titlePaint)

            val tableTop = y + 62f
            val headerH = 45f
            val col1 = side
            val col2 = side + 105f
            val col3 = side + 570f
            val col4 = side + 1080f
            val tableRight = width - side

            val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = darkGreen }
            canvas.drawRect(col1, tableTop, tableRight, tableTop + headerH, hp)

            val whitePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                typeface = Typeface.DEFAULT_BOLD
                textSize = 21f
            }
            canvas.drawText("क्रम", col1 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूर का नाम", col2 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("काम का प्रकार", col3 + 18f, tableTop + 30f, whitePaint)
            canvas.drawText("मजदूरी (₹)", col4 + 18f, tableTop + 30f, whitePaint)

            var rowY = tableTop + headerH
            rows.sortedWith(compareBy<Attendance> { it.labourId }.thenBy { it.fieldId }).forEachIndexed { index, a ->
                val l = store.labours.firstOrNull { it.id == a.labourId }
                val bg = if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(247, 250, 249)
                val rp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bg }
                canvas.drawRect(col1, rowY, tableRight, rowY + lineH, rp)

                val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.rgb(25, 25, 25)
                    typeface = Typeface.DEFAULT
                    textSize = 21f
                }
                canvas.drawText("${index + 1}", col1 + 24f, rowY + 29f, tp)
                canvas.drawText(l?.name ?: "मजदूर", col2 + 18f, rowY + 29f, tp)
                canvas.drawText(if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else if (a.fraction == 0.0) "भांजी (नहीं आया)" else "अन्य", col3 + 18f, rowY + 29f, tp)
                tp.typeface = Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction * a.rate)}", col4 + 18f, rowY + 29f, tp)
                rowY += lineH
            }

            val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(218, 246, 222)
                typeface = Typeface.DEFAULT_BOLD
                textSize = 24f
            }
            canvas.drawRect(col1, rowY, tableRight, rowY + 55f, totalPaint)
            totalPaint.color = darkGreen
            canvas.drawText("${displayDate(date)} का कुल", col1 + 25f, rowY + 36f, totalPaint)
            canvas.drawText("₹${money(dayTotal)}", col4 + 18f, rowY + 36f, totalPaint)

            y = rowY + 85f
        }

        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(235, 245, 255)
            typeface = Typeface.DEFAULT_BOLD
            textSize = 27f
        }
        canvas.drawRoundRect(side, y, width - side, y + 135f, 22f, 22f, totalPaint)
        totalPaint.color = darkGreen
        totalPaint.textSize = 32f
        canvas.drawText("${monthTitle(month)} — कुल योग", side + 25f, y + 45f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT
        totalPaint.textSize = 24f
        canvas.drawText("कार्य दिवस: ${days.size}   •   अलग मजदूर: $uniqueWorkers   •   कुल हाजिरी रिकॉर्ड: $totalRecords", side + 25f, y + 82f, totalPaint)
        totalPaint.typeface = Typeface.DEFAULT_BOLD
        totalPaint.textSize = 34f
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}", side + 25f, y + 119f, totalPaint)

        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(dir, "${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        shareFile(context, file, "image/png", "Photo साझा करें")
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Photo report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportAttendanceHistoryPdf(
    context: Context,
    title: String,
    month: String,
    dayGroups: List<Pair<String,List<Attendance>>>,
    store: Store
){
    try{
        val doc=PdfDocument()
        val pageW=595
        val pageH=842
        val left=24f
        val right=24f
        val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        var pageNo=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
        var canvas=page.canvas

        val days=dayGroups.sortedByDescending{it.first}
        val totalRecords=days.sumOf{it.second.size}
        val uniqueWorkers=days.flatMap{it.second.filter{a->a.fraction>0.0}.map{a->a.labourId}}.distinct().size
        val totalWage=days.sumOf{g->g.second.sumOf{a->a.fraction*a.rate}}

        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=22f
            canvas.drawText("MAJDOOR HISAAB PRO",left,32f,paint)
            paint.color=android.graphics.Color.BLACK
            paint.textSize=14f
            paint.typeface=Typeface.DEFAULT
            canvas.drawText("हाजिरी सूची • ${monthTitle(month)}",left,53f,paint)
            paint.textSize=9.5f
            canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी: $totalRecords • कुल मजदूरी: ₹${money(totalWage)}",left,70f,paint)
            paint.color=android.graphics.Color.LTGRAY
            canvas.drawRect(left,80f,pageW-right,81.5f,paint)
        }

        fun newPage(){
            doc.finishPage(page)
            pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
            canvas=page.canvas
            header()
        }

        fun ensure(space:Float, currentY:Float):Float{
            if(currentY+space>810f){newPage();return 100f}
            return currentY
        }

        header()
        var y=102f

        days.forEach{(date,rows)->
            val dayTotal=rows.sumOf{it.fraction*it.rate}
            val workers=rows.filter{it.fraction>0.0}.map{it.labourId}.distinct().size

            y=ensure(60f,y)
            paint.color=android.graphics.Color.rgb(234,248,241)
            canvas.drawRoundRect(left,y-18f,pageW-right,y+22f,8f,8f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=12f
            canvas.drawText(displayDate(date),left+8f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT
            paint.textSize=9.5f
            canvas.drawText("कुल मजदूर: $workers",left+115f,y+3f,paint)
            canvas.drawText("कुल हाजिरी: ${rows.size}",left+225f,y+3f,paint)
            paint.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText("दिन की मजदूरी: ₹${money(dayTotal)}",left+365f,y+3f,paint)
            y+=35f

            // Compact table columns
            val c1=left
            val c2=left+34f
            val c3=left+235f
            val c4=left+435f
            val tr=pageW-right
            paint.color=android.graphics.Color.rgb(6,76,54)
            canvas.drawRect(c1,y,c4+100f,y+24f,paint)
            paint.color=android.graphics.Color.WHITE
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=8.5f
            canvas.drawText("क्रम",c1+6f,y+16f,paint)
            canvas.drawText("मजदूर का नाम",c2+6f,y+16f,paint)
            canvas.drawText("काम का प्रकार",c3+6f,y+16f,paint)
            canvas.drawText("मजदूरी (₹)",c4+6f,y+16f,paint)
            y+=24f

            rows.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}).forEachIndexed{index,a->
                y=ensure(18f,y)
                paint.color=if(index%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(247,250,249)
                canvas.drawRect(c1,y,tr,y+18f,paint)
                val l=store.labours.firstOrNull{it.id==a.labourId}
                paint.color=android.graphics.Color.rgb(25,25,25)
                paint.typeface=Typeface.DEFAULT
                paint.textSize=8.5f
                canvas.drawText("${index+1}",c1+6f,y+13f,paint)
                canvas.drawText((l?.name?:"मजदूर").take(28),c2+6f,y+13f,paint)
                canvas.drawText(if(a.fraction==1.0)"पूरा दिन" else if(a.fraction==0.5)"आधा दिन" else if(a.fraction==0.0)"भांजी (नहीं आया)" else "अन्य",c3+6f,y+13f,paint)
                paint.typeface=Typeface.DEFAULT_BOLD
                canvas.drawText("₹${money(a.fraction*a.rate)}",c4+6f,y+13f,paint)
                y+=18f
            }
            paint.color=android.graphics.Color.rgb(218,246,222)
            canvas.drawRect(c1,y,tr,y+22f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=9.5f
            canvas.drawText("${displayDate(date)} का कुल",c1+6f,y+15f,paint)
            canvas.drawText("₹${money(dayTotal)}",c4+6f,y+15f,paint)
            y+=34f
        }

        y=ensure(65f,y)
        paint.color=android.graphics.Color.rgb(235,245,255)
        canvas.drawRoundRect(left,y,pageW-right,y+58f,10f,10f,paint)
        paint.color=android.graphics.Color.rgb(6,76,54)
        paint.typeface=Typeface.DEFAULT_BOLD
        paint.textSize=12f
        canvas.drawText("${monthTitle(month)} — कुल योग",left+8f,y+18f,paint)
        paint.typeface=Typeface.DEFAULT
        paint.textSize=9.5f
        canvas.drawText("कार्य दिवस: ${days.size} • अलग मजदूर: $uniqueWorkers • कुल हाजिरी रिकॉर्ड: $totalRecords",left+8f,y+36f,paint)
        paint.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText("कुल मजदूरी: ₹${money(totalWage)}",left+350f,y+36f,paint)

        doc.finishPage(page)
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use{doc.writeTo(it)}
        doc.close()
        shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){
        android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportWorkerLedgerPdf(
    context: Context,
    labour: Labour,
    store: Store,
    attendanceRows: List<Attendance>,
    paymentRows: List<Payment>,
    totalWage: Double,
    totalPaid: Double,
    background: Boolean = true
) {
    val generate = {
        try {
            val doc = PdfDocument()
            val pageW = 595
            val pageH = 842
            val left = 24f
            val right = 24f
            val contentRight = pageW - right
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            val green = android.graphics.Color.rgb(6, 76, 54)
            val mint = android.graphics.Color.rgb(237, 248, 243)
            val dark = android.graphics.Color.rgb(25, 25, 25)
            val grid = android.graphics.Color.rgb(205, 216, 212)
            var pageNo = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            var canvas = page.canvas

            fun text(value: String, x: Float, y: Float, size: Float, color: Int = dark, bold: Boolean = false) {
                paint.color = color
                paint.textSize = size
                paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                canvas.drawText(value, x, y, paint)
            }
            fun rect(l: Float, t: Float, r: Float, b: Float, color: Int) {
                paint.color = color
                canvas.drawRect(l, t, r, b, paint)
            }
            fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int = grid, stroke: Float = 0.7f) {
                paint.color = color
                paint.strokeWidth = stroke
                canvas.drawLine(x1, y1, x2, y2, paint)
            }
            fun rounded(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
                paint.color = color
                canvas.drawRoundRect(l, t, r, b, radius, radius, paint)
            }
            fun header() {
                rounded(left, 18f, contentRight, 92f, 12f, green)
                runCatching {
                    val logo = BitmapFactory.decodeResource(context.resources, R.drawable.majdoor_logo_small)
                    if (logo != null) {
                        canvas.drawBitmap(logo, null, android.graphics.RectF(left + 9f, 28f, left + 62f, 82f), Paint(Paint.ANTI_ALIAS_FLAG))
                        logo.recycle()
                    }
                }
                text("MAJDOOR HISAAB PRO", left + 72f, 49f, 22f, android.graphics.Color.WHITE, true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल", left + 72f, 73f, 12f, android.graphics.Color.rgb(224, 242, 234))
                text("मजदूर का हिसाब", contentRight - 142f, 48f, 13f, android.graphics.Color.WHITE, true)
                text("व्यक्तिगत विवरण", contentRight - 142f, 69f, 11f, android.graphics.Color.WHITE)
            }
            fun footer() {
                line(left, 806f, contentRight, 806f, green, 1.3f)
                text("तैयार करने की तारीख: ${displayDate(today())}", left + 8f, 825f, 9.5f)
                text("ऐप: MAJDOOR HISAAB PRO", left + 8f, 839f, 9f)
                text("पेज $pageNo", contentRight - 50f, 825f, 9.5f)
            }
            fun startNewPage() {
                footer()
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
                canvas = page.canvas
                header()
            }

            header()
            rounded(left, 102f, contentRight, 198f, 10f, mint)
            text("मजदूर का नाम", left + 17f, 124f, 11f, dark, true)
            text(labour.name.ifBlank { "मजदूर" }.take(30), left + 17f, 153f, 21f, dark, true)
            text("मोबाइल: ${labour.mobile.ifBlank { "-" }}".take(36), left + 17f, 177f, 10.5f)
            line(316f, 113f, 316f, 187f, android.graphics.Color.rgb(190, 220, 207), 0.8f)
            text("कुल दिहाड़ी दर", 334f, 124f, 11f)
            text(":  ₹${money(store.rateFor(labour.id, today()))} प्रति दिन", 428f, 124f, 11f, dark, true)
            text("कुल मजदूरी", 334f, 147f, 11f)
            text(":  ₹${money(totalWage)}", 428f, 147f, 11f, dark, true)
            text("भुगतान", 334f, 169f, 11f)
            text(":  ₹${money(totalPaid)}", 428f, 169f, 11f, dark, true)
            text("बाकी राशि", 334f, 190f, 11f)
            text(":  ₹${money(totalWage - totalPaid)}", 428f, 190f, 11f, green, true)

            // Work rows exclude absence/भांजी. Payments are shown only on their actual payment dates.
            data class LedgerRow(val date: String, val field: String, val attendance: String, val payment: Double?, val amount: Double?, val sortDate: String)
            val workRows = attendanceRows.filter { it.fraction > 0.0 }.map { a ->
                LedgerRow(a.date, store.fields.firstOrNull { it.id == a.fieldId }?.name ?: "खेत", if (a.fraction == 1.0) "पूरा दिन" else if (a.fraction == 0.5) "आधा दिन" else "${money(a.fraction)} दिन", null, a.fraction * a.rate, a.date)
            }
            val paymentsByDate = paymentRows.groupBy { it.date }.mapValues { (_, ps) -> ps.sumOf { it.amount } }
            val workDates = workRows.map { it.date }.toSet()
            val paymentOnlyRows = paymentsByDate.filterKeys { it !in workDates }.map { (date, amount) -> LedgerRow(date, "", "—", amount, null, date) }
            val rows = (workRows + paymentOnlyRows).sortedByDescending { it.sortDate }.toMutableList()
            val paidDates = paymentsByDate.keys
            val paidShown = mutableSetOf<String>()
            var y = 225f
            val cols = floatArrayOf(left, left + 43f, left + 145f, left + 332f, left + 418f, left + 500f, contentRight)
            val headers = listOf("क्रम सं.", "तारीख", "खेत / काम का नाम", "हाजिरी", "भुगतान (₹)", "रकम (₹)")
            fun drawTableHeader() {
                rounded(left, y, contentRight, y + 28f, 5f, green)
                headers.forEachIndexed { i, label -> text(label, cols[i] + 5f, y + 18f, 8.8f, android.graphics.Color.WHITE, true) }
                y += 28f
            }
            drawTableHeader()
            rows.forEachIndexed { index, row ->
                if (y + 38f > 650f) {
                    startNewPage()
                    y = 112f
                    drawTableHeader()
                }
                rect(left, y, contentRight, y + 38f, if (index % 2 == 0) android.graphics.Color.WHITE else android.graphics.Color.rgb(248, 251, 249))
                line(left, y + 38f, contentRight, y + 38f)
                for (x in cols.drop(1)) line(x, y, x, y + 38f)
                text("${index + 1}", cols[0] + 14f, y + 23f, 9.5f)
                text(displayDate(row.date), cols[1] + 5f, y + 23f, 8.6f)
                val fieldText = row.field.take(23)
                text(fieldText, cols[2] + 5f, y + 23f, 8.6f)
                text(row.attendance, cols[3] + 5f, y + 23f, 8.6f)
                val pay = if (row.date in paidDates && paidShown.add(row.date)) paymentsByDate[row.date] else null
                if (pay != null) text("₹${money(pay)}", cols[4] + 7f, y + 23f, 8.6f)
                if (row.amount != null) text("₹${money(row.amount)}", cols[5] + 8f, y + 23f, 8.6f)
                y += 38f
            }

            // Compact summary only; intentionally no note box.
            if (y + 135f > 790f) {
                startNewPage()
                y = 112f
            } else {
                y = maxOf(y + 24f, 560f)
            }
            rounded(left, y, contentRight, y + 130f, 10f, mint)
            text("कुल सारांश", left + 15f, y + 25f, 17f, green, true)
            val workDays = attendanceRows.filter { it.fraction > 0.0 }.sumOf { it.fraction }
            text("कुल कार्य दिवस", left + 20f, y + 53f, 11f)
            text(":  ${quantity(workDays)} दिन", left + 150f, y + 53f, 11f, dark, true)
            text("कुल मजदूरी", left + 20f, y + 78f, 11f)
            text(":  ₹${money(totalWage)}", left + 150f, y + 78f, 11f, dark, true)
            text("कुल भुगतान", left + 20f, y + 103f, 11f)
            text(":  ₹${money(totalPaid)}", left + 150f, y + 103f, 11f, dark, true)
            text("बाकी राशि", left + 300f, y + 78f, 11f)
            text(":  ₹${money(totalWage - totalPaid)}", left + 385f, y + 78f, 11f, android.graphics.Color.rgb(185, 35, 35), true)
            footer()
            doc.finishPage(page)
            val dir = File(context.cacheDir, "reports").apply { mkdirs() }
            val file = File(dir, "${safeFileName(labour.name + "_हिसाब")}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            if (background) reportMainHandler.post {
                runCatching { shareFile(context, file, "application/pdf", "PDF साझा करें") }.onFailure {
                    android.widget.Toast.makeText(context, "PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            } else shareFile(context, file, "application/pdf", "PDF साझा करें")
        } catch (e: Exception) {
            if (background) reportMainHandler.post { android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show() }
            else android.widget.Toast.makeText(context, "PDF report नहीं बन सकी: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    if (background) reportPdfExecutor.execute { generate() } else generate()
}

private val reportPdfExecutor = Executors.newSingleThreadExecutor()
private val reportMainHandler = android.os.Handler(android.os.Looper.getMainLooper())

private fun exportAllWorkersLedgerPdf(
    context:Context,
    title:String,
    dateLabel:String,
    fieldLabel:String,
    rows:List<LabourReportRow>,
    totalWage:Double,
    totalPaid:Double,
    background:Boolean=false
){
    val generate={
        try{
            val doc=PdfDocument(); val pageW=595; val pageH=842; val left=24f; val right=24f; val contentRight=pageW-right
            val green=android.graphics.Color.rgb(6,76,54); val mint=android.graphics.Color.rgb(237,248,243); val dark=android.graphics.Color.rgb(25,35,31); val red=android.graphics.Color.rgb(196,35,35)
            val paint=Paint(Paint.ANTI_ALIAS_FLAG)
            var pageNo=1
            var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
            fun text(t:String,x:Float,y:Float,size:Float=10f,color:Int=dark,bold:Boolean=false){paint.color=color;paint.textSize=size;paint.typeface=if(bold)Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL);canvas.drawText(t,x,y,paint)}
            fun line(x1:Float,y1:Float,x2:Float,y2:Float,color:Int=android.graphics.Color.LTGRAY,width:Float=0.6f){paint.color=color;paint.strokeWidth=width;canvas.drawLine(x1,y1,x2,y2,paint)}
            fun rect(l:Float,t:Float,r:Float,b:Float,color:Int){paint.color=color;canvas.drawRect(l,t,r,b,paint)}
            fun rounded(l:Float,t:Float,r:Float,b:Float,rad:Float,color:Int){paint.color=color;canvas.drawRoundRect(l,t,r,b,rad,rad,paint)}
            fun footer(){line(left,806f,contentRight,806f,green,1.2f);text("तैयार करने की तारीख: ${displayDate(today())}",left+7f,824f,9f);text("ऐप: MAJDOOR HISAAB PRO",left+7f,838f,8.5f);text("पेज $pageNo",contentRight-48f,824f,9f)}
            fun header(){
                rounded(left,20f,contentRight,82f,9f,green)
                val logo=runCatching{BitmapFactory.decodeResource(context.resources,R.drawable.majdoor_logo_small)}.getOrNull()
                if(logo!=null){paint.isFilterBitmap=true;canvas.drawBitmap(logo,null,android.graphics.RectF(left+10f,29f,left+68f,73f),paint);logo.recycle()}
                text("MAJDOOR HISAAB PRO",left+78f,49f,21f,android.graphics.Color.WHITE,true)
                text("खेत • मजदूर • खर्च • बिक्री • फसल",left+78f,68f,10f,android.graphics.Color.WHITE)
                text("चुने हुए मजदूरों का हिसाब",left,112f,20f,green,true)
                text("अवधि: $dateLabel",left,134f,10f,dark)
                text("खेत: ${fieldLabel.take(64)}",left,151f,10f,dark)
            }
            fun startNewPage(){footer();doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header()}
            header()
            rounded(left,166f,contentRight,229f,9f,mint)
            val workerCount=rows.size
            val summaryCols=floatArrayOf(left,left+137f,left+274f,left+411f,contentRight)
            val summaryLabels=listOf("कुल मजदूर","कुल मजदूरी","कुल भुगतान","कुल बकाया")
            val summaryValues=listOf("$workerCount मजदूर","₹${money(totalWage)}","₹${money(totalPaid)}","₹${money(totalWage-totalPaid)}")
            for(i in 0..3){
                if(i>0) line(summaryCols[i],174f,summaryCols[i],220f,android.graphics.Color.rgb(190,220,207),0.8f)
                text(summaryLabels[i],summaryCols[i]+9f,188f,8.5f,green,true)
                text(summaryValues[i],summaryCols[i]+9f,214f,if(i==0)14f else 12f,if(i==3)red else green,true)
            }
            var y=245f
            val cols=floatArrayOf(left,left+31f,left+195f,left+265f,left+355f,left+435f,contentRight)
            val headers=listOf("क्र.","मजदूर का नाम","काम के दिन","कुल मजदूरी (₹)","भुगतान (₹)","बाकी रकम (₹)")
            fun drawTableHeader(){rounded(left,y,contentRight,y+27f,4f,green);headers.forEachIndexed{i,h->text(h,cols[i]+4f,y+17f,7.5f,android.graphics.Color.WHITE,true)};y+=27f}
            drawTableHeader()
            rows.forEachIndexed{idx,r->
                if(y+29f>790f){startNewPage();y=170f;drawTableHeader()}
                rect(left,y,contentRight,y+29f,if(idx%2==0)android.graphics.Color.WHITE else android.graphics.Color.rgb(248,251,249))
                for(x in cols.drop(1))line(x,y,x,y+29f)
                line(left,y+29f,contentRight,y+29f)
                val balance=r.wage-r.paid
                text("${idx+1}",cols[0]+9f,y+18f,8.5f)
                text(r.labour.name.take(26),cols[1]+4f,y+18f,8.2f)
                text(quantity(r.workDays),cols[2]+10f,y+18f,8.5f)
                text("₹${money(r.wage)}",cols[3]+5f,y+18f,8.2f)
                text("₹${money(r.paid)}",cols[4]+5f,y+18f,8.2f)
                text("₹${money(balance)}",cols[5]+5f,y+18f,8.2f,if(balance>0)red else green,true)
                y+=29f
            }
            if(y+34f>790f){startNewPage();y=170f}
            rounded(left,y,contentRight,y+34f,5f,mint)
            text("कुल योग",left+12f,y+21f,10f,green,true)
            text("${quantity(rows.sumOf{it.workDays})}",cols[2]+10f,y+21f,9f,green,true)
            text("₹${money(totalWage)}",cols[3]+5f,y+21f,9f,green,true)
            text("₹${money(totalPaid)}",cols[4]+5f,y+21f,9f,green,true)
            text("₹${money(totalWage-totalPaid)}",cols[5]+5f,y+21f,9f,red,true)
            footer();doc.finishPage(page)
            val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close()
            if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${it.message}",android.widget.Toast.LENGTH_LONG).show()}} else shareFile(context,file,"application/pdf","PDF साझा करें")
        }catch(e:Exception){if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()} else android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
    }
    if(background)reportPdfExecutor.execute{generate()}else generate()
}

private fun exportReportPdf(context:Context,title:String,summary:String,lines:List<String>,background:Boolean=false){
    val generate = {
    try{
        val doc=PdfDocument(); val pageW=595; val pageH=842; val left=28f; val right=28f; val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG); paint.typeface=Typeface.DEFAULT; paint.textSize=11f
        var pageNo=1; var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54);paint.typeface=Typeface.DEFAULT_BOLD;paint.textSize=24f;canvas.drawText("MAJDOOR HISAAB PRO",left,42f,paint)
            paint.color=android.graphics.Color.BLACK;paint.textSize=19f;canvas.drawText(title.take(45),left,76f,paint)
            paint.textSize=12f;paint.typeface=Typeface.DEFAULT
            wrapReportText(summary,paint,maxW).take(2).forEachIndexed{i,t->canvas.drawText(t,left,100f+i*17f,paint)}
        }
        header(); var y=140f; var rowNo=1
        lines.forEach{line->
            val wrapped=wrapReportText("$rowNo. $line",paint,maxW)
            for(part in wrapped){
                if(y>805f){if(background){paint.typeface=Typeface.DEFAULT;paint.textSize=9f;paint.color=android.graphics.Color.DKGRAY;canvas.drawText("पृष्ठ $pageNo",pageW-right-48f,pageH-16f,paint)};doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header();y=140f}
                canvas.drawText(part,left,y,paint);y+=18f
            }
            rowNo++
            y+=4f
        }
        if(background){paint.typeface=Typeface.DEFAULT;paint.textSize=9f;paint.color=android.graphics.Color.DKGRAY;canvas.drawText("पृष्ठ $pageNo",pageW-right-48f,pageH-16f,paint)}
        doc.finishPage(page); val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close();if(background)reportMainHandler.post{runCatching{shareFile(context,file,"application/pdf","PDF साझा करें")}.onFailure{shareError->android.widget.Toast.makeText(context,"PDF तैयार है, लेकिन शेयर नहीं खुला: ${shareError.message}",android.widget.Toast.LENGTH_LONG).show()}} else shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){if(background)reportMainHandler.post{android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()} else android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
    }
    if(background)reportPdfExecutor.execute{generate()} else generate()
}

private fun caneSeason(date:String=today()):String{
    return try{
        val y=date.take(4).toInt(); val m=date.substring(5,7).toInt()
        if(m>=4) "$y-${(y+1).toString().takeLast(2)}" else "${y-1}-${y.toString().takeLast(2)}"
    }catch(_:Exception){"2026-27"}
}


@Composable
private fun CanePeelingScreen(store:Store,onBack:()->Unit){
    var tab by rememberSaveable{mutableStateOf(0)}
    var showEntry by remember{mutableStateOf(false)}
    var showPayment by remember{mutableStateOf(false)}
    var showLabours by remember{mutableStateOf(false)}
    var quickAddFandi by remember{mutableStateOf(false)}
    var quickAddDate by remember{mutableStateOf(today())}
    var quickAddField by remember{mutableStateOf("")}
    var selectedLabour by remember{mutableStateOf<String?>(null)}
    var selectedField by remember{mutableStateOf<String?>(null)}
    var editEntry by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedEdit by remember{mutableStateOf<CanePeeling?>(null)}
    var protectedDelete by remember{mutableStateOf<CanePeeling?>(null)}
    var editPayment by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentEdit by remember{mutableStateOf<CanePeelingPayment?>(null)}
    var protectedPaymentDelete by remember{mutableStateOf<CanePeelingPayment?>(null)}

    if(showLabours){
        CanePeelingLabourScreen(store,{showLabours=false;quickAddFandi=false},quickAddDate,quickAddField,quickAddFandi)
        return
    }
    if(selectedLabour!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingLabourDetail(store,selectedLabour!!,{selectedLabour=null},{showPayment=true})
        }
        if(showPayment){CanePeelingPaymentDialog(store,null,selectedLabour!!){showPayment=false}}
        return
    }
    if(selectedField!=null){
        Box(Modifier.fillMaxSize().background(Bg)){
            CanePeelingFieldDetail(store,selectedField!!,{selectedField=null},{showEntry=true})
        }
        if(showEntry){CanePeelingBulkEntryDialog(store,selectedField!!,{showEntry=false},{date,field->showEntry=false;selectedField=null;quickAddDate=date;quickAddField=field;quickAddFandi=true;showLabours=true},quickAddDate)}
        return
    }
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌿 गन्ना छिलाई • फांदी हिसाब",onBack)
        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=12.dp,vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){
            listOf("मुख्य","Search / Filter","भुगतान").forEachIndexed{index,label->FilterChip(selected=tab==index,onClick={tab=index},label={Text(label)})}
        }
        when(tab){
            0->CanePeelingHome(store,{quickAddDate=today();quickAddField="";showEntry=true},{tab=1},{tab=2},{quickAddDate=today();quickAddField="";quickAddFandi=true;showLabours=true})
            1->CanePeelingSearch(store,{selectedLabour=it},{selectedField=it},{editEntry=it;showEntry=true},{protectedDelete=it})
            else->CanePeelingPayments(store,{protectedPaymentEdit=it},{protectedPaymentDelete=it},{selectedLabour=it.labourId})
        }
    }
    if(showEntry){if(editEntry!=null) CanePeelingEntryDialog(store,editEntry,""){showEntry=false;editEntry=null} else CanePeelingBulkEntryDialog(store,quickAddField,{showEntry=false},{date,field->showEntry=false;selectedField=null;quickAddDate=date;quickAddField=field;quickAddFandi=true;showLabours=true},quickAddDate)}
    protectedDelete?.let{DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ","यह गन्ना छिलाई रिकॉर्ड स्थायी रूप से हट जाएगा।",{store.deleteCanePeeling(it.id);protectedDelete=null},{protectedDelete=null})}
    if(showPayment){CanePeelingPaymentDialog(store,null,"",{showPayment=false})}
    protectedPaymentEdit?.let{DeviceCredentialGate("छिलाई भुगतान बदलें","भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।",{editPayment=it;protectedPaymentEdit=null},{protectedPaymentEdit=null})}
    protectedPaymentDelete?.let{DeviceCredentialDeleteGate("छिलाई भुगतान हटाएँ","यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।",{store.deleteCanePeelingPayment(it.id);protectedPaymentDelete=null},{protectedPaymentDelete=null})}
    editPayment?.let{CanePeelingPaymentDialog(store,it,"",{editPayment=null})}
}

@Composable
private fun CanePeelingHome(store:Store,onAdd:()->Unit,onSearch:()->Unit,onPayments:()->Unit,onLabours:()->Unit){
    val day=today()
    val todayRows=store.canePeelings.filter{it.date==day}
    val todayFandi=todayRows.sumOf{it.fandi}
    val todayAmount=todayRows.sumOf{it.total}
    val paidToday=store.canePeelingPayments.filter{it.date==day}.sumOf{it.amount}
    val todayWorkers=todayRows.map{it.labourId}.distinct().size
    val recentDates=store.canePeelings.map{it.date}.distinct().sortedDescending().take(10)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){
                Column(Modifier.padding(17.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("गन्ना छिलाई",color=Color.White,fontSize=25.sp,fontWeight=FontWeight.ExtraBold)
                            Text("दैनिक फांदी और मजदूरी का हिसाब",color=Color.White.copy(alpha=.82f),fontSize=12.sp)
                        }
                        Surface(shape=RoundedCornerShape(13.dp),color=Color.White.copy(alpha=.14f)){
                            Column(Modifier.padding(horizontal=10.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally){
                                Icon(Icons.Default.DateRange,null,tint=Color.White)
                                Text(displayDate(day),fontSize=10.sp,color=Color.White,fontWeight=FontWeight.Bold)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की फांदी",money(todayFandi),Color(0xFFE4F6EA))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज की राशि","₹${money(todayAmount)}",Color(0xFFE5F0FF))}
                        Box(Modifier.weight(1f)){CaneMiniStat("आज भुगतान","₹${money(paidToday)}",Color(0xFFFFF0D9))}
                    }
                    Text("आज $todayWorkers मजदूरों की एंट्री",color=Color.White.copy(alpha=.9f),fontSize=12.sp)
                }
            }
        }
        item{
            Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("आज की छिलाई दर्ज करें",fontWeight=FontWeight.Bold,fontSize=16.sp)
            }
        }
        item{
            Button(onClick=onLabours,modifier=Modifier.fillMaxWidth().heightIn(min=54.dp),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){
                Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("नया फांदी मजदूर जोड़ें + आज की फांदी",fontWeight=FontWeight.Bold,fontSize=14.sp)
            }
        }
        item{Text("नाम और आज की फांदी एक साथ सेव करें। खेत चुनना वैकल्पिक है।",fontSize=12.sp,color=Color.Gray,modifier=Modifier.padding(horizontal=3.dp))}
        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
                OutlinedButton(onClick=onSearch,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Search,null);Spacer(Modifier.width(5.dp));Text("खोजें / रिकॉर्ड")
                }
                OutlinedButton(onClick=onPayments,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(14.dp)){
                    Icon(Icons.Default.Payments,null);Spacer(Modifier.width(5.dp));Text("भुगतान")
                }
            }
        }
        item{
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("हाल की छिलाई",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,color=GreenDark)
                    Text("तारीख के अनुसार रिकॉर्ड और कुल राशि",fontSize=11.sp,color=Color.Gray)
                }
                Surface(shape=RoundedCornerShape(50),color=Color(0xFFE6F5EC)){
                    Text("${store.canePeelings.size} रिकॉर्ड",Modifier.padding(horizontal=10.dp,vertical=6.dp),fontSize=11.sp,color=GreenDark,fontWeight=FontWeight.Bold)
                }
            }
        }
        if(recentDates.isEmpty()) item{EmptyCard("अभी कोई गन्ना छिलाई रिकॉर्ड नहीं है। शुरू करने के लिए ‘आज की छिलाई दर्ज करें’ दबाएँ।")}
        recentDates.forEach{d->
            item(key="cane_day_$d"){
                val rows=store.canePeelings.filter{it.date==d}
                val fieldNames=rows.map{it.fieldId}.filter{it.isNotBlank()}.distinct().mapNotNull{id->store.fields.firstOrNull{it.id==id}?.name}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Surface(shape=RoundedCornerShape(12.dp),color=Color(0xFFE8F5ED)){
                                Icon(Icons.Default.DateRange,null,Modifier.padding(10.dp),tint=GreenDark)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)){
                                Text(displayDate(d),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                                Text(if(fieldNames.isEmpty())"खेत नहीं चुना गया" else fieldNames.joinToString(", "),fontSize=11.sp,color=Color.Gray,maxLines=2)
                            }
                            Text("₹${money(rows.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,fontSize=17.sp,color=Green)
                        }
                        Divider(color=Color(0xFFE8ECE9))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                            Text("${rows.map{it.labourId}.distinct().size} मजदूर",fontSize=12.sp,color=Color.DarkGray)
                            Text("${money(rows.sumOf{it.fandi})} फांदी",fontSize=13.sp,fontWeight=FontWeight.Bold,color=GreenDark)
                            Text("${rows.size} एंट्री",fontSize=11.sp,color=Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
@Composable private fun CaneMiniStat(label:String,value:String,bg:Color){Card(colors=CardDefaults.cardColors(containerColor=bg),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(8.dp)){Text(label,fontSize=9.sp,color=GreenDark);Text(value,fontWeight=FontWeight.ExtraBold,fontSize=15.sp,color=GreenDark)}}}
@Composable private fun EmptyCard(text:String){Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp)){Text(text,Modifier.padding(16.dp),color=Color.Gray)}}

@Composable
private fun CanePeelingBulkEntryDialog(store:Store,presetField:String,onClose:()->Unit,onAddFandiLabour:(String,String)->Unit,initialDate:String=today()){
    var date by remember{mutableStateOf(initialDate)}
    var field by remember{mutableStateOf(presetField)}
    var error by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    var selected by remember{mutableStateOf<Map<String,String>>(emptyMap())}
    SimpleDialog("आज की छिलाई दर्ज करें",onClose){
        Text("एक ही दिन और खेत में सभी मजदूरों की फांदी एक साथ दर्ज करें।",fontSize=11.sp,color=Color.Gray)
        OutlinedButton(onClick={onAddFandiLabour(date,field)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(13.dp)){
            Icon(Icons.Default.PersonAdd,null,tint=Color(0xFF5E4AA8));Spacer(Modifier.width(7.dp))
            Text("नया फांदी मजदूर जोड़ें + आज की फांदी",fontWeight=FontWeight.Bold,color=Color(0xFF5E4AA8))
        }
        Text("नया मजदूर जोड़ते समय उसका नाम और आज की फांदी एक ही बार में सेव कर सकते हैं।",fontSize=11.sp,color=Color.Gray)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        val r=store.fandiRate
        Text("फांदी रेट: ₹${money(r)}",fontWeight=FontWeight.Bold,color=GreenDark)
        Text("मजदूरों की फांदी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
        store.fandiLabours.forEach{l->
            val v=selected[l.id].orEmpty()
            Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){
                Text(l.name,Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                OutlinedTextField(value=v,onValueChange={nv->selected=selected.toMutableMap().apply{if(nv.isBlank())remove(l.id) else put(l.id,nv.filter{c->c.isDigit()||c=='.'})}},modifier=Modifier.width(115.dp),label={Text("फांदी")},singleLine=true)
                val f=v.toDoubleOrNull()?:0.0
                Text("₹${money(f*r)}",modifier=Modifier.width(78.dp),fontWeight=FontWeight.Bold,color=Green)
            }
        }
        val entries=selected.mapNotNull{(lid,v)->val f=v.toDoubleOrNull();if(f!=null&&f>0&&f.isFinite()) lid to f else null}
        val totalFandi=entries.sumOf{it.second}; val totalAmount=totalFandi*r
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("कुल मजदूर");Text("${entries.size}",fontWeight=FontWeight.ExtraBold)};Column{Text("कुल फांदी");Text(money(totalFandi),fontWeight=FontWeight.ExtraBold,color=Green)};Column{Text("कुल राशि");Text("₹${money(totalAmount)}",fontWeight=FontWeight.ExtraBold,color=Green)}}}
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(enabled=!saving,onClick={if(!saving){when{!validDate(date)->error="सही तारीख चुनें।";r<=0||!r.isFinite()->error="रेट सही डालें।";entries.isEmpty()->error="कम से कम एक मजदूर की फांदी डालें।";entries.any{(lid,_)->store.canePeelings.any{old->old.labourId==lid&&old.fieldId==field&&old.date==date}}->error="इनमें से किसी मजदूर की इस तारीख की फांदी पहले से दर्ज है। पुरानी एंट्री खोजकर बदलें; कोई नई एंट्री सेव नहीं हुई।";else->{saving=true;entries.forEach{(lid,f)->store.addCanePeeling(CanePeeling(UUID.randomUUID().toString(),lid,field,date,f,r,f*r))};onClose()}}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(saving)"सेव हो रहा है…" else "✓ पूरी दिन की छिलाई सेव करें")}
    }
}

@Composable
private fun CanePeelingEntryDialog(store:Store,existing:CanePeeling?,presetField:String,onClose:()->Unit){
    var date by remember{mutableStateOf(existing?.date?:today())}; var field by remember{mutableStateOf(existing?.fieldId?:presetField)}; var labour by remember{mutableStateOf(existing?.labourId?:store.fandiLabours.firstOrNull()?.id.orEmpty())}; var fandi by remember{mutableStateOf(if(existing!=null) money(existing.fandi) else "")}; var error by remember{mutableStateOf("")}
    val r=existing?.rate ?: store.fandiRate
    SimpleDialog(if(existing==null) "आज की छिलाई दर्ज करें" else "छिलाई रिकॉर्ड बदलें",onClose){
        Text("फांदी रेट Settings में एक बार सेट करें। नई एंट्री में वही रेट अपने-आप लगेगा। पुराने रिकॉर्ड का सेव किया हुआ रेट बदलता नहीं है।",fontSize=11.sp,color=Color.Gray)
        Text("दिनांक",fontWeight=FontWeight.SemiBold); AttendanceDateButton(date){date=it}
        ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
        ChoiceField("मजदूर *",store.fandiLabours.map{it.id to it.name},labour){labour=it}
        OutlinedTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},label={Text("फांदी")},singleLine=true)
        Text("फांदी रेट: ₹${money(r)} / फांदी",fontWeight=FontWeight.Bold,color=GreenDark)
        val f=fandi.toDoubleOrNull()?:0.0
        val total=f*r
        Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${money(total)}",fontWeight=FontWeight.ExtraBold,color=Green)}}
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(onClick={when{labour.isBlank()->error="मजदूर चुनें।";!validDate(date)->error="सही तारीख चुनें।";f<=0||!f.isFinite()->error="फांदी सही डालें।";r<=0||!r.isFinite()->error="Settings में फांदी रेट सेट करें।";else->{val duplicate=store.canePeelings.any{it.id!=existing?.id&&it.labourId==labour&&it.fieldId==field&&it.date==date};if(duplicate){error="इस मजदूर की इस तारीख और खेत की फांदी पहले से दर्ज है। पुराने रिकॉर्ड को खोलकर बदलें।"}else{val x=(existing ?: CanePeeling(UUID.randomUUID().toString(),labour,field,date,f,r,total)).copy(labourId=labour,fieldId=field,date=date,fandi=f,rate=r,total=total);if(existing==null)store.addCanePeeling(x) else store.updateCanePeeling(x);onClose()}}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("✓ फांदी सेव करें")}
    }
}

@Composable
private fun CanePeelingSearch(store:Store,onLabour:(String)->Unit,onField:(String)->Unit,onEdit:(CanePeeling)->Unit,onDelete:(CanePeeling)->Unit){
    var query by rememberSaveable{mutableStateOf("")}
    var from by rememberSaveable{mutableStateOf("")}
    var to by rememberSaveable{mutableStateOf("")}
    var labourId by rememberSaveable{mutableStateOf("")}
    var fieldId by rememberSaveable{mutableStateOf("")}
    var rate by rememberSaveable{mutableStateOf("")}
    var paymentStatus by rememberSaveable{mutableStateOf("")}
    var showExport by remember{mutableStateOf(false)}

    val base=store.canePeelings.filter{row->
        val l=store.fandiLabours.firstOrNull{it.id==row.labourId}
        val f=store.fields.firstOrNull{it.id==row.fieldId}
        val q=query.trim().lowercase(Locale.getDefault())
        val earned=store.canePeelings.filter{it.labourId==row.labourId}.sumOf{it.total}
        val paid=store.canePeelingPayments.filter{it.labourId==row.labourId}.sumOf{it.amount}
        val bal=earned-paid
        (q.isBlank()||listOf(l?.name.orEmpty(),l?.mobile.orEmpty(),f?.name.orEmpty(),row.date,row.fandi.toString(),row.rate.toString(),row.total.toString()).any{it.lowercase(Locale.getDefault()).contains(q)}) &&
        (from.isBlank()||row.date>=from)&&(to.isBlank()||row.date<=to) &&
        (labourId.isBlank()||row.labourId==labourId)&&(fieldId.isBlank()||row.fieldId==fieldId) &&
        (rate.isBlank()||row.rate==rate.toDoubleOrNull()) &&
        (paymentStatus.isBlank() || when(paymentStatus){"paid"->bal<=0.009;"partial"->paid>0.009&&bal>0.009;"pending"->paid<=0.009&&bal>0.009;else->true})
    }.sortedWith(compareByDescending<CanePeeling>{it.date}.thenBy{store.fandiLabours.firstOrNull{l->l.id==it.labourId}?.name.orEmpty()})

    val totalFandi=base.sumOf{it.fandi}
    val totalAmount=base.sumOf{it.total}
    val workers=base.map{it.labourId}.distinct().size
    val fields=base.map{it.fieldId}.filter{it.isNotBlank()}.distinct().size
    val days=base.map{it.date}.distinct().size
    val context=LocalContext.current

    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item{
            OutlinedTextField(
                value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                label={Text("नाम, मोबाइल, खेत, तारीख या राशि खोजें")},
                leadingIcon={Icon(Icons.Default.Search,null)},
                trailingIcon={if(query.isNotBlank()){IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}}}
            )
        }
        item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("फिल्टर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark,modifier=Modifier.weight(1f));TextButton(onClick={query="";from="";to="";labourId="";fieldId="";rate="";paymentStatus=""}){Icon(Icons.Default.Refresh,null);Spacer(Modifier.width(4.dp));Text("रीसेट")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){DateFilterField("से",from){from=it}};Box(Modifier.weight(1f)){DateFilterField("तक",to){to=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("मजदूर",listOf("" to "सभी मजदूर")+store.fandiLabours.map{it.id to it.name},labourId){labourId=it}};Box(Modifier.weight(1f)){ChoiceField("खेत",listOf("" to "सभी खेत")+store.fields.map{it.id to it.name},fieldId){fieldId=it}}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){Box(Modifier.weight(1f)){ChoiceField("रेट",listOf("" to "सभी रेट")+store.canePeelings.map{it.rate}.distinct().sorted().map{it.toString() to "₹${money(it)} / फांदी"},rate){rate=it}};Box(Modifier.weight(1f)){ChoiceField("भुगतान",listOf("" to "सभी","paid" to "पूरा भुगतान","partial" to "आंशिक भुगतान","pending" to "पूरा बाकी"),paymentStatus){paymentStatus=it}}}}

        item{
            Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(16.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${base.size} रिकॉर्ड");Text("$workers मजदूर");Text("$fields खेत");Text("$days दिन")}
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("कुल फांदी",fontWeight=FontWeight.Bold);Text(money(totalFandi),fontWeight=FontWeight.ExtraBold,color=Green);Text("कुल राशि",fontWeight=FontWeight.Bold);Text("₹${money(totalAmount)}",fontWeight=FontWeight.ExtraBold,color=Green)}
                }
            }
        }

        item{
            Card(Modifier.fillMaxWidth(),RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Groups,null,tint=Green,modifier=Modifier.size(26.dp));Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text("सभी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark);Text("नाम पर टैप करें → पूरा हिसाब",fontSize=11.sp,color=Color.Gray)}}
                    if(store.fandiLabours.isEmpty()) Text("अभी कोई फांदी मजदूर नहीं है।",color=Color.Gray)
                    else store.fandiLabours.sortedBy{it.name.lowercase(Locale.getDefault())}.forEach{l->
                        val rr=store.canePeelings.filter{it.labourId==l.id}
                        val earned=rr.sumOf{it.total}
                        val paid=store.canePeelingPayments.filter{it.labourId==l.id}.sumOf{it.amount}
                        Card(Modifier.fillMaxWidth().clickable{onLabour(l.id)},shape=RoundedCornerShape(13.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF4FAF7))){
                            Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                                PhotoThumb(l.photo);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी • ₹${money(earned)}",fontSize=11.sp,color=Green);if(paid>0)Text("भुगतान ₹${money(paid)} • बाकी ₹${money(earned-paid)}",fontSize=10.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null,tint=Green)}
                        }
                    }
                }
            }
        }

        item{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                Button(onClick={showExport=true},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4FB3))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF / Excel")}
            }
        }

        if(base.isEmpty()) item{EmptyCard("इस Filter से कोई रिकॉर्ड नहीं मिला।")}
        base.forEach{row->
            item(key=row.id){
                val l=store.fandiLabours.firstOrNull{it.id==row.labourId}; val f=store.fields.firstOrNull{it.id==row.fieldId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp)){
                    Column(Modifier.padding(11.dp)){
                        Row(verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f).clickable{onLabour(row.labourId)}){Text(l?.name?:"मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=16.sp);Text(displayDate(row.date),fontSize=11.sp,color=Color.Gray);Text("🌾 ${f?.name?:"खेत नहीं चुना"}",fontSize=11.sp,color=Green,modifier=Modifier.clickable{if(f!=null)onField(f.id)})}
                            Text("₹${money(row.total)}",fontWeight=FontWeight.ExtraBold,color=Green)
                            IconButton(onClick={onEdit(row)}){Icon(Icons.Default.Edit,null,tint=Green)}
                            IconButton(onClick={onDelete(row)}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${money(row.fandi)} फांदी");Text("₹${money(row.rate)} / फांदी",color=Color.Gray);Text("₹${money(row.total)}",fontWeight=FontWeight.Bold)}
                    }
                }
            }
        }
    }
    if(showExport) CanePeelingExportDialog(store,base){showExport=false}
}

@Composable
private fun CanePeelingExportDialog(store:Store,rows:List<CanePeeling>,onClose:()->Unit){
    val allIds=remember(rows){rows.map{it.labourId}.distinct()}
    var selected by remember(rows){mutableStateOf(allIds.toSet())}
    val context=LocalContext.current
    AlertDialog(
        onDismissRequest=onClose,
        title={Text("रिपोर्ट बनाएं",fontWeight=FontWeight.ExtraBold)},
        text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp)){
            Text("सभी मजदूर या अपनी पसंद के मजदूर चुनें।",fontSize=12.sp,color=Color.Gray)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                OutlinedButton(onClick={selected=allIds.toSet()},modifier=Modifier.weight(1f)){Text("✓ Mark All")}
                OutlinedButton(onClick={selected=emptySet()},modifier=Modifier.weight(1f)){Text("सब हटाएं")}
            }
            if(allIds.isEmpty()) Text("कोई रिकॉर्ड उपलब्ध नहीं है।",color=Color.Gray)
            else LazyColumn(Modifier.weight(1f,false),verticalArrangement=Arrangement.spacedBy(2.dp)){
                items(allIds){id->
                    val l=store.fandiLabours.firstOrNull{it.id==id}
                    Row(Modifier.fillMaxWidth().clickable{selected=if(selected.contains(id))selected-id else selected+id},verticalAlignment=Alignment.CenterVertically){Checkbox(checked=selected.contains(id),onCheckedChange={checked->selected=if(checked)selected+id else selected-id});Text(l?.name?:"मजदूर",fontWeight=FontWeight.SemiBold)}
                }
            }
            Text("${selected.size} मजदूर चुने गए",fontWeight=FontWeight.Bold,color=Green)
        }},
        confirmButton={Button(onClick={
            if(selected.isEmpty()) return@Button
            val chosen=rows.filter{selected.contains(it.labourId)}
            val lines=chosen.map{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId};val f=store.fields.firstOrNull{it.id==r.fieldId};"${displayDate(r.date)} • ${l?.name?:"मजदूर"} • ${f?.name?:"खेत नहीं चुना"} • ${money(r.fandi)} फांदी × ₹${money(r.rate)} = ₹${money(r.total)}"}
            exportReportPdf(context,"गन्ना_छिलाई_रिपोर्ट","${selected.size} मजदूर • ${chosen.map{it.fieldId}.distinct().size} खेत • ${chosen.map{it.date}.distinct().size} दिन • ${money(chosen.sumOf{it.fandi})} फांदी • ₹${money(chosen.sumOf{it.total})}",lines);onClose()
        },enabled=selected.isNotEmpty()){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(4.dp));Text("PDF बनाएं")}},
        dismissButton={OutlinedButton(onClick={
            if(selected.isEmpty()) return@OutlinedButton
            exportCanePeelingCsv(context,rows.filter{selected.contains(it.labourId)},store);onClose()
        }){Text("CSV / Excel")}}
    )
}

private fun exportCanePeelingCsv(context:Context,rows:List<CanePeeling>,store:Store){
    try{val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"Ganna_Chhilai_${System.currentTimeMillis()}.csv");file.writeText(buildString{append("तारीख,मजदूर,खेत,फांदी,रेट,राशि\n");rows.forEach{r->val l=store.fandiLabours.firstOrNull{it.id==r.labourId};val f=store.fields.firstOrNull{it.id==r.fieldId};append("${r.date},\"${l?.name.orEmpty()}\",\"${f?.name?:"खेत नहीं चुना"}\",${r.fandi},${r.rate},${r.total}\n")}},Charsets.UTF_8);shareFile(context,file,"text/csv","CSV साझा करें")}catch(e:Exception){android.widget.Toast.makeText(context,"CSV report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}}

@Composable
private fun DateFilterField(label:String,value:String,onSelected:(String)->Unit){
    val context=LocalContext.current
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
        OutlinedButton(onClick={
            val parsed=try{SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value.ifBlank{today()})}catch(_:Exception){Date()}
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(context,{_,year,month,day->
                val selected=Calendar.getInstance().apply{set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)}
                onSelected(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time))
            },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).apply{datePicker.maxDate=System.currentTimeMillis()}.show()
        },modifier=Modifier.weight(1f)){Text(if(value.isBlank()) "$label: कोई सीमा" else "$label: ${displayDate(value)}",maxLines=1);Spacer(Modifier.width(4.dp));Icon(Icons.Default.DateRange,null)}
        if(value.isNotBlank()) IconButton(onClick={onSelected("")}){Icon(Icons.Default.Clear,null)}
    }
}

@Composable
private fun CanePeelingLabourScreen(store:Store,onBack:()->Unit,initialDate:String=today(),initialField:String="",autoOpenAdd:Boolean=false){
    var add by remember{mutableStateOf(autoOpenAdd)}
    var edit by remember{mutableStateOf<FandiLabour?>(null)}
    var delete by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedEdit by remember{mutableStateOf<FandiLabour?>(null)}
    var protectedDelete by remember{mutableStateOf<FandiLabour?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    var rateText by remember(store.fandiRate){mutableStateOf(money(store.fandiRate))}
    val visibleWorkers=store.fandiLabours.filter{query.isBlank()||it.name.contains(query,true)||it.mobile.contains(query,true)||it.address.contains(query,true)}.sortedBy{it.name.lowercase(Locale.ROOT)}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("👷 फांदी मजदूर",onBack)
        Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
            Row(Modifier.fillMaxWidth().padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                Column(Modifier.weight(1f)){
                    Text("फांदी मजदूर",fontWeight=FontWeight.ExtraBold,fontSize=22.sp,color=Color.White)
                    Text("${store.fandiLabours.size} सेव मजदूर • नाम दोबारा सेव नहीं होगा",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                }
                Button(onClick={add=true},shape=RoundedCornerShape(13.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6550AC))){Icon(Icons.Default.Add,null);Spacer(Modifier.width(4.dp));Text("नया मजदूर")}
            }
        }
        Card(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=3.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
            Column(Modifier.padding(13.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Text("⚙️ फांदी रेट",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark);Spacer(Modifier.weight(1f));Text("₹${money(store.fandiRate)} / फांदी",fontWeight=FontWeight.Bold,color=Green)}
                Text("यह रेट नई एंट्री में अपने-आप लगेगा।",fontSize=11.sp,color=Color.Gray)
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedTextField(value=rateText,onValueChange={rateText=it.filter{c->c.isDigit()||c=='.'}},modifier=Modifier.weight(1f),singleLine=true,label={Text("₹ प्रति फांदी")},shape=RoundedCornerShape(12.dp))
                    Button(onClick={rateText.toDoubleOrNull()?.takeIf{it>0&&it.isFinite()}?.let{store.updateFandiRate(it)}},shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("रेट सेव करें")}
                }
            }
        }
        OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=7.dp),singleLine=true,label={Text("मजदूर का नाम / मोबाइल खोजें")},leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Clear,null)}},shape=RoundedCornerShape(15.dp))
        if(visibleWorkers.isEmpty()){
            Box(Modifier.weight(1f).fillMaxWidth().padding(14.dp),contentAlignment=Alignment.TopCenter){EmptyCard(if(query.isBlank())"अभी कोई फांदी मजदूर नहीं है। ‘नया मजदूर’ दबाकर जोड़ें।" else "इस नाम से कोई मजदूर नहीं मिला।")}
        }else LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(bottom=14.dp)){
            items(visibleWorkers,key={it.id}){l->
                val workRows=store.canePeelings.filter{it.labourId==l.id}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo);Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(2.dp)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                            Text(l.mobile.ifBlank{"मोबाइल नहीं दिया"},fontSize=11.sp,color=Color.Gray)
                            Text("${workRows.size} रिकॉर्ड • ${money(workRows.sumOf{it.fandi})} फांदी • ₹${money(workRows.sumOf{it.total})}",fontSize=11.sp,color=Green,fontWeight=FontWeight.SemiBold)
                        }
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FandiLabourDialog(store,null,initialDate,initialField){add=false;if(autoOpenAdd)onBack()}
    protectedEdit?.let{worker->DeviceCredentialGate("फांदी मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=worker;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{worker->DeviceCredentialDeleteGate("फांदी मजदूर हटाएँ","इस मजदूर से जुड़े छिलाई और भुगतान रिकॉर्ड भी हटेंगे।",{delete=worker;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FandiLabourDialog(store,edit){edit=null}
    delete?.let{worker->ConfirmDialog("फांदी मजदूर हटाएँ?","इस मजदूर के सभी फांदी छिलाई और भुगतान रिकॉर्ड हटेंगे।",{store.deleteFandiLabour(worker.id);delete=null},{delete=null})}
}
@Composable
private fun FandiLabourDialog(store:Store,existing:FandiLabour?,initialDate:String=today(),initialField:String="",onClose:()->Unit){
    var name by remember{mutableStateOf(existing?.name.orEmpty())}
    var address by remember{mutableStateOf(existing?.address.orEmpty())}
    var mobile by remember{mutableStateOf(existing?.mobile.orEmpty())}
    var photo by remember{mutableStateOf(existing?.photo.orEmpty())}
    var showExtra by remember{mutableStateOf(existing!=null)}
    var saveTodayFandi by remember{mutableStateOf(existing==null)}
    var date by remember{mutableStateOf(initialDate)}
    var field by remember{mutableStateOf(initialField)}
    var fandi by remember{mutableStateOf("")}
    var error by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null){val persisted=store.persistPhoto(uri.toString(),ownerId);if(persisted.isNotBlank())photo=persisted}}
    SimpleDialog(if(existing==null)"फांदी मजदूर जोड़ें" else "फांदी मजदूर बदलें",onClose){
        Text("नाम सेव करते समय ही आज की फांदी भी दर्ज कर सकते हैं।",fontSize=12.sp,color=Color.Gray)
        OutlinedTextField(value=name,onValueChange={name=it},label={Text("मजदूर का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        TextButton(onClick={showExtra=!showExtra}){Text(if(showExtra)"− अतिरिक्त जानकारी छिपाएँ" else "+ पता / मोबाइल / फोटो (वैकल्पिक)")}
        if(showExtra){
            OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=mobile,onValueChange={mobile=it.filter{c->c.isDigit()||c=='+'}},label={Text("मोबाइल (Optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")}
        }
        if(existing==null){
            Row(Modifier.fillMaxWidth().clickable{saveTodayFandi=!saveTodayFandi}.padding(vertical=4.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=saveTodayFandi,onCheckedChange={saveTodayFandi=it});Spacer(Modifier.width(5.dp));Column{Text("आज की फांदी भी साथ में सेव करें",fontWeight=FontWeight.Bold);Text("मजदूर का नाम और फांदी एक ही बार में सेव होंगे।",fontSize=11.sp,color=Color.Gray)}}
            if(saveTodayFandi){
                Text("दिनांक",fontWeight=FontWeight.SemiBold)
                AttendanceDateButton(date){date=it}
                ChoiceField("खेत (वैकल्पिक)",listOf("" to "खेत नहीं चुनें")+store.fields.map{it.id to it.name},field){field=it}
                OutlinedTextField(value=fandi,onValueChange={fandi=it.filter{c->c.isDigit()||c=='.'}},label={Text("आज की फांदी *")},singleLine=true,modifier=Modifier.fillMaxWidth())
                val amount=(fandi.toDoubleOrNull()?:0.0)*store.fandiRate
                Text("रेट ₹${money(store.fandiRate)} / फांदी • कुल ₹${money(amount)}",fontWeight=FontWeight.Bold,color=GreenDark)
            }
        }
        if(error.isNotBlank())Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE8E6)),shape=RoundedCornerShape(12.dp)){Text(error,Modifier.padding(10.dp),color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)}
        Button(enabled=!saving,onClick={
            if(!saving){
                val f=fandi.toDoubleOrNull()?:0.0
                val normalizedName=name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)
                val sameNameAlreadySaved=store.fandiLabours.any{old->
                    old.id!=existing?.id && old.name.trim().replace(Regex("\\s+")," ").lowercase(Locale.ROOT)==normalizedName
                }
                when{
                    name.isBlank()->error="मजदूर का नाम लिखें।"
                    sameNameAlreadySaved->error="यह नाम पहले से सेव है। उसी मजदूर को सूची से चुनें; नाम दोबारा सेव नहीं होगा।"
                    existing==null && saveTodayFandi && field.isNotBlank() && store.fields.none{it.id==field}->error="चुना हुआ खेत उपलब्ध नहीं है। खेत हटाएँ या दूसरा चुनें।"
                    existing==null && saveTodayFandi && !validDate(date)->error="सही तारीख चुनें।"
                    existing==null && saveTodayFandi && (f<=0||!f.isFinite())->error="आज की फांदी सही डालें।"
                    existing==null && saveTodayFandi && (store.fandiRate<=0||!store.fandiRate.isFinite())->error="पहले सही फांदी रेट सेट करें।"
                    else->{
                        val phoneKey=mobile.filter{it.isDigit()}
                        val duplicatePhone=existing==null && phoneKey.length>=7 && store.fandiLabours.any{old->old.mobile.filter{it.isDigit()}.let{it.length>=7&&it==phoneKey}}
                        if(duplicatePhone){error="यह मोबाइल नंबर पहले से सेव है। मौजूदा मजदूर की जानकारी देखें।"}
                        else{
                            saving=true
                            val resolvedId=existing?.id?:ownerId
                            val x=FandiLabour(resolvedId,name.trim(),address.trim(),existing?.rate?:0.0,mobile.trim(),photo)
                            if(existing!=null){
                                store.updateFandiLabour(x)
                                onClose()
                            }else if(saveTodayFandi){
                                // Save the fandi first and inspect the result. If a duplicate is detected,
                                // do not create the labour record or close the form as if it succeeded.
                                val r=store.fandiRate
                                val fandiSaved=store.addCanePeeling(CanePeeling(UUID.randomUUID().toString(),resolvedId,field,date,f,r,f*r))
                                if(!fandiSaved){
                                    error="इस मजदूर की इस तारीख और खेत की फांदी पहले से दर्ज है। कोई नया रिकॉर्ड सेव नहीं हुआ। पुरानी एंट्री खोलकर जाँचें।"
                                    saving=false
                                }else{
                                    store.addFandiLabour(x)
                                    onClose()
                                }
                            }else{
                                store.addFandiLabour(x)
                                onClose()
                            }
                        }
                    }
                }
            }
        },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(saving)"सेव हो रहा है…" else if(existing==null && saveTodayFandi)"✓ मजदूर + आज की फांदी सेव करें" else "✓ फांदी मजदूर सेव करें")}
    }
}

@Composable
private fun CanePeelingLabourDetail(
    store: Store,
    labourId: String,
    onBack: () -> Unit,
    onPay: () -> Unit
) {
    val labour = store.fandiLabours.firstOrNull { it.id == labourId }
    if (labour == null) { onBack(); return }

    val rows = store.canePeelings.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val paid = store.canePeelingPayments.filter { it.labourId == labourId }.sortedByDescending { it.date }
    val earned = rows.sumOf { it.total }
    val paidTotal = paid.sumOf { it.amount }
    val balance = earned - paidTotal
    val fields = rows.map { it.fieldId }.distinct()
    val days = rows.map { it.date }.distinct().size

    var selectedFieldId by remember { mutableStateOf<String?>(null) }
    var selectedRow by remember { mutableStateOf<CanePeeling?>(null) }
    var selectedPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedEdit by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedDelete by remember { mutableStateOf<CanePeeling?>(null) }
    var protectedPaymentEdit by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var protectedPaymentDelete by remember { mutableStateOf<CanePeelingPayment?>(null) }
    var editRow by remember { mutableStateOf<CanePeeling?>(null) }
    var editPayment by remember { mutableStateOf<CanePeelingPayment?>(null) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        DetailTopBar("👷 ${labour.name} • पूरा हिसाब", onBack)
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF8F1))) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoThumb(labour.photo); Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text(labour.name, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = GreenDark)
                            if (labour.mobile.isNotBlank()) Text(labour.mobile, fontSize = 11.sp, color = Color.Gray)
                            Text("गन्ना छिलाई / फांदी मजदूर", fontSize = 11.sp, color = Green)
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth(), RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Box(Modifier.weight(1f)) { Stat("कुल दिन", days.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल खेत", fields.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("कुल रिकॉर्ड", rows.size.toDouble()) }
                            Box(Modifier.weight(1f)) { Stat("फांदी", rows.sumOf { it.fandi }) }
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            SummaryMoneyCard("कुल छिलाई राशि", "₹${money(earned)}", Green, Modifier.weight(1f))
                            SummaryMoneyCard("कुल भुगतान", "₹${money(paidTotal)}", Color(0xFF276B8A), Modifier.weight(1f))
                            SummaryMoneyCard("बाकी", "₹${money(balance)}", if (balance > 0) Color(0xFFB3261E) else Green, Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                Button(onClick = onPay, Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Icon(Icons.Default.Payments, null); Spacer(Modifier.width(7.dp)); Text("इस मजदूर को भुगतान दर्ज करें", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            item { SectionTitle("🌾 खेतवार हिसाब", "हर खेत में कितने दिन, फांदी और राशि • कार्ड पर टैप करें") }
            if (fields.isEmpty()) item { EmptyCard("इस मजदूर का अभी कोई छिलाई रिकॉर्ड नहीं है।") }
            fields.forEach { fieldId ->
                item(key = "field_$fieldId") {
                    val fieldRows = rows.filter { it.fieldId == fieldId }
                    val fieldName = store.fields.firstOrNull { it.id == fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedFieldId = fieldId },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🌾", fontSize = 27.sp); Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(fieldName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = GreenDark)
                                Text("${fieldRows.map { it.date }.distinct().size} दिन • ${money(fieldRows.sumOf { it.fandi })} फांदी", fontSize = 12.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("₹${money(fieldRows.sumOf { it.total })}", fontWeight = FontWeight.ExtraBold, color = Green)
                                Text("विवरण देखें ›", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
            item { SectionTitle("📅 तारीखवार पूरा हिसाब", "हर काम का पूरा रिकॉर्ड • रिकॉर्ड पर टैप करें") }
            rows.forEach { row ->
                item(key = "day_${row.id}") {
                    val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedRow = row },
                        RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.width(104.dp)) {
                                Text(displayDate(row.date), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = GreenDark)
                                Text(try { SimpleDateFormat("EEEE", Locale("hi", "IN")).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(row.date) ?: Date()) } catch (_: Exception) { "" }, fontSize = 10.sp, color = Color.Gray)
                            }
                            Column(Modifier.weight(1f)) {
                                Text("🌾 $fieldName", fontWeight = FontWeight.SemiBold)
                                Text("${money(row.fandi)} फांदी × ₹${money(row.rate)}", fontSize = 12.sp, color = Color.Gray)
                                Text("₹${money(row.total)}", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                            }
                            Text("›", fontSize = 26.sp, color = Green)
                        }
                    }
                }
            }
            item { SectionTitle("💳 भुगतान इतिहास", "किस दिन कितने रुपये दिए गए • भुगतान पर टैप करें") }
            if (paid.isEmpty()) item { EmptyCard("अभी कोई भुगतान दर्ज नहीं है।") }
            paid.forEach { payment ->
                item(key = "payment_${payment.id}") {
                    Card(
                        Modifier.fillMaxWidth().clickable { selectedPayment = payment },
                        RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(displayDate(payment.date), fontWeight = FontWeight.Bold)
                                Text(payment.method.ifBlank { "नकद" }, fontSize = 11.sp, color = Color.Gray)
                                if (payment.note.isNotBlank()) Text(payment.note, fontSize = 11.sp, color = Color.Gray)
                            }
                            Text("₹${money(payment.amount)}  ›", fontWeight = FontWeight.ExtraBold, color = Green, fontSize = 17.sp)
                        }
                    }
                }
            }
        }
    }

    selectedFieldId?.let { fid ->
        val field = store.fields.firstOrNull { it.id == fid }
        val fr = rows.filter { it.fieldId == fid }
        SimpleDialog("🌾 ${field?.name ?: "खेत"} • पूरा हिसाब", { selectedFieldId = null }) {
            Text("कुल दिन: ${fr.map { it.date }.distinct().size}")
            Text("कुल फांदी: ${money(fr.sumOf { it.fandi })}")
            Text("कुल राशि: ₹${money(fr.sumOf { it.total })}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(6.dp))
            fr.forEach { r ->
                Text("${displayDate(r.date)} • ${money(r.fandi)} फांदी × ₹${money(r.rate)} = ₹${money(r.total)}", fontSize = 12.sp)
            }
        }
    }

    selectedRow?.let { row ->
        SimpleDialog("📅 छिलाई रिकॉर्ड", { selectedRow = null }) {
            val fieldName = store.fields.firstOrNull { it.id == row.fieldId }?.name ?: "खेत"
            Text("दिनांक: ${displayDate(row.date)}")
            Text("खेत: $fieldName")
            Text("फांदी: ${money(row.fandi)}")
            Text("दर: ₹${money(row.rate)}")
            Text("कुल राशि: ₹${money(row.total)}", fontWeight = FontWeight.Bold, color = Green)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedEdit = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedDelete = row; selectedRow = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    selectedPayment?.let { payment ->
        SimpleDialog("💳 भुगतान विवरण", { selectedPayment = null }) {
            Text("दिनांक: ${displayDate(payment.date)}")
            Text("राशि: ₹${money(payment.amount)}", fontWeight = FontWeight.Bold, color = Green)
            Text("तरीका: ${payment.method.ifBlank { "नकद" }}")
            if (payment.note.isNotBlank()) Text("टिप्पणी: ${payment.note}")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { protectedPaymentEdit = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(4.dp)); Text("Edit") }
                OutlinedButton(onClick = { protectedPaymentDelete = payment; selectedPayment = null }, Modifier.weight(1f)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }

    protectedEdit?.let { row ->
        DeviceCredentialGate("छिलाई रिकॉर्ड बदलें", "इस रिकॉर्ड की तारीख, खेत या फांदी बदलने के लिए Android screen lock से पुष्टि करें।", { editRow = row; protectedEdit = null }, { protectedEdit = null })
    }
    protectedDelete?.let { row ->
        DeviceCredentialDeleteGate("छिलाई रिकॉर्ड हटाएँ", "यह छिलाई रिकॉर्ड स्थायी रूप से हट जाएगा।", { store.deleteCanePeeling(row.id); protectedDelete = null }, { protectedDelete = null })
    }
    protectedPaymentEdit?.let { payment ->
        DeviceCredentialGate("भुगतान बदलें", "भुगतान की तारीख/राशि बदलने के लिए Android screen lock से पुष्टि करें।", { editPayment = payment; protectedPaymentEdit = null }, { protectedPaymentEdit = null })
    }
    protectedPaymentDelete?.let { payment ->
        DeviceCredentialDeleteGate("भुगतान हटाएँ", "यह भुगतान रिकॉर्ड स्थायी रूप से हट जाएगा।", { store.deleteCanePeelingPayment(payment.id); protectedPaymentDelete = null }, { protectedPaymentDelete = null })
    }
    editRow?.let { row -> CanePeelingEntryDialog(store, row, row.fieldId) { editRow = null } }
    editPayment?.let { payment -> CanePeelingPaymentDialog(store, payment, labourId) { editPayment = null } }
}

@Composable
private fun CanePeelingFieldDetail(store:Store,fieldId:String,onBack:()->Unit,onAdd:()->Unit){
    val f=store.fields.firstOrNull{it.id==fieldId}?:run{onBack();return}
    val rows=store.canePeelings.filter{it.fieldId==fieldId}.sortedByDescending{it.date}
    val workers=rows.map{it.labourId}.distinct()
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("🌾 ${f.name} • छिलाई हिसाब",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(11.dp)){
            item{
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                    Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                        Text(f.name,fontSize=23.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
                        Text("इस खेत का पूरा फांदी और मजदूरी हिसाब",fontSize=12.sp,color=Color.White.copy(alpha=.82f))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){CaneMiniStat("मजदूर",workers.size.toString(),Color(0xFFE5F6EA))}
                            Box(Modifier.weight(1f)){CaneMiniStat("फांदी",money(rows.sumOf{it.fandi}),Color(0xFFE5F0FF))}
                            Box(Modifier.weight(1f)){CaneMiniStat("कुल राशि","₹${money(rows.sumOf{it.total})}",Color(0xFFFFF0D9))}
                        }
                    }
                }
            }
            item{Button(onClick=onAdd,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("इस खेत में छिलाई दर्ज करें",fontWeight=FontWeight.Bold)}}
            item{Text("मजदूरवार हिसाब",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark)}
            if(workers.isEmpty())item{EmptyCard("इस खेत में अभी कोई छिलाई दर्ज नहीं है।")}
            workers.forEach{lid->item(key="field_worker_$lid"){
                val rr=rows.filter{it.labourId==lid};val l=store.fandiLabours.firstOrNull{it.id==lid}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){PhotoThumb(l?.photo.orEmpty());Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold,color=GreenDark);Text("${rr.map{it.date}.distinct().size} दिन • ${money(rr.sumOf{it.fandi})} फांदी",fontSize=12.sp,color=Color.Gray)};Text("₹${money(rr.sumOf{it.total})}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
            item{Text("तारीखवार रिकॉर्ड",fontWeight=FontWeight.ExtraBold,fontSize=19.sp,color=GreenDark)}
            rows.forEach{r->item(key="field_entry_${r.id}"){
                val l=store.fandiLabours.firstOrNull{it.id==r.labourId}
                Card(Modifier.fillMaxWidth(),RoundedCornerShape(15.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(r.date),fontWeight=FontWeight.Bold,color=GreenDark);Text(l?.name?:"मजदूर",fontSize=12.sp);Text("${money(r.fandi)} फांदी × ₹${money(r.rate)}",fontSize=11.sp,color=Color.Gray)};Text("₹${money(r.total)}",fontWeight=FontWeight.ExtraBold,color=Green,fontSize=16.sp)}
                }
            }}
        }
    }
}
@Composable
private fun CanePeelingPayments(
    store: Store,
    onEdit: (CanePeelingPayment) -> Unit,
    onDelete: (CanePeelingPayment) -> Unit,
    onOpenLabour: (CanePeelingPayment) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }

    val rows = store.canePeelingPayments
        .filter { payment ->
            val labour = store.fandiLabours.firstOrNull { worker ->
                worker.id == payment.labourId
            }
            query.isBlank() ||
                labour?.name?.contains(query, true) == true ||
                payment.date.contains(query)
        }
        .sortedByDescending { payment -> payment.date }

    val total = rows.sumOf { payment -> payment.amount }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { value -> query = value },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("भुगतान में नाम / तारीख खोजें") },
                leadingIcon = { Icon(Icons.Default.Search, null) }
            )
        }

        item {
            val earned = store.canePeelings.sumOf { it.total }
            val allPaid = store.canePeelingPayments.sumOf { it.amount }
            val balance = earned - allPaid
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = GreenDark), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("छिलाई भुगतान", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("${rows.size} भुगतान रिकॉर्ड • इस सूची में ₹${money(total)}", color = Color.White.copy(alpha = .82f), fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल मजदूरी", "₹${money(earned)}", Color(0xFFE5F6EA)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("कुल भुगतान", "₹${money(allPaid)}", Color(0xFFE5F0FF)) }
                        Box(Modifier.weight(1f)) { CaneMiniStat("बाकी", "₹${money(balance)}", Color(0xFFFFF0D9)) }
                    }
                }
            }
        }

        rows.forEach { payment ->
            item(key = payment.id) {
                val labour = store.fandiLabours.firstOrNull { worker ->
                    worker.id == payment.labourId
                }

                Card(
                    Modifier.fillMaxWidth(),
                    RoundedCornerShape(15.dp)
                ) {
                    Row(
                        Modifier.padding(11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable { onOpenLabour(payment) }
                        ) {
                            Text(
                                labour?.name ?: "मजदूर",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                displayDate(payment.date),
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            Text(
                                payment.method.ifBlank { "नकद" },
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                            if (payment.note.isNotBlank()) {
                                Text(
                                    payment.note,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Text(
                            "₹${money(payment.amount)}",
                            fontWeight = FontWeight.ExtraBold,
                            color = Green
                        )

                        IconButton(onClick = { onEdit(payment) }) {
                            Icon(Icons.Default.Edit, null, tint = Green)
                        }

                        IconButton(onClick = { onDelete(payment) }) {
                            Icon(
                                Icons.Default.Delete,
                                null,
                                tint = Color(0xFFB3261E)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CanePeelingPaymentDialog(
    store: Store,
    existing: CanePeelingPayment?,
    presetLabour: String,
    onClose: () -> Unit
) {
    var labour by remember {
        mutableStateOf(
            existing?.labourId
                ?: presetLabour.ifBlank {
                    store.fandiLabours.firstOrNull()?.id.orEmpty()
                }
        )
    }

    var date by remember {
        mutableStateOf(existing?.date ?: today())
    }

    var amount by remember {
        mutableStateOf(
            if (existing != null) money(existing.amount) else ""
        )
    }

    var method by remember {
        mutableStateOf(existing?.method ?: "नकद")
    }

    var note by remember {
        mutableStateOf(existing?.note ?: "")
    }

    SimpleDialog(
        if (existing == null) "छिलाई भुगतान दर्ज करें" else "छिलाई भुगतान बदलें",
        onClose
    ) {
        if (presetLabour.isNotBlank()) {
            val selectedLabour = store.fandiLabours.firstOrNull { worker ->
                worker.id == labour
            }

            Text(
                "मजदूर: ${selectedLabour?.name ?: "मजदूर"}",
                fontWeight = FontWeight.Bold,
                color = Green
            )
        } else {
            ChoiceField(
                "मजदूर *",
                store.fandiLabours.map { worker ->
                    worker.id to worker.name
                },
                labour
            ) { selectedId ->
                labour = selectedId
            }
        }

        Text(
            "भुगतान तारीख",
            fontWeight = FontWeight.SemiBold
        )

        AttendanceDateButton(date) { selectedDate ->
            date = selectedDate
        }

        OutlinedTextField(
            value = amount,
            onValueChange = { value ->
                amount = value.filter { character ->
                    character.isDigit() || character == '.'
                }
            },
            label = { Text("कितने रुपये दिए? *") },
            singleLine = true
        )

        ChoiceField(
            "भुगतान तरीका",
            listOf(
                "नकद" to "नकद",
                "बैंक" to "बैंक",
                "UPI" to "UPI",
                "अन्य" to "अन्य"
            ),
            method
        ) { selectedMethod ->
            method = selectedMethod
        }

        OutlinedTextField(
            value = note,
            onValueChange = { value ->
                note = value
            },
            label = { Text("टिप्पणी (Optional)") },
            singleLine = true
        )

        Button(
            onClick = {
                val parsedAmount = amount.toDoubleOrNull()

                if (
                    labour.isBlank() ||
                    parsedAmount == null ||
                    parsedAmount <= 0 ||
                    !parsedAmount.isFinite() ||
                    !validDate(date)
                ) {
                    return@Button
                }

                val payment = (
                    existing
                        ?: CanePeelingPayment(
                            UUID.randomUUID().toString(),
                            labour,
                            date,
                            parsedAmount,
                            method,
                            note.trim()
                        )
                    ).copy(
                        labourId = labour,
                        date = date,
                        amount = parsedAmount,
                        method = method,
                        note = note.trim()
                    )

                if (existing == null) {
                    store.addCanePeelingPayment(payment)
                } else {
                    store.updateCanePeelingPayment(payment)
                }

                onClose()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) {
            Text("✓ सेव करें")
        }
    }
}

private fun exportCaneCsv(context:Context,list:List<CaneParchi>,season:String){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Parchi_${safeFileName(season)}_${System.currentTimeMillis()}.csv")
        FileOutputStream(file).use{out->
            out.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()))
            out.bufferedWriter(Charsets.UTF_8).use{w->
                w.append("नाम,पिता का नाम,पर्ची कोड,दिनांक,वजन (क्विंटल),भाव/क्विंटल,कुल राशि,टिप्पणी").append('\n')
                list.forEach{p->
                    fun q(s:String) = "\"" + s.replace("\"", "\"\"") + "\""
                    w.append(listOf(q(p.name),q(p.fatherName),q(p.code),q(displayDate(p.date)),q(String.format(Locale.US,"%.2f",p.weight)),q(money(p.rate)),q(money(p.weight*p.rate)),q(p.remark)).joinToString(",")).append('\n')
                }
            }
        }
        shareFile(context,file,"text/csv","Excel साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Excel रिपोर्ट नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable private fun SummaryMini(label:String,value:Double,unit:String,modifier:Modifier){Card(modifier,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(9.dp)){Text(label,fontSize=10.sp,color=Color.Gray);Text(if(label=="कुल राशि")"₹${money(value)}" else money(value),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark);if(unit.isNotBlank())Text(unit,fontSize=9.sp,color=Color.Gray)}}}


@Composable
private fun CaneParchiDashboardScreen(store:Store){
    var showForm by rememberSaveable { mutableStateOf(false) }
    var edit by remember { mutableStateOf<CaneParchi?>(null) }
    var detail by remember { mutableStateOf<CaneParchi?>(null) }
    var delete by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedEdit by remember { mutableStateOf<CaneParchi?>(null) }
    var protectedDelete by remember { mutableStateOf<CaneParchi?>(null) }
    var showPriceHistory by rememberSaveable { mutableStateOf(false) }
    var season by rememberSaveable { mutableStateOf(caneSeason()) }
    var query by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    val seasons = remember(store.caneParchis) {
        (store.caneParchis.map { it.season }.filter { it.isNotBlank() } + caneSeason()).distinct().sortedDescending()
    }
    if (season !in seasons) season = seasons.firstOrNull() ?: caneSeason()
    val allRows = if (season == "ALL") store.caneParchis else store.caneParchis.filter { it.season == season }
    val rows = allRows.filter {
        query.isBlank() || listOf(it.name, it.fatherName, it.code, it.remark).any { value ->
            value.contains(query.trim(), ignoreCase = true)
        }
    }.sortedWith(compareByDescending<CaneParchi> { it.date }.thenBy { it.name })
    val totalWeight = allRows.sumOf { it.weight }
    val totalAmount = allRows.sumOf { it.weight * it.rate }
    val avgRate = if (allRows.isEmpty()) 0.0 else allRows.sumOf { it.rate } / allRows.size

    if (showForm) {
        CaneParchiFormScreen(store, edit) {
            showForm = false
            edit = null
        }
        return
    }

    LazyColumn(
        Modifier.fillMaxSize().background(Bg).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🌾 गन्ना पर्ची", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = GreenDark)
                    Text("पर्ची का पूरा हिसाब • पुराना सीजन • रिपोर्ट", fontSize = 11.sp, color = Color.Gray)
                }
                Button(
                    onClick = { edit = null; showForm = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Green)
                ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("नई पर्ची") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = GreenDark)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("पर्ची डैशबोर्ड", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("कुल पर्ची", allRows.size.toDouble(), "", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल वजन", totalWeight, "क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल राशि", totalAmount, "", Modifier.fillMaxWidth()) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.weight(1f)) { SummaryMini("औसत भाव", avgRate, "/ क्विंटल", Modifier.fillMaxWidth()) }
                        Box(Modifier.weight(1f)) { SummaryMini("कुल सीजन", seasons.size.toDouble(), "सीजन", Modifier.fillMaxWidth()) }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceField(
                        "सीजन / पुरानी पर्चियां",
                        listOf("ALL" to "सभी सीजन") + seasons.map { it to "सीजन $it" },
                        season
                    ) { season = it }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("पर्ची खोजें — नाम / पिता / कोड") },
                        leadingIcon = { Icon(Icons.Default.Search, null) }
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedButton(onClick = { showPriceHistory = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.History, null); Spacer(Modifier.width(4.dp)); Text("भाव इतिहास")
                }
                OutlinedButton(onClick = {
                    exportCaneCsv(context, rows, if (season == "ALL") "ALL" else season)
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.TableChart, null); Spacer(Modifier.width(4.dp)); Text("Excel / CSV")
                }
                OutlinedButton(onClick = {
                    val lines = rows.map { p ->
                        "${p.name} • पिता: ${p.fatherName} • कोड: ${p.code} • ${displayDate(p.date)} • ${String.format(Locale.US, "%.2f", p.weight)} क्विंटल • ₹${money(p.rate)}/क्विंटल • कुल ₹${money(p.weight * p.rate)}${if (p.remark.isNotBlank()) " • ${p.remark}" else ""}"
                    }
                    exportReportPdf(context, "गन्ना_पर्ची_${safeFileName(season)}", "${rows.size} पर्चियां • ${money(totalWeight)} क्विंटल • कुल ₹${money(totalAmount)}", lines)
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(4.dp)); Text("PDF")
                }
            }
        }
        item { Text("${if (season == "ALL") "सभी सीजन" else "सीजन $season"} की पर्चियां (${rows.size})", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = GreenDark) }
        if (rows.isEmpty()) {
            item { EmptyCard("इस सीजन में अभी कोई पर्ची नहीं है। ऊपर 'नई पर्ची' दबाकर जोड़ें।") }
        }
        items(rows, key = { it.id }) { p ->
            Card(
                Modifier.fillMaxWidth().clickable { detail = p },
                RoundedCornerShape(17.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (p.photo.isNotBlank()) PhotoThumb(p.photo, Modifier.size(58.dp)) else Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8F3ED)), contentAlignment = Alignment.Center) { Text("🌾", fontSize = 25.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = GreenDark)
                            Text("पिता: ${p.fatherName.ifBlank { "—" }}", fontSize = 11.sp, color = Color.Gray)
                            Text("कोड: ${p.code} • ${displayDate(p.date)}", fontSize = 11.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { protectedEdit = p }) { Icon(Icons.Default.Edit, "पर्ची बदलें", tint = Green) }
                        IconButton(onClick = { protectedDelete = p }) { Icon(Icons.Default.Delete, "पर्ची हटाएं", tint = Color(0xFFB3261E)) }
                    }
                    HorizontalDivider()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${String.format(Locale.US, "%.2f", p.weight)} क्विंटल", fontWeight = FontWeight.Bold)
                        Text("₹${money(p.rate)} / क्विंटल", color = Green)
                        Text("₹${money(p.weight * p.rate)}", fontWeight = FontWeight.ExtraBold, color = GreenDark)
                    }
                }
            }
        }
    }

    detail?.let { p -> CaneParchiDetail(p) { detail = null } }
    protectedEdit?.let { p ->
        DeviceCredentialGate("गन्ना पर्ची बदलें", "पर्ची की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।", {
            edit = p; protectedEdit = null; showForm = true
        }, { protectedEdit = null })
    }
    protectedDelete?.let { p ->
        DeviceCredentialDeleteGate("गन्ना पर्ची हटाएं", "यह पर्ची स्थायी रूप से हट जाएगी।", {
            store.deleteCaneParchi(p.id); protectedDelete = null
        }, { protectedDelete = null })
    }
    if (showPriceHistory) {
        val selectedSeason = if (season == "ALL") caneSeason() else season
        CanePriceDialog(store, selectedSeason) { showPriceHistory = false }
    }
}

@Composable
private fun CaneParchiFormScreen(store:Store,existing:CaneParchi?=null,onClose:()->Unit){
    var name by rememberSaveable(existing?.id){mutableStateOf(existing?.name?:"")}
    var father by rememberSaveable(existing?.id){mutableStateOf(existing?.fatherName?:"")}
    var code by rememberSaveable(existing?.id){mutableStateOf(existing?.code?:"")}
    var date by rememberSaveable(existing?.id){mutableStateOf(existing?.date?:today())}
    var weight by rememberSaveable(existing?.id){mutableStateOf(if(existing==null)"" else existing.weight.toString())}
    var remark by rememberSaveable(existing?.id){mutableStateOf(existing?.remark?:"")}
    var photo by rememberSaveable(existing?.id){mutableStateOf(existing?.photo?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val season=caneSeason(date)
    val rate=store.caneRateFor(season,date)
    val amount=(weight.toDoubleOrNull()?:0.0)*rate
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)photo=store.persistPhoto(uri.toString(),"cane")}
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){bitmap->if(bitmap!=null)photo=store.persistBitmapPhoto(bitmap,"cane")}
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onClose){Icon(Icons.Default.ArrowBack,"वापस")}
            Text(if(existing==null)"नई गन्ना पर्ची जोड़ें" else "गन्ना पर्ची बदलें",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        }
        OutlinedTextField(value=name,onValueChange={name=it},label={Text("नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=father,onValueChange={father=it},label={Text("पिता का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(value=code,onValueChange={code=it.filter(Char::isDigit).take(7)},label={Text("पर्ची कोड * (6–7 अंक)")},singleLine=true,modifier=Modifier.weight(1f))
            OutlinedTextField(value=date,onValueChange={date=it},label={Text("दिनांक *")},singleLine=true,modifier=Modifier.weight(1f))
        }
        OutlinedTextField(value=weight,onValueChange={weight=it.filter{c->c.isDigit()||c=='.'}},label={Text("वजन (क्विंटल) *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFF1F4F2)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){
                Text("भाव/क्विंटल (इस तारीख का)",fontSize=12.sp,color=Color.Gray)
                Text("₹${money(rate)}",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
            }
        }
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){Text("कुल अनुमानित राशि",fontSize=12.sp,color=Color.Gray);Text("₹${money(amount)}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)}
        }
        OutlinedTextField(value=remark,onValueChange={remark=it},label={Text("टिप्पणी (वैकल्पिक)")},minLines=2,maxLines=3,modifier=Modifier.fillMaxWidth())
        Text("पर्ची की फोटो",fontWeight=FontWeight.Bold,color=GreenDark)
        if(photo.isNotBlank())PhotoThumb(photo,Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={camera.launch(null)},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(5.dp));Text("कैमरा से लें")}
            OutlinedButton(onClick={picker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoLibrary,null);Spacer(Modifier.width(5.dp));Text("गैलरी से चुनें")}
        }
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
        Button(onClick={
            val w=weight.toDoubleOrNull()
            when{
                name.isBlank()->error="नाम दर्ज करें"
                father.isBlank()->error="पिता का नाम दर्ज करें"
                !Regex("\\d{6,7}").matches(code)->error="पर्ची कोड 6–7 अंक का होना चाहिए"
                !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
                date>today()->error="भविष्य की तारीख नहीं हो सकती"
                w==null||w<=0||!w.isFinite()->error="सही वजन दर्ज करें"
                else->{
                    val x=(existing?:CaneParchi(UUID.randomUUID().toString(),name.trim(),father.trim(),code.trim(),date.trim(),w,rate,photo,remark.trim(),season)).copy(name=name.trim(),fatherName=father.trim(),code=code.trim(),date=date.trim(),weight=w,rate=rate,photo=photo,remark=remark.trim(),season=season)
                    if(existing==null) store.addCaneParchi(x) else store.updateCaneParchi(x)
                    onClose()
                }
            }
        },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(existing==null)"पर्ची सेव करें" else "पर्ची अपडेट करें",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun CanePriceDialog(store:Store,season:String,onClose:()->Unit){
    var date by remember{mutableStateOf(today())};var rate by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};
    SimpleDialog("गन्ना भाव इतिहास",onClose){Text("सीजन: $season",fontWeight=FontWeight.Bold,color=GreenDark);Text("नया भाव जिस तारीख से लागू हो, वही तारीख डालें। उसी सीजन और तारीख पर पहले से भाव है तो वही रिकॉर्ड अपडेट होगा। पुरानी पर्चियों का सेव किया हुआ भाव नहीं बदलेगा।",fontSize=11.sp,color=Color.Gray);OutlinedTextField(value=rate,onValueChange={rate=it.filter{c->c.isDigit()||c=='.'}},label={Text("भाव / क्विंटल")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val r=rate.toDoubleOrNull();when{r==null||r<=0->error="सही भाव दर्ज करें";!validDate(date)->error="सही तारीख डालें";date>today()->error="भविष्य की तारीख नहीं";else->{store.addCanePrice(CanePrice(UUID.randomUUID().toString(),season,date,r));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("नया भाव सेव करें")};Spacer(Modifier.height(8.dp));Text("भाव इतिहास",fontWeight=FontWeight.ExtraBold);store.canePricesFor(season).forEach{p->Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(displayDate(p.effectiveDate),Modifier.weight(1f));Text("₹${money(p.rate)} / क्विंटल",fontWeight=FontWeight.Bold,color=GreenDark)}}}
}

@Composable private fun CaneParchiDetail(p:CaneParchi,onClose:()->Unit){SimpleDialog("पर्ची विवरण",onClose){Text("नाम: ${p.name}",fontWeight=FontWeight.Bold);Text("पिता का नाम: ${p.fatherName.ifBlank{"—"}}");Text("पर्ची कोड: ${p.code}");Text("दिनांक: ${displayDate(p.date)}");Text("वजन: ${String.format(Locale.US,"%.2f",p.weight)} क्विंटल");Text("भाव: ₹${money(p.rate)} / क्विंटल");Text("कुल राशि: ₹${money(p.weight*p.rate)}",fontWeight=FontWeight.ExtraBold,color=GreenDark);if(p.remark.isNotBlank())Text("Remark: ${p.remark}");if(p.photo.isNotBlank())PhotoThumb(p.photo,Modifier.fillMaxWidth().height(220.dp))}}

@Composable
private fun ProfileScreen(onBackup:()->Unit){
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.AccountCircle,null,tint=Color.White,modifier=Modifier.size(52.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Majdoor Hisaab PRO",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)
                        Text("प्रोफाइल और डेटा सुरक्षा",color=Color.White.copy(alpha=.85f),fontSize=12.sp)
                    }
                }
            }
        }
        item{
            Card(Modifier.fillMaxWidth().clickable(onClick=onBackup),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE4F2FF)),contentAlignment=Alignment.Center){Text("☁️",fontSize=27.sp)}
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Backup & Restore",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Text("Android Auto Backup + Manual Backup",fontSize=11.sp,color=Color.Gray)
                    }
                    Icon(Icons.Default.ChevronRight,null,tint=GreenDark)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("🔐 सुरक्षा",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                    Text("App खोलने, Edit/Delete और Backup Restore पर Android screen lock से पुष्टि होगी।",fontSize=12.sp,color=Color.DarkGray)
                }
            }
        }
    }
}

@Composable
private fun BackupScreen(store:Store,status:String,onStatus:(String)->Unit,onBackup:()->Unit,onRestore:()->Unit,driveEmail:String,driveBusy:Boolean,onDriveSignIn:()->Unit,onDriveBackup:()->Unit,onDriveRestore:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){
        Text("☁️ Backup & Restore",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Spacer(Modifier.height(4.dp))
        Text("आपका मजदूर, हाजिरी, भुगतान, खेत, फसल, खर्च और बिक्री data सुरक्षित रखें।",fontSize=12.sp,color=Color.Gray)
        Spacer(Modifier.height(14.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("☁️ Android Auto Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Android Auto Backup ON है। फोन में Google Account लगा होने पर Android का app-data backup system backup ले सकता है।",fontSize=12.sp,color=Color.DarkGray)
                Text("यह Google Drive की सामान्य files list में अलग backup file के रूप में जरूरी नहीं दिखेगा।",fontSize=11.sp,color=Color.Gray)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                Text("☁️ Direct Google Drive",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Google Account: $driveEmail",fontSize=12.sp,color=if(driveEmail.contains("@")) GreenDark else Color.Gray)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    OutlinedButton(onClick=onDriveSignIn,enabled=!driveBusy,modifier=Modifier.weight(1f)){Text(if(driveEmail.contains("@"))"Account बदलें" else "Google Account जोड़ें")}
                    Button(onClick=onDriveBackup,enabled=!driveBusy&&driveEmail.contains("@"),modifier=Modifier.weight(1f)){Text(if(driveBusy)"काम हो रहा है…" else "Drive Backup")}
                }
                OutlinedButton(onClick=onDriveRestore,enabled=!driveBusy&&driveEmail.contains("@"),modifier=Modifier.fillMaxWidth()){Text("Drive से Latest Restore")}
                Text("Backup सीधे Google Drive के ‘Majdoor Hisaab PRO’ folder में जाएगा।",fontSize=11.sp,color=Color.Gray)
                Spacer(Modifier.height(8.dp))

                Text("📦 Manual Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Google Drive में रखने के लिए नीचे Backup बनाएं दबाएँ। अगली screen में Google Drive चुनकर अपना Gmail account और folder चुनें।",fontSize=12.sp,color=GreenDark,fontWeight=FontWeight.SemiBold)
                Button(onClick=onBackup,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                    Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(8.dp));Text("Google Drive / फोन में Backup",fontWeight=FontWeight.Bold)
                }
                OutlinedButton(onClick=onRestore,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){
                    Icon(Icons.Default.CloudDownload,null);Spacer(Modifier.width(8.dp));Text("Google Drive से Restore करें",fontWeight=FontWeight.Bold)
                }
                Text("Restore से पहले Android screen lock पूछा जाएगा। Restore करने पर मौजूदा app data backup के data से replace होगा।",fontSize=11.sp,color=Color.Gray)
            }
        }
        if(status.isNotBlank()){
            Spacer(Modifier.height(12.dp))
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF0F7FF))){
                Text(status,Modifier.padding(14.dp),fontWeight=FontWeight.SemiBold,color=GreenDark)
            }
        }
    }
}

@Composable private fun PaymentDialog(store:Store,labourId:String,preField:String?,preCrop:String?,onClose:()->Unit,existing:Payment?=null){
    var field by remember{mutableStateOf(existing?.fieldId ?: preField?:"")}
    var crop by remember{mutableStateOf(existing?.cropId ?: preCrop?:"")}
    var amount by remember{mutableStateOf(existing?.amount?.let{money(it)} ?: "")}
    var date by remember{mutableStateOf(existing?.date ?: today())}
    var error by remember{mutableStateOf("")}
    var saving by remember{mutableStateOf(false)}
    val lockedField=preField?.isNotBlank()==true
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){
        if(crop.isNotBlank() && crops.none{it.id==crop}) crop=""
        if(crop.isBlank() && crops.size==1) crop=crops.first().id
    }
    SimpleDialog(if(existing==null)"भुगतान दर्ज करें" else "भुगतान बदलें",onClose){
        if(lockedField){
            val name=store.fields.firstOrNull{it.id==field}?.name?:"खेत"
            Text("खेत: $name",fontWeight=FontWeight.Bold,color=Green)
        } else {
            ChoiceField("खेत (Optional)",listOf("" to "खेत नहीं चुनना")+store.fields.map{it.id to it.name},field){field=it}
        }
        if(field.isNotBlank() && crops.size>1){
            ChoiceField("फसल (Optional)",listOf("" to "फसल नहीं चुनना")+crops.map{it.id to it.name},crop){crop=it}
        }
        AttendanceDateButton(date){date=it}
        OutlinedTextField(value=amount,onValueChange={amount=it;error=""},label={Text("भुगतान की रकम (₹)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=Color(0xFFB3261E),fontSize=12.sp)
        Button(enabled=!saving,onClick={
            if(saving) return@Button
            val n=amount.toDoubleOrNull()
            when {
                n==null||n<=0||!n.isFinite()->error="सही भुगतान रकम दर्ज करें।"
                !validDate(date)->error="सही भुगतान तारीख चुनें।"
                (existing!=null && store.isClosedDate(labourId,existing.date)) || store.isClosedDate(labourId,date)->error="इस तारीख तक का हिसाब फाइनल है। नई अवधि की तारीख चुनें।"
                else->{saving=true;val row=Payment(existing?.id?:UUID.randomUUID().toString(),labourId,field,crop,date,n);val saved=if(existing==null)store.addPayment(row) else store.updatePayment(row);if(saved)onClose() else {saving=false;error="भुगतान सेव नहीं हुआ। तारीख या फाइनल हिसाब जाँचें।"}}
            }
        },modifier=Modifier.fillMaxWidth()){Text(if(existing==null)"भुगतान सेव करें" else "बदलाव सेव करें")}
    }
}

@Composable private fun RateDialog(store:Store,labourId:String,onClose:()->Unit){var rate by remember{mutableStateOf("")};var date by remember{mutableStateOf(today())};var error by remember{mutableStateOf("")};val current=store.rateFor(labourId,today());SimpleDialog("दिहाड़ी बदलें",onClose){Text("अभी की प्रभावी दिहाड़ी: ₹${money(current)}/दिन",fontWeight=FontWeight.SemiBold,color=Green);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("नई दिहाड़ी")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=rate.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही दिहाड़ी दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";store.setRate(WageRate(UUID.randomUUID().toString(),labourId,date.trim(),n));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save नई दर")}}}

@Composable private fun CropDetail(store:Store,id:String,onBack:()->Unit,onExpense:()->Unit,onSale:()->Unit){val c=store.crops.firstOrNull{it.id==id}?:return;val f=store.fields.firstOrNull{it.id==c.fieldId};val exp=store.expenses.filter{it.cropId==id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==id}.sumOf{it.total};val wage=store.attendances.filter{it.cropId==id}.sumOf{it.fraction*it.rate};Column(Modifier.fillMaxSize()){DetailTopBar("🌱 ${c.name}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Text("खेत: ${f?.name?:"नहीं चुना"}",fontWeight=FontWeight.Bold)};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",exp+wage)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-exp-wage)}}};this.item{Text("मजदूरी ₹${money(wage)}",fontWeight=FontWeight.Bold)};this.item{Text("खेती खर्च ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("बिक्री ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{SmallAction("💰 इस फसल के खर्च",onExpense)};this.item{SmallAction("🧺 इस फसल की बिक्री",onSale)}}}}

@Composable private fun DetailTopBar(title:String,onBack:()->Unit){
    Surface(color=Green,tonalElevation=2.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}
            Text(title,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}

@Composable private fun SectionTitle(title:String,sub:String,onAdd:(()->Unit)?=null){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);Text(sub,fontSize=12.sp,color=Color.Gray)};if(onAdd!=null){IconButton(onClick=onAdd){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}}}
@Composable private fun SmallAction(text:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Text(text,Modifier.padding(16.dp),fontWeight=FontWeight.SemiBold)}}
@Composable private fun SimpleDialog(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){BackHandler{onClose()};AlertDialog(onDismissRequest={},title={Text(title,fontWeight=FontWeight.Bold)},text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)},confirmButton={},dismissButton={TextButton(onClick=onClose){Text("बंद")}})}
@Composable private fun ConfirmDialog(title:String,message:String,onYes:()->Unit,onNo:()->Unit){AlertDialog(onDismissRequest=onNo,title={Text(title)},text={Text(message)},confirmButton={Button(onClick=onYes){Text("हटाएँ")}},dismissButton={TextButton(onClick=onNo){Text("रद्द")}})}
@Composable
private fun ChoiceField(label:String,options:List<Pair<String,String>>,selected:String,onSelected:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    Column{
        Text(label,fontSize=12.sp,color=Color.Gray)
        Box{
            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){
                Text(options.firstOrNull{it.first==selected}?.second?.ifBlank{"नहीं चुना"} ?: "चुनें")
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                options.forEach{(id,name)->
                    DropdownMenuItem(text={Text(name.ifBlank{"नहीं चुना"})},onClick={onSelected(id);open=false})
                }
            }
        }
    }
}
