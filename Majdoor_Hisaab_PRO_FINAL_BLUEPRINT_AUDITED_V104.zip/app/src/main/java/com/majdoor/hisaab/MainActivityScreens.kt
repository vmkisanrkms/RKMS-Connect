package com.majdoor.hisaab

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import android.content.res.Configuration
import android.graphics.BitmapFactory
import com.majdoor.hisaab.model.*
import com.majdoor.hisaab.feature.AppServices
import com.majdoor.hisaab.security.SecurityManager
import com.majdoor.hisaab.BuildConfig
import com.majdoor.hisaab.notification.NotificationHelper
import com.majdoor.hisaab.notification.NotificationSettings
import com.majdoor.hisaab.security.AutoLockManager
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.io.File

    internal fun MainActivity.savedThemeMode():String = prefs.getString("theme","system") ?: "system"


    internal fun MainActivity.applySavedTheme(){
        val mode=savedThemeMode()
        val dark=when(mode){
            "dark" -> true
            "light" -> false
            else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES
        }
        setTheme(if(dark) R.style.AppTheme_Dark else R.style.AppTheme_Light)
    }


    internal fun MainActivity.selectedDatePattern():String {
        val allowed = setOf("dd/MM/yyyy","dd-MM-yyyy","yyyy-MM-dd")
        return prefs.getString("date_format","dd/MM/yyyy")?.takeIf { it in allowed } ?: "dd/MM/yyyy"
    }


    internal fun MainActivity.isoToDisplay(iso:String):String {
        if(iso.isBlank()) return iso
        return try {
            val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(iso)
            if(d==null) iso else SimpleDateFormat(selectedDatePattern(),Locale.getDefault()).format(d)
        } catch(_:Exception){ iso }
    }


    internal fun MainActivity.displayDateTime(iso:String):String = isoToDisplay(iso)


    internal fun MainActivity.displayTimestamp(ts:Long, withSeconds:Boolean=false):String {
        if(ts<=0L) return "Unknown time"
        val date = Date(ts)
        val pattern = (selectedDatePattern()) + if(withSeconds) " HH:mm:ss" else " HH:mm"
        return SimpleDateFormat(pattern,Locale.getDefault()).format(date)
    }


    internal fun MainActivity.parseDisplayDate(value:String):String {
        val v=value.trim()
        if(v.isBlank()) return ""
        val format=selectedDatePattern()
        return try {
            val d=SimpleDateFormat(format,Locale.getDefault()).apply{isLenient=false}.parse(v)
            if(d==null) throw IllegalArgumentException("Invalid date")
            SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d)
        } catch(_:Exception){
            if(v.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) v else throw IllegalArgumentException("Invalid date. Use ${format}")
        }
    }


    internal fun MainActivity.dateField(hint:String, iso:String=today):EditText = field("$hint (${selectedDatePattern()})", if(iso.isBlank()) "" else isoToDisplay(iso)).apply {
        isFocusable = true
        isClickable = true
        setOnClickListener {
            val initial = runCatching { parseDisplayDate(text.toString()) }.getOrDefault(today)
            val parsed = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(initial) }.getOrNull() ?: Date()
            val cal = Calendar.getInstance().apply { time = parsed }
            DatePickerDialog(this@dateField, { _, y, m, d ->
                val picked = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                setText(isoToDisplay(picked))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
    }


    internal fun MainActivity.dateValue(e:EditText):String = parseDisplayDate(e.text.toString())


    internal fun MainActivity.displayDateOrRaw(value:String):String = isoToDisplay(value)


    internal fun MainActivity.showSplash(){
        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            gravity=Gravity.CENTER
            setPadding(32,32,32,32)
            setBackgroundColor(bg)
            addView(txt("MAJDOOR HISAAB PRO",26f,true))
            addView(txt("Agricultural Labour & Farm Accounts",15f,false))
            addView(ProgressBar(this@showSplash).apply{isIndeterminate=true})
            addView(txt("Loading your local records…",13f,false))
        }
        setContentView(box)
    }


    internal fun MainActivity.initializeStartup(){
        app=AppServices(this);security=SecurityManager(this)
        failedPinAttempts=prefs.getInt("pin_failed_attempts",0)
        pinBlockedUntil=prefs.getLong("pin_blocked_until",0L)
        NotificationHelper.ensure(this)
        if(prefs.getBoolean("auto_backup",false)) scheduleAutoBackup(true)
        if(prefs.getBoolean("auto_backup",false) && System.currentTimeMillis()-prefs.getLong("last_auto_backup",0L) >= 24L*60L*60L*1000L){ try{ app.backup.create(); prefs.edit().putLong("last_auto_backup",System.currentTimeMillis()).apply() }catch(_:Exception){} }
        if(NotificationSettings.enabled(this) && !NotificationHelper.permissionGranted(this)) requestNotificationPermission()
        lastUserActivity=System.currentTimeMillis()
        autoLockHandler.post(autoLockChecker)
        if(!prefs.getBoolean("first_setup_done", false)) { firstTimeSetup(); return }
        if(BuildConfig.E2E_ERROR_TEST && intent.getBooleanExtra("e2e_error_state", false)) {
            unlocked=true
            dashboard()
            root.post { showErrorState("E2E test action", IllegalStateException("Intentional E2E error for recovery-path verification")){ dashboard() } }
            return
        }
        if(security.hasPin()) {
            if(security.biometricEnabled() && security.biometricAvailable()) biometricUnlock() else unlockDialog()
        } else {unlocked=true;openRestoredRoute()}
    }


    internal fun MainActivity.openRestoredRoute(){
        val route=restoredRoute
        restoredRoute=null
        when(route){
            "workers"->workers()
            "fields"->fields()
            "crops"->crops()
            "attendance"->attendance()
            "work"->workList()
            "payments"->payments()
            "expenses"->expenses()
            "production"->production()
            "revenue"->revenue()
            "reports"->reports()
            "backup"->backup()
            "settings"->settings()
            "search"->search()
            else->dashboard()
        }
    }


    internal fun MainActivity.autoLockTimeout():Long = AutoLockManager.timeoutMinutes(prefs.getString("auto_lock_timeout","Off"))


    internal fun MainActivity.lockApp(){
        if(!security.hasPin()) return
        unlocked=false
        lastUserActivity=System.currentTimeMillis()
        if(security.biometricEnabled() && security.biometricAvailable()) biometricUnlock() else unlockDialog()
    }


    internal fun MainActivity.firstTimeSetup(){
        val name=field("Farm / business name", "My Farm")
        val pin=field("Optional 4-12 digit PIN")
        LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24)
            addView(txt("Welcome to Majdoor Hisaab PRO",24f,true))
            addView(txt("One-time setup. Core records stay in the local SQLite database on this phone; JSON is used as the backup/export mirror.",14f))
            addView(name); addView(pin)
            addView(btn("Start App"){
                val pv=pin.text.toString().trim()
                if(pv.isNotEmpty() && (pv.length !in 4..12 || pv.any{!it.isDigit()})){toast("PIN must be 4-12 digits");return@btn}
                prefs.edit().putBoolean("first_setup_done",true).putString("farm_name",name.text.toString().trim().ifEmpty{"My Farm"}).apply()
                if(pv.isNotEmpty()) security.setPin(pv)
                unlocked=true; dashboard()
            })
            setContentView(this)
        }
    }


    internal fun MainActivity.biometricUnlock(){ security.authenticate(this, Executors.newSingleThreadExecutor(), { runOnUiThread{ unlocked=true; openRestoredRoute() } }, { runOnUiThread{ unlockDialog() } }) }



    internal fun MainActivity.unlockDialog(){
        val e=field("Enter PIN")
        AlertDialog.Builder(this).setTitle("Majdoor Hisaab PRO Locked").setMessage("Enter your app PIN to continue.")
            .setView(e).setCancelable(false)
            .setPositiveButton("Unlock"){_,_->
                val now=System.currentTimeMillis()
                if(now < pinBlockedUntil){
                    toast("Too many incorrect attempts. Try again later.")
                    unlockDialog()
                } else if(security.verifyPin(e.text.toString())){
                    failedPinAttempts=0; pinBlockedUntil=0L; prefs.edit().putInt("pin_failed_attempts",0).putLong("pin_blocked_until",0L).apply(); unlocked=true; openRestoredRoute()
                } else {
                    failedPinAttempts++
                    if(failedPinAttempts>=5){ pinBlockedUntil=System.currentTimeMillis()+30_000L; failedPinAttempts=0; toast("Too many incorrect attempts. PIN locked for 30 seconds.") }
                    else toast("Incorrect PIN (${5-failedPinAttempts} attempts remaining)")
                    unlockDialog()
                }
            }.setNegativeButton("Exit"){_,_->finishAndRemoveTask()}.show()
    }


    internal fun MainActivity.photoView(uri:String):ImageView? {
        if(uri.isBlank()) return null
        return try { contentResolver.openInputStream(Uri.parse(uri)).use{input-> BitmapFactory.decodeStream(input) }.let{ bmp-> if(bmp==null) null else ImageView(this).apply{setImageBitmap(bmp);adjustViewBounds=true;setPadding(8,8,8,8)} } } catch(_:Exception){ null }
    }


    internal fun MainActivity.dp(v:Int):Int = (v * resources.displayMetrics.density + 0.5f).toInt()


    internal fun MainActivity.txt(s:String,size:Float=14f,bold:Boolean=false):TextView{
        return TextView(this).apply{
            text=s; textSize=size
            setTextColor(if(isDarkTheme()) Color.WHITE else Color.rgb(30,40,31))
            if(bold)setTypeface(null,1)
            setPadding(dp(8),dp(7),dp(8),dp(7))
            if(size >= 14f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) setAutoSizeTextTypeUniformWithConfiguration(dp(10),dp(22),dp(1),android.util.TypedValue.COMPLEX_UNIT_PX)
            maxLines = if (s.contains("\n")) 8 else 3
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
    }


    internal fun MainActivity.btn(s:String,action:()->Unit)=Button(this).apply{
        text=s
        minHeight=dp(48); minimumHeight=dp(48); minWidth=dp(48); minimumWidth=dp(48)
        setPadding(dp(10),dp(6),dp(10),dp(6))
        isAllCaps=false
        setOnClickListener{
            try { action() }
            catch(e:Exception){ showErrorState(s,e,action) }
        }
    }


    internal fun MainActivity.showErrorState(label:String,e:Throwable,retry:()->Unit){
        val message=e.message?.trim().orEmpty().ifBlank{"Unexpected error. Your existing local data was not intentionally deleted."}
        AlertDialog.Builder(this)
            .setTitle("Something went wrong")
            .setMessage("$label failed.\n\n$message")
            .setNegativeButton("Home"){_,_->dashboard()}
            .setPositiveButton("Retry"){_,_->
                try { retry() } catch(next:Exception) { showErrorState(label,next,retry) }
            }
            .show()
    }


    internal fun MainActivity.page(title:String):LinearLayout{
        currentRoute=when(title){
            "Workers"->"workers"; "Fields"->"fields"; "Crops"->"crops"; "Attendance"->"attendance";
            "Work"->"work"; "Payments"->"payments"; "Expenses"->"expenses"; "Production"->"production";
            "Revenue"->"revenue"; "Reports"->"reports"; "Backup & Restore"->"backup"; "Settings"->"settings";
            "Search"->"search"; else->currentRoute
        }
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        val h=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        h.addView(btn("‹"){dashboard()},LinearLayout.LayoutParams(dp(56),dp(58)))
        h.addView(txt(title,22f,true),LinearLayout.LayoutParams(0,dp(58),1f))
        h.addView(btn("🔔"){notificationSettingsDialog()},LinearLayout.LayoutParams(dp(56),dp(58)))
        h.addView(btn("⌕"){search()},LinearLayout.LayoutParams(dp(56),dp(58)))
        root.addView(h);val sc=ScrollView(this);val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(10),dp(10),dp(10))}
        sc.addView(body);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);return body
    }


    internal fun MainActivity.field(hint:String,value:String=""):EditText=EditText(this).apply{
        this.hint=hint; setText(value); minHeight=dp(48); setPadding(dp(10),dp(6),dp(10),dp(6))
        maxLines=4; isSingleLine=false
        setTextColor(if(isDarkTheme()) Color.WHITE else Color.rgb(30,40,31))
        setHintTextColor(if(isDarkTheme()) Color.rgb(190,200,192) else Color.rgb(90,100,92))
    }


    internal fun MainActivity.row(vararg views:View):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;views.forEach{addView(it,LinearLayout.LayoutParams(0,-2,1f))}}

    internal fun MainActivity.toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

    internal fun MainActivity.isDarkTheme():Boolean { val mode=prefs.getString("theme","system"); return when(mode){"dark"->true;"light"->false;else->(resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK)==android.content.res.Configuration.UI_MODE_NIGHT_YES} }

    internal fun MainActivity.money(v:Double):String { val c=prefs.getString("currency","INR ₹") ?: "INR ₹"; val symbol=when{c.startsWith("USD")->"$";c.startsWith("EUR")->"€";else->"₹"}; return symbol+String.format(Locale.US,"%.2f",v) }

    internal fun MainActivity.pick(title:String, labels:List<String>, current:Int=-1, onPick:(Int)->Unit):Button {
        return btn(if(current in labels.indices) labels[current] else title){
            AlertDialog.Builder(this).setTitle(title).setItems(labels.toTypedArray()){_,which->onPick(which)}.show()
        }
    }


    internal fun MainActivity.selectedName(id:String, names:List<Pair<String,String>>):String = names.firstOrNull{it.first==id}?.second ?: "Not selected"


    internal fun MainActivity.dashboard(){
        currentRoute="dashboard"
        val b=page("Majdoor Hisaab PRO")
        val farmName=(prefs.getString("farm_name","My Farm") ?: "My Farm").trim().ifBlank{"My Farm"}
        b.addView(txt(farmName,20f,true))
        b.addView(txt(isoToDisplay(today),14f))
        val securityLabel=when {
            !security.hasPin() -> "Security: App Lock OFF"
            security.biometricEnabled() -> "Security: PIN enabled • Biometric enabled"
            else -> "Security: PIN enabled • Biometric OFF"
        }
        b.addView(txt(securityLabel,12f))
        b.addView(txt("OFFLINE MODE • Local phone storage • No internet required",12f,true))

        val workers=app.workers.list()
        val activeWorkers=workers.filter{it.active}
        val activeIds=activeWorkers.map{it.id}.toSet()
        val fields=app.fields.list()
        val crops=app.crops.list()
        val attendance=app.attendance.list()
        val work=app.work.list()
        val payments=app.payments.list()
        val expenses=app.expenses.list()

        val todayAttendance=attendance.filter{it.date==today && it.workerId in activeIds}
        val todayWork=work.filter{it.date==today}
        val todayPayments=payments.filter{it.date==today}
        val full=todayAttendance.count{it.status.equals("FULL",true)}
        val half=todayAttendance.count{it.status.equals("HALF",true)}
        val markedIds=todayAttendance.filter{it.status.equals("FULL",true)||it.status.equals("HALF",true)}.map{it.workerId}.toSet()
        val none=activeWorkers.count{it.id !in markedIds}
        val attendanceWages=todayAttendance.sumOf{when(it.status.uppercase()){"FULL"->it.rate.coerceAtLeast(0.0);"HALF"->it.rate.coerceAtLeast(0.0)/2.0;else->0.0}}
        val todayWorkCost=todayWork.sumOf{app.calculation.workCost(it).coerceAtLeast(0.0)}
        val todayWages=attendanceWages+todayWorkCost
        val todayPaid=todayPayments.sumOf{it.amount.coerceAtLeast(0.0)}

        // Financial totals include historical records of inactive workers too.
        // Active/inactive status must not erase a worker's past earned/paid ledger.
        val earned=workers.sumOf{app.calculation.ledger(it.id,attendance,work,payments).earned}
        val paid=payments.sumOf{it.amount.coerceAtLeast(0.0)}
        val outstanding=workers.sumOf{app.calculation.ledger(it.id,attendance,work,payments).outstanding}
        val advances=payments.filter{it.advance}.sumOf{it.amount.coerceAtLeast(0.0)}
        val monthPrefix=today.substring(0,7)
        val monthAttendance=attendance.filter{it.date.startsWith(monthPrefix)}.sumOf{when(it.status.uppercase()){"FULL"->it.rate.coerceAtLeast(0.0);"HALF"->it.rate.coerceAtLeast(0.0)/2.0;else->0.0}}
        val monthWork=work.filter{it.date.startsWith(monthPrefix)}.sumOf{app.calculation.workCost(it).coerceAtLeast(0.0)}
        val monthCost=monthAttendance+monthWork
        val ongoingWork=work.count{it.date<=today && it.endTime.isBlank()}

        b.addView(row(txt("WORKERS\n${activeWorkers.size}",17f,true),txt("FIELDS\n${fields.count{it.active}}",17f,true),txt("CROPS\n${crops.count{it.active}}",17f,true)))
        b.addView(txt("TODAY'S TEAM",13f,true))
        val teamSeen=mutableSetOf<String>()
        val todayTeam=todayAttendance.mapNotNull{a->
            val w=activeWorkers.find{it.id==a.workerId} ?: return@mapNotNull null
            if(!teamSeen.add(w.id)) null else "${w.name} • ${a.status.uppercase()}"
        }
        if(todayTeam.isEmpty()) b.addView(txt("No attendance team marked today",13f)) else todayTeam.forEach{name->b.addView(txt(name,13f))}
        b.addView(txt("TODAY'S SUMMARY",13f,true))
        b.addView(row(txt("FULL\n$full",16f,true),txt("HALF\n$half",16f,true),txt("NONE\n$none",16f,true)))
        b.addView(row(txt("WORK\n${money(todayWorkCost)}",14f,true),txt("WAGES\n${money(todayWages)}",14f,true),txt("PAID\n${money(todayPaid)}",14f,true)))
        b.addView(txt("TODAY OUTSTANDING: ${money(outstanding)}",14f,true))
        b.addView(txt("FINANCIAL — Total Labour Cost ${money(earned)} • Total Payments ${money(paid)} • Total Outstanding ${money(outstanding)} • Advances ${money(advances)} • Current Month Cost ${money(monthCost)}",13f,true))
        b.addView(txt("ONGOING WORK: $ongoingWork",13f,true))
        b.addView(txt("QUICK ACTIONS",13f,true))
        listOf(
            "Mark Attendance" to ::attendance,
            "Add Worker" to {editingWorker=null;pendingWorkerPhoto="";workerForm()},
            "Add Work" to ::addWork,
            "Payment" to {paymentForm()},
            "Add Field" to {editingField=null;pendingFieldPhoto="";fieldForm()},
            "Add Crop" to {cropForm()},
            "Add Expense" to {expenseForm()},
            "Reports" to ::reports,
            "Global Search" to ::search
        ).forEach{(label,action)->b.addView(btn(label,action))}

        b.addView(txt("RECENT ACTIVITY",13f,true))
        data class Recent(val date:String,val label:String,val action:()->Unit)
        val recent=mutableListOf<Recent>()
        attendance.forEach{a->recent.add(Recent(a.date,"Attendance • ${displayDateOrRaw(a.date)} • ${a.status}"){attendanceDetail(a.id)})}
        work.forEach{w->recent.add(Recent(w.date,"Work • ${displayDateOrRaw(w.date)} • ${w.workType}"){workDetail(w.id)})}
        payments.forEach{p->recent.add(Recent(p.date,"Payment • ${displayDateOrRaw(p.date)} • ${money(p.amount)}"){paymentDetail(p.id)})}
        expenses.forEach{e->recent.add(Recent(e.date,"Expense • ${displayDateOrRaw(e.date)} • ${money(e.amount)}"){expenseDetail(e.id)})}
        recent.sortedByDescending{it.date}.take(12).forEach{item->b.addView(btn(item.label,item.action))}
        if(recent.isEmpty()) b.addView(txt("No recent activity",13f))
    }


    internal fun MainActivity.workers(){
        val b=page("Workers")
        b.addView(btn("+ Add Worker"){editingWorker=null;pendingWorkerPhoto="";workerForm()})
        b.addView(txt("Search / Filter / Sort",12f,true))
        val search=field("Search name/mobile/type/reference/address")
        b.addView(search);b.addView(btn("Apply Search"){ workerList(b,WorkerQuery.search(app.workers.list(),search.text.toString())) })
        b.addView(btn("Active Workers Only"){workerList(b,WorkerQuery.active(app.workers.list()))})
        b.addView(btn("Inactive Workers Only"){workerList(b,WorkerQuery.inactive(app.workers.list()))})
        b.addView(btn("Wage > 0"){workerList(b,WorkerQuery.wagePositive(app.workers.list()))})
        b.addView(btn("Wage = 0"){workerList(b,WorkerQuery.wageZero(app.workers.list()))})
        b.addView(btn("Outstanding > 0"){workerList(b,WorkerQuery.outstandingPositive(app.workers.list(),app.attendance.list(),app.work.list(),app.payments.list()))})
        b.addView(btn("Outstanding = 0"){workerList(b,WorkerQuery.outstandingZero(app.workers.list(),app.attendance.list(),app.work.list(),app.payments.list()))})
        b.addView(btn("Sort by Name A-Z"){workerList(b,WorkerQuery.sortNameAsc(app.workers.list()))})
        b.addView(btn("Sort by Name Z-A"){workerList(b,WorkerQuery.sortNameDesc(app.workers.list()))})
        b.addView(btn("Sort by Wage High-Low"){workerList(b,WorkerQuery.sortWageDesc(app.workers.list()))})
        b.addView(btn("Sort by Wage Low-High"){workerList(b,WorkerQuery.sortWageAsc(app.workers.list()))})
        workerList(b,app.workers.list())
    }


internal fun MainActivity.workerList(b:LinearLayout,list:List<Worker>){
        b.addView(txt("WORKER LIST (${list.size})",12f,true))
        list.forEach{w->
            val x=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,10,12,10);setBackgroundColor(Color.WHITE)}
            x.addView(txt(w.name,17f,true));x.addView(txt("${w.mobile} • ${money(w.defaultRate)} / ${w.rateUnit}",12f))
            x.addView(row(btn("Open"){workerProfile(w.id)},btn("Edit"){editingWorker=w.id;workerForm()},btn(if(w.active) "Deactivate" else "Activate"){app.workers.save(w.copy(active=!w.active));workers()}))
            b.addView(x)
        }
    }


    internal fun MainActivity.workerForm(){
        val b=page(if(editingWorker==null)"Add Worker" else "Edit Worker")
        val old=app.workers.list().find{it.id==editingWorker}
        val name=field("Worker name",old?.name?:"");val mobile=field("Mobile",old?.mobile?:"")
        val address=field("Address",old?.address?:"");val type=field("Worker type",old?.workerType?:"General")
        val rate=field("Default wage",old?.defaultRate?.toString() ?: String.format(Locale.US,"%.2f",prefs.getFloat("default_wage",0f)));val unit=field("Wage unit: DAY/HALF_DAY/HOUR/ACRE/QUANTITY/PIECE",old?.rateUnit?:"DAY")
        val join=field("Joining date (YYYY-MM-DD)",old?.joiningDate?:today);val reference=field("Reference / ID",old?.referenceId?:"");val notes=field("Notes",old?.notes?:"")
        listOf(name,mobile,address,type,rate,unit,join,reference,notes).forEach{b.addView(it)}
        b.addView(btn(if(old?.photoUri.isNullOrBlank()) "Add Worker Photo" else "Change Worker Photo"){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(i,2200) })
        if(!old?.photoUri.isNullOrBlank()) b.addView(btn("Remove Worker Photo"){ pendingWorkerPhoto=""; app.workers.save(old!!.copy(photoUri="")); toast("Worker photo removed"); workerForm() })
        b.addView(btn("Save Worker"){
            val cleanName=name.text.toString().trim()
            val cleanMobile=mobile.text.toString().trim()
            val cleanUnit=unit.text.toString().trim().uppercase()
            if(cleanName.isEmpty()){toast("Worker name required");return@btn}
            if(cleanMobile.isNotEmpty() && !cleanMobile.matches(Regex("[0-9]{10}"))){toast("Mobile number must be exactly 10 digits");return@btn}
            val wage=rate.text.toString().trim().toDoubleOrNull()
            if(wage==null || !wage.isFinite() || wage<0){toast("Enter a valid non-negative wage");return@btn}
            if(cleanUnit !in setOf("DAY","HALF_DAY","HOUR","ACRE","QUANTITY","PIECE")){toast("Invalid wage unit");return@btn}
            try {
                val x=Worker(old?.id?:UUID.randomUUID().toString(),cleanName,cleanMobile,
                    address.text.toString().trim(),type.text.toString().trim().ifBlank{"General"},wage,
                    cleanUnit,join.text.toString().trim(),reference.text.toString().trim(),notes.text.toString().trim(),
                    if(pendingWorkerPhoto.isNotBlank()) pendingWorkerPhoto else (old?.photoUri ?: ""),old?.active ?: true)
                app.workers.save(x);toast("Worker saved successfully");workers()
            } catch(e:IllegalArgumentException){toast(e.message ?: "Invalid worker data")}
        })
    }


    internal fun MainActivity.workerProfile(id:String){
        val w=app.workers.list().first{it.id==id};val b=page("Worker Profile")
        val ledger=app.calculation.ledger(id,app.attendance.list(),app.work.list(),app.payments.list())
        b.addView(txt(w.name,24f,true));b.addView(txt("ID: ${w.id}",10f));b.addView(txt("Mobile: ${w.mobile.ifBlank{"—"}}",13f))
        b.addView(txt("Address: ${w.address.ifBlank{"—"}}\nWorker Type: ${w.workerType.ifBlank{"General"}}\nDefault Wage: ${money(w.defaultRate)} / ${w.rateUnit}\nJoining Date: ${if(w.joiningDate.isBlank())"—" else displayDateOrRaw(w.joiningDate)}\nReference / ID: ${w.referenceId.ifBlank{"—"}}\nStatus: ${if(w.active)"Active" else "Inactive"}\nNotes: ${w.notes.ifBlank{"—"}}",13f))
        photoView(w.photoUri)?.let{b.addView(it,LinearLayout.LayoutParams(-1,260))}
        b.addView(txt("Earned ${money(ledger.earned)} | Paid ${money(ledger.normalPaid)} | Advance ${money(ledger.advance)} | Outstanding ${money(ledger.outstanding)}",15f,true))
        b.addView(btn("Attendance"){workerAttendance(id)});b.addView(btn("Work History"){workerWork(id)})
        b.addView(btn("Ledger"){workerLedger(id)});b.addView(btn("Payments"){workerPayments(id)})
        b.addView(btn("Advances"){workerAdvances(id)});b.addView(btn("Add Advance"){paymentForm(id, advanceDefault=true)})
        b.addView(btn("Wage History"){workerWageHistory(id)})
        b.addView(btn("Documents"){workerDocuments(id)})
        b.addView(btn(if(w.active) "Deactivate Worker" else "Activate Worker"){app.workers.save(w.copy(active=!w.active));toast(if(w.active) "Worker deactivated" else "Worker activated");workerProfile(id)})
        b.addView(btn("Edit"){editingWorker=id;workerForm()})
    }


    internal fun MainActivity.workerAttendance(id:String){
        val b=page("Worker Attendance")
        app.attendance.list().filter{it.workerId==id}.sortedByDescending{it.date}.forEach{a->
            b.addView(btn("${displayDateOrRaw(a.date)} • ${a.status} • ${money(a.rate)}"){editingAttendance=a.id;attendanceForm(a)})
        }
    }


    internal fun MainActivity.workerWork(id:String){
        val b=page("Worker Work History")
        app.work.list().filter{id in it.workerIds}.sortedByDescending{it.date}.forEach{w->
            val ids=w.workerIds.distinct(); val allocated=if(ids.isEmpty()) 0.0 else app.calculation.workCost(w)/ids.size; b.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType} • ${money(allocated)}"){workDetail(w.id)})
        }
    }


    internal fun MainActivity.workerLedger(id:String){
        val b=page("Worker Ledger");val a=app.attendance.list();val w=app.work.list();val p=app.payments.list()
        val worker=app.workers.list().first{it.id==id};val ledger=app.calculation.ledger(id,a,w,p)
        b.addView(txt(worker.name,22f,true));b.addView(txt("Total Earned: ${money(ledger.earned)}",16f))
        b.addView(txt("Paid: ${money(ledger.normalPaid)}",16f));b.addView(txt("Advance: ${money(ledger.advance)}",16f));b.addView(txt("Total Paid: ${money(ledger.totalPaid)}",16f));b.addView(txt("Outstanding: ${money(ledger.outstanding)}",19f,true));if(ledger.credit>0)b.addView(txt("Credit / Overpaid: ${money(ledger.credit)}",16f,true))
        p.filter{it.workerId==id}.sortedByDescending{it.date}.forEach{x->b.addView(txt("${displayDateOrRaw(x.date)}  ${if(x.advance)"ADVANCE" else "PAYMENT"}  ${money(x.amount)}  ${x.method}",13f))}
    }


    internal fun MainActivity.workerWageHistory(id:String){
        val worker=app.workers.list().firstOrNull{it.id==id} ?: run{toast("Worker not found");return}
        val b=page("Wage History"); b.addView(txt(worker.name,22f,true))
        b.addView(btn("+ Add Wage Rate"){
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,4,12,4)}
            val d=dateField("Effective from",today); val r=field("Rate",worker.defaultRate.toString()); val u=field("Unit",worker.rateUnit); val n=field("Note")
            listOf(d,r,u,n).forEach{box.addView(it)}
            AlertDialog.Builder(this).setTitle("Add Wage Rate").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                try{
                    val rate=r.text.toString().toDoubleOrNull() ?: throw IllegalArgumentException("Invalid rate"); val unit=u.text.toString().trim().uppercase()
                    require(rate.isFinite() && rate>=0){"Rate must be non-negative."}; require(unit in setOf("DAY","HALF_DAY","HOUR","ACRE","QUANTITY","PIECE")){"Invalid wage unit."}
                    app.workers.saveWage(WorkerWageHistory(workerId=id,effectiveFrom=dateValue(d),rate=rate,rateUnit=unit,note=n.text.toString().trim())); toast("Wage rate saved"); workerWageHistory(id)
                }catch(e:Exception){toast(e.message ?: "Wage save failed")}
            }.show()
        })
        val rows=app.workers.wageHistory().filter{it.workerId==id}.sortedByDescending{it.effectiveFrom}
        if(rows.isEmpty()) b.addView(txt("No wage history recorded.",13f))
        rows.forEach{x->b.addView(btn("${displayDateOrRaw(x.effectiveFrom)} • ${money(x.rate)} / ${x.rateUnit}${if(x.note.isBlank())"" else " • ${x.note}"}"){
            AlertDialog.Builder(this).setTitle("Wage Rate").setMessage("Effective: ${displayDateOrRaw(x.effectiveFrom)}\nRate: ${money(x.rate)} / ${x.rateUnit}\nSource: ${x.source}${if(x.note.isBlank())"" else "\nNote: ${x.note}"}").setPositiveButton("OK",null).setNegativeButton("Delete"){_,_->try{app.workers.deleteWage(x.id);workerWageHistory(id)}catch(e:Exception){toast(e.message ?: "Delete failed")}}.show()
        })}
    }


    internal fun MainActivity.workerPayments(id:String){
        val b=page("Worker Payments");b.addView(btn("Add Payment"){paymentForm(id)})
        app.payments.list().filter{it.workerId==id}.forEach{x->b.addView(btn("${displayDateOrRaw(x.date)} • ${money(x.amount)} • ${x.method}"){paymentForm(id,x.id)})}
    }


    internal fun MainActivity.workerAdvances(id:String){
        val b=page("Worker Advances")
        b.addView(btn("Add Advance"){paymentForm(id, advanceDefault=true)})
        val advances=app.payments.list().filter{it.workerId==id && it.advance}.sortedByDescending{it.date}
        if(advances.isEmpty()) b.addView(txt("No advances recorded.",13f))
        advances.forEach{x->b.addView(btn("${displayDateOrRaw(x.date)} • ${money(x.amount)} • ${x.method}"){paymentForm(id,x.id)})}
        b.addView(txt("Total Advances: ${money(advances.sumOf{it.amount.coerceAtLeast(0.0)})}",16f,true))
    }


    internal fun MainActivity.fields(){
        val b=page("Fields");b.addView(btn("+ Add Field"){editingField=null;pendingFieldPhoto="";fieldForm()})
        app.fields.list().forEach{x->b.addView(btn("${x.name} • ${x.area} ${x.unit}"){fieldProfile(x.id)})}
    }


    internal fun MainActivity.fieldForm(id:String?=null){
        val actualId=id ?: editingField
        val old=app.fields.list().find{it.id==actualId};val b=page(if(actualId==null)"Add Field" else "Edit Field")
        val n=field("Field name",old?.name?:"");val a=field("Area",old?.area?.toString()?:"0");val u=field("Unit",old?.unit?:"acre")
        val l=field("Location",old?.location?:"");val soil=field("Soil type",old?.soilType?:"");val irr=field("Irrigation",old?.irrigation?:"");val notes=field("Notes",old?.notes?:"")
        listOf(n,a,u,l,soil,irr,notes).forEach{b.addView(it)}
        b.addView(btn(if(old?.photoUri.isNullOrBlank()) "Add Field Photo" else "Change Field Photo"){ val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)};startActivityForResult(i,2201) })
        if(!old?.photoUri.isNullOrBlank()) b.addView(btn("Remove Field Photo"){ pendingFieldPhoto=""; app.fields.save(old!!.copy(photoUri="")); fieldForm(actualId) })
        b.addView(btn("Save Field"){
            if(n.text.toString().trim().isBlank()){toast("Field name required");return@btn}
            val area=a.text.toString().trim().toDoubleOrNull()
            if(area==null || !area.isFinite() || area<0.0){toast("Enter a valid non-negative area");return@btn}
            if(u.text.toString().trim().isBlank()){toast("Field unit required");return@btn}
            try {
                app.fields.save(Field(old?.id?:UUID.randomUUID().toString(),n.text.toString().trim(),area,u.text.toString().trim(),l.text.toString().trim(),soil.text.toString().trim(),irr.text.toString().trim(),notes.text.toString(),if(pendingFieldPhoto.isNotBlank()) pendingFieldPhoto else (old?.photoUri ?: ""),true))
                pendingFieldPhoto=""
                toast("Field saved successfully");fields()
            } catch(e:Exception){toast(e.message ?: "Save failed")}
        })
        if(old!=null) b.addView(btn("Delete Field"){confirmDelete("Field"){app.fields.delete(old.id);fields()}})
    }


    internal fun MainActivity.crops(){
        val b=page("Crops")
        b.addView(btn("Crop Master"){cropMaster()})
        b.addView(btn("Crop Variety Master"){cropVarietyMaster()})
        b.addView(btn("+ Add Crop"){cropForm()})
        val rows=app.crops.list().sortedWith(compareBy<Crop>{it.name.lowercase()}.thenBy{it.variety.lowercase()}.thenByDescending{it.plantingDate})
        if(rows.isEmpty()) b.addView(txt("No crops added yet."))
        rows.forEach{x->val f=app.fields.list().find{it.id==x.fieldId}?.name?:"No field";b.addView(btn("${x.name} ${x.variety.ifBlank{"(Custom)"}} • $f • ${if(x.plantingDate.isBlank())"No date" else displayDateOrRaw(x.plantingDate)}"){cropProfile(x.id)})}
    }


    internal fun MainActivity.cropMaster(){
        val b=page("Crop Master")
        b.addView(txt("Crop master — names and varieties used in crop records",18f,true))
        val groups=app.crops.list().groupBy{it.name.trim().ifBlank{"Unnamed"}}.toSortedMap(String.CASE_INSENSITIVE_ORDER)
        if(groups.isEmpty()){b.addView(txt("No crop master entries yet."));b.addView(btn("+ Add Crop"){cropForm()});return}
        groups.forEach{(name,rows)->
            val varieties=rows.map{it.variety.trim().ifBlank{"Custom"}}.distinct().sorted()
            b.addView(txt("$name • ${rows.size} record${if(rows.size==1)"" else "s"}",16f,true))
            varieties.forEach{v->b.addView(btn("Variety: $v (${rows.count{it.variety.trim().ifBlank{"Custom"}==v}})"){val target=rows.firstOrNull{it.variety.trim().ifBlank{"Custom"}==v};if(target!=null)cropProfile(target.id)})}
        }
        b.addView(btn("+ Add Crop"){cropForm()})
    }


    internal fun MainActivity.cropVarietyMaster(){
        val b=page("Crop Variety Master"); val crops=app.crops.list().sortedBy{it.name.lowercase()}; b.addView(txt("Reusable crop varieties linked to crop records.",13f))
        b.addView(btn("+ Add Variety"){
            if(crops.isEmpty()){toast("Add a crop first");return@btn}
            val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,4,12,4)}; var cropId=crops.first().id
            val cropBtn=btn("Crop: ${crops.first().name}"); val name=field("Variety name"); val notes=field("Notes")
            cropBtn.setOnClickListener{AlertDialog.Builder(this).setTitle("Crop").setItems(crops.map{it.name}.toTypedArray()){_,i->cropId=crops[i].id;cropBtn.text="Crop: ${crops[i].name}"}.show()}
            listOf(cropBtn,name,notes).forEach{box.addView(it)}
            AlertDialog.Builder(this).setTitle("Add Crop Variety").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->try{app.crops.saveVariety(CropVariety(cropId=cropId,name=name.text.toString().trim(),notes=notes.text.toString().trim()));toast("Variety saved");cropVarietyMaster()}catch(e:Exception){toast(e.message ?: "Variety save failed")}}.show()
        })
        val varieties=app.crops.varieties().sortedWith(compareBy({crops.firstOrNull{c->c.id==it.cropId}?.name.orEmpty().lowercase()},{it.name.lowercase()}))
        if(varieties.isEmpty()) b.addView(txt("No varieties recorded.",13f))
        varieties.forEach{v->val cropName=crops.firstOrNull{it.id==v.cropId}?.name ?: "Unknown crop";b.addView(btn("$cropName • ${v.name}${if(v.notes.isBlank())"" else " • ${v.notes}"}"){AlertDialog.Builder(this).setTitle("${cropName} — ${v.name}").setMessage(if(v.notes.isBlank())"No notes" else v.notes).setPositiveButton("OK",null).setNegativeButton("Delete"){_,_->try{app.crops.deleteVariety(v.id);cropVarietyMaster()}catch(e:Exception){toast(e.message ?: "Delete failed")}}.show()})}
    }


    internal fun MainActivity.cropForm(id:String?=null){
        val old=app.crops.list().find{it.id==id};val b=page(if(id==null)"Add Crop" else "Edit Crop")
        val n=field("Crop name",old?.name?:"");val v=field("Variety",old?.variety?:"");val fields=app.fields.list().filter{it.active};var fieldId=old?.fieldId?:fields.firstOrNull()?.id.orEmpty();val fb=btn("Field: ${selectedName(fieldId,fields.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select field").setItems(fields.map{it.name}.toTypedArray()){_,i->fieldId=fields[i].id;it.text="Field: ${fields[i].name}"}.show()};val d=dateField("Planting date",old?.plantingDate?:today);val a=field("Area",old?.area?.toString()?:"0");val notes=field("Notes",old?.notes?:"")
        listOf(n,v,fb,d,a,notes).forEach{b.addView(it)}
        b.addView(btn("Save Crop"){
            if(n.text.isBlank()){toast("Crop name required");return@btn}
            if(fieldId.isBlank() || app.fields.list().none{it.id==fieldId}){toast("Select a field");return@btn}
            val cropArea=a.text.toString().trim().toDoubleOrNull() ?: run{toast("Area must be a valid number.");return@btn}
            if(!cropArea.isFinite() || cropArea<=0.0){toast("Crop area must be greater than zero");return@btn}
            val selectedField=app.fields.list().firstOrNull{it.id==fieldId} ?: throw IllegalArgumentException("Select a field")
            if(selectedField.area>0.0) require(cropArea<=selectedField.area){"Crop area cannot exceed field area (${selectedField.area})."}
            try {
                app.crops.save(Crop(old?.id?:UUID.randomUUID().toString(),n.text.toString().trim(),v.text.toString().trim(),fieldId,dateValue(d),cropArea,notes.text.toString(),true))
                toast("Crop saved successfully");crops()
            } catch(e:Exception){toast(e.message ?: "Save failed")}
        })
        if(old!=null) b.addView(btn("Delete Crop"){confirmDelete("Crop"){app.crops.delete(old.id);crops()}})
    }


    internal fun MainActivity.attendance(){
        val b=page("Today's Attendance")
        val date=dateField("Date",today)
        val fields=app.fields.list().filter{it.active}
        var fieldId=app.attendance.list().firstOrNull{it.date==today && it.fieldId.isNotBlank()}?.fieldId.orEmpty()
        val fieldBtn=btn("Field: ${if(fieldId.isBlank()) "Not linked" else selectedName(fieldId,fields.map{it.id to it.name})}")
        val selected=mutableSetOf<String>()
        val states=mutableMapOf<String,String>()
        val statusViews=mutableMapOf<String,TextView>()
        val checks=mutableMapOf<String,CheckBox>()
        val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}

        fun reloadSelection(){
            val chosenDate=runCatching{dateValue(date)}.getOrDefault(today)
            selected.clear(); states.clear()
            app.workers.list().filter{it.active}.forEach{w->
                val old=app.attendance.list().find{it.date==chosenDate && it.workerId==w.id && it.fieldId==fieldId}
                if(old!=null){selected.add(w.id);states[w.id]=old.status.uppercase()}
            }
            checks.values.forEach{it.isChecked=it.tag in selected}
            statusViews.forEach{(id,v)->v.text=states[id] ?: AttendanceRules.UNMARKED}
        }

        fieldBtn.setOnClickListener{
            val labels=arrayOf("Not linked")+fields.map{it.name}.toTypedArray()
            AlertDialog.Builder(this).setTitle("Select field").setItems(labels){_,i->
                fieldId=if(i==0) "" else fields[i-1].id
                fieldBtn.text="Field: ${if(i==0) "Not linked" else fields[i-1].name}"
                reloadSelection()
            }.show()
        }
        b.addView(fieldBtn); b.addView(date)
        b.addView(btn("Load Selected Date"){reloadSelection();toast("Attendance loaded for ${displayDateOrRaw(dateValue(date))}")})

        b.addView(btn("Select Saved Team — workers only"){
            val teams=app.teams.list()
            if(teams.isEmpty()){toast("No saved team");return@btn}
            AlertDialog.Builder(this).setTitle("Select saved team").setItems(teams.map{it.name}.toTypedArray()){_,i->
                selected.clear(); states.clear()
                selected.addAll(AttendanceRules.copyWorkersOnly(teams[i],app.workers.list().map{it.id}.toSet()))
                selected.forEach{id->states[id]=AttendanceRules.statusAfterWorkerSelection()}
                checks.values.forEach{it.isChecked=it.tag in selected}
                statusViews.forEach{(id,v)->v.text=states[id] ?: AttendanceRules.UNMARKED}
                toast("Team copied. Attendance statuses remain Unmarked.")
            }.show()
        })
        b.addView(btn("Previous Team — copy workers only"){
            val team=app.teams.list().lastOrNull()
            if(team==null) toast("No saved team") else {
                selected.clear(); states.clear()
                selected.addAll(AttendanceRules.copyWorkersOnly(team,app.workers.list().map{it.id}.toSet()))
                selected.forEach{id->states[id]=AttendanceRules.UNMARKED}
                checks.values.forEach{it.isChecked=it.tag in selected}
                statusViews.forEach{(id,v)->v.text=states[id] ?: AttendanceRules.UNMARKED}
                toast("Previous team copied. Attendance remains NONE until you set it.")
            }
        })
        attendanceRows(rows,date,selected,states,statusViews,checks)
        b.addView(rows)
        b.addView(btn("Select All"){
            app.workers.list().filter{it.active}.forEach{selected.add(it.id);states[it.id]=AttendanceRules.statusAfterWorkerSelection()}
            checks.values.forEach{it.isChecked=true};statusViews.forEach{(id,v)->v.text=states[id] ?: AttendanceRules.UNMARKED}
        })
        b.addView(btn("All Full"){
            selected.clear(); selected.addAll(app.workers.list().filter{it.active}.map{it.id})
            app.workers.list().filter{it.active}.forEach{states[it.id]="FULL"}
            checks.values.forEach{it.isChecked=true};statusViews.forEach{it.text="FULL"}
        })
        b.addView(btn("All Half"){
            selected.clear(); selected.addAll(app.workers.list().filter{it.active}.map{it.id})
            app.workers.list().filter{it.active}.forEach{states[it.id]="HALF"}
            checks.values.forEach{it.isChecked=true};statusViews.forEach{it.text="HALF"}
        })
        b.addView(btn("Clear All"){
            selected.clear(); states.clear()
            checks.values.forEach{it.isChecked=false};statusViews.forEach{it.text=AttendanceRules.UNMARKED}
        })
        b.addView(btn("Save Attendance"){
            try{
                val dateValue=dateValue(date); if(dateValue.isEmpty()) throw IllegalArgumentException("Date required")
                selected.forEach{id->
                    val w=app.workers.list().first{it.id==id}; val status=states[id] ?: AttendanceRules.UNMARKED
                    val old=app.attendance.list().find{it.date==dateValue&&it.workerId==id&&it.fieldId==fieldId}
                    app.attendance.save(Attendance(old?.id?:UUID.randomUUID().toString(),dateValue,id,fieldId,status,app.workers.wageFor(id,dateValue,w.defaultRate).first,old?.note ?: ""))
                }
                app.attendance.list().filter{it.date==dateValue && it.fieldId==fieldId && it.workerId !in selected}.forEach{app.attendance.delete(it.id)}
                toast("Attendance saved"); dashboard()
            }catch(e:Exception){toast(e.message ?: "Attendance save failed")}
        })
        b.addView(btn("Attendance History"){attendanceHistory()})
        b.addView(btn("Attendance Calendar"){attendanceCalendar()})
        b.addView(btn("Save Current Team"){saveTeamDialog(selected.toList())})
        reloadSelection()
    }


    internal fun MainActivity.attendanceRows(
        b:LinearLayout,
        date:EditText,
        selected:MutableSet<String>,
        states:MutableMap<String,String>,
        statusViews:MutableMap<String,TextView>,
        checks:MutableMap<String,CheckBox>
    ){
        app.workers.list().filter{it.active}.forEach{w->
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(4,2,4,2)}
            val cb=CheckBox(this).apply{
                text=w.name
                isChecked=w.id in selected
                tag=w.id
                setOnCheckedChangeListener{_,checked->
                    if(checked){selected.add(w.id);states[w.id]=AttendanceRules.statusAfterWorkerSelection(states[w.id])}
                    else{selected.remove(w.id);states[w.id]="NONE"}
                }
            }
            val status=TextView(this).apply{
                text=states[w.id] ?: "NONE";gravity=Gravity.CENTER;setPadding(5,5,5,5)
                setOnClickListener{ chooseStatus(w.id,this,states) }
            }
            checks[w.id]=cb;statusViews[w.id]=status
            r.addView(cb,LinearLayout.LayoutParams(0,dp(55),1f))
            r.addView(status,LinearLayout.LayoutParams(dp(110),dp(55)))
            b.addView(r)
        }
    }


    internal fun MainActivity.chooseStatus(id:String,status:TextView,states:MutableMap<String,String>){
        AlertDialog.Builder(this).setTitle("Attendance status").setItems(arrayOf("Full","Half","None / Unmarked")){_,i->
            val value=arrayOf("FULL","HALF","NONE")[i]
            states[id]=value
            status.text=value
        }.show()
    }


    internal fun MainActivity.saveTeamDialog(workerIds:List<String> = app.workers.list().map{it.id}){
        if(workerIds.isEmpty()){toast("No workers selected");return}
        val name=field("Team name")
        AlertDialog.Builder(this).setTitle("Save Team").setView(name)
            .setPositiveButton("Save"){_,_->
                val clean=workerIds.distinct().filter{id->app.workers.list().any{it.id==id}}
                app.teams.save(Team(name=name.text.toString().ifBlank{"Team ${app.teams.list().size+1}"},workerIds=clean.toMutableList()))
                toast("Team saved")
            }.setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.workList(){
        val b=page("Work")
        b.addView(btn("+ Add Work"){workForm()})
        b.addView(btn("Today's Work"){todayWorkList()})
        b.addView(btn("Work History"){workHistoryList()})
        b.addView(btn("Work Templates"){workTemplates()})
        val all=app.work.list().sortedByDescending{it.date}
        if(all.isEmpty()) b.addView(txt("No work records yet.",14f))
        all.forEach{w->
            val fieldName=app.fields.list().find{it.id==w.fieldId}?.name?:w.fieldId
            val cropName=app.crops.list().find{it.id==w.cropId}?.name?:w.cropId
            b.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType} • $fieldName / $cropName • ${money(app.calculation.workCost(w))}"){workDetail(w.id)})
        }
    }


    internal fun MainActivity.todayWorkList(){
        val b=page("Today's Work")
        val todayRows=app.work.list().filter{it.date==today}.sortedByDescending{it.startTime}
        b.addView(txt("Date: ${displayDateOrRaw(today)}",16f,true))
        b.addView(txt("Records: ${todayRows.size} • Labour: ${money(todayRows.sumOf{app.calculation.workCost(it)})}",14f,true))
        if(todayRows.isEmpty()) b.addView(txt("No work recorded for today.",14f))
        todayRows.forEach{w->
            val fieldName=app.fields.list().find{it.id==w.fieldId}?.name?:w.fieldId
            val cropName=app.crops.list().find{it.id==w.cropId}?.name?:w.cropId
            b.addView(btn("${w.workType} • $fieldName / $cropName • ${money(app.calculation.workCost(w))}"){workDetail(w.id)})
        }
    }


    internal fun MainActivity.workHistoryList(){
        val b=page("Work History")
        val fields=app.fields.list()
        val crops=app.crops.list()
        val workers=app.workers.list()
        var fieldId=""; var cropId=""; var workerId=""; var date=""
        val fb=btn("Field: All")
        val cb=btn("Crop: All")
        val wb=btn("Worker: All")
        val db=btn("Date: All")
        fun render(){
            b.removeViews(4,b.childCount-4)
            val rows=app.work.list().filter{
                (fieldId.isBlank()||it.fieldId==fieldId) &&
                (cropId.isBlank()||it.cropId==cropId) &&
                (workerId.isBlank()||workerId in it.workerIds) &&
                (date.isBlank()||it.date==date)
            }.sortedByDescending{it.date}
            if(rows.isEmpty()) b.addView(txt("No matching work records.",14f))
            rows.forEach{w->
                val fn=fields.find{it.id==w.fieldId}?.name?:w.fieldId
                val cn=crops.find{it.id==w.cropId}?.name?:w.cropId
                b.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType} • $fn / $cn • ${money(app.calculation.workCost(w))}"){workDetail(w.id)})
            }
        }
        fb.setOnClickListener{AlertDialog.Builder(this).setTitle("Filter field").setItems((listOf("All")+fields.map{it.name}).toTypedArray()){_,i->fieldId=if(i==0)"" else fields[i-1].id;fb.text="Field: ${if(i==0)"All" else fields[i-1].name}";render()}.show()}
        cb.setOnClickListener{AlertDialog.Builder(this).setTitle("Filter crop").setItems((listOf("All")+crops.map{it.name}).toTypedArray()){_,i->cropId=if(i==0)"" else crops[i-1].id;cb.text="Crop: ${if(i==0)"All" else crops[i-1].name}";render()}.show()}
        wb.setOnClickListener{AlertDialog.Builder(this).setTitle("Filter worker").setItems((listOf("All")+workers.map{it.name}).toTypedArray()){_,i->workerId=if(i==0)"" else workers[i-1].id;wb.text="Worker: ${if(i==0)"All" else workers[i-1].name}";render()}.show()}
        db.setOnClickListener{val e=dateField("Date filter",date);AlertDialog.Builder(this).setTitle("Work date").setView(e).setNegativeButton("Clear"){_,_->date="";db.text="Date: All";render()}.setPositiveButton("Apply"){_,_->date=if(e.text.isNullOrBlank())"" else dateValue(e);db.text="Date: ${if(date.isBlank())"All" else displayDateOrRaw(date)}";render()}.show()}
        listOf(fb,cb,wb,db).forEach{b.addView(it)}
        render()
    }


    internal fun MainActivity.production(){
        val b=page("Production")
        b.addView(btn("+ Add Production"){productionForm()})
        app.accounting.production().sortedByDescending{it.date}.forEach{x->{val crop=app.crops.list().find{it.id==x.cropId}?.name?:"Unknown";b.addView(btn("${displayDateOrRaw(x.date)} • $crop • ${x.quantity} ${x.unit}"){productionForm(x.id)})}}
    }


    internal fun MainActivity.productionForm(id:String?=null){
        val old=app.accounting.production().find{it.id==id}; val b=page(if(id==null)"Add Production" else "Edit Production")
        val crops=app.crops.list().filter{it.active}; var cropId=old?.cropId ?: crops.firstOrNull()?.id.orEmpty()
        val cropBtn=btn("Crop: ${selectedName(cropId,crops.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select crop").setItems(crops.map{it.name}.toTypedArray()){_,i->cropId=crops[i].id;it.text="Crop: ${crops[i].name}"}.show()}
        val d=dateField("Date",old?.date?:today);val q=field("Quantity",old?.quantity?.toString()?:"0");val u=field("Unit",old?.unit?:"kg");val n=field("Note",old?.note?:"")
        b.addView(cropBtn);listOf(d,q,u,n).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.accounting.saveProduction(Production(old?.id?:UUID.randomUUID().toString(),cropId,dateValue(d),q.text.toString().toDoubleOrNull()?:0.0,u.text.toString().trim(),n.text.toString()));production()}catch(e:Exception){toast(e.message?:"Save failed")}})
        if(old!=null)b.addView(btn("Delete Production"){confirmDelete("Production"){app.accounting.deleteProduction(old.id);production()}})
    }


    internal fun MainActivity.revenue(){
        val b=page("Revenue");b.addView(btn("+ Add Revenue"){revenueForm()});app.accounting.revenue().sortedByDescending{it.date}.forEach{x->{val crop=app.crops.list().find{it.id==x.cropId}?.name?:"Unknown";b.addView(btn("${displayDateOrRaw(x.date)} • $crop • ${money(x.amount)}"){revenueForm(x.id)})}}
    }


    internal fun MainActivity.revenueForm(id:String?=null){
        val old=app.accounting.revenue().find{it.id==id};val b=page(if(id==null)"Add Revenue" else "Edit Revenue");val crops=app.crops.list().filter{it.active};var cropId=old?.cropId?:crops.firstOrNull()?.id.orEmpty()
        val cropBtn=btn("Crop: ${selectedName(cropId,crops.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select crop").setItems(crops.map{it.name}.toTypedArray()){_,i->cropId=crops[i].id;it.text="Crop: ${crops[i].name}"}.show()}
        val d=dateField("Date",old?.date?:today);val a=field("Amount",old?.amount?.toString()?:(""));val n=field("Note",old?.note?:"");b.addView(cropBtn);listOf(d,a,n).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.accounting.saveRevenue(Revenue(old?.id?:UUID.randomUUID().toString(),cropId,dateValue(d),a.text.toString().toDoubleOrNull()?:0.0,n.text.toString()));revenue()}catch(e:Exception){toast(e.message?:"Save failed")}})
        if(old!=null)b.addView(btn("Delete Revenue"){confirmDelete("Revenue"){app.accounting.deleteRevenue(old.id);revenue()}})
    }


    internal fun MainActivity.addWork(){workForm()}

    internal fun MainActivity.workForm(id:String?=null){
        val old=app.work.list().find{it.id==id};val b=page(if(id==null)"Add Work" else "Edit Work")
        val fields=app.fields.list().filter{it.active};val crops=app.crops.list().filter{it.active};val workers=app.workers.list().filter{it.active}
        var fieldId=old?.fieldId?:fields.firstOrNull()?.id.orEmpty();var cropId=old?.cropId?:crops.firstOrNull()?.id.orEmpty();var selectedWorkers=old?.workerIds?.toMutableList()?:mutableListOf()
        val fieldBtn=btn("Field: ${selectedName(fieldId,fields.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select field").setItems(fields.map{it.name}.toTypedArray()){_,i->fieldId=fields[i].id;it.text="Field: ${fields[i].name}"}.show()}
        val cropBtn=btn("Crop: ${selectedName(cropId,crops.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select crop").setItems(crops.map{it.name}.toTypedArray()){_,i->cropId=crops[i].id;it.text="Crop: ${crops[i].name}"}.show()}
        val workerBtn=btn("Workers: ${selectedWorkers.size}"){
            val checked=workers.map{selectedWorkers.contains(it.id)}.toBooleanArray()
            AlertDialog.Builder(this).setTitle("Select workers").setMultiChoiceItems(workers.map{it.name}.toTypedArray(),checked){_,which,on->if(on)selectedWorkers.add(workers[which].id)else selectedWorkers.remove(workers[which].id)}.setPositiveButton("Done"){_,_->it.text="Workers: ${selectedWorkers.distinct().size}"}.show()
        }
        val d=dateField("Date",old?.date?:today);val t=field("Work type",old?.workType?:"Weeding");val workTypeBtn=btn("Work Type Presets"){AlertDialog.Builder(this).setTitle("Select work type").setItems(app.calculation.workTypes().toTypedArray()){_,i->t.setText(app.calculation.workTypes()[i])}.show()};var rateType=app.calculation.normalize(old?.rateType?:"QUANTITY",old?.unit?:"acre");val rateTypeBtn=btn("Rate type: $rateType"){AlertDialog.Builder(this).setTitle("Select rate type").setItems(app.calculation.rateTypes().toTypedArray()){_,i->rateType=app.calculation.rateTypes()[i];it.text="Rate type: $rateType"}.show()};val q=field("Quantity",old?.quantity?.toString()?:"0");val u=field("Unit",old?.unit?:"acre");val r=field("Rate",old?.rate?.toString()?:"0");val st=field("Start time",old?.startTime?:"");val et=field("End time",old?.endTime?:"");val notes=field("Notes",old?.notes?:"")
        val templateBtn=btn("Apply Work Template"){
            val ts=app.work.templates(); if(ts.isEmpty()){toast("No work templates saved")}else AlertDialog.Builder(this).setTitle("Select template").setItems(ts.map{it.name}.toTypedArray()){_,i->t.setText(ts[i].workType);rateType=app.calculation.normalize(ts[i].rateType,ts[i].unit);rateTypeBtn.text="Rate type: $rateType";u.setText(ts[i].unit);r.setText(ts[i].rate.toString());notes.setText(ts[i].notes)}.show()
        }
        b.addView(templateBtn)
        b.addView(workTypeBtn)
        val startBtn=btn("Pick Start Time"){val now=Calendar.getInstance();TimePickerDialog(this,{_,h,m->st.setText(String.format(Locale.US,"%02d:%02d",h,m))},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show()}
        val endBtn=btn("Pick End Time"){val now=Calendar.getInstance();TimePickerDialog(this,{_,h,m->et.setText(String.format(Locale.US,"%02d:%02d",h,m))},now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),true).show()}
        listOf(fieldBtn,cropBtn,workerBtn,d,t,rateTypeBtn,q,u,r,startBtn,st,endBtn,et,notes).forEach{b.addView(it)}
        b.addView(btn("Save Work"){try{val ids=selectedWorkers.distinct();if(d.text.toString().trim().isEmpty())throw IllegalArgumentException("Date required");if(t.text.toString().trim().isEmpty())throw IllegalArgumentException("Work type required");if(u.text.toString().trim().isEmpty())throw IllegalArgumentException("Unit required");if(ids.isEmpty())throw IllegalArgumentException("Select at least one worker");app.work.save(WorkRecord(old?.id?:UUID.randomUUID().toString(),dateValue(d),fieldId,cropId,t.text.toString(),q.text.toString().toDoubleOrNull()?:0.0,rateType,u.text.toString(),r.text.toString().toDoubleOrNull()?:0.0,ids.toMutableList(),st.text.toString(),et.text.toString(),notes.text.toString()));toast("Work saved");workList()}catch(e:Exception){toast(e.message?:"Save failed")}})
    }


    internal fun MainActivity.workDetail(id:String){val w=app.work.list().first{it.id==id};val b=page("Work Detail");val fn=app.fields.list().find{it.id==w.fieldId}?.name?:"Unknown";val cn=app.crops.list().find{it.id==w.cropId}?.name?:"Unknown";val wn=w.workerIds.mapNotNull{id2->app.workers.list().find{it.id==id2}?.name}.joinToString(", ");b.addView(txt("${displayDateOrRaw(w.date)} • ${w.workType}",22f,true));b.addView(txt("Total labour cost: ${money(app.calculation.workCost(w))}",17f,true));b.addView(txt("Allocated per worker: ${money(if(w.workerIds.isEmpty()) 0.0 else (app.calculation.workCost(w))/w.workerIds.distinct().size)}",14f));b.addView(txt("Field: $fn\nCrop: $cn\nWorkers: $wn\nWork Type: ${w.workType}\nRate Type: ${app.calculation.normalize(w.rateType,w.unit)}\nQuantity: ${w.quantity} ${w.unit}\nRate: ${money(w.rate)} / ${w.unit}\nLabour Cost: ${money(app.calculation.workCost(w))}\nStart Time: ${w.startTime.ifBlank{"—"}}\nEnd Time: ${w.endTime.ifBlank{"—"}}\nNotes: ${w.notes.ifBlank{"—"}}",13f));b.addView(btn("Work Audit History"){workAuditHistory(id)})
        b.addView(btn("Edit"){workForm(id)});b.addView(btn("Delete"){confirmDelete("Work"){app.work.delete(id);workList()}})}


    internal fun MainActivity.workAuditHistory(id:String){
        val b=page("Work Audit History")
        val entries=app.audit.auditLog().filter{it.optString("entity")=="work" && it.optString("entityId")==id}.sortedByDescending{it.optLong("timestamp",0L)}
        if(entries.isEmpty()) b.addView(txt("No audit events for this work record.",14f))
        entries.forEach{e->
            val whenText=displayTimestamp(e.optLong("timestamp",0L))
            b.addView(txt("$whenText • ${e.optString("action")} • ${e.optString("summary")}",14f))
        }
    }


    internal fun MainActivity.payments(){val b=page("Payments");b.addView(btn("Pay Worker"){paymentForm()});b.addView(btn("Advance"){paymentForm(advanceDefault=true)});app.payments.list().sortedByDescending{it.date}.forEach{x->{val n=app.workers.list().find{it.id==x.workerId}?.name?:"Unknown";b.addView(btn("${displayDateOrRaw(x.date)} • $n • ${money(x.amount)} • ${if(x.advance)"ADVANCE" else x.method}"){paymentForm(x.workerId,x.id)})}}}

    internal fun MainActivity.paymentForm(workerId:String?=null,paymentId:String?=null,advanceDefault:Boolean=false){
        val old=paymentId?.let{pid->app.payments.list().find{it.id==pid}};val b=page(if(old==null)"Payment" else "Edit Payment");val workers=app.workers.list().filter{it.active};var wid=old?.workerId?:workerId?:workers.firstOrNull()?.id.orEmpty();var advance=old?.advance?:advanceDefault
        val wb=btn("Worker: ${selectedName(wid,workers.map{it.id to it.name})}"){AlertDialog.Builder(this).setTitle("Select worker").setItems(workers.map{it.name}.toTypedArray()){_,i->wid=workers[i].id;it.text="Worker: ${workers[i].name}"}.show()};val d=dateField("Date",old?.date?:today);val a=field("Amount",old?.amount?.toString()?:"");var method=old?.method?:"Cash";val mb=btn("Method: $method"){val methods=arrayOf("Cash","Bank","UPI");AlertDialog.Builder(this).setTitle("Payment method").setItems(methods){_,i->method=methods[i];it.text="Method: ${methods[i]}"}.show()};val adv=btn("Advance: ${if(advance)"YES" else "NO"}"){advance=!advance;it.text="Advance: ${if(advance)"YES" else "NO"}"};val ref=field("Reference",old?.reference?:"");val notes=field("Notes",old?.notes?:"");listOf(wb,d,a,mb,adv,ref,notes).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.payments.save(Payment(old?.id?:UUID.randomUUID().toString(),wid,dateValue(d),a.text.toString().toDoubleOrNull()?:0.0,method,advance,ref.text.toString(),notes.text.toString()));payments()}catch(e:Exception){toast(e.message?:"Payment failed")}});if(old!=null)b.addView(btn("Delete Payment"){confirmDelete("Payment"){app.payments.delete(old.id);payments()}})
    }


    internal fun MainActivity.expenses(){val b=page("Expenses");b.addView(btn("+ Add Expense"){expenseForm()});app.expenses.list().sortedByDescending{it.date}.forEach{x->b.addView(btn("${displayDateOrRaw(x.date)} • ${x.category} • ${money(x.amount)}"){expenseForm(x.id)})}}

    internal fun MainActivity.expenseForm(id:String?=null){
        val old=app.expenses.list().find{it.id==id};val b=page(if(id==null)"Add Expense" else "Edit Expense");val fields=app.fields.list();val crops=app.crops.list();var fieldId=old?.fieldId.orEmpty();var cropId=old?.cropId.orEmpty();val requiredCats=listOf("Labour","Fertilizer","Seed","Pesticide","Irrigation","Machinery","Diesel","Transport","Repair","Other");val configured=(prefs.getString("expense_categories", "") ?: "").split(",").map{it.trim()}.filter{it.isNotBlank()};val cats=(requiredCats+configured).distinct();var cat=old?.category?:cats[0]
        val cb=btn("Category: $cat"){AlertDialog.Builder(this).setTitle("Expense category").setItems(cats.toTypedArray()){_,i->cat=cats[i];it.text="Category: $cat"}.show()};val fb=btn("Field: ${if(fieldId.isBlank())"Not linked" else selectedName(fieldId,fields.map{it.id to it.name})}"){val labels=listOf("Not linked")+fields.map{it.name};AlertDialog.Builder(this).setTitle("Select field").setItems(labels.toTypedArray()){_,i->if(i==0){fieldId="";it.text="Field: Not linked"}else{fieldId=fields[i-1].id;it.text="Field: ${fields[i-1].name}"}}.show()};val crb=btn("Crop: ${if(cropId.isBlank())"Not linked" else selectedName(cropId,crops.map{it.id to it.name})}"){val labels=listOf("Not linked")+crops.map{it.name};AlertDialog.Builder(this).setTitle("Select crop").setItems(labels.toTypedArray()){_,i->if(i==0){cropId="";it.text="Crop: Not linked"}else{cropId=crops[i-1].id;it.text="Crop: ${crops[i-1].name}"}}.show()};val d=dateField("Date",old?.date?:today);val a=field("Amount",old?.amount?.toString()?:(""));val n=field("Notes",old?.notes?:"");listOf(cb,fb,crb,d,a,n).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.expenses.save(Expense(old?.id?:UUID.randomUUID().toString(),dateValue(d),cat,a.text.toString().toDoubleOrNull()?:0.0,fieldId,cropId,n.text.toString()));expenses()}catch(e:Exception){toast(e.message?:"Save failed")}});if(old!=null)b.addView(btn("Delete Expense"){confirmDelete("Expense"){app.expenses.delete(old.id);expenses()}})
    }


    internal fun MainActivity.reportFiltersDialog(){
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,8,16,8)}
        val from=dateField("From date",prefs.getString("report_from", "") ?: "")
        val to=dateField("To date",prefs.getString("report_to", "") ?: "")
        val workers=app.workers.list().filter{it.active}; val fields=app.fields.list().filter{it.active}; val crops=app.crops.list().filter{it.active}
        var wid=prefs.getString("report_worker", "") ?: ""; var fid=prefs.getString("report_field", "") ?: ""; var cid=prefs.getString("report_crop", "") ?: ""
        val wb=btn("Worker: ${if(wid.isBlank())"All" else selectedName(wid,workers.map{it.id to it.name})}"){ val labels=listOf("All")+workers.map{it.name}; AlertDialog.Builder(this).setTitle("Worker").setItems(labels.toTypedArray()){_,i->wid=if(i==0)"" else workers[i-1].id; it.text="Worker: ${if(i==0)"All" else workers[i-1].name}"}.show() }
        val fb=btn("Field: ${if(fid.isBlank())"All" else selectedName(fid,fields.map{it.id to it.name})}"){ val labels=listOf("All")+fields.map{it.name}; AlertDialog.Builder(this).setTitle("Field").setItems(labels.toTypedArray()){_,i->fid=if(i==0)"" else fields[i-1].id; it.text="Field: ${if(i==0)"All" else fields[i-1].name}"}.show() }
        val cb=btn("Crop: ${if(cid.isBlank())"All" else selectedName(cid,crops.map{it.id to it.name})}"){ val labels=listOf("All")+crops.map{it.name}; AlertDialog.Builder(this).setTitle("Crop").setItems(labels.toTypedArray()){_,i->cid=if(i==0)"" else crops[i-1].id; it.text="Crop: ${if(i==0)"All" else crops[i-1].name}"}.show() }
        listOf(from,to,wb,fb,cb).forEach{b.addView(it)}
        AlertDialog.Builder(this).setTitle("Report Filters").setView(b).setPositiveButton("Save"){_,_->prefs.edit().putString("report_from",runCatching { dateValue(from) }.getOrDefault("")).putString("report_to",runCatching { dateValue(to) }.getOrDefault("")).putString("report_worker",wid).putString("report_field",fid).putString("report_crop",cid).apply();toast("Report filters saved")}.setNeutralButton("Clear"){_,_->prefs.edit().remove("report_from").remove("report_to").remove("report_worker").remove("report_field").remove("report_crop").apply();toast("Report filters cleared")}.setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.reports(){
        val b=page("Reports Home")
        val names=listOf("Daily Labour","Weekly Labour","Monthly Labour","Worker Report","Field Report","Crop Report","Attendance Report","Payment Report","Expense Report","Outstanding Report","Labour Cost Report","Profit/Loss Report","Custom Report")
        b.addView(btn("Report Filters"){reportFiltersDialog()})
        b.addView(btn("Custom Date Range Report"){customReport()})
        names.forEach{s->b.addView(btn(s){reportView(s)})}
        b.addView(btn("Export Workers CSV"){exportType="workers";createDocument("text/csv","workers.csv")})
        b.addView(btn("Export Ledger CSV"){exportType="ledger";createDocument("text/csv","worker_ledger.csv")})
        b.addView(btn("Export Labour PDF"){exportType="pdf";createDocument("application/pdf","labour_report.pdf")})
    }


    internal fun MainActivity.currentReportFilter(): com.majdoor.hisaab.report.ReportFilter = com.majdoor.hisaab.report.ReportFilter(
        prefs.getString("report_from", "") ?: "",
        prefs.getString("report_to", "") ?: "",
        prefs.getString("report_worker", "") ?: "",
        prefs.getString("report_field", "") ?: "",
        prefs.getString("report_crop", "") ?: ""
    )


    internal fun MainActivity.reportView(title:String, forcedFieldId:String?=null){
        val b=page(title)
        val base=app.reports.period(title,currentReportFilter(),today)
        val f=if(forcedFieldId.isNullOrBlank()) base else base.copy(fieldId=forcedFieldId)
        val d=app.reports.preview(f,app.attendance.list(),app.work.list(),app.payments.list(),app.expenses.list(),app.accounting.revenue(),app.accounting.production(),app.crops.list().associate { it.id to it.fieldId })
        val workers=app.workers.list().associateBy{it.id}; val fields=app.fields.list().associateBy{it.id}
        fun workerLine(w:Worker){ val s=app.reports.workerSummary(w,d); b.addView(txt("${w.name}: Earned ${money(s.earned)} | Paid ${money(s.normalPaid)} | Advance ${money(s.advance)} | Outstanding ${money(s.outstanding)}${if(s.credit>0) " | Credit ${money(s.credit)}" else ""}",13f)) }
        when(title){
            "Daily Labour" -> { val day=if(f.from.isNotBlank())f.from else if(f.to.isNotBlank())f.to else today; val x=d.copy(attendance=d.attendance.filter{it.date==day},work=d.work.filter{it.date==day}); b.addView(txt("Date: ${displayDateOrRaw(day)}",16f,true)); b.addView(txt("Full ${x.attendance.count{it.status.equals("FULL",true)}} • Half ${x.attendance.count{it.status.equals("HALF",true)}} • Unmarked ${x.attendance.count{it.status.equals("NONE",true)}}",14f)); b.addView(txt("Attendance wages: ${money(x.attendanceCost())} | Work cost: ${money(x.workCost())} | Total labour: ${money(x.totalLabourCost())}",14f,true)) }
            "Weekly Labour", "Monthly Labour" -> { b.addView(txt("Period: ${if(f.from.isBlank())"All dates" else f.from} → ${if(f.to.isBlank())"All dates" else f.to}",16f,true)); b.addView(txt("Attendance wages: ${money(d.attendanceCost())}",14f)); b.addView(txt("Work cost: ${money(d.workCost())}",14f)); b.addView(txt("Total labour cost: ${money(d.totalLabourCost())}",16f,true)) }
            "Worker Report", "Outstanding Report" -> { (if(f.workerId.isBlank())app.workers.list() else app.workers.list().filter{it.id==f.workerId}).forEach(::workerLine) }
            "Payment Report" -> { b.addView(txt("Total payments: ${money(d.payments.sumOf{it.amount.coerceAtLeast(0.0)})} | Advances: ${money(d.payments.filter{it.advance}.sumOf{it.amount.coerceAtLeast(0.0)})}",15f,true)); d.payments.sortedByDescending{it.date}.forEach{p->b.addView(txt("${displayDateOrRaw(p.date)} • ${workers[p.workerId]?.name?:"Unknown"} • ${money(p.amount)} • ${if(p.advance)"Advance" else p.method}",12f))} }
            "Field Report", "Field Cost Report" -> { val list=if(f.fieldId.isBlank())app.fields.list() else app.fields.list().filter{it.id==f.fieldId}; list.forEach{fld-> val labour=d.attendance.filter{it.fieldId==fld.id}.sumOf{when(it.status.uppercase()){ "FULL"->it.rate; "HALF"->it.rate/2.0; else->0.0 }}+d.work.filter{it.fieldId==fld.id}.sumOf{app.calculation.workCost(it)}; val exp=d.expenses.filter{it.fieldId==fld.id}.sumOf{it.amount}; val cropIds=app.crops.list().filter{it.fieldId==fld.id}.map{it.id}.toSet(); val rev=d.revenues.filter{it.cropId in cropIds}.sumOf{it.amount}; b.addView(txt("${fld.name}: Labour ${money(labour)} | Expenses ${money(exp)} | Revenue ${money(rev)} | Profit/Loss ${money(rev-labour-exp)}",13f))} }
            "Crop Report", "Crop Cost Report" -> { val list=if(f.cropId.isBlank())app.crops.list() else app.crops.list().filter{it.id==f.cropId}; list.forEach{c-> val labour=d.work.filter{it.cropId==c.id}.sumOf{app.calculation.workCost(it)}; val exp=d.expenses.filter{it.cropId==c.id}.sumOf{it.amount}; val income=d.revenues.filter{it.cropId==c.id}.sumOf{it.amount}; val prod=d.production.filter{it.cropId==c.id}.sumOf{it.quantity}; b.addView(txt("${c.name}: Production $prod | Labour ${money(labour)} | Other Cost ${money(exp)} | Revenue ${money(income)} | Profit/Loss ${money(income-labour-exp)}",13f))} }
            "Attendance Report" -> { b.addView(txt("Attendance wage: ${money(d.attendanceCost())}",15f,true)); d.attendance.sortedByDescending{it.date}.forEach{a->b.addView(txt("${displayDateOrRaw(a.date)} • ${workers[a.workerId]?.name?:"Unknown"} • ${fields[a.fieldId]?.name?:""} • ${a.status} • ${money(a.rate)}",12f))} }
            "Expense Report" -> {
                b.addView(txt("Total expenses: ${money(d.expenseCost())}",15f,true))
                val byCategory=d.expenses.groupBy{it.category}.mapValues{(_,items)->items.sumOf{it.amount}}
                if(byCategory.isEmpty()) b.addView(txt("No expense records in the selected filters.",13f))
                else {
                    b.addView(txt("Category totals",14f,true))
                    byCategory.toSortedMap().forEach{(category,total)->b.addView(txt("$category: ${money(total)}",13f))}
                }
                d.expenses.sortedByDescending{it.date}.forEach{e->b.addView(txt("${displayDateOrRaw(e.date)} • ${e.category} • ${money(e.amount)}",12f))}
            }
            "Labour Cost Report" -> { b.addView(txt("Attendance: ${money(d.attendanceCost())}",15f,true)); b.addView(txt("Work: ${money(d.workCost())}",15f,true)); b.addView(txt("Total labour cost: ${money(d.totalLabourCost())}",17f,true)) }
            "Profit/Loss Report" -> { b.addView(txt("Revenue: ${money(d.revenueTotal())}",17f,true)); b.addView(txt("Labour: ${money(d.totalLabourCost())}",15f)); b.addView(txt("Other costs: ${money(d.expenseCost())}",15f)); b.addView(txt("Tracked cost: ${money(d.trackedCost())}",15f)); b.addView(txt("Profit/Loss: ${money(d.profitLoss())}",20f,true)); b.addView(txt("Only recorded revenue and tracked costs are included.",12f)) }
            "Custom Report" -> { b.addView(txt("Date: ${if(f.from.isBlank())"All" else f.from} → ${if(f.to.isBlank())"All" else f.to}",14f)); b.addView(txt("Attendance wages: ${money(d.attendanceCost())}",14f)); b.addView(txt("Work cost: ${money(d.workCost())}",14f)); b.addView(txt("Payments: ${money(d.payments.sumOf{it.amount})}",14f)); b.addView(txt("Expenses: ${money(d.expenseCost())}",14f)); b.addView(txt("Revenue: ${money(d.revenueTotal())}",14f)); b.addView(txt("Profit/Loss: ${money(d.profitLoss())}",17f,true)) }
        }
        b.addView(btn("Export ${title} CSV"){exportType="report:$title";createDocument("text/csv","${title.replace(" ","_")}.csv")})
        b.addView(btn("Export ${title} PDF"){exportType="reportpdf:$title";createDocument("application/pdf","${title.replace(" ","_")}.pdf")})
    }


    internal fun MainActivity.backup(){
        val b=page("Backup & Restore");b.addView(txt("OFFLINE JSON STORAGE — no database",15f,true));b.addView(txt(app.backup.storageInfo(),12f));
        b.addView(btn("Create Local Backup"){try{val f=app.backup.create();toast("Backup created: ${f.name}")}catch(e:Exception){toast(e.message?:"Backup failed")}})
        b.addView(btn("Export Backup to Phone Storage"){exportType="backup";createDocument("application/zip","Majdoor_Hisaab_Backup.zip")})
        b.addView(btn("Import Data (Merge)"){openImport()})
        b.addView(btn("Restore Backup (Replace)"){openBackup()})
        b.addView(btn("Data Health"){AlertDialog.Builder(this).setTitle("Data Health").setMessage(app.backup.health().joinToString("\n")).setPositiveButton("OK",null).show()})
    }


    internal fun MainActivity.createDocument(type:String,name:String){startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{this.type=type;putExtra(Intent.EXTRA_TITLE,name)},1001)}
    internal fun MainActivity.openBackup(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";addCategory(Intent.CATEGORY_OPENABLE)},1002)}
    internal fun MainActivity.openImport(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="application/zip";addCategory(Intent.CATEGORY_OPENABLE)},1003)}

    internal fun MainActivity.persistUriPermission(uri: android.net.Uri, data: Intent?) {
        val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        if (flags != 0) {
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: SecurityException) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            } catch (_: Exception) {}
        }
    }


    internal fun MainActivity.handleActivityResult(req:Int,res:Int,data:Intent?){
        if(res!=Activity.RESULT_OK||data?.data==null)return
        val uri=data.data!!
        try{
            if(req==2200){ persistUriPermission(uri, data); pendingWorkerPhoto=uri.toString(); toast("Worker photo selected"); workerForm(); return }
            else if(req==2201){ applySelectedFieldPhoto(uri, data); return }
            else if(req==2100){
                val wid=documentWorkerId ?: return
                try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
                app.workers.saveDocument(WorkerDocument(workerId=wid,name=uri.lastPathSegment?:"Document",uri=uri.toString()))
                toast("Document saved"); workerDocuments(wid); return
            } else if(req==1001){
                contentResolver.openOutputStream(uri)!!.use{out->when(exportType){
                    "workers"->app.export.csvWorkers(out)
                    "ledger"->app.export.csvLedger(out)
                    exportType.startsWith("report:")->app.export.csvReport(exportType.removePrefix("report:"),out)
                    exportType.startsWith("reportpdf:")->app.export.pdfReport(exportType.removePrefix("reportpdf:"),out)
                    "pdf"->app.export.pdfSummary(out)
                    "backup"->app.backup.export(out)
                }}
            } else if(req==1002){
                contentResolver.openInputStream(uri)!!.use{input->{val v=app.backup.validate(input);if(!v.first)throw IllegalArgumentException(v.second)}}
                AlertDialog.Builder(this).setTitle("Restore backup?").setMessage("Current local data will be replaced after validation. A rollback is attempted automatically if restore fails.").setNegativeButton("Cancel",null).setPositiveButton("Restore"){_,_->try{contentResolver.openInputStream(uri)!!.use{app.backup.restore(it)};toast("Restore successful");dashboard()}catch(e:Exception){toast("Restore failed: ${e.message}")}}.show();return
            } else if(req==1003){
                contentResolver.openInputStream(uri)!!.use{input->{val v=app.backup.validate(input);if(!v.first)throw IllegalArgumentException(v.second)}}
                AlertDialog.Builder(this).setTitle("Import data?").setMessage("Import will MERGE this backup with current data. Existing records are never silently overwritten. Identical records are skipped. If the same ID contains different data, the import stops safely and no live data is changed.").setNegativeButton("Cancel",null).setPositiveButton("Import"){_,_->try{val result=contentResolver.openInputStream(uri)!!.use{app.backup.merge(it)};toast(result);dashboard()}catch(e:Exception){toast("Import stopped: ${e.message}")}}.show();return
            }
            toast("Export successful"); dashboard()
        }catch(e:Exception){toast("Operation failed: ${e.message}")}
    }


    internal fun MainActivity.settings(){
        val b=page("Settings");b.addView(btn("Farm Profile"){farmProfileDialog()});b.addView(btn("Wage Settings"){wageSettingsDialog()});b.addView(btn("Currency"){currencyDialog()});b.addView(btn("Date Format"){dateFormatDialog()});b.addView(btn("Theme"){themeDialog()});b.addView(btn("Security / PIN"){pinDialog()});b.addView(btn("Biometric Unlock"){biometricToggle()}); b.addView(btn("Auto-Lock"){autoLockDialog()});b.addView(btn("Report Settings"){reportSettingsDialog()})
        b.addView(btn("Auto Backup"){autoBackupDialog()});b.addView(btn("Notifications"){notificationSettingsDialog()});b.addView(btn("Audit Log"){auditLogScreen()});b.addView(btn("Expense Categories"){expenseCategoriesDialog()});b.addView(btn("Backup Settings"){backupSettingsDialog()});b.addView(btn("About"){aboutDialog()})
    }


    internal fun MainActivity.reportSettingsDialog(){
        val pageSizes=arrayOf("A4","Letter")
        val orientations=arrayOf("Portrait","Landscape")
        val currentSize=prefs.getString("report_page_size","A4") ?: "A4"
        val currentOrientation=prefs.getString("report_orientation","Portrait") ?: "Portrait"
        val header=CheckBox(this).apply{text="Include report header";isChecked=prefs.getBoolean("report_include_header",true)}
        val filters=CheckBox(this).apply{text="Include filter/date summary";isChecked=prefs.getBoolean("report_include_filters",true)}
        val footer=CheckBox(this).apply{text="Include page footer";isChecked=prefs.getBoolean("report_include_footer",true)}
        val csvHeaders=CheckBox(this).apply{text="Include CSV column headers";isChecked=prefs.getBoolean("report_csv_headers",true)}
        val csvBom=CheckBox(this).apply{text="Excel-compatible CSV (UTF-8 BOM)";isChecked=prefs.getBoolean("report_csv_bom",true)}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        box.addView(TextView(this).apply{text="PDF page size";textSize=14f;setPadding(0,8,0,4)})
        val sizeSpinner=Spinner(this).apply{adapter=ArrayAdapter(this@reportSettingsDialog,android.R.layout.simple_spinner_dropdown_item,pageSizes);setSelection(pageSizes.indexOf(currentSize).coerceAtLeast(0))}
        box.addView(sizeSpinner)
        box.addView(TextView(this).apply{text="PDF orientation";textSize=14f;setPadding(0,12,0,4)})
        val orientationSpinner=Spinner(this).apply{adapter=ArrayAdapter(this@reportSettingsDialog,android.R.layout.simple_spinner_dropdown_item,orientations);setSelection(orientations.indexOf(currentOrientation).coerceAtLeast(0))}
        box.addView(orientationSpinner)
        box.addView(header);box.addView(filters);box.addView(footer);box.addView(csvHeaders);box.addView(csvBom)
        AlertDialog.Builder(this).setTitle("Report Settings").setView(box)
            .setPositiveButton("Save"){_,_->prefs.edit().putString("report_page_size",pageSizes[sizeSpinner.selectedItemPosition]).putString("report_orientation",orientations[orientationSpinner.selectedItemPosition]).putBoolean("report_include_header",header.isChecked).putBoolean("report_include_filters",filters.isChecked).putBoolean("report_include_footer",footer.isChecked).putBoolean("report_csv_headers",csvHeaders.isChecked).putBoolean("report_csv_bom",csvBom.isChecked).apply();toast("Report settings saved")}
            .setNeutralButton("Reset Defaults"){_,_->prefs.edit().remove("report_page_size").remove("report_orientation").remove("report_include_header").remove("report_include_filters").remove("report_include_footer").remove("report_csv_headers").remove("report_csv_bom").apply();toast("Report settings reset")}
            .setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.notificationSettingsDialog(){
        NotificationHelper.ensure(this)
        val master=CheckBox(this).apply{text="Enable notifications";isChecked=NotificationSettings.enabled(this@notificationSettingsDialog)}
        val attendance=CheckBox(this).apply{text="Daily attendance reminder";isChecked=NotificationSettings.attendanceEnabled(this@notificationSettingsDialog)}
        val payment=CheckBox(this).apply{text="Daily payment reminder";isChecked=NotificationSettings.paymentEnabled(this@notificationSettingsDialog)}
        val ah=NotificationSettings.attendanceTime(this); val ph=NotificationSettings.paymentTime(this)
        val attendanceTimeBtn=btn("Attendance time: %02d:%02d".format(Locale.US,ah.first,ah.second))
        val paymentTimeBtn=btn("Payment time: %02d:%02d".format(Locale.US,ph.first,ph.second))
        fun pickTime(current:Pair<Int,Int>, button:Button, save:(Int,Int)->Unit){
            TimePickerDialog(this,{_,h,m->save(h,m);button.text=(button.text.toString().substringBefore(": ")+": %02d:%02d".format(Locale.US,h,m))},current.first,current.second,true).show()
        }
        attendanceTimeBtn.setOnClickListener{pickTime(NotificationSettings.attendanceTime(this),attendanceTimeBtn){h,m->NotificationSettings.setAttendanceTime(this,h,m)}}
        paymentTimeBtn.setOnClickListener{pickTime(NotificationSettings.paymentTime(this),paymentTimeBtn){h,m->NotificationSettings.setPaymentTime(this,h,m)}}
        val status=TextView(this).apply{text="Android permission: ${if(NotificationHelper.permissionGranted(this@notificationSettingsDialog)) "Allowed" else "Not allowed"}";setPadding(12,8,12,8)}
        val test=Button(this).apply{text="Send Test Notification";setOnClickListener{if(!NotificationHelper.permissionGranted(this@notificationSettingsDialog)){requestNotificationPermission()}else{NotificationHelper.show(this@notificationSettingsDialog,"Test Notification","Majdoor Hisaab PRO notifications are working.");toast("Test notification sent")}}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8);addView(master);addView(status);addView(attendance);addView(attendanceTimeBtn);addView(payment);addView(paymentTimeBtn);addView(test)}
        master.setOnCheckedChangeListener{_,v->NotificationSettings.setMaster(this,v);if(v&&!NotificationHelper.permissionGranted(this))requestNotificationPermission()}
        attendance.setOnCheckedChangeListener{_,v->NotificationSettings.setAttendance(this,v)}
        payment.setOnCheckedChangeListener{_,v->NotificationSettings.setPayment(this,v)}
        AlertDialog.Builder(this).setTitle("Notification Settings").setView(box).setPositiveButton("Done",null).setNeutralButton("Open Android Settings"){_,_->startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply{putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,packageName)})}.show()
    }


    internal fun MainActivity.requestNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),700)
    }


    internal fun MainActivity.farmProfileDialog(){val e=field("Farm / business name",prefs.getString("farm_name","My Farm")!!);AlertDialog.Builder(this).setTitle("Farm Profile").setView(e).setPositiveButton("Save"){_,_->val name=e.text.toString().trim(); if(name.length<2){toast("Farm / business name must be at least 2 characters")} else { prefs.edit().putString("farm_name",name).apply(); app.audit.logSettingChange("farm_name",name); dashboard() }}.setNegativeButton("Cancel",null).show()}

    internal fun MainActivity.wageSettingsDialog(){val e=field("Default daily wage",String.format(Locale.US,"%.2f",prefs.getFloat("default_wage",0f)));AlertDialog.Builder(this).setTitle("Wage Settings").setView(e).setPositiveButton("Save"){_,_->val x=e.text.toString().toDoubleOrNull();if(x==null||!x.isFinite()||x<0)toast("Enter a valid non-negative wage") else { prefs.edit().putFloat("default_wage",x.toFloat()).apply(); app.audit.logSettingChange("default_wage",String.format(Locale.US,"%.2f",x)); dashboard() }}.setNegativeButton("Cancel",null).show()}

    internal fun MainActivity.currencyDialog(){val values=arrayOf("INR ₹","USD $","EUR €");AlertDialog.Builder(this).setTitle("Currency").setItems(values){_,i->prefs.edit().putString("currency",values[i]).apply();app.audit.logSettingChange("currency",values[i]);toast("Currency set to ${values[i]}");recreate()}.show()}

    internal fun MainActivity.expenseCategoriesDialog(){
        val required=listOf("Labour","Fertilizer","Seed","Pesticide","Irrigation","Machinery","Diesel","Transport","Repair","Other")
        val current=(prefs.getString("expense_categories",required.joinToString(",")) ?: required.joinToString(","))
        val existing=current.split(',').map{it.trim()}.filter{it.isNotBlank()}
        val e=field("Categories (comma-separated; built-in categories cannot be removed)",existing.distinct().joinToString(","))
        AlertDialog.Builder(this).setTitle("Expense Categories").setMessage("Built-in categories: Labour, Fertilizer, Seed, Pesticide, Irrigation, Machinery, Diesel, Transport, Repair, Other. You may add custom categories.").setView(e).setPositiveButton("Save"){_,_->
            val custom=e.text.toString().split(',').map{it.trim()}.filter{it.isNotBlank()}.distinct()
            val cleaned=(required+custom).distinct()
            prefs.edit().putString("expense_categories",cleaned.joinToString(",")).apply()
            toast("Expense categories saved")
        }.setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.settingsText(s:String){AlertDialog.Builder(this).setTitle("Settings").setMessage(s).setPositiveButton("OK",null).show()}

    internal fun MainActivity.aboutDialog(){
        val license="Proprietary — all rights reserved. No open-source license is granted unless separately stated in the project repository."
        val msg="Majdoor Hisaab PRO\nAgricultural Labour & Farm Accounts\n\nVersion: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\nPackage: ${BuildConfig.APPLICATION_ID}\nStorage: Local JSON / offline-first\nLicense: $license"
        AlertDialog.Builder(this).setTitle("About").setMessage(msg).setPositiveButton("OK",null).show()
    }


    internal fun MainActivity.backupSettingsDialog(){
        val enabled=prefs.getBoolean("auto_backup",false)
        val message="Automatic backup: ${if(enabled) "Enabled" else "Disabled"}\nSchedule: approximately every 24 hours\nBackups are stored locally. Use Export Backup to choose phone storage."
        AlertDialog.Builder(this).setTitle("Backup Settings").setMessage(message)
            .setPositiveButton(if(enabled) "Disable Auto Backup" else "Enable Auto Backup"){_,_->
                val next=!enabled
                prefs.edit().putBoolean("auto_backup",next).apply()
                scheduleAutoBackup(next)
                toast(if(next) "Automatic backup enabled" else "Automatic backup disabled")
            }.setNeutralButton("Open Backup & Restore"){_,_->backup()}
            .setNegativeButton("Close",null).show()
    }


    internal fun MainActivity.dateFormatDialog(){
        val values=arrayOf("dd/MM/yyyy","dd-MM-yyyy","yyyy-MM-dd")
        val current=selectedDatePattern()
        val checked=values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Date Format").setSingleChoiceItems(values,checked){d,i->prefs.edit().putString("date_format",values[i]).apply();app.audit.logSettingChange("date_format",values[i]);d.dismiss();recreate()} .setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.themeDialog(){AlertDialog.Builder(this).setTitle("Theme").setItems(arrayOf("Light","Dark","System")){_,i->val mode=arrayOf("light","dark","system")[i];prefs.edit().putString("theme",mode).apply();app.audit.logSettingChange("theme",mode);recreate()}.show()}

    internal fun MainActivity.pinDialog(){
        if(!security.hasPin()){
            val e=field("Enter 4-12 digit PIN")
            AlertDialog.Builder(this).setTitle("Enable App Lock").setView(e)
                .setPositiveButton("Save"){_,_->
                    val p=e.text.toString()
                    if(p.length !in 4..12 || p.any{!it.isDigit()}) toast("PIN must be 4-12 digits")
                    else { security.setPin(p); toast("App Lock enabled") }
                }.setNegativeButton("Cancel",null).show()
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,0,8,0)}
        val current=field("Current PIN"); val next=field("New 4-12 digit PIN")
        box.addView(current); box.addView(next)
        AlertDialog.Builder(this).setTitle("App Lock / Change PIN").setView(box)
            .setPositiveButton("Change PIN"){_,_->
                val old=current.text.toString(); val p=next.text.toString()
                if(!security.verifyPin(old)) toast("Current PIN is incorrect")
                else if(p.length !in 4..12 || p.any{!it.isDigit()}) toast("PIN must be 4-12 digits")
                else { security.setPin(p); failedPinAttempts=0; pinBlockedUntil=0L; prefs.edit().putInt("pin_failed_attempts",0).putLong("pin_blocked_until",0L).apply(); toast("PIN changed") }
            }
            .setNeutralButton("Disable App Lock"){_,_->
                val old=current.text.toString()
                if(security.verifyPin(old)){
                    security.clearPin(); security.setBiometricEnabled(false)
                    prefs.edit().putString("auto_lock_timeout","Off").putInt("pin_failed_attempts",0).putLong("pin_blocked_until",0L).apply()
                    unlocked=true; toast("App Lock disabled")
                } else toast("Current PIN is incorrect")
            }
            .setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.autoLockDialog(){
        val values=arrayOf("Off","1 minute","5 minutes","10 minutes","15 minutes","30 minutes","60 minutes")
        val current=prefs.getString("auto_lock_timeout","Off") ?: "Off"
        val checked=values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Auto-Lock")
            .setMessage("After this period of inactivity, the app locks and requires PIN/biometric again. Auto-Lock works only when a PIN is set.")
            .setSingleChoiceItems(values,checked){d,i->
                prefs.edit().putString("auto_lock_timeout",values[i]).apply()
                app.audit.logSettingChange("auto_lock_timeout",values[i])
                lastUserActivity=System.currentTimeMillis()
                d.dismiss(); toast("Auto-Lock set to ${values[i]}")
            }.setNegativeButton("Cancel",null).show()
    }


    internal fun MainActivity.biometricToggle(){
        if(!security.biometricAvailable()){ toast("Biometric is not available/enrolled on this device"); return }
        val enabled=security.biometricEnabled(); security.setBiometricEnabled(!enabled); toast(if(enabled) "Biometric unlock disabled" else "Biometric unlock enabled")
    }


    internal fun MainActivity.biometricInfo(){if(android.os.Build.VERSION.SDK_INT<28){toast("Biometric authentication requires Android 9+");return};if(!security.biometricAvailable()){toast("Biometric authentication is not available or enrolled");return};toast("Biometric authentication is available. App unlock can use the enrolled biometric.")}

    internal fun MainActivity.search(){
        val e=field("Search workers, fields, crops, attendance, work, payments, expenses")
        AlertDialog.Builder(this).setTitle("Global Search").setView(e).setPositiveButton("Search"){_,_->
            val q=e.text.toString().trim().lowercase()
            if(q.isBlank()){ toast("Search text required"); return@setPositiveButton }
            val results=mutableListOf<Pair<String,()->Unit>>()
            app.workers.list().filter{it.name.lowercase().contains(q)||it.mobile.contains(q)||it.workerType.lowercase().contains(q)||it.referenceId.lowercase().contains(q)||it.address.lowercase().contains(q)||it.notes.lowercase().contains(q)}.forEach{w->results.add("Worker • ${w.name} • ${w.mobile}" to {workerProfile(w.id)})}
            app.fields.list().filter{it.name.lowercase().contains(q)||it.location.lowercase().contains(q)||it.soilType.lowercase().contains(q)||it.irrigation.lowercase().contains(q)||it.notes.lowercase().contains(q)}.forEach{f->results.add("Field • ${f.name} • ${f.area} ${f.unit}" to {fieldProfile(f.id)})}
            app.crops.list().filter{it.name.lowercase().contains(q)||it.variety.lowercase().contains(q)||it.notes.lowercase().contains(q)}.forEach{c->results.add("Crop • ${c.name} • ${c.variety}" to {cropProfile(c.id)})}
            app.attendance.list().filter{a->a.date.lowercase().contains(q)||a.status.lowercase().contains(q)||app.workers.list().find{w->w.id==a.workerId}?.name?.lowercase()?.contains(q)==true}.forEach{a->
                val wn=app.workers.list().find{w->w.id==a.workerId}?.name?:"Unknown"
                results.add("Attendance • ${displayDateOrRaw(a.date)} • $wn • ${a.status}" to {attendanceDetail(a.id)})
            }
            app.work.list().filter{it.workType.lowercase().contains(q)||it.notes.lowercase().contains(q)||it.date.lowercase().contains(q)}.forEach{w->results.add("Work • ${displayDateOrRaw(w.date)} • ${w.workType}" to {workDetail(w.id)})}
            app.expenses.list().filter{it.category.lowercase().contains(q)||it.notes.lowercase().contains(q)||it.date.lowercase().contains(q)}.forEach{x->results.add("Expense • ${displayDateOrRaw(x.date)} • ${x.category} • ${money(x.amount)}" to {expenseDetail(x.id)})}
            app.payments.list().filter{it.reference.lowercase().contains(q)||it.notes.lowercase().contains(q)||it.date.lowercase().contains(q)||app.workers.list().find{w->w.id==it.workerId}?.name?.lowercase()?.contains(q)==true}.forEach{x->
                val wn=app.workers.list().find{w->w.id==x.workerId}?.name?:"Unknown"
                results.add("Payment • ${displayDateOrRaw(x.date)} • $wn • ${money(x.amount)}" to {paymentDetail(x.id)})
            }
            val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,4,8,4)}
            if(results.isEmpty()) panel.addView(txt("No results",16f,true)) else results.forEach{(label,action)->panel.addView(btn(label,action))}
            val scroll=ScrollView(this).apply{addView(panel)}
            AlertDialog.Builder(this).setTitle("Search Results (${results.size})").setView(scroll).setPositiveButton("Close",null).show()
        }.show()
    }


    internal fun MainActivity.paymentDetail(id:String){
        val p=app.payments.list().firstOrNull{it.id==id} ?: run{toast("Payment not found");return}
        val worker=app.workers.list().find{it.id==p.workerId}?.name?:"Unknown"
        val b=page("Payment Detail")
        b.addView(txt(worker,22f,true))
        b.addView(txt("Date: ${displayDateOrRaw(p.date)}\nAmount: ${money(p.amount)}\nMethod: ${p.method}\nType: ${if(p.advance)"Advance" else "Payment"}\nReference: ${p.reference}\nNotes: ${p.notes}",15f))
        b.addView(btn("Edit Payment"){paymentForm(p.workerId,p.id)})
        b.addView(btn("Delete Payment"){confirmDelete("Payment"){app.payments.delete(p.id);payments()}})
    }


    internal fun MainActivity.expenseDetail(id:String){
        val x=app.expenses.list().firstOrNull{it.id==id} ?: run{toast("Expense not found");return}
        val fn=app.fields.list().find{it.id==x.fieldId}?.name?:"Not linked"
        val cn=app.crops.list().find{it.id==x.cropId}?.name?:"Not linked"
        val b=page("Expense Detail")
        b.addView(txt(x.category,22f,true))
        b.addView(txt("Date: ${displayDateOrRaw(x.date)}\nAmount: ${money(x.amount)}\nField: $fn\nCrop: $cn\nNotes: ${x.notes}",15f))
        b.addView(btn("Edit Expense"){expenseForm(x.id)})
        b.addView(btn("Delete Expense"){confirmDelete("Expense"){app.expenses.delete(x.id);expenses()}})
    }


    internal fun MainActivity.workTemplates(){
        val b=page("Work Templates"); b.addView(btn("+ Add Template"){workTemplateForm()})
        app.work.templates().forEach{t->b.addView(btn("${t.name} • ${t.workType} • ${money(t.rate)}/${t.unit}"){workTemplateForm(t.id)})}
    }


    internal fun MainActivity.workTemplateForm(id:String?=null){
        val old=app.work.templates().find{it.id==id}; val b=page(if(id==null)"Add Work Template" else "Edit Work Template")
        val n=field("Template name",old?.name?:""); val t=field("Work type",old?.workType?:"Weeding"); var rateType=app.calculation.normalize(old?.rateType?:"QUANTITY",old?.unit?:"acre"); val rateTypeBtn=btn("Rate type: $rateType"){AlertDialog.Builder(this).setTitle("Select rate type").setItems(app.calculation.rateTypes().toTypedArray()){_,i->rateType=app.calculation.rateTypes()[i];it.text="Rate type: $rateType"}.show()}; val u=field("Unit",old?.unit?:"acre"); val r=field("Rate",old?.rate?.toString() ?: "0"); val notes=field("Notes",old?.notes?:"")
        listOf(n,t,rateTypeBtn,u,r,notes).forEach{b.addView(it)}
        b.addView(btn("Save Template"){try{app.work.saveTemplate(WorkTemplate(old?.id?:UUID.randomUUID().toString(),n.text.toString().trim(),t.text.toString().trim(),u.text.toString().trim(),r.text.toString().toDoubleOrNull()?:0.0,rateType,notes.text.toString()));workTemplates()}catch(e:Exception){toast(e.message?:"Save failed")}})
        if(old!=null)b.addView(btn("Delete Template"){confirmDelete("Template"){app.work.deleteTemplate(old.id);workTemplates()}})
    }


    internal fun MainActivity.fieldProfile(id:String){
        val f=app.fields.list().first{it.id==id}; val b=page("Field Profile")
        val crops=app.crops.list().filter{it.fieldId==id}; val works=app.work.list().filter{it.fieldId==id}; val ex=app.expenses.list().filter{it.fieldId==id}
        val labour=works.sumOf{app.calculation.workCost(it)}+app.attendance.list().filter{it.fieldId==id}.sumOf{if(it.status=="FULL")it.rate else if(it.status=="HALF")it.rate/2 else 0.0}
        b.addView(txt(f.name,24f,true)); photoView(f.photoUri)?.let{b.addView(it,LinearLayout.LayoutParams(-1,260))}; b.addView(txt("Area: ${f.area} ${f.unit}\nLocation: ${f.location}\nSoil: ${f.soilType}\nIrrigation: ${f.irrigation}\nNotes: ${f.notes.ifBlank{"—"}}",14f))
        b.addView(txt("Crops: ${crops.size} | Work records: ${works.size} | Expenses: ${money(ex.sumOf{it.amount})}",14f,true))
        b.addView(txt("Labour Cost: ${money(labour)}",17f,true))
        b.addView(btn("Edit Field"){editingField=id;fieldForm(id)}); b.addView(btn("Field Crops"){val x=page("Field Crops");crops.forEach{c->x.addView(btn("${c.name} ${c.variety}"){cropProfile(c.id)})}})
        b.addView(btn("Field Work"){val x=page("Field Work");works.sortedByDescending{it.date}.forEach{w->x.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType} • ${money(app.calculation.workCost(w))}"){workDetail(w.id)})}})
        b.addView(btn("Field Expenses"){val x=page("Field Expenses");ex.sortedByDescending{it.date}.forEach{e->x.addView(btn("${displayDateOrRaw(e.date)} • ${e.category} • ${money(e.amount)}"){expenseForm(e.id)})}})
        b.addView(btn("Field Labour Cost"){ fieldLabourCost(id) })
        b.addView(btn("Field Reports"){reportView("Field Report", id)})
    }


    internal fun MainActivity.fieldLabourCost(id:String){
        val f=app.fields.list().first{it.id==id}; val b=page("Field Labour Cost")
        val attendanceCost=app.attendance.list().filter{it.fieldId==id}.sumOf{when(it.status.uppercase()){"FULL"->it.rate;"HALF"->it.rate/2.0;else->0.0}}
        val workCost=app.work.list().filter{it.fieldId==id}.sumOf{app.calculation.workCost(it)}
        val total=attendanceCost+workCost
        b.addView(txt(f.name,24f,true))
        b.addView(txt("Attendance labour: ${money(attendanceCost)}",15f))
        b.addView(txt("Work labour: ${money(workCost)}",15f))
        b.addView(txt("Total Field Labour Cost: ${money(total)}",19f,true))
    }


    internal fun MainActivity.cropProfile(id:String){
        val c=app.crops.list().first{it.id==id}; val b=page("Crop Profile"); val f=app.fields.list().find{it.id==c.fieldId}
        val work=app.work.list().filter{it.cropId==id}; val ex=app.expenses.list().filter{it.cropId==id}; val rev=app.accounting.revenue().filter{it.cropId==id}
        val labour=work.sumOf{app.calculation.workCost(it)}; val other=ex.sumOf{it.amount}; val income=rev.sumOf{it.amount}; val categories=ex.groupBy{it.category}.mapValues{(_,v)->v.sumOf{it.amount}}
        b.addView(txt(c.name,24f,true));b.addView(txt("Variety: ${c.variety.ifBlank{"Custom"}}\nField: ${f?.name?:"Unknown"}\nPlanting: ${if(c.plantingDate.isBlank())"—" else displayDateOrRaw(c.plantingDate)}\nArea: ${c.area}",14f))
        b.addView(txt("Labour: ${money(labour)} | Other cost: ${money(other)}\nRevenue: ${money(income)} | Profit/Loss: ${money(income-labour-other)}",15f,true))
        b.addView(txt("Costs: Fertilizer ${money(categories["Fertilizer"]?:0.0)} • Seed ${money(categories["Seed"]?:0.0)} • Pesticide ${money(categories["Pesticide"]?:0.0)} • Irrigation ${money(categories["Irrigation"]?:0.0)} • Machinery ${money(categories["Machinery"]?:0.0)} • Transport ${money(categories["Transport"]?:0.0)} • Other ${money(categories["Other"]?:0.0)}",12f))
        b.addView(btn("Edit Crop"){cropForm(id)}); b.addView(btn("Crop Calendar"){cropCalendar(id)}); b.addView(btn("Crop Work"){val x=page("Crop Work");work.sortedByDescending{it.date}.forEach{w->x.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType}"){workDetail(w.id)})}}); b.addView(btn("Crop Labour Cost"){val x=page("Crop Labour Cost");x.addView(txt("${c.name}: ${money(labour)}",19f,true));work.sortedByDescending{it.date}.forEach{w->x.addView(btn("${displayDateOrRaw(w.date)} • ${w.workType} • ${money(app.calculation.workCost(w))}"){workDetail(w.id)})}}); b.addView(btn("Crop Expenses"){val x=page("Crop Expenses");ex.sortedByDescending{it.date}.forEach{e->x.addView(btn("${displayDateOrRaw(e.date)} • ${e.category} • ${money(e.amount)}"){expenseForm(e.id)})}}); b.addView(btn("Production"){cropProduction(id)}); b.addView(btn("Revenue"){cropRevenue(id)}); b.addView(btn("Profitability"){cropProfitability(id)})
    }


    internal fun MainActivity.cropProduction(id:String){
        val c=app.crops.list().first{it.id==id}; val b=page("Crop Production"); b.addView(txt("${c.name} — recorded production",18f,true))
        val rows=app.accounting.production().filter{it.cropId==id}.sortedByDescending{it.date}; if(rows.isEmpty())b.addView(txt("No production recorded yet.")); rows.forEach{x->b.addView(btn("${displayDateOrRaw(x.date)} • ${x.quantity} ${x.unit}"){productionFormWithLockedCrop(id,x.id)})}
        b.addView(btn("+ Add Production"){productionFormForCrop(id)})
    }


    internal fun MainActivity.cropRevenue(id:String){
        val c=app.crops.list().first{it.id==id}; val b=page("Crop Revenue"); b.addView(txt("${c.name} — recorded revenue",18f,true))
        val rows=app.accounting.revenue().filter{it.cropId==id}.sortedByDescending{it.date}; if(rows.isEmpty())b.addView(txt("No revenue recorded yet.")); rows.forEach{x->b.addView(btn("${displayDateOrRaw(x.date)} • ${money(x.amount)}"){revenueFormWithLockedCrop(id,x.id)})}
        b.addView(btn("+ Add Revenue"){revenueFormForCrop(id)})
    }


    internal fun MainActivity.productionFormForCrop(cropId:String){
        val crops=app.crops.list().filter{it.active && it.id==cropId}
        if(crops.isEmpty()){toast("Crop not found");return}
        productionFormWithLockedCrop(cropId)
    }


    internal fun MainActivity.productionFormWithLockedCrop(cropId:String,id:String?=null){
        val old=app.accounting.production().find{it.id==id}; val b=page(if(id==null)"Add Production" else "Edit Production")
        val c=app.crops.list().firstOrNull{it.id==cropId} ?: run{toast("Crop not found");return}
        b.addView(txt("Crop: ${c.name}",16f,true))
        val d=dateField("Date",old?.date?:today);val q=field("Quantity",old?.quantity?.toString()?: "");val u=field("Unit",old?.unit?:"kg");val n=field("Note",old?.note?:"")
        listOf(d,q,u,n).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.accounting.saveProduction(Production(old?.id?:UUID.randomUUID().toString(),cropId,dateValue(d),q.text.toString().toDoubleOrNull()?:0.0,u.text.toString().trim(),n.text.toString()));cropProduction(cropId)}catch(e:Exception){toast(e.message?:"Save failed")}})
        if(old!=null)b.addView(btn("Delete Production"){confirmDelete("Production"){app.accounting.deleteProduction(old.id);cropProduction(cropId)}})
    }


    internal fun MainActivity.revenueFormForCrop(cropId:String){
        val crops=app.crops.list().filter{it.active && it.id==cropId}
        if(crops.isEmpty()){toast("Crop not found");return}
        revenueFormWithLockedCrop(cropId)
    }


    internal fun MainActivity.revenueFormWithLockedCrop(cropId:String,id:String?=null){
        val old=app.accounting.revenue().find{it.id==id}; val b=page(if(id==null)"Add Revenue" else "Edit Revenue")
        val c=app.crops.list().firstOrNull{it.id==cropId} ?: run{toast("Crop not found");return}
        b.addView(txt("Crop: ${c.name}",16f,true))
        val d=dateField("Date",old?.date?:today);val a=field("Amount",old?.amount?.toString()?: "");val n=field("Note",old?.note?:"")
        listOf(d,a,n).forEach{b.addView(it)}
        b.addView(btn("Save"){try{app.accounting.saveRevenue(Revenue(old?.id?:UUID.randomUUID().toString(),cropId,dateValue(d),a.text.toString().toDoubleOrNull()?:0.0,n.text.toString()));cropRevenue(cropId)}catch(e:Exception){toast(e.message?:"Save failed")}})
        if(old!=null)b.addView(btn("Delete Revenue"){confirmDelete("Revenue"){app.accounting.deleteRevenue(old.id);cropRevenue(cropId)}})
    }


    internal fun MainActivity.cropCalendar(id:String){
        val c=app.crops.list().first{it.id==id}; val b=page("Crop Calendar")
        b.addView(txt("${c.name} — ${c.variety.ifBlank{"Custom"}}",22f,true))
        val events=mutableMapOf<String,MutableList<String>>()
        app.work.list().filter{it.cropId==id}.forEach{events.getOrPut(it.date){mutableListOf()}.add("Work: ${it.workType}")}
        app.accounting.production().filter{it.cropId==id}.forEach{events.getOrPut(it.date){mutableListOf()}.add("Production: ${it.quantity} ${it.unit}")}
        app.accounting.revenue().filter{it.cropId==id}.forEach{events.getOrPut(it.date){mutableListOf()}.add("Revenue: ${money(it.amount)}")}
        val base=runCatching{SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(c.plantingDate.ifBlank{today})}.getOrNull() ?: Date()
        var viewCal=Calendar.getInstance().apply{time=base;set(Calendar.DAY_OF_MONTH,1)}
        val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val title=txt("",18f,true); val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val prev=btn("‹ Previous"); val next=btn("Next ›")
        header.addView(prev,LinearLayout.LayoutParams(0,dp(48),1f)); header.addView(title,LinearLayout.LayoutParams(0,48,2f)); header.addView(next,LinearLayout.LayoutParams(0,dp(48),1f)); b.addView(header); b.addView(txt("Mon   Tue   Wed   Thu   Fri   Sat   Sun",12f,true)); b.addView(grid)
        fun render(){
            title.text=SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(viewCal.time); grid.removeAllViews()
            val first=(viewCal.get(Calendar.DAY_OF_WEEK)+5)%7; val max=viewCal.getActualMaximum(Calendar.DAY_OF_MONTH); var row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            repeat(first){row.addView(txt("   ",12f),LinearLayout.LayoutParams(0,dp(48),1f))}
            for(day in 1..max){
                val key=String.format(Locale.US,"%04d-%02d-%02d",viewCal.get(Calendar.YEAR),viewCal.get(Calendar.MONTH)+1,day)
                val label=if(events[key].isNullOrEmpty()) "$day" else "[$day]"
                val cell=btn(label){if(events[key].isNullOrEmpty())toast("No crop activity on ${displayDateOrRaw(key)}")else AlertDialog.Builder(this).setTitle(displayDateOrRaw(key)).setMessage(events[key]!!.joinToString("\n")).setPositiveButton("OK",null).show()}
                row.addView(cell,LinearLayout.LayoutParams(0,dp(48),1f)); if((first+day)%7==0){grid.addView(row);row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}}
            }
            if(row.childCount>0){while(row.childCount<7)row.addView(txt("   ",12f),LinearLayout.LayoutParams(0,dp(48),1f));grid.addView(row)}
        }
        prev.setOnClickListener{viewCal.add(Calendar.MONTH,-1);render()}; next.setOnClickListener{viewCal.add(Calendar.MONTH,1);render()}; render()
        b.addView(txt("Activity history",16f,true)); events.toSortedMap().forEach{(date,items)->b.addView(txt("${displayDateOrRaw(date)} • ${items.joinToString(" | ")}",12f))}
    }


    internal fun MainActivity.cropProfitability(id:String){
        val c=app.crops.list().first{it.id==id}; val labour=app.work.list().filter{it.cropId==id}.sumOf{app.calculation.workCost(it)}
        val expenses=app.expenses.list().filter{it.cropId==id}; val revenue=app.accounting.revenue().filter{it.cropId==id}.sumOf{it.amount}; val production=app.accounting.production().filter{it.cropId==id}.sumOf{it.quantity}
        val byCategory=expenses.groupBy{it.category}.mapValues{(_,v)->v.sumOf{it.amount}}
        val other=expenses.sumOf{it.amount}; val tracked=labour+other; val b=page("Profitability")
        b.addView(txt(c.name,22f,true)); b.addView(txt("Revenue: ${money(revenue)}\nProduction: $production\nLabour: ${money(labour)}\nTracked Costs: ${money(tracked)}\nTracked Profit/Loss: ${money(revenue-tracked)}",17f,true))
        b.addView(txt("Cost breakdown\nFertilizer: ${money(byCategory["Fertilizer"]?:0.0)}\nSeed: ${money(byCategory["Seed"]?:0.0)}\nPesticide: ${money(byCategory["Pesticide"]?:0.0)}\nIrrigation: ${money(byCategory["Irrigation"]?:0.0)}\nMachinery: ${money(byCategory["Machinery"]?:0.0)}\nTransport: ${money(byCategory["Transport"]?:0.0)}\nOther: ${money(byCategory["Other"]?:0.0)}",13f))
        val missing=mutableListOf<String>(); if(revenue<=0.0)missing.add("revenue"); if(production<=0.0)missing.add("production")
        if(missing.isNotEmpty())b.addView(txt("Incomplete data: ${missing.joinToString(", ")}. Profit/Loss uses recorded values only.",13f,true))
        if(tracked<=0.0) b.addView(txt("No tracked labour/expense costs have been recorded yet; profit may be incomplete.",13f,true))
    }


    internal fun MainActivity.attendanceForm(old:Attendance){
        val b=page("Edit Attendance")
        val fields=app.fields.list().filter{it.active}
        var fieldId=old.fieldId
        val fieldBtn=btn("Field: ${if(fieldId.isBlank()) "Not linked" else selectedName(fieldId,fields.map{it.id to it.name})}"){
            val labels=arrayOf("Not linked")+fields.map{it.name}.toTypedArray()
            AlertDialog.Builder(this).setTitle("Select field").setItems(labels){_,i->
                fieldId=if(i==0) "" else fields[i-1].id
                it.text="Field: ${if(i==0) "Not linked" else fields[i-1].name}"
            }.show()
        }
        val date=dateField("Date",old.date)
        var status=old.status.uppercase()
        val statusBtn=btn("Status: $status"){
            AlertDialog.Builder(this).setTitle("Attendance status").setItems(arrayOf("Full","Half","None / Unmarked")){_,i->
                status=arrayOf("FULL","HALF","NONE")[i]
                it.text="Status: $status"
            }.show()
        }
        val rate=field("Rate",old.rate.toString())
        val note=field("Note",old.note)
        listOf(fieldBtn,date,statusBtn,rate,note).forEach{b.addView(it)}
        b.addView(btn("Save Attendance"){
            try{
                val d=date.text.toString().trim(); val r=rate.text.toString().toDoubleOrNull() ?: throw IllegalArgumentException("Invalid rate")
                if(d.isBlank()) throw IllegalArgumentException("Date required")
                AlertDialog.Builder(this).setTitle("Confirm attendance change").setMessage("Save these attendance changes?").setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->
                    try{ app.attendance.save(Attendance(old.id,dateValue(date),old.workerId,fieldId,status,r,note.text.toString())); toast("Attendance updated"); workerAttendance(old.workerId) }
                    catch(e:Exception){toast(e.message ?: "Attendance update failed")}
                }.show()
            }catch(e:Exception){toast(e.message ?: "Attendance update failed")}
        })
        b.addView(btn("Delete Attendance"){confirmDelete("Attendance"){app.attendance.delete(old.id);workerAttendance(old.workerId)}})
    }


    internal fun MainActivity.attendanceHistory(){
        val b=page("Attendance History")
        val workers=app.workers.list().sortedBy{it.name}; val fields=app.fields.list().sortedBy{it.name}
        var workerId=""; var fieldId=""; var status=""; var date=""
        val workerBtn=btn("Worker: All"); val fieldBtn=btn("Field: All"); val statusBtn=btn("Status: All"); val dateBtn=dateField("Date filter","")
        val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        workerBtn.setOnClickListener{val labels=arrayOf("All")+workers.map{it.name};AlertDialog.Builder(this).setTitle("Filter worker").setItems(labels){_,i->workerId=if(i==0)"" else workers[i-1].id;workerBtn.text="Worker: ${if(i==0)"All" else workers[i-1].name}"}.show()}
        fieldBtn.setOnClickListener{val labels=arrayOf("All")+fields.map{it.name};AlertDialog.Builder(this).setTitle("Filter field").setItems(labels){_,i->fieldId=if(i==0)"" else fields[i-1].id;fieldBtn.text="Field: ${if(i==0)"All" else fields[i-1].name}"}.show()}
        statusBtn.setOnClickListener{val labels=arrayOf("All","Full","Half","None / Unmarked");AlertDialog.Builder(this).setTitle("Filter status").setItems(labels){_,i->status=when(i){1->"FULL";2->"HALF";3->"NONE";else->""};statusBtn.text="Status: ${labels[i]}"}.show()}
        listOf(workerBtn,fieldBtn,statusBtn,dateBtn).forEach{b.addView(it)}
        b.addView(btn("Apply Filters"){
            results.removeAllViews(); date=runCatching{dateValue(dateBtn)}.getOrDefault("")
            val list=app.attendance.list().filter{(workerId.isBlank()||it.workerId==workerId)&&(fieldId.isBlank()||it.fieldId==fieldId)&&(status.isBlank()||it.status.equals(status,true))&&(date.isBlank()||it.date==date)}.sortedByDescending{it.date}
            if(list.isEmpty())results.addView(txt("No attendance found."))
            list.forEach{a->results.addView(btn("${displayDateOrRaw(a.date)} • ${app.workers.list().find{w->w.id==a.workerId}?.name?:"Unknown"} • ${app.fields.list().find{f->f.id==a.fieldId}?.name?:"Not linked"} • ${a.status}"){attendanceDetail(a.id)})}
        })
        b.addView(results)
    }


    internal fun MainActivity.attendanceDetail(id:String){ val a=app.attendance.list().first{it.id==id}; val b=page("Attendance Detail"); b.addView(txt("${app.workers.list().find{it.id==a.workerId}?.name?:"Unknown"}\nDate: ${displayDateOrRaw(a.date)}\nField: ${app.fields.list().find{it.id==a.fieldId}?.name?:"Not linked"}\nStatus: ${a.status}\nRate: ${money(a.rate)}",17f,true)); b.addView(btn("Edit Attendance"){editingAttendance=id;attendanceForm(a)}) }

    internal fun MainActivity.attendanceCalendar(){
        val b=page("Attendance Calendar")
        var shown=Calendar.getInstance()
        var selectedDate=today

        val monthTitle=txt("",20f,true).apply{gravity=Gravity.CENTER}
        val grid=GridLayout(this).apply{columnCount=7;rowCount=7;alignmentMode=GridLayout.ALIGN_BOUNDS}
        val summary=txt("",15f,true)
        val records=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}

        fun iso(cal:Calendar):String=String.format(Locale.US,"%04d-%02d-%02d",cal.get(Calendar.YEAR),cal.get(Calendar.MONTH)+1,cal.get(Calendar.DAY_OF_MONTH))
        fun dayButton(label:String,date:String,hasRecords:Boolean,selected:Boolean,onClick:()->Unit):Button{
            return Button(this).apply{
                text=if(hasRecords) "$label\n•" else label
                textSize=12f
                setPadding(0,2,0,2)
                isAllCaps=false
                if(selected) setTypeface(null,1)
                setOnClickListener{onClick()}
            }
        }
        fun render(){
            grid.removeAllViews()
            monthTitle.text=SimpleDateFormat("MMMM yyyy",Locale.US).format(shown.time)
            val weekdays=arrayOf("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
            weekdays.forEach{w->
                grid.addView(txt(w,11f,true).apply{gravity=Gravity.CENTER},GridLayout.LayoutParams().apply{width=0;height=48;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);rowSpec=GridLayout.spec(0)} )
            }
            val first=shown.clone() as Calendar
            first.set(Calendar.DAY_OF_MONTH,1)
            val mondayOffset=(first.get(Calendar.DAY_OF_WEEK)+5)%7
            val max=shown.getActualMaximum(Calendar.DAY_OF_MONTH)
            for(i in 0 until mondayOffset){
                grid.addView(TextView(this),GridLayout.LayoutParams().apply{width=0;height=62;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);rowSpec=GridLayout.spec((i/7)+1)})
            }
            for(day in 1..max){
                val c=shown.clone() as Calendar; c.set(Calendar.DAY_OF_MONTH,day)
                val d=iso(c)
                val list=app.attendance.list().filter{it.date==d}
                val col=(mondayOffset+day-1)%7
                val row=(mondayOffset+day-1)/7+1
                val cell=dayButton(day.toString(),d,list.isNotEmpty(),d==selectedDate){
                    selectedDate=d
                    renderSummary()
                }
                grid.addView(cell,GridLayout.LayoutParams().apply{width=0;height=62;columnSpec=GridLayout.spec(col,1f);rowSpec=GridLayout.spec(row)})
            }
            renderSummary()
        }
        fun renderSummary(){
            val list=app.attendance.list().filter{it.date==selectedDate}
            summary.text=if(list.isEmpty()) "${displayDateOrRaw(selectedDate)}\nNo attendance saved" else "${displayDateOrRaw(selectedDate)}  •  Full ${list.count{it.status=="FULL"}}  •  Half ${list.count{it.status=="HALF"}}  •  Unmarked ${list.count{it.status=="NONE"}}"
            records.removeAllViews()
            if(list.isEmpty()) records.addView(txt("No attendance records for this date."))
            else list.sortedBy{app.workers.list().find{w->w.id==it.workerId}?.name ?: ""}.forEach{a->
                val worker=app.workers.list().find{w->w.id==a.workerId}?.name ?: "Unknown"
                val field=if(a.fieldId.isBlank()) "No field" else app.fields.list().find{f->f.id==a.fieldId}?.name ?: "Unknown field"
                records.addView(btn("$worker  •  ${a.status}  •  $field  •  ${money(a.rate)}"){attendanceDetail(a.id)})
            }
        }

        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        nav.addView(btn("‹ Previous") {shown.add(Calendar.MONTH,-1);render()},LinearLayout.LayoutParams(0,dp(52),1f))
        nav.addView(btn("Today") {shown=Calendar.getInstance();selectedDate=today;render()},LinearLayout.LayoutParams(0,dp(52),1f))
        nav.addView(btn("Next ›") {shown.add(Calendar.MONTH,1);render()},LinearLayout.LayoutParams(0,dp(52),1f))
        b.addView(nav); b.addView(monthTitle); b.addView(grid); b.addView(summary); b.addView(txt("Tap a date to view/edit that day's attendance.",13f)); b.addView(records)
        render()
    }


    internal fun MainActivity.paymentLedger(){
        val b=page("Payment Ledger")
        app.workers.list().sortedBy{it.name}.forEach{w->
            val ledger=app.calculation.ledger(w.id,app.attendance.list(),app.work.list(),app.payments.list())
            b.addView(txt("${w.name}\nEarned ${money(ledger.earned)} | Paid ${money(ledger.normalPaid)} | Advance ${money(ledger.advance)} | Outstanding ${money(ledger.outstanding)}${if(ledger.credit>0) " | Credit ${money(ledger.credit)}" else ""}",14f))
        }
    }


    internal fun MainActivity.outstanding(){
        val b=page("Outstanding")
        app.workers.list().map{w->w to app.calculation.ledger(w.id,app.attendance.list(),app.work.list(),app.payments.list())}
            .filter{it.second.outstanding>0.0001}.sortedByDescending{it.second.outstanding}.forEach{b.addView(txt("${it.first.name}: ${money(it.second.outstanding)} outstanding",16f,true))}
    }


    internal fun MainActivity.paymentHistory(){ payments() }
    private var documentWorkerId:String?=null


    internal fun MainActivity.workerDocuments(id:String){
        documentWorkerId=id
        val b=page("Worker Documents")
        b.addView(btn("Add Document"){
            documentWorkerId=id
            val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)}
            startActivityForResult(i,2100)
        })
        app.workers.documents().filter{it.workerId==id}.forEach{d->
            b.addView(btn(d.name){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(d.uri)))}catch(_:Exception){toast("Unable to open document")}})
            b.addView(btn("Delete ${d.name}"){confirmDelete("Document"){app.workers.deleteDocument(d.id);workerDocuments(id)}})
        }
    }


    internal fun MainActivity.customReport(){
        val b=page("Custom Report")
        val from=dateField("From date",today); val to=dateField("To date",today)
        val workers=app.workers.list().filter{it.active}; val fields=app.fields.list().filter{it.active}; val crops=app.crops.list().filter{it.active}
        var wid=""; var fid=""; var cid=""
        val wb=btn("Worker: All"){AlertDialog.Builder(this).setTitle("Worker").setItems((listOf("All")+workers.map{it.name}).toTypedArray()){_,i->wid=if(i==0)"" else workers[i-1].id;it.text="Worker: ${if(i==0)"All" else workers[i-1].name}"}.show()}
        val fb=btn("Field: All"){AlertDialog.Builder(this).setTitle("Field").setItems((listOf("All")+fields.map{it.name}).toTypedArray()){_,i->fid=if(i==0)"" else fields[i-1].id;it.text="Field: ${if(i==0)"All" else fields[i-1].name}"}.show()}
        val cb=btn("Crop: All"){AlertDialog.Builder(this).setTitle("Crop").setItems((listOf("All")+crops.map{it.name}).toTypedArray()){_,i->cid=if(i==0)"" else crops[i-1].id;it.text="Crop: ${if(i==0)"All" else crops[i-1].name}"}.show()}
        listOf(from,to,wb,fb,cb).forEach{b.addView(it)}
        b.addView(btn("Generate"){
            try{
                val fromIso=dateValue(from); val toIso=dateValue(to); require(fromIso<=toIso){"From date cannot be after To date."}
                val d=app.reports.preview(com.majdoor.hisaab.report.ReportFilter(fromIso,toIso,wid,fid,cid),app.attendance.list(),app.work.list(),app.payments.list(),app.expenses.list(),app.accounting.revenue(),app.accounting.production())
                b.addView(txt("Attendance wages: ${money(d.attendanceCost())}",15f,true)); b.addView(txt("Work cost: ${money(d.workCost())}")); b.addView(txt("Payments: ${money(d.payments.sumOf{it.amount})}")); b.addView(txt("Expenses: ${money(d.expenseCost())}")); b.addView(txt("Revenue: ${money(d.revenueTotal())}")); b.addView(txt("Tracked cost: ${money(d.trackedCost())}")); b.addView(txt("Profit/Loss: ${money(d.profitLoss())}",17f,true))
            }catch(e:Exception){toast(e.message ?: "Report generation failed")}
        })
    }


    internal fun MainActivity.auditLogScreen(){
        val b=page("Audit Log")
        val entries=app.audit.auditLog().sortedByDescending{it.optLong("timestamp",0L)}
        b.addView(txt("${entries.size} recorded event(s). Data changes, imports, restores, backups and deletions are recorded here.",13f,true))
        b.addView(btn("Refresh"){auditLogScreen()})
        b.addView(btn("Clear Audit Log"){
            AlertDialog.Builder(this).setTitle("Clear audit log?").setMessage("All audit history will be permanently cleared from this phone. A new CLEAR event will be recorded.").setNegativeButton("Cancel",null).setPositiveButton("Clear"){_,_->app.audit.clearAuditLog();auditLogScreen()}.show()
        })
        if(entries.isEmpty()) b.addView(txt("No audit events recorded yet.",14f))
        entries.take(300).forEach{e->
            val ts=e.optLong("timestamp",0L)
            val time=if(ts>0) displayTimestamp(ts,true) else "Unknown time"
            val action=e.optString("action","-")
            val entity=e.optString("entity","-")
            val id=e.optString("entityId","")
            val summary=e.optString("summary","")
            val source=e.optString("source","UI")
            val detail = if(summary.isBlank()) "" else "\n$summary"
            b.addView(txt("$time • $action • $entity${if(id.isBlank())"" else " • $id"}$detail\nSource: $source",12f))
            b.addView(View(this).apply{layoutParams=LinearLayout.LayoutParams(-1,1)})
        }
    }


    internal fun MainActivity.dataHealth(){
        val report=app.backup.health().joinToString("\n")
        AlertDialog.Builder(this).setTitle("Relational Data Health").setMessage(report).setPositiveButton("OK",null).setNeutralButton("Refresh"){_,_->dataHealth()}.show()
    }


    internal fun MainActivity.scheduleAutoBackup(enabled:Boolean){
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val intent=Intent(this, com.majdoor.hisaab.backup.AutoBackupReceiver::class.java)
        val pi=PendingIntent.getBroadcast(this,9001,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if(enabled){ val first=System.currentTimeMillis()+24L*60L*60L*1000L; am.cancel(pi); am.setInexactRepeating(AlarmManager.RTC_WAKEUP,first,24L*60L*60L*1000L,pi) } else am.cancel(pi)
    }


    internal fun MainActivity.autoBackupDialog(){ val enabled=prefs.getBoolean("auto_backup",false); AlertDialog.Builder(this).setTitle("Automatic Backup").setMessage("When enabled, a local JSON backup is created approximately every 24 hours. You can still export a backup manually.").setPositiveButton(if(enabled)"Disable" else "Enable"){_,_->val next=!enabled;prefs.edit().putBoolean("auto_backup",next).apply();scheduleAutoBackup(next);toast(if(next)"Automatic backup enabled" else "Automatic backup disabled")}.setNegativeButton("Cancel",null).show() }



    internal fun MainActivity.confirmDelete(type:String,action:()->Unit){AlertDialog.Builder(this).setTitle("Delete $type?").setMessage("This cannot be silently undone. Linked records are protected from accidental deletion.").setPositiveButton("Delete"){_,_->try{action()}catch(e:Exception){toast(e.message?:"Delete failed")}}.setNegativeButton("Cancel",null).show()}


