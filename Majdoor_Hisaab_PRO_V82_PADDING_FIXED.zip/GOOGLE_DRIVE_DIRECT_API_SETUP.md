# Google Drive Direct API setup

This build adds direct Google Drive backup/restore using Google Sign-In OAuth and Drive API `drive.file`.

Before production use, enable **Google Drive API** in the Google Cloud project used by this Android app and configure an Android OAuth client for package `com.majdoor.hisaabpro` with the release SHA-1 certificate. The first sign-in asks for Drive file access.

The app creates/uses a `Majdoor Hisaab PRO` folder and uploads `.mhbackup` files there. Restore downloads the newest `.mhbackup` from that folder and still requires the Android device credential before replacing local data.

No Google password is stored by the app.
