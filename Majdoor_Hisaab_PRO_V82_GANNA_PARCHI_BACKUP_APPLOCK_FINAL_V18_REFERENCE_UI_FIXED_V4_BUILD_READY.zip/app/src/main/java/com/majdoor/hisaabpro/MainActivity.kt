package com.majdoor.hisaabpro

import android.app.Activity
import android.app.DatePickerDialog
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.content.ContentResolver
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private val Green = Color(0xFF0B6B4A)
private val GreenDark = Color(0xFF064C36)
private val Bg = Color(0xFFF6FAF8)
private val CardBg = Color.White

private data class Labour(val id:String,val name:String,val address:String,val rate:Double,val mobile:String,val photo:String)
private data class Field(val id:String,val name:String,val address:String,val area:String,val photo:String)
private data class Crop(val id:String,val fieldId:String,val name:String,val variety:String,val sowingDate:String,val season:String)
private data class Expense(val id:String,val fieldId:String,val cropId:String,val type:String,val item:String,val qty:String,val unit:String,val amount:Double,val date:String)
private data class Sale(val id:String,val fieldId:String,val cropId:String,val qty:Double,val unit:String,val rate:Double,val total:Double,val buyer:String,val date:String)
private data class Attendance(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val fraction:Double,val rate:Double)
private data class Payment(val id:String,val labourId:String,val fieldId:String,val cropId:String,val date:String,val amount:Double)
private data class WageRate(val id:String,val labourId:String,val effectiveDate:String,val rate:Double)
private data class CanePrice(val id:String,val season:String,val effectiveDate:String,val rate:Double)
private data class CaneParchi(val id:String,val name:String,val fatherName:String,val code:String,val date:String,val weight:Double,val rate:Double,val photo:String,val remark:String,val season:String)

private sealed class Screen {
    data object Home:Screen()
    data object LabourList:Screen()
    data object FieldList:Screen()
    data class ExpenseList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class SaleList(val fieldId:String?=null,val cropId:String?=null):Screen()
    data class CropList(val fieldId:String?=null):Screen()
    data class LabourDetail(val id:String):Screen()
    data class FieldDetail(val id:String):Screen()
    data class CropDetail(val id:String):Screen()
    data class Attendance(val fieldId:String?=null):Screen()
    data object AttendanceHistory:Screen()
    data object TodayAttendance:Screen()
    data object Backup:Screen()
    data object Profile:Screen()
    data object CaneParchi:Screen()
}

private class Store(private val context:Context){
    private val prefs=context.getSharedPreferences("mhpro_store",Context.MODE_PRIVATE)
    var labours by mutableStateOf(loadLabours()); private set
    var fields by mutableStateOf(loadFields()); private set
    var crops by mutableStateOf(loadCrops()); private set
    var expenses by mutableStateOf(loadExpenses()); private set
    var sales by mutableStateOf(loadSales()); private set
    var attendances by mutableStateOf(loadAttendance()); private set
    var payments by mutableStateOf(loadPayments()); private set
    var rates by mutableStateOf(loadRates()); private set
    var canePrices by mutableStateOf(loadCanePrices()); private set
    var caneParchis by mutableStateOf(loadCaneParchis()); private set

    private fun read(key:String)=JSONArray(prefs.getString(key,"[]") ?: "[]")
    private fun str(o:JSONObject,k:String)=o.optString(k,"")
    private fun num(o:JSONObject,k:String)=o.optDouble(k,0.0)
    private fun save(key:String,a:JSONArray){prefs.edit().putString(key,a.toString()).apply()}
    private fun <T> JSONArray.mapList(mapper:(JSONObject)->T): List<T> = (0 until length()).map { mapper(getJSONObject(it)) }

    private fun loadLabours()=read("labour").mapList{Labour(str(it,"id"),str(it,"name"),str(it,"address"),num(it,"rate"),str(it,"mobile"),str(it,"photo"))}
    private fun loadFields()=read("field").mapList{Field(str(it,"id"),str(it,"name"),str(it,"address"),str(it,"area"),str(it,"photo"))}
    private fun loadCrops()=read("crop").mapList{Crop(str(it,"id"),str(it,"fieldId"),str(it,"name"),str(it,"variety"),str(it,"sowingDate"),str(it,"season"))}
    private fun loadExpenses()=read("expense").mapList{Expense(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),str(it,"type"),str(it,"item"),str(it,"qty"),str(it,"unit"),num(it,"amount"),str(it,"date"))}
    private fun loadSales()=read("sale").mapList{Sale(str(it,"id"),str(it,"fieldId"),str(it,"cropId"),num(it,"qty"),str(it,"unit"),num(it,"rate"),num(it,"total"),str(it,"buyer"),str(it,"date"))}
    private fun loadAttendance():List<Attendance>{
        val raw=read("attendance").mapList{Attendance(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"fraction"),num(it,"rate"))}
        // Backward compatibility: an old attendance without cropId can be safely
        // attached to the only crop in that field. If multiple crops exist, keep
        // it field-level because assigning it to a crop would be guesswork.
        return raw.map{a->
            if(a.cropId.isBlank()){
                val matches=crops.filter{it.fieldId==a.fieldId}
                if(matches.size==1) a.copy(cropId=matches.first().id) else a
            } else a
        }
    }
    private fun loadPayments()=read("payment").mapList{Payment(str(it,"id"),str(it,"labourId"),str(it,"fieldId"),str(it,"cropId"),str(it,"date"),num(it,"amount"))}
    private fun loadRates()=read("rateHistory").mapList{WageRate(str(it,"id"),str(it,"labourId"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCanePrices()=read("canePriceHistory").mapList{CanePrice(str(it,"id"),str(it,"season"),str(it,"effectiveDate"),num(it,"rate"))}
    private fun loadCaneParchis()=read("caneParchi").mapList{CaneParchi(str(it,"id"),str(it,"name"),str(it,"fatherName"),str(it,"code"),str(it,"date"),num(it,"weight"),num(it,"rate"),str(it,"photo"),str(it,"remark"),str(it,"season"))}

    private fun obj(x:Labour)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("rate",x.rate);put("mobile",x.mobile);put("photo",x.photo)}
    private fun obj(x:Field)=JSONObject().apply{put("id",x.id);put("name",x.name);put("address",x.address);put("area",x.area);put("photo",x.photo)}
    private fun obj(x:Crop)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("name",x.name);put("variety",x.variety);put("sowingDate",x.sowingDate);put("season",x.season)}
    private fun obj(x:Expense)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("type",x.type);put("item",x.item);put("qty",x.qty);put("unit",x.unit);put("amount",x.amount);put("date",x.date)}
    private fun obj(x:Sale)=JSONObject().apply{put("id",x.id);put("fieldId",x.fieldId);put("cropId",x.cropId);put("qty",x.qty);put("unit",x.unit);put("rate",x.rate);put("total",x.total);put("buyer",x.buyer);put("date",x.date)}
    private fun obj(x:Attendance)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("fraction",x.fraction);put("rate",x.rate)}
    private fun obj(x:Payment)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("fieldId",x.fieldId);put("cropId",x.cropId);put("date",x.date);put("amount",x.amount)}
    private fun obj(x:WageRate)=JSONObject().apply{put("id",x.id);put("labourId",x.labourId);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CanePrice)=JSONObject().apply{put("id",x.id);put("season",x.season);put("effectiveDate",x.effectiveDate);put("rate",x.rate)}
    private fun obj(x:CaneParchi)=JSONObject().apply{put("id",x.id);put("name",x.name);put("fatherName",x.fatherName);put("code",x.code);put("date",x.date);put("weight",x.weight);put("rate",x.rate);put("photo",x.photo);put("remark",x.remark);put("season",x.season)}
    private fun <T> write(key:String,list:List<T>,mapper:(T)->JSONObject){save(key,JSONArray(list.map(mapper)))}

    private val backupKeys = listOf("labour","field","crop","expense","sale","attendance","payment","rateHistory","canePriceHistory","caneParchi")

    fun createBackupZip(output:File){
        output.parentFile?.mkdirs()
        val root=JSONObject().apply{
            put("schemaVersion",2)
            put("app","Majdoor Hisaab PRO")
            put("appVersion",BuildConfig.VERSION_NAME)
            put("createdAt",System.currentTimeMillis())
            backupKeys.forEach{put(it,read(it))}
        }
        val photoPaths=(labours.map{it.photo}+fields.map{it.photo}+caneParchis.map{it.photo}).filter{it.isNotBlank()}
            .map{File(it)}.filter{it.isFile}.distinctBy{it.absolutePath}
        val photoMap=JSONObject()
        photoPaths.forEachIndexed{index,file->
            val safeBase=file.name.replace(Regex("[^A-Za-z0-9._-]"),"_")
            photoMap.put(file.absolutePath,"${index}_${safeBase}")
        }
        root.put("photoMap",photoMap)
        ZipOutputStream(FileOutputStream(output)).use{zos->
            zos.putNextEntry(ZipEntry("backup.json"))
            zos.write(root.toString().toByteArray(Charsets.UTF_8))
            zos.closeEntry()
            photoPaths.forEach{file->
                val safe=photoMap.optString(file.absolutePath)
                if(safe.isBlank()) return@forEach
                zos.putNextEntry(ZipEntry("photos/$safe"))
                file.inputStream().use{it.copyTo(zos)}
                zos.closeEntry()
            }
        }
    }

    fun restoreBackupZip(input:File):String{
        var backupJson:String?=null
        val photoEntries=mutableListOf<Pair<String,ByteArray>>()
        var total=0L
        ZipInputStream(input.inputStream().buffered()).use{zis->
            var count=0
            while(true){
                val entry=zis.nextEntry?:break
                count++
                if(count>1000) throw IllegalArgumentException("Backup में बहुत ज्यादा files हैं।")
                if(entry.isDirectory){zis.closeEntry();continue}
                val name=entry.name.replace('\\','/')
                if(name.contains("..") || name.startsWith("/")) throw IllegalArgumentException("Backup file सुरक्षित नहीं है।")
                if(name.startsWith("photos/") && name.removePrefix("photos/").isBlank()) throw IllegalArgumentException("Backup photo entry गलत है।")
                val bytes=zis.readBytes()
                total+=bytes.size
                if(total>100L*1024L*1024L) throw IllegalArgumentException("Backup 100 MB से बड़ा है।")
                when{
                    name=="backup.json" -> backupJson=bytes.toString(Charsets.UTF_8)
                    name.startsWith("photos/") -> photoEntries.add(name.removePrefix("photos/") to bytes)
                }
                zis.closeEntry()
            }
        }
        val root=JSONObject(backupJson?:throw IllegalArgumentException("यह Majdoor Hisaab PRO backup नहीं है।"))
        if(root.optString("app")!="Majdoor Hisaab PRO")
            throw IllegalArgumentException("Backup app match नहीं करता।")
        val schema=root.optInt("schemaVersion",0)
        if(schema !in 1..2) throw IllegalArgumentException("Backup version supported नहीं है।")
        val photoMap=root.optJSONObject("photoMap") ?: JSONObject()
        val restoredPhotoNames=mutableMapOf<String,String>()
        fun restoredPath(original:String):String{
            if(original.isBlank()) return ""
            val backupName=photoMap.optString(original,"")
            if(backupName.isNotBlank()) return restoredPhotoNames[File(backupName).name].orEmpty()
            // Backward compatibility for schema v1 backups: match by original basename.
            val legacy=File(original).name
            val candidate=photoEntries.firstOrNull{File(it.first).name.endsWith("_$legacy") || File(it.first).name==legacy}
            return candidate?.let{restoredPhotoNames[File(it.first).name].orEmpty()} ?: ""
        }
        backupKeys.forEach{key->
            val arr=root.optJSONArray(key) ?: JSONArray()
            prefs.edit().putString(key,arr.toString()).apply()
        }
        // Restore is a full data replacement. Remove the managed photo folder first so
        // photos from an older backup/device cannot remain as orphan files.
        val photoDir=File(context.filesDir,"photos")
        if(photoDir.exists()) photoDir.deleteRecursively()
        photoDir.mkdirs()
        photoEntries.forEach{(name,bytes)->
            if(name.isBlank()) return@forEach
            val safe=File(name).name
            File(photoDir,safe).outputStream().use{it.write(bytes)}
            restoredPhotoNames[safe]=File(photoDir,safe).absolutePath
        }
        labours=loadLabours().map{l->if(l.photo.isBlank()) l else l.copy(photo=restoredPath(l.photo))}
        fields=loadFields().map{f->if(f.photo.isBlank()) f else f.copy(photo=restoredPath(f.photo))}
        // Persist restored photo paths so the restored database remains portable on this device.
        write("labour",labours,::obj); write("field",fields,::obj)
        crops=loadCrops(); expenses=loadExpenses()
        sales=loadSales(); attendances=loadAttendance(); payments=loadPayments(); rates=loadRates(); canePrices=loadCanePrices(); caneParchis=loadCaneParchis()
        caneParchis=caneParchis.map{x->if(x.photo.isBlank()) x else x.copy(photo=restoredPath(x.photo))}
        write("caneParchi",caneParchis,::obj)
        return root.optString("createdAt","")
    }

    fun addCanePrice(x:CanePrice){
        canePrices=canePrices.filterNot{it.season==x.season && it.effectiveDate==x.effectiveDate}+x
        write("canePriceHistory",canePrices,::obj)
    }
    fun caneRateFor(season:String,date:String):Double=
        canePrices.filter{it.season==season && validDate(it.effectiveDate) && it.effectiveDate<=date}
            .maxByOrNull{it.effectiveDate}?.rate ?: 400.0
    fun canePricesFor(season:String)=canePrices.filter{it.season==season}.sortedByDescending{it.effectiveDate}.distinctBy{it.effectiveDate}
    fun addCaneParchi(x:CaneParchi){caneParchis=caneParchis+x;write("caneParchi",caneParchis,::obj)}
    fun updateCaneParchi(x:CaneParchi){caneParchis=caneParchis.map{if(it.id==x.id)x else it};write("caneParchi",caneParchis,::obj)}
    fun deleteCaneParchi(id:String){caneParchis=caneParchis.filterNot{it.id==id};write("caneParchi",caneParchis,::obj)}

    fun persistPhoto(uriString:String, owner:String):String {
        if(uriString.isBlank() || uriString.startsWith("file://")) return uriString
        return try {
            val uri=Uri.parse(uriString)
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return ""
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun persistBitmapPhoto(bitmap:Bitmap, owner:String):String {
        return try {
            val dir=File(context.filesDir,"photos").apply{mkdirs()}
            val file=File(dir, "${owner}_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG,90,out) }
            file.absolutePath
        } catch(_:Exception){ "" }
    }

    fun addLabour(x:Labour){
        labours=labours+x
        write("labour",labours,::obj)
        if(x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
    }
    fun updateLabour(x:Labour){
        val old=labours.firstOrNull{it.id==x.id}
        labours=labours.map{if(it.id==x.id)x else it}
        write("labour",labours,::obj)
        if(old!=null && old.rate!=x.rate && x.rate>0){
            rates=rates.filterNot{it.labourId==x.id && it.effectiveDate==today()}+WageRate(UUID.randomUUID().toString(),x.id,today(),x.rate)
            write("rateHistory",rates,::obj)
        }
    }
    fun deleteLabour(id:String){labours=labours.filterNot{it.id==id};attendances=attendances.filterNot{it.labourId==id};payments=payments.filterNot{it.labourId==id};rates=rates.filterNot{it.labourId==id};write("labour",labours,::obj);write("attendance",attendances,::obj);write("payment",payments,::obj);write("rateHistory",rates,::obj)}

    fun addField(x:Field){fields=fields+x;write("field",fields,::obj)}
    fun updateField(x:Field){fields=fields.map{if(it.id==x.id)x else it};write("field",fields,::obj)}
    fun deleteField(id:String){fields=fields.filterNot{it.id==id};val cids=crops.filter{it.fieldId==id}.map{it.id}.toSet();crops=crops.filterNot{it.fieldId==id};expenses=expenses.filterNot{it.fieldId==id};sales=sales.filterNot{it.fieldId==id};attendances=attendances.filterNot{it.fieldId==id};payments=payments.filterNot{it.fieldId==id};write("field",fields,::obj);write("crop",crops,::obj);write("expense",expenses,::obj);write("sale",sales,::obj);write("attendance",attendances,::obj);write("payment",payments,::obj)}

    fun addCrop(x:Crop){crops=crops+x;write("crop",crops,::obj)}
    fun updateCrop(x:Crop){crops=crops.map{if(it.id==x.id)x else it};write("crop",crops,::obj)}
    fun deleteCrop(id:String){
        crops=crops.filterNot{it.id==id}
        expenses=expenses.filterNot{it.cropId==id}
        sales=sales.filterNot{it.cropId==id}
        attendances=attendances.filterNot{it.cropId==id}
        payments=payments.filterNot{it.cropId==id}
        write("crop",crops,::obj)
        write("expense",expenses,::obj)
        write("sale",sales,::obj)
        write("attendance",attendances,::obj)
        write("payment",payments,::obj)
    }

    fun addExpense(x:Expense){expenses=expenses+x;write("expense",expenses,::obj)}
    fun updateExpense(x:Expense){expenses=expenses.map{if(it.id==x.id)x else it};write("expense",expenses,::obj)}
    fun deleteExpense(id:String){expenses=expenses.filterNot{it.id==id};write("expense",expenses,::obj)}

    fun addSale(x:Sale){sales=sales+x;write("sale",sales,::obj)}
    fun updateSale(x:Sale){sales=sales.map{if(it.id==x.id)x else it};write("sale",sales,::obj)}
    fun deleteSale(id:String){sales=sales.filterNot{it.id==id};write("sale",sales,::obj)}

    fun addPayment(x:Payment){payments=payments+x;write("payment",payments,::obj)}
    fun deletePayment(id:String){payments=payments.filterNot{it.id==id};write("payment",payments,::obj)}
    fun setRate(x:WageRate){rates=rates.filterNot{it.labourId==x.labourId&&it.effectiveDate==x.effectiveDate}+x;write("rateHistory",rates,::obj)}
    fun attendanceConflict(x:Attendance):String?{
        val existingSame=attendances.firstOrNull{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.cropId==x.cropId &&
            it.date==x.date
        }
        val otherTotal=attendances.filter{
            it.labourId==x.labourId &&
            it.date==x.date &&
            it.id!=existingSame?.id
        }.sumOf{it.fraction}
        if(otherTotal+x.fraction>1.0001){
            return if(otherTotal>=0.9999) "इस तारीख में इस मजदूर की पूरी 1 दिन की हाजिरी पहले से लगी है।" else "इस तारीख में इस मजदूर की ${if(otherTotal>=0.5) "Half" else "कुछ"} हाजिरी पहले से लगी है। बाकी जगह केवल बची हुई हाजिरी लग सकती है।"
        }
        return null
    }
    fun upsertAttendance(x:Attendance):String?{
        val conflict=attendanceConflict(x)
        if(conflict!=null) return conflict
        attendances=attendances.filterNot{
            it.labourId==x.labourId &&
            it.fieldId==x.fieldId &&
            it.cropId==x.cropId &&
            it.date==x.date
        }+x
        write("attendance",attendances,::obj)
        return null
    }
    fun deleteAttendance(id:String){attendances=attendances.filterNot{it.id==id};write("attendance",attendances,::obj)}
    fun rateFor(labourId:String,date:String):Double{
        val l=labours.firstOrNull{it.id==labourId}?:return 0.0
        val applicable=rates.filter{it.labourId==labourId && validDate(it.effectiveDate) && it.effectiveDate<=date}
        return applicable.maxByOrNull{it.effectiveDate}?.rate ?: l.rate
    }
    fun rateHistoryFor(labourId:String)=rates.filter{it.labourId==labourId}.sortedByDescending{it.effectiveDate}
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{MajdoorApp()}
    }
}

@Composable private fun MajdoorApp(){
    val context=LocalContext.current
    val activity=context as? Activity
    val store=remember{Store(context)}
    val stack=remember{mutableStateListOf<Screen>(Screen.Home)}
    val screen=stack.last()
    var appUnlocked by rememberSaveable{mutableStateOf(false)}
    var backupStatus by remember{mutableStateOf("")}
    var restorePending by remember{mutableStateOf(false)}
    var restoreFile by remember{mutableStateOf<File?>(null)}
    val createBackupLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->
        if(uri==null){backupStatus="Backup save नहीं किया गया।"}
        else{
            val temp=File(context.cacheDir,"mhpro_backup_${System.currentTimeMillis()}.zip")
            runCatching{
                store.createBackupZip(temp)
                context.contentResolver.openOutputStream(uri)?.use{out->temp.inputStream().use{it.copyTo(out)}}
                    ?: throw IllegalStateException("Backup location open नहीं हुई।")
                backupStatus="Backup सफलतापूर्वक save हो गया।"
            }.onFailure{backupStatus="Backup failed: ${it.message ?: "Unknown error"}"}
            temp.delete()
        }
    }
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            runCatching{
                val temp=File(context.cacheDir,"mhpro_restore_${System.currentTimeMillis()}.zip")
                context.contentResolver.openInputStream(uri)?.use{input->temp.outputStream().use{input.copyTo(it)}}
                    ?: throw IllegalStateException("Backup file open नहीं हुई।")
                restoreFile=temp
                restorePending=true
            }.onFailure{backupStatus="Restore file नहीं खुली: ${it.message ?: "Unknown error"}"}
        }
    }
    if(!appUnlocked){
        DeviceCredentialGate("Majdoor Hisaab PRO खोलें","App का data देखने के लिए Android screen lock से पुष्टि करें।",{appUnlocked=true},{activity?.finish()})
        Box(Modifier.fillMaxSize().background(Bg),contentAlignment=Alignment.Center){
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){
                Column(Modifier.padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(10.dp)){
                    Text("🔐",fontSize=42.sp); Text("Majdoor Hisaab PRO",fontWeight=FontWeight.ExtraBold,fontSize=22.sp); Text("App खोलने के लिए phone screen lock जरूरी है।",color=Color.Gray)
                }
            }
        }
        return
    }
    fun go(s:Screen){
        if(stack.lastOrNull()==s) return
        stack.add(s)
    }
    fun goRoot(s:Screen){
        stack.clear(); stack.add(s)
    }
    fun back(){ if(stack.size>1) stack.removeAt(stack.lastIndex) else goRoot(Screen.Home) }
    val isRoot=screen is Screen.Home||screen is Screen.LabourList||screen is Screen.FieldList||screen is Screen.ExpenseList&&screen.fieldId==null&&screen.cropId==null||screen is Screen.SaleList&&screen.fieldId==null&&screen.cropId==null||(screen is Screen.CropList&&screen.fieldId==null)
    restoreFile?.let{file->
        DeviceCredentialGate("Backup Restore करें","Backup data से app का मौजूदा data replace होगा। Android screen lock से पुष्टि करें।",{
            runCatching{store.restoreBackupZip(file);backupStatus="Backup सफलतापूर्वक restore हो गया।"}.onFailure{backupStatus="Restore failed: ${it.message ?: "Unknown error"}"}
            file.delete();restoreFile=null;restorePending=false
        },{file.delete();restoreFile=null;restorePending=false})
    }
    BackHandler(enabled=true){
        when {
            stack.size > 1 -> back()
            screen !is Screen.Home -> goRoot(Screen.Home)
            else -> (context as? Activity)?.finish()
        }
    }
    Surface(Modifier.fillMaxSize(),color=Bg){Column(Modifier.fillMaxSize()){
        TopBar(title="MAJDOOR HISAAB PRO",subtitle="खेत • मजदूर • खर्च • बिक्री • फसल",canBack=!isRoot,onBack={if(isRoot) goRoot(Screen.Home) else back()},onProfile={goRoot(Screen.Profile)})
        Box(Modifier.weight(1f).fillMaxWidth().imePadding()){when(val s=screen){
            Screen.Home->Dashboard(store){key->goRoot(when(key){"attendance"->Screen.Attendance();"attendance_history"->Screen.AttendanceHistory;"today_attendance"->Screen.TodayAttendance;"backup"->Screen.Backup;"labour"->Screen.LabourList;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();"cane"->Screen.CaneParchi;else->Screen.CropList()})}
            Screen.LabourList->LabourScreen(store,{go(Screen.LabourDetail(it))},{go(Screen.Attendance())})
            Screen.FieldList->FieldScreen(store){go(Screen.FieldDetail(it))}
            is Screen.ExpenseList->ExpenseScreen(store,s.fieldId,s.cropId){goRoot(Screen.ExpenseList(s.fieldId,s.cropId))}
            is Screen.SaleList->SaleScreen(store,s.fieldId,s.cropId)
            is Screen.CropList->CropScreen(store,s.fieldId){go(Screen.CropDetail(it))}
            is Screen.LabourDetail->LabourDetail(store,s.id,{back()})
            is Screen.FieldDetail->FieldDetail(store,s.id,{back()},{go(Screen.CropDetail(it))},{go(Screen.Attendance(s.id))},{go(Screen.ExpenseList(s.id,null))},{go(Screen.SaleList(s.id,null))},{go(Screen.CropList(s.id))})
            is Screen.CropDetail->CropDetail(store,s.id,{back()},{go(Screen.ExpenseList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))},{go(Screen.SaleList(store.crops.firstOrNull{it.id==s.id}?.fieldId,s.id))})
            is Screen.Attendance->AttendanceScreen(store,s.fieldId,{back()})
            Screen.AttendanceHistory->AttendanceHistoryScreen(store,{back()})
            Screen.TodayAttendance->TodayAttendanceScreen(store,{back()})
            Screen.Backup->BackupScreen(store,backupStatus,{msg->backupStatus=msg},{createBackupLauncher.launch("Majdoor_Hisaab_PRO_Backup_${today()}.mhbackup")},{restoreLauncher.launch(arrayOf("application/zip","application/octet-stream"))})
            Screen.Profile->ProfileScreen(onBackup={goRoot(Screen.Backup)})
            Screen.CaneParchi->CaneParchiScreen(store,{back()})
        }}
        if(isRoot) BottomBar(screen){key->goRoot(when(key){"home"->Screen.Home;"attendance"->Screen.Attendance();"attendance_history"->Screen.AttendanceHistory;"today_attendance"->Screen.TodayAttendance;"backup"->Screen.Backup;"labour"->Screen.LabourList;"field"->Screen.FieldList;"expense"->Screen.ExpenseList();"sale"->Screen.SaleList();else->Screen.CropList()})}
    }}
}

@Composable private fun TopBar(title:String,subtitle:String?=null,canBack:Boolean=true,onBack:()->Unit,onProfile:(()->Unit)?=null){
    Surface(color=GreenDark,shadowElevation=4.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack,modifier=Modifier.size(44.dp)){Icon(imageVector=if(canBack) Icons.Default.ArrowBack else Icons.Default.Home,contentDescription=if(canBack) "Back" else "Home",tint=Color.White)}
            Image(painterResource(R.drawable.majdoor_logo_small),null,Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)),contentScale=ContentScale.Crop)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)){
                Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1)
                if(!subtitle.isNullOrBlank()) Text(subtitle,color=Color.White.copy(alpha=.82f),fontSize=10.sp,maxLines=1)
            }
            if(onProfile!=null){
                IconButton(onClick=onProfile,modifier=Modifier.size(44.dp)){
                    Icon(Icons.Default.AccountCircle,contentDescription="Profile",tint=Color.White,modifier=Modifier.size(29.dp))
                }
            }
        }
    }
}

@Composable private fun BottomBar(screen:Screen,onTab:(String)->Unit){val current=when(screen){Screen.LabourList->"labour";Screen.FieldList->"field";is Screen.ExpenseList->"expense";is Screen.SaleList->"sale";is Screen.CropList->"crop";else->"home"};Surface(shadowElevation=8.dp){Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceAround){listOf("home" to Icons.Default.Home,"labour" to Icons.Default.Groups,"field" to Icons.Default.Landscape,"expense" to Icons.Default.Payments,"sale" to Icons.Default.ShoppingCart,"crop" to Icons.Default.Spa).forEach{(k,ic)->Column(Modifier.clickable{onTab(k)}.padding(horizontal=7.dp,vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(imageVector=ic,contentDescription=null,modifier=Modifier.size(22.dp),tint=if(current==k)Green else Color.Gray);Text(when(k){"home"->"Home";"labour"->"Labour";"field"->"Field";"expense"->"Kharch";"sale"->"Sale";else->"Crop"},fontSize=10.sp,color=if(current==k)Green else Color.Gray)}}}}}

@Composable
private fun Dashboard(store:Store,onGo:(String)->Unit){
    val today=today()
    val wage=store.attendances.filter{it.date==today}.sumOf{it.fraction*it.rate}
    val exp=store.expenses.filter{it.date==today}.sumOf{it.amount}
    val sale=store.sales.filter{it.date==today}.sumOf{it.total}
    val workerCount=store.attendances.filter{it.date==today}.map{it.labourId}.distinct().size
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark),elevation=CardDefaults.cardElevation(3.dp)){Box(Modifier.fillMaxWidth().height(185.dp)){Image(painterResource(R.drawable.dashboard_hero),null,Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)),contentScale=ContentScale.Crop);Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,GreenDark.copy(alpha=.9f)))));Column(Modifier.align(Alignment.BottomStart).padding(18.dp)){Text("मेहनत का सही हिसाब",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.ExtraBold);Text("किसान की सही ताकत",color=Color(0xFFD5F4E6),fontSize=20.sp,fontWeight=FontWeight.Bold);Text("खेत का हर काम • हर खर्च • हर कमाई",color=Color.White.copy(alpha=.92f),fontSize=12.sp)}}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CalendarMonth,null,tint=Green,modifier=Modifier.size(27.dp));Spacer(Modifier.width(8.dp));Text("आज का हिसाब • ${displayDate(today)}",fontWeight=FontWeight.ExtraBold,fontSize=18.sp,modifier=Modifier.weight(1f));AssistChip(onClick={onGo("expense")},label={Text("विवरण देखें")})};Spacer(Modifier.height(9.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){DashboardStat("👷","मजदूरी",wage,"$workerCount मजदूर",Color(0xFFE8F3FF),Modifier.weight(1f)){onGo("labour")};DashboardStat("💰","खर्च",exp,"आज का खर्च",Color(0xFFFFF2DF),Modifier.weight(1f)){onGo("expense")};DashboardStat("🧺","बिक्री",sale,"आज की बिक्री",Color(0xFFE8F7EA),Modifier.weight(1f)){onGo("sale")} }}}}
        item{Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){Column(Modifier.padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.width(5.dp).height(58.dp).clip(RoundedCornerShape(5.dp)).background(Green));Spacer(Modifier.width(11.dp));Text("👷",fontSize=30.sp);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text("आज की हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold);Text("जल्दी से मजदूरों की हाजिरी लगाएँ",fontSize=12.sp,color=Color.Gray)};OutlinedButton(onClick={onGo("attendance_history")}){Text("हाजिरी सूची  ›")}};Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){Button(onClick={onGo("attendance")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(16.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Default.Fingerprint,null);Spacer(Modifier.width(6.dp));Column{Text("नई हाजिरी लगाएँ",fontWeight=FontWeight.Bold);Text("मजदूर चुनें और दर्ज करें",fontSize=9.sp)}};OutlinedButton(onClick={onGo("today_attendance")},modifier=Modifier.weight(.78f),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.List,null);Spacer(Modifier.width(5.dp));Column{Text("आज की हाजिरी",fontWeight=FontWeight.Bold);Text("देखें / संपादित करें",fontSize=9.sp)}}}}}}
        item{Row(verticalAlignment=Alignment.CenterVertically){Text("▦  मुख्य काम",fontWeight=FontWeight.ExtraBold,fontSize=20.sp,modifier=Modifier.weight(1f));Text("सभी मॉड्यूल  ›",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("👷","Labour","मजदूर प्रबंधन","हाजिरी • मजदूरी • भुगतान",Color(0xFFDCEBFF),Modifier.weight(1f)){onGo("labour")};DashboardModule("🌾","Field","खेत प्रबंधन","खेत • काम • गतिविधि",Color(0xFFE0F3D9),Modifier.weight(1f)){onGo("field")}}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){DashboardModule("💰","Kharch","खर्च प्रबंधन","बीज • खाद • दवा",Color(0xFFFFEBD4),Modifier.weight(1f)){onGo("expense")};DashboardModule("🧺","Sale","बिक्री प्रबंधन","फसल • उपज • बिक्री",Color(0xFFFFE3E1),Modifier.weight(1f)){onGo("sale")}}}
        item{DashboardModule("🌾","गन्ना पर्ची","गन्ने की पर्ची और तौल","पर्ची • वजन • भाव • फोटो",Color(0xFFDFF5E7),Modifier.fillMaxWidth()){onGo("cane")}}
        item{DashboardModule("🌱","Crop","फसल प्रबंधन","फसल चक्र • बुवाई • कटाई",Color(0xFFEAE2FF),Modifier.fillMaxWidth()){onGo("crop")}}
    }
}


@Composable private fun DashboardStat(icon:String,label:String,value:Double,sub:String,bgColor:Color,modifier:Modifier=Modifier,onClick:()->Unit={}){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(0.dp)){Column(Modifier.padding(9.dp),verticalArrangement=Arrangement.spacedBy(2.dp)){Text(icon,fontSize=21.sp);Text(label,fontSize=11.sp,color=GreenDark);Text("₹${money(value)}",fontSize=18.sp,fontWeight=FontWeight.ExtraBold);Text(sub,fontSize=9.sp,color=Color.Gray,maxLines=1)}}}

@Composable private fun DashboardModule(icon:String,title:String,subtitle:String,detail:String,bgColor:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=bgColor),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.fillMaxWidth().padding(13.dp).heightIn(min=125.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha=.62f)),contentAlignment=Alignment.Center){Text(icon,fontSize=27.sp)};Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(title,fontSize=19.sp,fontWeight=FontWeight.ExtraBold);Text(subtitle,fontSize=10.sp,color=Color.DarkGray)};Icon(Icons.Default.ChevronRight,null,tint=GreenDark)};Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.72f)){Text(detail,Modifier.padding(horizontal=9.dp,vertical=5.dp),fontSize=9.sp,fontWeight=FontWeight.SemiBold,color=GreenDark,maxLines=1)}}}}

@Composable private fun Stat(label:String,value:Double){
    val icon=when(label){"मजदूरी","Labour"->"👷";"खर्च","लागत","खेती खर्च"->"💰";"बिक्री","Sale"->"🧺";"भुगतान"->"💵";"बाकी"->"📌";"लाभ"->"📈";"कुल काम","कुल दिन","पूरा दिन","आधा दिन","मजदूर","कुल मजदूर"->"📅";else->"📊"}
    val unit=when(label){"कुल काम","कुल दिन"->" दिन";"पूरा दिन"->" दिन";"आधा दिन"->" दिन";"मजदूर","कुल मजदूर"->"";else->null}
    val display=if(unit!=null) "${money(value)}$unit" else "₹${money(value)}"
    Card(Modifier.fillMaxWidth().heightIn(min=78.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
        Column(Modifier.fillMaxWidth().padding(horizontal=11.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=15.sp);Spacer(Modifier.width(5.dp));Text(label,fontSize=11.sp,color=Color.Gray,maxLines=1)}
            Text(display,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}
private fun money(v:Double)=String.format(Locale.US,"%.0f",v)
private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
private fun validDate(v:String):Boolean{
    val value=v.trim()
    if(!Regex("\\d{4}-\\d{2}-\\d{2}").matches(value)) return false
    return try{
        val f=SimpleDateFormat("yyyy-MM-dd",Locale.US)
        f.isLenient=false
        val parsed=f.parse(value) ?: return false
        f.format(parsed)==value
    }catch(_:Exception){false}
}
private fun monthTitle(value:String):String{
    return try{
        val f=SimpleDateFormat("yyyy-MM",Locale.US).apply{isLenient=false}
        val d=f.parse(value) ?: return value
        SimpleDateFormat("MMMM yyyy",Locale("hi","IN")).format(d)
    }catch(_:Exception){value}
}
private fun displayDate(v:String):String{
    val value=v.trim()
    if(!validDate(value)) return value
    return try{
        val input=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}
        val output=SimpleDateFormat("dd/MM/yyyy",Locale.US)
        output.format(input.parse(value)!!)
    }catch(_:Exception){value}
}

@Composable
private fun PhotoThumb(path:String,modifier:Modifier=Modifier.size(52.dp)){
    val bitmap=remember(path){if(path.isNotBlank()) runCatching{BitmapFactory.decodeFile(path)?.asImageBitmap()}.getOrNull() else null}
    if(bitmap!=null){
        Image(bitmap=bitmap,contentDescription=null,modifier=modifier.clip(RoundedCornerShape(14.dp)),contentScale=ContentScale.Crop)
    }else{
        Box(modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=22.sp)}
    }
}

@Composable
private fun LabourScreen(store:Store,onOpen:(String)->Unit,onAttendance:()->Unit){
    var edit by remember{mutableStateOf<Labour?>(null)}
    var delete by remember{mutableStateOf<Labour?>(null)}
    var protectedEdit by remember{mutableStateOf<Labour?>(null)}
    var protectedDelete by remember{mutableStateOf<Labour?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("👷 Labour","मजदूरों की सूची") { edit=Labour("","","",0.0,"","") }
        Spacer(Modifier.height(10.dp))
        SmallAction("📅 हाजिरी / तारीख चुनें",onAttendance)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.labours,key={it.id}){l->
                Card(Modifier.fillMaxWidth().clickable{onOpen(l.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(l.photo);Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold)
                            Text("₹${money(store.rateFor(l.id,today()))}/दिन",fontSize=12.sp,color=Color.Gray)
                        }
                        IconButton(onClick={protectedEdit=l}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=l}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(edit!=null) LabourDialog(store,edit!!.takeIf{it.id.isNotBlank()}){edit=null}
    protectedEdit?.let{item->
        DeviceCredentialGate("मजदूर बदलें","मजदूर की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})
    }
    protectedDelete?.let{item->
        DeviceCredentialGate("मजदूर हटाएँ","मजदूर और उससे जुड़े attendance, payment तथा rate history हटाने के लिए Android screen lock से पुष्टि करें।",{delete=item;protectedDelete=null},{protectedDelete=null})
    }
    if(delete!=null) ConfirmDialog("मजदूर हटाएँ?","इस मजदूर का attendance, payment और rate history भी हटेगा.",{store.deleteLabour(delete!!.id);delete=null},{delete=null})
}
@Composable private fun LabourDialog(store:Store,existing:Labour?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var address by remember{mutableStateOf(existing?.address?:"")};var rate by remember{mutableStateOf(if(existing==null||existing.rate==0.0)"" else money(existing.rate))};var mobile by remember{mutableStateOf(existing?.mobile?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"मजदूर जोड़ें" else "मजदूर बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("नाम (Optional)")},singleLine=true);OutlinedTextField(value=address,onValueChange={address=it},label={Text("पता (Optional)")},singleLine=true);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("रुपये/दिन (Optional)")},singleLine=true);OutlinedTextField(value=mobile,onValueChange={mobile=it},label={Text("मोबाइल (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"फोटो चुनें (Optional)" else "✓ फोटो चुनी गई")};Button(onClick={val x=Labour(ownerId,name,address,rate.toDoubleOrNull()?:0.0,mobile,photo);if(existing==null)store.addLabour(x) else store.updateLabour(x);onClose()},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun FieldScreen(store:Store,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Field?>(null)}
    var del by remember{mutableStateOf<Field?>(null)}
    var protectedEdit by remember{mutableStateOf<Field?>(null)}
    var protectedDelete by remember{mutableStateOf<Field?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌾 Field","खेतों की सूची") {add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.fields,key={it.id}){f->
                Card(Modifier.fillMaxWidth().clickable{onOpen(f.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        PhotoThumb(f.photo);Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)){
                            Text(f.name.ifBlank{"खेत का नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=17.sp)
                            Text(listOf(f.area.ifBlank{"रकबा नहीं दिया"},f.address).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)
                        }
                        IconButton(onClick={protectedEdit=f}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=f}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)FieldDialog(store,null){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("खेत बदलें","खेत की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खेत हटाएँ","खेत और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)FieldDialog(store,edit!!){edit=null}
    if(del!=null)ConfirmDialog("खेत हटाएँ?","इस खेत से जुड़े crop, expense, sale, attendance और payment records हटेंगे.",{store.deleteField(del!!.id);del=null},{del=null})
}
@Composable private fun FieldDialog(store:Store,existing:Field?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var addr by remember{mutableStateOf(existing?.address?:"")};var area by remember{mutableStateOf(existing?.area?:"")};var photo by remember{mutableStateOf(existing?.photo?:"")};val ownerId=existing?.id?:remember{UUID.randomUUID().toString()}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){
            val persisted=store.persistPhoto(uri.toString(),ownerId)
            if(persisted.isNotBlank()) photo=persisted
        }
    };SimpleDialog(if(existing==null)"खेत जोड़ें" else "खेत बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("खेत का नाम (Optional)")},singleLine=true);OutlinedTextField(value=addr,onValueChange={addr=it},label={Text("पता/स्थान (Optional)")},singleLine=true);OutlinedTextField(value=area,onValueChange={area=it},label={Text("रकबा (Optional)")},singleLine=true);OutlinedButton(onClick={picker.launch(arrayOf("image/*"))}){Text(if(photo.isBlank())"खेत की फोटो (Optional)" else "✓ फोटो चुनी गई")};Button(onClick={val x=Field(ownerId,name,addr,area,photo);if(existing==null)store.addField(x) else store.updateField(x);onClose()},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun CropScreen(store:Store,preField:String?,onOpen:(String)->Unit){
    var add by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<Crop?>(null)}
    var del by remember{mutableStateOf<Crop?>(null)}
    var protectedEdit by remember{mutableStateOf<Crop?>(null)}
    var protectedDelete by remember{mutableStateOf<Crop?>(null)}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🌱 Crop","फसल सूची"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.items(store.crops,key={it.id}){c->
                val f=store.fields.firstOrNull{it.id==c.fieldId}
                Card(Modifier.fillMaxWidth().clickable{onOpen(c.id)},RoundedCornerShape(16.dp)){
                    Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(c.name.ifBlank{"फसल का नाम नहीं दिया"},fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${c.season}",fontSize=12.sp,color=Color.Gray)
                        }
                        IconButton(onClick={protectedEdit=c}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=c}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)CropDialog(store,null,preField){add=false}
    protectedEdit?.let{item->DeviceCredentialGate("फसल बदलें","फसल की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("फसल हटाएँ","फसल और उससे जुड़े रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null)CropDialog(store,edit!!,null){edit=null}
    if(del!=null)ConfirmDialog("फसल हटाएँ?","इस crop के जुड़े expense, sale और attendance links हटेंगे.",{store.deleteCrop(del!!.id);del=null},{del=null})
}
@Composable private fun CropDialog(store:Store,existing:Crop?,preField:String?,onClose:()->Unit){var name by remember{mutableStateOf(existing?.name?:"")};var field by remember{mutableStateOf(existing?.fieldId?:preField?:store.fields.firstOrNull()?.id?:"")};var variety by remember{mutableStateOf(existing?.variety?:"")};var sow by remember{mutableStateOf(existing?.sowingDate?:"")};var season by remember{mutableStateOf(existing?.season?:SimpleDateFormat("yyyy",Locale.US).format(Date()))};var error by remember{mutableStateOf("")};SimpleDialog(if(existing==null)"फसल जोड़ें" else "फसल बदलें",onClose){OutlinedTextField(value=name,onValueChange={name=it},label={Text("फसल का नाम")},singleLine=true);ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it};OutlinedTextField(value=variety,onValueChange={variety=it},label={Text("किस्म (Optional)")},singleLine=true);OutlinedTextField(value=sow,onValueChange={sow=it},label={Text("बुवाई तारीख YYYY-MM-DD (Optional)")},singleLine=true);OutlinedTextField(value=season,onValueChange={season=it},label={Text("Season")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={when{ name.isBlank()->error="फसल का नाम डालें"; field.isBlank()->error="खेत चुनें"; !sow.isBlank()&&!validDate(sow)->error="सही बुवाई तारीख डालें: YYYY-MM-DD"; else->{error="";val x=Crop(existing?.id?:UUID.randomUUID().toString(),field,name,variety,sow,season);if(existing==null)store.addCrop(x) else store.updateCrop(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun ExpenseScreen(store:Store,preField:String?,preCrop:String?,onSaved:()->Unit){
    var edit by remember{mutableStateOf<Expense?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Expense?>(null)}
    var protectedEdit by remember{mutableStateOf<Expense?>(null)}
    var protectedDelete by remember{mutableStateOf<Expense?>(null)}
    val list=store.expenses.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("💰 Kharch","खेती का खर्च"){add=true}
        if(preField==null&&preCrop==null)Text("सभी खर्च",fontWeight=FontWeight.Bold)
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){e->
                val f=store.fields.firstOrNull{it.id==e.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(e.type+if(e.item.isNotBlank())" • ${e.item}" else "",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(e.date)}",fontSize=12.sp,color=Color.Gray)
                            Text("₹${money(e.amount)}",fontWeight=FontWeight.Bold)
                        }
                        IconButton(onClick={protectedEdit=e}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=e}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)ExpenseDialog(store,edit?:Expense(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),"बीज","","","",0.0,today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("खर्च बदलें","खर्च की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("खर्च हटाएँ","खर्च रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)ExpenseDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("खर्च हटाएँ?","यह खर्च रिकॉर्ड हट जाएगा.",{store.deleteExpense(del!!.id);del=null},{del=null})
}
@Composable private fun ExpenseDialog(store:Store,existing:Expense,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var type by remember{mutableStateOf(existing.type)};var item by remember{mutableStateOf(existing.item)};var qty by remember{mutableStateOf(existing.qty)};var unit by remember{mutableStateOf(existing.unit)};var amount by remember{mutableStateOf(if(existing.amount==0.0)"" else money(existing.amount))};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"खर्च बदलें" else "खर्च जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};ChoiceField("खर्च का प्रकार",listOf("बीज" to "बीज","उर्वरक/खाद" to "उर्वरक/खाद","दवा/कीटनाशक" to "दवा/कीटनाशक","डीजल" to "डीजल","सिंचाई" to "सिंचाई","ट्रैक्टर/मशीन" to "ट्रैक्टर/मशीन","ढुलाई" to "ढुलाई","अन्य" to "अन्य"),type){type=it};OutlinedTextField(value=item,onValueChange={item=it},label={Text("नाम (Optional)")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value=qty,onValueChange={qty=it},modifier=Modifier.weight(1f),label={Text("मात्रा (Optional)")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},modifier=Modifier.weight(1f),label={Text("इकाई (Optional)")},singleLine=true)};OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("रकम")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=amount.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";n==null||n<=0||!n.isFinite()->error="सही रकम दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,type=type,item=item,qty=qty,unit=unit,amount=n,date=date.trim());if(isEdit)store.updateExpense(x) else store.addExpense(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun SaleScreen(store:Store,preField:String?,preCrop:String?){
    var edit by remember{mutableStateOf<Sale?>(null)}
    var add by remember{mutableStateOf(false)}
    var del by remember{mutableStateOf<Sale?>(null)}
    var protectedEdit by remember{mutableStateOf<Sale?>(null)}
    var protectedDelete by remember{mutableStateOf<Sale?>(null)}
    val list=store.sales.filter{(preField==null||it.fieldId==preField)&&(preCrop==null||it.cropId==preCrop)}.sortedByDescending{it.date}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        SectionTitle("🧺 Sale","बिक्री"){add=true}
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
            this.items(list,key={it.id}){s->
                val f=store.fields.firstOrNull{it.id==s.fieldId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text("${s.qty} ${s.unit} × ₹${money(s.rate)}",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत नहीं चुना"} • ${displayDate(s.date)}",fontSize=12.sp)
                            Text("₹${money(s.total)}",fontWeight=FontWeight.Bold,color=Green)
                        }
                        IconButton(onClick={protectedEdit=s}){Icon(Icons.Default.Edit,null,tint=Green)}
                        IconButton(onClick={protectedDelete=s}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }
    }
    if(add)SaleDialog(store,edit?:Sale(UUID.randomUUID().toString(),preField?:(store.fields.firstOrNull()?.id?:""),preCrop?:(store.crops.firstOrNull{it.fieldId==preField}?.id?:""),0.0,"क्विंटल",0.0,0.0,"",today()),{add=false;edit=null},edit!=null)
    protectedEdit?.let{item->DeviceCredentialGate("बिक्री बदलें","बिक्री की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=item;protectedEdit=null},{protectedEdit=null})}
    protectedDelete?.let{item->DeviceCredentialGate("बिक्री हटाएँ","बिक्री रिकॉर्ड हटाने के लिए Android screen lock से पुष्टि करें।",{del=item;protectedDelete=null},{protectedDelete=null})}
    if(edit!=null && !add)SaleDialog(store,edit!!,{edit=null},true)
    if(del!=null)ConfirmDialog("बिक्री हटाएँ?","यह बिक्री रिकॉर्ड हट जाएगा.",{store.deleteSale(del!!.id);del=null},{del=null})
}
@Composable private fun SaleDialog(store:Store,existing:Sale,onClose:()->Unit,isEdit:Boolean){var field by remember{mutableStateOf(existing.fieldId)};var crop by remember{mutableStateOf(existing.cropId)};var qty by remember{mutableStateOf(if(existing.qty==0.0)"" else existing.qty.toString())};var unit by remember{mutableStateOf(existing.unit)};var rate by remember{mutableStateOf(if(existing.rate==0.0)"" else existing.rate.toString())};var buyer by remember{mutableStateOf(existing.buyer)};var date by remember{mutableStateOf(existing.date)};var error by remember{mutableStateOf("")};val crops=store.crops.filter{it.fieldId==field};LaunchedEffect(field){if(crop.isNotBlank()&&crops.none{it.id==crop})crop=""};SimpleDialog(if(isEdit)"बिक्री बदलें" else "बिक्री जोड़ें",onClose){ChoiceField("खेत",store.fields.map{it.id to it.name},field){field=it;crop=""};ChoiceField("फसल",listOf("" to "फसल नहीं चुनी")+crops.map{it.id to it.name},crop){crop=it};OutlinedTextField(value=qty,onValueChange={qty=it},label={Text("मात्रा")},singleLine=true);OutlinedTextField(value=unit,onValueChange={unit=it},label={Text("इकाई")},singleLine=true);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("दर")},singleLine=true);OutlinedTextField(value=buyer,onValueChange={buyer=it},label={Text("खरीदार (Optional)")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("तारीख YYYY-MM-DD")},singleLine=true);val total=(qty.toDoubleOrNull()?:0.0)*(rate.toDoubleOrNull()?:0.0);Text("कुल रकम: ₹${money(total)}",fontWeight=FontWeight.Bold);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val q=qty.toDoubleOrNull();val r=rate.toDoubleOrNull();when{field.isBlank()->error="खेत चुनें";q==null||q<=0||!q.isFinite()->error="सही मात्रा दर्ज करें";r==null||r<=0||!r.isFinite()->error="सही दर दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";val x=existing.copy(fieldId=field,cropId=crop,qty=q,unit=unit,rate=r,total=total,buyer=buyer,date=date.trim());if(isEdit)store.updateSale(x) else store.addSale(x);onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save")}}}

@Composable
private fun DeviceCredentialGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
){
    val context=LocalContext.current
    var noLock by remember{mutableStateOf(false)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        if(result.resultCode==Activity.RESULT_OK) onUnlocked() else onCancel()
    }
    LaunchedEffect(Unit){
        val km=context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if(!km.isKeyguardSecure){
            noLock=true
        }else{
            val intent=km.createConfirmDeviceCredentialIntent(title,message)
            if(intent!=null) launcher.launch(intent) else onCancel()
        }
    }
    if(noLock){
        AlertDialog(
            onDismissRequest=onCancel,
            title={Text("Android Screen Lock जरूरी है")},
            text={Text("इस रिकॉर्ड को बदलने या हटाने के लिए फोन में PIN, Pattern या Password screen lock चालू होना चाहिए।")},
            confirmButton={Button(onClick=onCancel){Text("ठीक है")}}
        )
    }
}

@Composable
private fun DeviceCredentialDeleteGate(
    title:String,
    message:String,
    onUnlocked:()->Unit,
    onCancel:()->Unit
)=DeviceCredentialGate(title,message,onUnlocked,onCancel)

private fun isNotFutureDate(value:String):Boolean{
    return validDate(value) && value<=today()
}

@Composable
private fun AttendanceDateButton(value:String,onDateSelected:(String)->Unit){
    val context=LocalContext.current
    val parsed=try{
        SimpleDateFormat("yyyy-MM-dd",Locale.US).apply{isLenient=false}.parse(value)
    }catch(_:Exception){Date()}
    OutlinedButton(
        onClick={
            val cal=Calendar.getInstance().apply{time=parsed?:Date()}
            DatePickerDialog(
                context,
                {_,year,month,day->
                    val selected=Calendar.getInstance().apply{
                        set(Calendar.YEAR,year);set(Calendar.MONTH,month);set(Calendar.DAY_OF_MONTH,day)
                    }
                    val formatted=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(selected.time)
                    if(formatted<=today()) onDateSelected(formatted)
                },
                cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)
            ).apply{
                datePicker.maxDate=System.currentTimeMillis()
            }.show()
        },
        modifier=Modifier.fillMaxWidth()
    ){
        Icon(Icons.Default.CalendarMonth,null)
        Spacer(Modifier.width(7.dp))
        Text("हाजिरी तारीख: ${displayDate(value)}")
    }
}

@Composable
private fun AttendanceScreen(store:Store,preField:String?,onBack:()->Unit){
    val context=LocalContext.current
    var selectedDate by remember{mutableStateOf(today())}
    var activeField by remember{mutableStateOf(preField?:store.fields.firstOrNull()?.id?:"")}
    var activeCrop by remember{mutableStateOf("")}
    var attendanceError by remember{mutableStateOf("")}
    var deleteAttendance by remember{mutableStateOf<Attendance?>(null)}
    var protectedAttendanceEdit by remember{mutableStateOf<Pair<Attendance,Double>?>(null)}
    val field=store.fields.firstOrNull{it.id==activeField}
    val crops=store.crops.filter{it.fieldId==activeField}
    LaunchedEffect(activeField){activeCrop=if(crops.size==1)crops.first().id else ""}

    val credentialDelete=deleteAttendance

    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📅 हाजिरी • ${displayDate(selectedDate)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            this.item{
                Card(shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(15.dp)){
                        Text("📅 तारीख के हिसाब से हाजिरी",fontSize=20.sp,fontWeight=FontWeight.ExtraBold)
                        Spacer(Modifier.height(8.dp))
                        AttendanceDateButton(selectedDate){selectedDate=it;attendanceError=""}
                        Spacer(Modifier.height(6.dp))
                        Text("आज या पिछली तारीख की हाजिरी लगाएँ। आगे की तारीख की हाजिरी नहीं लगेगी।",fontSize=11.sp,color=Color.Gray)
                    }
                }
            }
            this.item{
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(14.dp)){
                        Text("🌾 खेत चुनें",fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            store.fields.forEach{f->
                                val fieldName=f.name.ifBlank { "खेत" }
                                FilterChip(
                                    selected=f.id==activeField,
                                    onClick={activeField=f.id;attendanceError=""},
                                    label={Text("🌾 $fieldName")}
                                )
                            }
                        }
                        if(field!=null&&crops.size>1){
                            Spacer(Modifier.height(8.dp))
                            ChoiceField("फसल",crops.map{it.id to it.name},activeCrop){activeCrop=it;attendanceError=""}
                        }
                    }
                }
            }
            if(attendanceError.isNotBlank()) this.item{
                Card(colors=CardDefaults.cardColors(containerColor=Color(0xFFFFE8E6)),shape=RoundedCornerShape(14.dp)){
                    Text("⚠ $attendanceError",Modifier.padding(12.dp),color=Color(0xFFB3261E),fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                }
            }
            if(field!=null){
                this.item{
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text("मजदूरों की हाजिरी",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,modifier=Modifier.weight(1f))
                        Text("${displayDate(selectedDate)}",fontSize=11.sp,color=Color.Gray)
                    }
                }
                this.items(store.labours,key={it.id}){l->
                    val a=store.attendances.firstOrNull{it.labourId==l.id&&it.fieldId==activeField&&it.cropId==activeCrop&&it.date==selectedDate}
                    val totalForLabour=store.attendances.filter{it.labourId==l.id&&it.date==selectedDate}.sumOf{it.fraction}
                    val remaining=(1.0-totalForLabour+(a?.fraction?:0.0)).coerceAtLeast(0.0)
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(1.dp)){
                        Column(Modifier.padding(13.dp)){
                            Row(verticalAlignment=Alignment.CenterVertically){
                                Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F3FF)),contentAlignment=Alignment.Center){Text("👷",fontSize=24.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(l.name.ifBlank{"नाम नहीं दिया"},fontWeight=FontWeight.Bold,fontSize=16.sp)
                                    Text("दिहाड़ी ₹${money(store.rateFor(l.id,selectedDate))}/दिन",fontSize=11.sp,color=Color.Gray)
                                }
                                if(a!=null) Text(if(a.fraction==1.0)"✓ Full" else "✓ Half",color=Green,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                                val fullSelected = a?.fraction == 1.0
                                val halfSelected = a?.fraction == 0.5
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.9999 || fullSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,1.0)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,1.0,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:""
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(fullSelected) Green else Color.White,
                                        contentColor=if(fullSelected) Color.White else Green
                                    ),
                                    border=if(fullSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Green)
                                ){Text(if(fullSelected)"✓ पूरा दिन" else "पूरा दिन",fontWeight=FontWeight.Bold)}
                                Button(
                                    enabled=(crops.size<=1||activeCrop.isNotBlank()) && (remaining>=0.5 || halfSelected),
                                    onClick={
                                        if(a!=null){
                                            protectedAttendanceEdit=Pair(a,0.5)
                                        }else{
                                            val result=store.upsertAttendance(Attendance(UUID.randomUUID().toString(),l.id,activeField,activeCrop,selectedDate,0.5,store.rateFor(l.id,selectedDate)))
                                            attendanceError=result?:""
                                        }
                                    },
                                    modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),
                                    colors=ButtonDefaults.buttonColors(
                                        containerColor=if(halfSelected) Color(0xFF6B4BC1) else Color.White,
                                        contentColor=if(halfSelected) Color.White else Color(0xFF6B4BC1)
                                    ),
                                    border=if(halfSelected) null else androidx.compose.foundation.BorderStroke(1.5.dp,Color(0xFF6B4BC1))
                                ){Text(if(halfSelected)"✓ आधा दिन" else "आधा दिन",fontWeight=FontWeight.Bold)}
                                if(a!=null){
                                    IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                }
                            }
                        }
                    }
                }
            }
            if(store.fields.isEmpty()) this.item{Text("पहले Field में खेत जोड़ें।",color=Color.Gray)}
            if(store.labours.isEmpty()) this.item{Text("पहले Labour में मजदूर जोड़ें।",color=Color.Gray)}

            this.item{
                Text("इस तारीख की लगी हुई हाजिरी",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
            }
            this.items(store.attendances.filter{it.date==selectedDate}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}),key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth()){
                    Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                        Column(Modifier.weight(1f)){
                            Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold)
                            Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"Full" else "Half"} • ₹${money(a.fraction*a.rate)}",fontSize=11.sp,color=Color.Gray)
                        }
                        IconButton(onClick={deleteAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }
        }

        protectedAttendanceEdit?.let{pending->
            DeviceCredentialGate(
                "हाजिरी बदलें",
                "हाजिरी का पूरा दिन/आधा दिन बदलने के लिए Android screen lock से पुष्टि करें।",
                {
                    val a=pending.first
                    val result=store.upsertAttendance(a.copy(fraction=pending.second,rate=store.rateFor(a.labourId,a.date)))
                    attendanceError=result?:"हाजिरी सफलतापूर्वक बदली गई।"
                    protectedAttendanceEdit=null
                },
                {protectedAttendanceEdit=null}
            )
        }

        credentialDelete?.let{a->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                {store.deleteAttendance(a.id);deleteAttendance=null;attendanceError="हाजिरी सफलतापूर्वक हटाई गई।"},
                {deleteAttendance=null}
            )
        }
    }
}

@Composable private fun FieldDetail(store:Store,id:String,onBack:()->Unit,onCrop:(String)->Unit,onAttendance:(String)->Unit,onExpense:()->Unit,onSale:()->Unit,onAddCrop:()->Unit){val f=store.fields.firstOrNull{it.id==id}?:return;val crops=store.crops.filter{it.fieldId==id};val labourCost=store.attendances.filter{it.fieldId==id}.sumOf{it.fraction*it.rate};val exp=store.expenses.filter{it.fieldId==id}.sumOf{it.amount};val sale=store.sales.filter{it.fieldId==id}.sumOf{it.total};val total=labourCost+exp;Column(Modifier.fillMaxSize()){DetailTopBar("🌾 ${f.name.ifBlank{"खेत"}}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",total)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-total)}}};this.item{SmallAction("👷 Labour / हाजिरी",{onAttendance(id)})};this.item{SmallAction("💰 खेती का खर्च",onExpense)};this.item{SmallAction("🧺 Sale",onSale)};this.item{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("🌱 फसल",modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp);IconButton(onClick=onAddCrop){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}};this.items(crops,key={it.id}){c->Card(Modifier.fillMaxWidth().clickable{onCrop(c.id)},RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp)){Text(c.name,fontWeight=FontWeight.Bold);Text(listOf(c.variety,c.season).filter{it.isNotBlank()}.joinToString(" • "),fontSize=12.sp,color=Color.Gray)}}};this.item{Text("कुल मजदूरी: ₹${money(labourCost)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल खेती खर्च: ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल लागत: ₹${money(total)}",fontWeight=FontWeight.Bold)};this.item{Text("कुल बिक्री: ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{Text("लाभ: ₹${money(sale-total)}",fontWeight=FontWeight.Bold,color=Green)}}}}

@Composable
private fun TodayAttendanceScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val day=today()
    val rows=store.attendances.filter{it.date==day}.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId})
    val total=rows.sumOf{it.fraction*it.rate}
    val workerCount=rows.map{it.labourId}.distinct().size
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 आज की हाजिरी • ${displayDate(day)}",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Box(Modifier.weight(1f)){Stat("कुल मजदूर",workerCount.toDouble())}
                    Box(Modifier.weight(1f)){Stat("कुल मजदूरी",total)}
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else "आधा दिन"} • ₹${money(a.fraction*a.rate)}"})},
                    onPdf={exportReportPdf(context,"आज_की_हाजिरी","${displayDate(day)} • ${workerCount} मजदूर • कुल मजदूरी ₹${money(total)}",rows.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else "आधा दिन"} • ₹${money(a.fraction*a.rate)}"})}
                )
            }
            items(rows,key={it.id}){a->
                val l=store.labours.firstOrNull{it.id==a.labourId}; val f=store.fields.firstOrNull{it.id==a.fieldId}; val c=store.crops.firstOrNull{it.id==a.cropId}
                Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){
                        Text("👷",fontSize=24.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text(l?.name?:"मजदूर",fontWeight=FontWeight.Bold);Text("${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""}",fontSize=11.sp,color=Color.Gray)}
                        Surface(shape=RoundedCornerShape(10.dp),color=if(a.fraction==1.0) Color(0xFFE0F5E8) else Color(0xFFE9E0FF)){Text(if(a.fraction==1.0)"पूरा दिन" else "आधा दिन",Modifier.padding(horizontal=9.dp,vertical=6.dp),fontSize=11.sp,fontWeight=FontWeight.Bold,color=if(a.fraction==1.0)Green else Color(0xFF6B4BC1))}
                        Spacer(Modifier.width(8.dp));Text("₹${money(a.fraction*a.rate)}",fontWeight=FontWeight.Bold)
                    }
                }
            }
            if(rows.isEmpty()) item{Text("आज अभी कोई हाजिरी नहीं लगी है।",color=Color.Gray)}
        }
    }
}

@Composable
private fun AttendanceHistoryScreen(store:Store,onBack:()->Unit){
    val context=LocalContext.current
    val months=store.attendances.map{it.date.take(7)}.distinct().sortedDescending()
    var monthIndex by remember { mutableStateOf(0) }
    val month=months.getOrNull(monthIndex) ?: today().take(7)
    val rows=store.attendances.filter{it.date.startsWith(month)}.sortedByDescending{it.date}
    val total=rows.sumOf{it.fraction*it.rate}
    val dayGroups=rows.groupBy{it.date}.toList().sortedByDescending{it.first}
    Column(Modifier.fillMaxSize().background(Bg)){
        DetailTopBar("📋 हाजिरी सूची",onBack)
        LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
            item{
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                    Column(Modifier.padding(14.dp)){
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                            IconButton(enabled=monthIndex < months.lastIndex,onClick={if(monthIndex < months.lastIndex) monthIndex++}){Icon(Icons.Default.ChevronLeft,null)}
                            Text(if(month.isBlank())"हाजिरी सूची" else monthTitle(month),Modifier.weight(1f),fontSize=18.sp,fontWeight=FontWeight.ExtraBold,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
                            IconButton(enabled=monthIndex>0,onClick={if(monthIndex>0) monthIndex--}){Icon(Icons.Default.ChevronRight,null)}
                        }
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल दिन",dayGroups.size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूर",rows.map{it.labourId}.distinct().size.toDouble())}
                            Box(Modifier.weight(1f)){Stat("मजदूरी",total)}
                        }
                    }
                }
            }
            item{
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"हाजिरी_सूची_$month","महीना $month • ${rows.size} रिकॉर्ड • कुल मजदूरी ₹${money(total)}",rows.map{a->val l=store.labours.firstOrNull{it.id==a.labourId};"${displayDate(a.date)} • ${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा दिन" else "आधा दिन"} • ₹${money(a.fraction*a.rate)}"})},
                    onPdf={exportAttendanceHistoryPdf(context,"हाजिरी_सूची_$month",month,dayGroups,store)}
                )
            }
            dayGroups.forEach{(date,dayRows)->
                item{
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                        Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(displayDate(date),fontWeight=FontWeight.Bold,fontSize=16.sp);Text("${dayRows.size} मजदूर",fontSize=11.sp,color=Color.Gray)};Text("₹${money(dayRows.sumOf{it.fraction*it.rate})}",fontWeight=FontWeight.ExtraBold,color=Green)}
                        Column(Modifier.padding(horizontal=4.dp)){dayRows.forEach{a->val l=store.labours.firstOrNull{it.id==a.labourId};Text("${l?.name?:"मजदूर"} • ${if(a.fraction==1.0)"पूरा" else "आधा"}",fontSize=11.sp)}}
                    }
                }
            }
            if(rows.isEmpty()) item{Text("इस महीने कोई हाजिरी रिकॉर्ड नहीं है।",color=Color.Gray)}
        }
    }
}

@Composable
private fun LabourDetail(
    store: Store,
    id: String,
    onBack: () -> Unit
) {
    val l = store.labours.firstOrNull { it.id == id } ?: return
    val context=LocalContext.current

    var edit by remember { mutableStateOf(false) }
    var payment by remember { mutableStateOf(false) }
    var rate by remember { mutableStateOf(false) }
    var protectedRateEdit by remember { mutableStateOf(false) }
    var delPay by remember { mutableStateOf<Payment?>(null) }
    var delAttendance by remember { mutableStateOf<Attendance?>(null) }

    val wage = store.attendances
        .filter { it.labourId == id }
        .sumOf { it.fraction * it.rate }

    val paid = store.payments
        .filter { it.labourId == id }
        .sumOf { it.amount }

    Column(Modifier.fillMaxSize()) {
        DetailTopBar(
            "👷 ${l.name.ifBlank { "मजदूर" }}",
            onBack
        )

        LazyColumn(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            this.item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(Modifier.weight(1f)) { Stat("मजदूरी", wage) }
                    Box(Modifier.weight(1f)) { Stat("भुगतान", paid) }
                    Box(Modifier.weight(1f)) { Stat("बाकी", wage - paid) }
                }
            }

            this.item {
                Button(
                    onClick = { payment = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("₹ Cash+ भुगतान जोड़ें")
                }
            }

            this.item {
                Button(
                    onClick = { protectedRateEdit = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
                ) {
                    Text("दिहाड़ी बदलें")
                }
            }

            this.item {
                val attendanceRows=store.attendances.filter{it.labourId==id}.sortedByDescending{it.date}
                val paymentRows=store.payments.filter{it.labourId==id}.sortedByDescending{it.date}
                val report=attendanceRows.map{a->val f=store.fields.firstOrNull{it.id==a.fieldId};"${displayDate(a.date)} • ${f?.name?:"खेत"} • ${if(a.fraction==1.0)"पूरा दिन" else "आधा दिन"} • ₹${money(a.fraction*a.rate)}"} + listOf("","भुगतान") + paymentRows.map{p->"${displayDate(p.date)} • भुगतान • ₹${money(p.amount)}"}
                ExportButtons(
                    onPhoto={exportReportPhoto(context,"${l.name}_हिसाब","कुल मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बाकी ₹${money(wage-paid)}",report)},
                    onPdf={exportReportPdf(context,"${l.name}_हिसाब","कुल मजदूरी ₹${money(wage)} • भुगतान ₹${money(paid)} • बाकी ₹${money(wage-paid)}",report)}
                )
            }

            this.item {
                Text(
                    "वर्तमान दिहाड़ी: ₹${money(store.rateFor(id, today()))}/दिन",
                    fontWeight = FontWeight.Bold,
                    color = Green
                )
            }

            this.item {
                Text(
                    "दिहाड़ी इतिहास",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(store.rateHistoryFor(id), key = { it.id }) { r ->
                Text(
                    "${displayDate(r.effectiveDate)} से ₹${money(r.rate)}/दिन",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            this.item {
                val labourRows = store.attendances.filter { it.labourId == id }
                val fullDays = labourRows.count { it.fraction == 1.0 }
                val halfDays = labourRows.count { it.fraction == 0.5 }
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                    Column(Modifier.padding(12.dp)){
                        Text("📊 काम का सार",fontWeight=FontWeight.ExtraBold,fontSize=17.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            Box(Modifier.weight(1f)){Stat("कुल काम",labourRows.sumOf{it.fraction})}
                            Box(Modifier.weight(1f)){Stat("पूरा दिन",fullDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("आधा दिन",halfDays.toDouble())}
                            Box(Modifier.weight(1f)){Stat("कुल मजदूरी",wage)}
                        }
                    }
                }
            }

            this.item {
                Text(
                    "हाजिरी",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                store.attendances
                    .filter { it.labourId == id }
                    .sortedByDescending { it.date },
                key = { it.id }
            ) { a ->
                val f = store.fields.firstOrNull { it.id == a.fieldId }
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                        Text(
                            "${displayDate(a.date)} • ${f?.name ?: "खेत"} • " +
                                "${store.crops.firstOrNull { it.id == a.cropId }?.name?.let { "$it • " } ?: ""}" +
                                "${if (a.fraction == 1.0) "Full" else "Half"} • " +
                                "₹${money(a.fraction * a.rate)}",
                            Modifier.weight(1f)
                        )
                        IconButton(onClick={delAttendance=a}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                    }
                }
            }

            this.item {
                Text(
                    "भुगतान",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            this.items(
                store.payments
                    .filter { it.labourId == id }
                    .sortedByDescending { it.date },
                key = { it.id }
            ) { p ->
                val f = store.fields.firstOrNull { it.id == p.fieldId }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${displayDate(p.date)} • ${f?.name ?: "सामान्य"}" +
                            "${store.crops.firstOrNull { it.id == p.cropId }?.name?.let { " • $it" } ?: ""}" +
                            " • ₹${money(p.amount)}",
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { delPay = p }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = Color(0xFFB3261E)
                        )
                    }
                }
            }
        }

        if (edit) {
            LabourDialog(store, l) {
                edit = false
            }
        }

        if (payment) {
            PaymentDialog(store, id, null, "") {
                payment = false
            }
        }

        protectedRateEdit.takeIf{it}?.let{
            DeviceCredentialGate(
                "दिहाड़ी बदलें",
                "मजदूर की दिहाड़ी बदलने के लिए Android screen lock से पुष्टि करें।",
                {rate=true;protectedRateEdit=false},
                {protectedRateEdit=false}
            )
        }

        if (rate) {
            RateDialog(store, id) {
                rate = false
            }
        }

        delAttendance?.let { attendanceItem ->
            DeviceCredentialDeleteGate(
                "हाजिरी हटाएँ",
                "गलत हाजिरी हटाने के लिए Android screen lock से पुष्टि करें।",
                { store.deleteAttendance(attendanceItem.id); delAttendance = null },
                { delAttendance = null }
            )
        }

        delPay?.let { paymentItem ->
            DeviceCredentialDeleteGate(
                "भुगतान हटाएँ",
                "गलत payment entry हटाने के लिए Android screen lock से पुष्टि करें।",
                { store.deletePayment(paymentItem.id); delPay = null },
                { delPay = null }
            )
        }
        /*
        delPay?.let { paymentItem ->
            ConfirmDialog(
                "भुगतान हटाएँ?",
                "यह payment record हट जाएगा।",
                {
                    store.deletePayment(paymentItem.id)
                    delPay = null
                },
                {
                    delPay = null
                }
            )
        }
        */
    }
}


@Composable
private fun ExportButtons(onPhoto:()->Unit,onPdf:()->Unit){
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
        Button(onClick=onPhoto,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6B4BC1))){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(6.dp));Text("Photo",fontWeight=FontWeight.Bold)}
        Button(onClick=onPdf,modifier=Modifier.weight(1f),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.PictureAsPdf,null);Spacer(Modifier.width(6.dp));Text("PDF",fontWeight=FontWeight.Bold)}
    }
}

private fun safeFileName(value:String):String=value.replace(Regex("[^A-Za-z0-9_-]+"),"_").trim('_').ifBlank{"report"}

private fun shareFile(context:Context,file:File,mime:String,title:String){
    val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file)
    val intent=Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
    context.startActivity(Intent.createChooser(intent,title))
}

private fun wrapReportText(text:String, paint:Paint, maxWidth:Float):List<String>{
    val words=text.trim().split(Regex("\\s+"))
    if(words.isEmpty()) return listOf("")
    val out=mutableListOf<String>(); var line=""
    for(word in words){
        val candidate=if(line.isBlank()) word else "$line $word"
        if(paint.measureText(candidate)<=maxWidth){line=candidate}else{
            if(line.isNotBlank()) out.add(line)
            line=word
        }
    }
    if(line.isNotBlank()) out.add(line)
    return out.ifEmpty{listOf("")}
}

private fun exportReportPhoto(context:Context,title:String,summary:String,lines:List<String>){
    try{
        val width=1200; val side=45f; val contentW=width-side*2; val lineH=38f; val headerH=255f
        val textPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.BLACK;typeface=Typeface.DEFAULT;textSize=27f}
        val wrapped=lines.flatMapIndexed{idx,line->wrapReportText("${idx+1}. $line",textPaint,contentW)}
        val height=(headerH+wrapped.size*lineH+70f).toInt().coerceAtLeast(500)
        val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
        val canvas=Canvas(bitmap); canvas.drawColor(android.graphics.Color.WHITE)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(6,76,54);typeface=Typeface.DEFAULT_BOLD;textSize=46f}
        canvas.drawText("MAJDOOR HISAAB PRO",side,65f,paint)
        paint.typeface=Typeface.DEFAULT;paint.textSize=30f;paint.color=android.graphics.Color.DKGRAY
        canvas.drawText(title,side,115f,paint)
        paint.textSize=26f;paint.color=android.graphics.Color.rgb(11,107,74)
        wrapReportText(summary,paint,contentW).take(2).forEachIndexed{i,t->canvas.drawText(t,side,165f+i*32f,paint)}
        paint.color=android.graphics.Color.LTGRAY;canvas.drawRect(side,205f,width-side,207f,paint)
        paint.color=android.graphics.Color.BLACK;paint.textSize=27f;paint.typeface=Typeface.DEFAULT
        var y=250f
        wrapped.forEach{line->canvas.drawText(line,side,y,paint);y+=lineH}
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}; val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}; bitmap.recycle(); shareFile(context,file,"image/png","Photo साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Photo report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun exportAttendanceHistoryPdf(context:Context,title:String,month:String,dayGroups:List<Pair<String,List<Attendance>>>,store:Store){
    try{
        val doc=PdfDocument()
        val pageW=595; val pageH=842; val left=32f; val maxW=pageW-left*2
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{typeface=Typeface.DEFAULT;textSize=11f}
        var pageNo=1
        var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
        var canvas=page.canvas
        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=24f
            canvas.drawText("MAJDOOR HISAAB PRO",left,40f,paint)
            paint.color=android.graphics.Color.BLACK
            paint.textSize=17f
            canvas.drawText("हाजिरी सूची • ${monthTitle(month)}",left,68f,paint)
            paint.typeface=Typeface.DEFAULT
            paint.textSize=11f
            paint.color=android.graphics.Color.DKGRAY
            canvas.drawText("हर तारीख का काम अलग समूह में",left,90f,paint)
            paint.color=android.graphics.Color.LTGRAY
            canvas.drawRect(left,103f,pageW-left,105f,paint)
        }
        fun newPage(){
            doc.finishPage(page);pageNo++
            page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create())
            canvas=page.canvas
            header()
        }
        header()
        var y=130f
        dayGroups.sortedByDescending{it.first}.forEach{(date,dayRows)->
            val dayTotal=dayRows.sumOf{it.fraction*it.rate}
            val workers=dayRows.map{it.labourId}.distinct().size
            if(y>740f) { newPage(); y=130f }
            paint.color=android.graphics.Color.rgb(234,248,241)
            canvas.drawRoundRect(left,y-22f,pageW-left,y+24f,12f,12f,paint)
            paint.color=android.graphics.Color.rgb(6,76,54)
            paint.typeface=Typeface.DEFAULT_BOLD
            paint.textSize=14f
            canvas.drawText(displayDate(date),left+12f,y+2f,paint)
            paint.typeface=Typeface.DEFAULT
            paint.textSize=10f
            canvas.drawText("$workers मजदूर",left+145f,y+2f,paint)
            paint.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText("कुल मजदूरी ₹${money(dayTotal)}",left+330f,y+2f,paint)
            y+=48f
            paint.color=android.graphics.Color.BLACK
            paint.typeface=Typeface.DEFAULT
            paint.textSize=10.5f
            dayRows.sortedWith(compareBy<Attendance>{it.labourId}.thenBy{it.fieldId}).forEachIndexed{index,a->
                val l=store.labours.firstOrNull{it.id==a.labourId}
                val f=store.fields.firstOrNull{it.id==a.fieldId}
                val c=store.crops.firstOrNull{it.id==a.cropId}
                val line="${index+1}. ${l?.name?:"मजदूर"} • ${f?.name?:"खेत"}${c?.name?.let{" • $it"}?:""} • ${if(a.fraction==1.0)"पूरा दिन" else "आधा दिन"} • ₹${money(a.fraction*a.rate)}"
                val wrapped=wrapReportText(line,paint,maxW-20f)
                wrapped.forEach{part->
                    if(y>805f){newPage();y=130f}
                    canvas.drawText(part,left+12f,y,paint);y+=16f
                }
                y+=4f
            }
            paint.color=android.graphics.Color.LTGRAY
            canvas.drawRect(left,y,pageW-left,y+1f,paint)
            y+=22f
        }
        doc.finishPage(page)
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf")
        FileOutputStream(file).use{doc.writeTo(it)}
        doc.close()
        shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){
        android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()
    }
}

private fun exportReportPdf(context:Context,title:String,summary:String,lines:List<String>){
    try{
        val doc=PdfDocument(); val pageW=595; val pageH=842; val left=28f; val right=28f; val maxW=pageW-left-right
        val paint=Paint(Paint.ANTI_ALIAS_FLAG); paint.typeface=Typeface.DEFAULT; paint.textSize=11f
        var pageNo=1; var page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create()); var canvas=page.canvas
        fun header(){
            paint.color=android.graphics.Color.rgb(6,76,54);paint.typeface=Typeface.DEFAULT_BOLD;paint.textSize=24f;canvas.drawText("MAJDOOR HISAAB PRO",left,42f,paint)
            paint.color=android.graphics.Color.BLACK;paint.textSize=19f;canvas.drawText(title.take(45),left,76f,paint)
            paint.textSize=12f;paint.typeface=Typeface.DEFAULT
            wrapReportText(summary,paint,maxW).take(2).forEachIndexed{i,t->canvas.drawText(t,left,100f+i*17f,paint)}
        }
        header(); var y=140f; var rowNo=1
        lines.forEach{line->
            val wrapped=wrapReportText("$rowNo. $line",paint,maxW)
            for(part in wrapped){
                if(y>805f){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(pageW,pageH,pageNo).create());canvas=page.canvas;header();y=140f}
                canvas.drawText(part,left,y,paint);y+=18f
            }
            rowNo++
            y+=4f
        }
        doc.finishPage(page); val dir=File(context.cacheDir,"reports").apply{mkdirs()};val file=File(dir,"${safeFileName(title)}_${System.currentTimeMillis()}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close();shareFile(context,file,"application/pdf","PDF साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"PDF report नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

private fun caneSeason(date:String=today()):String{
    return try{
        val y=date.take(4).toInt(); val m=date.substring(5,7).toInt()
        if(m>=4) "$y-${(y+1).toString().takeLast(2)}" else "${y-1}-${y.toString().takeLast(2)}"
    }catch(_:Exception){"2026-27"}
}

@Composable
private fun CaneParchiScreen(store:Store,onBack:()->Unit){
    var search by rememberSaveable{mutableStateOf("")}
    var season by rememberSaveable{mutableStateOf(caneSeason())}
    var tab by rememberSaveable{mutableStateOf(0)}
    var showForm by remember{mutableStateOf(false)}
    var edit by remember{mutableStateOf<CaneParchi?>(null)}
    var protectedEdit by remember{mutableStateOf<CaneParchi?>(null)}
    var protectedDelete by remember{mutableStateOf<CaneParchi?>(null)}
    var showPrice by remember{mutableStateOf(false)}
    var protectedPrice by remember{mutableStateOf(false)}
    var selected by remember{mutableStateOf<CaneParchi?>(null)}
    var sortMode by rememberSaveable{mutableStateOf("date")}
    var filterMenu by remember{mutableStateOf("")}

    val availableSeasons=(store.caneParchis.map{it.season}+store.canePrices.map{it.season}+caneSeason())
        .filter{it.isNotBlank()}.distinct().sortedDescending()
    val seasonOptions=listOf("ALL" to "सभी")+availableSeasons.map{it to it}
    if(season!="ALL" && season !in availableSeasons) season=caneSeason()
    val priceSeason=if(season=="ALL") caneSeason() else season
    val filteredList=store.caneParchis
        .filter{(season=="ALL"||it.season==season) && (search.isBlank()||it.name.contains(search,true)||it.code.contains(search,true)||it.fatherName.contains(search,true))}
    val list=when(sortMode){
        "priceHigh"->filteredList.sortedWith(compareByDescending<CaneParchi>{it.rate}.thenByDescending{it.date}.thenBy{it.name})
        "priceLow"->filteredList.sortedWith(compareBy<CaneParchi>{it.rate}.thenByDescending{it.date}.thenBy{it.name})
        "oldest"->filteredList.sortedWith(compareBy<CaneParchi>{it.date}.thenBy{it.name})
        else->filteredList.sortedWith(compareByDescending<CaneParchi>{it.date}.thenBy{it.name})
    }
    val totalWeight=list.sumOf{it.weight}
    val totalAmount=list.sumOf{it.weight*it.rate}
    val context=LocalContext.current

    Column(Modifier.fillMaxSize().background(Bg)){
        Row(Modifier.fillMaxWidth().padding(horizontal=6.dp,vertical=4.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"वापस")}
            Text("गन्ना पर्ची",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark,modifier=Modifier.weight(1f))
        }
        // Four clear tabs, matching the reference design. Each tab has a single job.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=10.dp,vertical=7.dp),
            horizontalArrangement=Arrangement.spacedBy(6.dp)
        ){
            listOf("पर्ची सूची","नई पर्ची","भाव इतिहास","रिपोर्ट").forEachIndexed{index,title->
                FilterChip(
                    selected=tab==index,
                    onClick={tab=index},
                    label={Text(title,fontSize=12.sp,fontWeight=FontWeight.SemiBold)},
                    leadingIcon=if(tab==index){null}else null
                )
            }
        }

        when(tab){
            0->{
                Column(Modifier.fillMaxWidth().padding(horizontal=14.dp)){
                    Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                            Column(Modifier.weight(1f)){
                                Text("इस वर्ष का गन्ना भाव",fontSize=13.sp,color=GreenDark)
                                Text("₹${money(store.caneRateFor(priceSeason,today()))} / क्विंटल",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                                Text("सीजन $priceSeason",fontSize=11.sp,color=Color.Gray)
                            }
                            Button(onClick={protectedPrice=true},shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("भाव बदलें")}
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                        SummaryMini("कुल पर्चियां",list.size.toDouble(),"",Modifier.weight(1f))
                        SummaryMini("कुल वजन",totalWeight,"क्विंटल",Modifier.weight(1f))
                        SummaryMini("कुल राशि",totalAmount,"",Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(9.dp))
                    OutlinedTextField(
                        value=search,onValueChange={search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                        placeholder={Text("नाम, पर्ची कोड से खोजें...")},leadingIcon={Icon(Icons.Default.Search,null)},
                        trailingIcon={if(search.isNotBlank()) IconButton(onClick={search=""}){Icon(Icons.Default.Close,"साफ करें")} else null},
                        shape=RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        FilterChip(selected=season=="ALL",onClick={season="ALL"},label={Text("सभी",fontSize=11.sp)})
                        Box(Modifier.weight(1f)){
                            var open by remember{mutableStateOf(false)}
                            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),contentPadding=PaddingValues(horizontal=10.dp,vertical=0.dp)){
                                Text(if(season=="ALL")"वर्ष" else season,fontSize=11.sp,maxLines=1)
                                Icon(Icons.Default.ArrowDropDown,null,Modifier.size(18.dp))
                            }
                            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                                seasonOptions.forEach{(id,label)->DropdownMenuItem(text={Text(label)},onClick={season=id;open=false})}
                            }
                        }
                        Box{
                            FilterChip(selected=sortMode=="date"||sortMode=="oldest",onClick={filterMenu="date"},label={Text("तारीख",fontSize=11.sp)})
                            DropdownMenu(expanded=filterMenu=="date",onDismissRequest={filterMenu=""}){
                                DropdownMenuItem(text={Text("नवीन तारीख पहले")},onClick={sortMode="date";filterMenu=""})
                                DropdownMenuItem(text={Text("पुरानी तारीख पहले")},onClick={sortMode="oldest";filterMenu=""})
                            }
                        }
                        Box{
                            FilterChip(selected=sortMode=="priceHigh"||sortMode=="priceLow",onClick={filterMenu="price"},label={Text("भाव",fontSize=11.sp)})
                            DropdownMenu(expanded=filterMenu=="price",onDismissRequest={filterMenu=""}){
                                DropdownMenuItem(text={Text("अधिक भाव पहले")},onClick={sortMode="priceHigh";filterMenu=""})
                                DropdownMenuItem(text={Text("कम भाव पहले")},onClick={sortMode="priceLow";filterMenu=""})
                            }
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Button(onClick={edit=null;tab=1},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                        Icon(Icons.Default.Add,null);Spacer(Modifier.width(7.dp));Text("नई गन्ना पर्ची जोड़ें",fontWeight=FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(7.dp))
                LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(horizontal=14.dp,bottom=16.dp),modifier=Modifier.weight(1f)){
                    if(list.isEmpty()) item{Card(Modifier.fillMaxWidth(),RoundedCornerShape(16.dp)){Text("इस वर्ष कोई पर्ची नहीं मिली।",Modifier.padding(20.dp),color=Color.Gray)}}
                    items(list,key={it.id}){p->
                        Card(Modifier.fillMaxWidth().clickable{selected=p},RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){
                            Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){
                                if(p.photo.isNotBlank()) PhotoThumb(p.photo,Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)))
                                else Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEAF8F1)),contentAlignment=Alignment.Center){Text("🌾",fontSize=25.sp)}
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)){
                                    Text(p.name,fontWeight=FontWeight.ExtraBold,fontSize=16.sp)
                                    Text("पर्ची #${p.code} • ${displayDate(p.date)}",fontSize=11.sp,color=Color.Gray)
                                    Text("${String.format(Locale.US,"%.2f",p.weight)} क्विंटल × ₹${money(p.rate)}",fontSize=12.sp,color=GreenDark)
                                    if(p.remark.isNotBlank()) Text("टिप्पणी: ${p.remark}",fontSize=10.sp,color=Color.Gray,maxLines=1)
                                }
                                Column(horizontalAlignment=Alignment.End){
                                    Text("₹${money(p.weight*p.rate)}",fontWeight=FontWeight.ExtraBold,color=Green)
                                    Row{
                                        IconButton(onClick={protectedEdit=p}){Icon(Icons.Default.Edit,null,tint=Green)}
                                        IconButton(onClick={protectedDelete=p}){Icon(Icons.Default.Delete,null,tint=Color(0xFFB3261E))}
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1->{
                CaneParchiFormScreen(store,existing=edit,onClose={edit=null;tab=0})
            }
            2->{
                Column(Modifier.fillMaxSize().padding(14.dp)){
                    Text("गन्ना भाव इतिहास",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                    Spacer(Modifier.height(8.dp))
                    Text("हर प्रभावी तारीख का भाव सुरक्षित रहता है। पुरानी पर्चियों का saved rate नहीं बदलता।",fontSize=12.sp,color=Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick={protectedPrice=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("+ नया भाव जोड़ें")}
                    Spacer(Modifier.height(10.dp))
                    Card(Modifier.fillMaxWidth(),RoundedCornerShape(14.dp)){
                        Column(Modifier.padding(12.dp)){
                            Row(Modifier.fillMaxWidth().padding(bottom=7.dp)){Text("क्रम",Modifier.weight(.55f),fontWeight=FontWeight.Bold);Text("दिनांक",Modifier.weight(1f),fontWeight=FontWeight.Bold);Text("भाव/क्विंटल",Modifier.weight(1.2f),fontWeight=FontWeight.Bold)}
                            store.canePricesFor(priceSeason).forEachIndexed{i,p->Row(Modifier.fillMaxWidth().padding(vertical=7.dp)){Text("${i+1}",Modifier.weight(.55f));Text(displayDate(p.effectiveDate),Modifier.weight(1f));Text("₹${money(p.rate)}",Modifier.weight(1.2f),fontWeight=FontWeight.Bold,color=GreenDark)}}
                        }
                    }
                }
            }
            3->{
                Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(14.dp)){
                    Text("रिपोर्ट",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                    Spacer(Modifier.height(8.dp))
                    Text("सालवार सारांश • ${if(season=="ALL")"सभी वर्ष" else season}",fontSize=12.sp,color=Color.Gray)
                    Spacer(Modifier.height(9.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){
                        SummaryMini("कुल पर्चियां",list.size.toDouble(),"",Modifier.weight(1f))
                        SummaryMini("कुल वजन",totalWeight,"क्विंटल",Modifier.weight(1f))
                        SummaryMini("कुल राशि",totalAmount,"",Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Card(Modifier.fillMaxWidth(),RoundedCornerShape(14.dp)){
                        Column(Modifier.padding(12.dp)){
                            Text("भाव अनुसार विवरण",fontWeight=FontWeight.ExtraBold,color=GreenDark)
                            Spacer(Modifier.height(6.dp))
                            store.canePricesFor(priceSeason).sortedBy{it.rate}.forEach{price->
                                val rows=list.filter{it.rate==price.rate}
                                if(rows.isNotEmpty()){
                                    Text("₹${money(price.rate)} / क्विंटल  •  ${rows.size} पर्चियां  •  ${String.format(Locale.US,"%.2f",rows.sumOf{it.weight})} क्विंटल  •  ₹${money(rows.sumOf{it.weight*it.rate})}",fontSize=12.sp,modifier=Modifier.padding(vertical=5.dp))
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    val reportSeason=if(season=="ALL")"सभी वर्ष" else season
                    val reportSummary="$reportSeason • ${list.size} पर्चियां • कुल वजन ${String.format(Locale.US,"%.2f",totalWeight)} क्विंटल • कुल राशि ₹${money(totalAmount)}"
                    val reportLines=list.map{p->
                        val wt=String.format(Locale.US,"%.2f",p.weight)
                        "${p.name} • ${p.code} • ${displayDate(p.date)} • $wt क्विंटल • ₹${money(p.rate)} • ₹${money(p.weight*p.rate)}"
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button(onClick={exportReportPdf(context,"गन्ना_पर्ची_रिपोर्ट",reportSummary,reportLines)},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp)){Text("PDF बनाएं")}
                        Button(onClick={exportCaneCsv(context,list,if(season=="ALL")"सभी_वर्ष" else season)},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("Excel बनाएं")}
                    }
                }
            }
        }
    }

    protectedEdit?.let{p->DeviceCredentialGate("गन्ना पर्ची बदलें","पर्ची की जानकारी बदलने के लिए Android screen lock से पुष्टि करें।",{edit=p;protectedEdit=null;tab=1},{protectedEdit=null})}
    protectedDelete?.let{p->DeviceCredentialGate("गन्ना पर्ची हटाएँ","यह गन्ना पर्ची स्थायी रूप से हट जाएगी।",{store.deleteCaneParchi(p.id);protectedDelete=null},{protectedDelete=null})}
    if(protectedPrice) DeviceCredentialGate("गन्ना भाव बदलें","गन्ने के भाव में बदलाव के लिए Android screen lock से पुष्टि करें।",{protectedPrice=false;showPrice=true},{protectedPrice=false})
    selected?.let{p->CaneParchiDetail(p){selected=null}}
    if(showPrice) CanePriceDialog(store,priceSeason){showPrice=false}
}

private fun exportCaneCsv(context:Context,list:List<CaneParchi>,season:String){
    try{
        val dir=File(context.cacheDir,"reports").apply{mkdirs()}
        val file=File(dir,"Ganna_Parchi_${safeFileName(season)}_${System.currentTimeMillis()}.csv")
        FileOutputStream(file).use{out->
            out.write(byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()))
            out.bufferedWriter(Charsets.UTF_8).use{w->
                w.append("नाम,पिता का नाम,पर्ची कोड,दिनांक,वजन (क्विंटल),भाव/क्विंटल,कुल राशि,टिप्पणी").append('\n')
                list.forEach{p->
                    fun q(s:String) = "\"" + s.replace("\"", "\"\"") + "\""
                    w.append(listOf(q(p.name),q(p.fatherName),q(p.code),q(displayDate(p.date)),q(String.format(Locale.US,"%.2f",p.weight)),q(money(p.rate)),q(money(p.weight*p.rate)),q(p.remark)).joinToString(",")).append('\n')
                }
            }
        }
        shareFile(context,file,"text/csv","Excel साझा करें")
    }catch(e:Exception){android.widget.Toast.makeText(context,"Excel रिपोर्ट नहीं बन सकी: ${e.message}",android.widget.Toast.LENGTH_LONG).show()}
}

@Composable private fun SummaryMini(label:String,value:Double,unit:String,modifier:Modifier){Card(modifier,shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(9.dp)){Text(label,fontSize=10.sp,color=Color.Gray);Text(if(label=="कुल राशि")"₹${money(value)}" else money(value),fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark);if(unit.isNotBlank())Text(unit,fontSize=9.sp,color=Color.Gray)}}}

@Composable
private fun CaneParchiFormScreen(store:Store,existing:CaneParchi?=null,onClose:()->Unit){
    var name by rememberSaveable(existing?.id){mutableStateOf(existing?.name?:"")}
    var father by rememberSaveable(existing?.id){mutableStateOf(existing?.fatherName?:"")}
    var code by rememberSaveable(existing?.id){mutableStateOf(existing?.code?:"")}
    var date by rememberSaveable(existing?.id){mutableStateOf(existing?.date?:today())}
    var weight by rememberSaveable(existing?.id){mutableStateOf(if(existing==null)"" else existing.weight.toString())}
    var remark by rememberSaveable(existing?.id){mutableStateOf(existing?.remark?:"")}
    var photo by rememberSaveable(existing?.id){mutableStateOf(existing?.photo?:"")}
    var error by rememberSaveable{mutableStateOf("")}
    val season=caneSeason(date)
    val rate=store.caneRateFor(season,date)
    val amount=(weight.toDoubleOrNull()?:0.0)*rate
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)photo=store.persistPhoto(uri.toString(),"cane")}
    val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()){bitmap->if(bitmap!=null)photo=store.persistBitmapPhoto(bitmap,"cane")}
    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onClose){Icon(Icons.Default.ArrowBack,"वापस")}
            Text(if(existing==null)"नई गन्ना पर्ची जोड़ें" else "गन्ना पर्ची बदलें",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        }
        OutlinedTextField(value=name,onValueChange={name=it},label={Text("नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=father,onValueChange={father=it},label={Text("पिता का नाम *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(value=code,onValueChange={code=it.filter(Char::isDigit).take(7)},label={Text("पर्ची कोड * (6–7 अंक)")},singleLine=true,modifier=Modifier.weight(1f))
            OutlinedTextField(value=date,onValueChange={date=it},label={Text("दिनांक *")},singleLine=true,modifier=Modifier.weight(1f))
        }
        OutlinedTextField(value=weight,onValueChange={weight=it.filter{c->c.isDigit()||c=='.'}},label={Text("वजन (क्विंटल) *")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFF1F4F2)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){
                Text("भाव/क्विंटल (इस तारीख का)",fontSize=12.sp,color=Color.Gray)
                Text("₹${money(rate)}",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
            }
        }
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1)),shape=RoundedCornerShape(12.dp)){
            Column(Modifier.padding(12.dp)){Text("कुल अनुमानित राशि",fontSize=12.sp,color=Color.Gray);Text("₹${money(amount)}",fontSize=21.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)}
        }
        OutlinedTextField(value=remark,onValueChange={remark=it},label={Text("टिप्पणी (वैकल्पिक)")},minLines=2,maxLines=3,modifier=Modifier.fillMaxWidth())
        Text("पर्ची की फोटो *",fontWeight=FontWeight.Bold,color=GreenDark)
        if(photo.isNotBlank())PhotoThumb(photo,Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={camera.launch(null)},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoCamera,null);Spacer(Modifier.width(5.dp));Text("कैमरा से लें")}
            OutlinedButton(onClick={picker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PhotoLibrary,null);Spacer(Modifier.width(5.dp));Text("गैलरी से चुनें")}
        }
        if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp,fontWeight=FontWeight.SemiBold)
        Button(onClick={
            val w=weight.toDoubleOrNull()
            when{
                name.isBlank()->error="नाम दर्ज करें"
                father.isBlank()->error="पिता का नाम दर्ज करें"
                !Regex("\\d{6,7}").matches(code)->error="पर्ची कोड 6–7 अंक का होना चाहिए"
                !validDate(date)->error="सही तारीख डालें: YYYY-MM-DD"
                date>today()->error="भविष्य की तारीख नहीं हो सकती"
                w==null||w<=0||!w.isFinite()->error="सही वजन दर्ज करें"
                photo.isBlank()->error="पर्ची की फोटो जोड़ें"
                else->{
                    val x=(existing?:CaneParchi(UUID.randomUUID().toString(),name.trim(),father.trim(),code.trim(),date.trim(),w,rate,photo,remark.trim(),season)).copy(name=name.trim(),fatherName=father.trim(),code=code.trim(),date=date.trim(),weight=w,rate=rate,photo=photo,remark=remark.trim(),season=season)
                    if(existing==null) store.addCaneParchi(x) else store.updateCaneParchi(x)
                    onClose()
                }
            }
        },modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Text(if(existing==null)"पर्ची सेव करें" else "पर्ची अपडेट करें",fontWeight=FontWeight.Bold)}
        Spacer(Modifier.height(12.dp))
    }
}

@Composable private fun CanePriceDialog(store:Store,season:String,onClose:()->Unit){
    var date by remember{mutableStateOf(today())};var rate by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};
    SimpleDialog("गन्ना भाव इतिहास",onClose){Text("सीजन: $season",fontWeight=FontWeight.Bold,color=GreenDark);Text("नया भाव जिस तारीख से लागू हो, वही तारीख डालें। उसी सीजन और तारीख पर पहले से भाव है तो वही रिकॉर्ड अपडेट होगा। पुरानी पर्चियों का सेव किया हुआ भाव नहीं बदलेगा।",fontSize=11.sp,color=Color.Gray);OutlinedTextField(value=rate,onValueChange={rate=it.filter{c->c.isDigit()||c=='.'}},label={Text("भाव / क्विंटल")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val r=rate.toDoubleOrNull();when{r==null||r<=0->error="सही भाव दर्ज करें";!validDate(date)->error="सही तारीख डालें";date>today()->error="भविष्य की तारीख नहीं";else->{store.addCanePrice(CanePrice(UUID.randomUUID().toString(),season,date,r));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("नया भाव सेव करें")};Spacer(Modifier.height(8.dp));Text("भाव इतिहास",fontWeight=FontWeight.ExtraBold);store.canePricesFor(season).forEach{p->Row(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(displayDate(p.effectiveDate),Modifier.weight(1f));Text("₹${money(p.rate)} / क्विंटल",fontWeight=FontWeight.Bold,color=GreenDark)}}}
}

@Composable private fun CaneParchiDetail(p:CaneParchi,onClose:()->Unit){SimpleDialog("पर्ची विवरण",onClose){Text("नाम: ${p.name}",fontWeight=FontWeight.Bold);Text("पिता का नाम: ${p.fatherName.ifBlank{"—"}}");Text("पर्ची कोड: ${p.code}");Text("दिनांक: ${displayDate(p.date)}");Text("वजन: ${String.format(Locale.US,"%.2f",p.weight)} क्विंटल");Text("भाव: ₹${money(p.rate)} / क्विंटल");Text("कुल राशि: ₹${money(p.weight*p.rate)}",fontWeight=FontWeight.ExtraBold,color=GreenDark);if(p.remark.isNotBlank())Text("Remark: ${p.remark}");if(p.photo.isNotBlank())PhotoThumb(p.photo,Modifier.fillMaxWidth().height(220.dp))}}

@Composable
private fun ProfileScreen(onBackup:()->Unit){
    LazyColumn(Modifier.fillMaxSize().background(Bg).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Card(shape=RoundedCornerShape(24.dp),colors=CardDefaults.cardColors(containerColor=GreenDark)){
                Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.AccountCircle,null,tint=Color.White,modifier=Modifier.size(52.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Majdoor Hisaab PRO",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.ExtraBold)
                        Text("प्रोफाइल और डेटा सुरक्षा",color=Color.White.copy(alpha=.85f),fontSize=12.sp)
                    }
                }
            }
        }
        item{
            Card(Modifier.fillMaxWidth().clickable(onClick=onBackup),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){
                Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
                    Box(Modifier.size(50.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFE4F2FF)),contentAlignment=Alignment.Center){Text("☁️",fontSize=27.sp)}
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Backup & Restore",fontSize=18.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
                        Text("Android Auto Backup + Manual Backup",fontSize=11.sp,color=Color.Gray)
                    }
                    Icon(Icons.Default.ChevronRight,null,tint=GreenDark)
                }
            }
        }
        item{
            Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
                Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Text("🔐 सुरक्षा",fontWeight=FontWeight.ExtraBold,fontSize=16.sp,color=GreenDark)
                    Text("App खोलने, Edit/Delete और Backup Restore पर Android screen lock से पुष्टि होगी।",fontSize=12.sp,color=Color.DarkGray)
                }
            }
        }
    }
}

@Composable
private fun BackupScreen(store:Store,status:String,onStatus:(String)->Unit,onBackup:()->Unit,onRestore:()->Unit){
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)){
        Text("☁️ Backup & Restore",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=GreenDark)
        Spacer(Modifier.height(4.dp))
        Text("आपका मजदूर, हाजिरी, भुगतान, खेत, फसल, खर्च और बिक्री data सुरक्षित रखें।",fontSize=12.sp,color=Color.Gray)
        Spacer(Modifier.height(14.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF8F1))){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("☁️ Android Auto Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Text("Android Auto Backup ON है। Google Account के Android backup में app data का automatic backup हो सकता है।",fontSize=12.sp,color=Color.DarkGray)
                Text("साथ में नीचे Manual Backup भी रखें—इसे आप Google Drive या किसी दूसरी जगह खुद save कर सकते हैं।",fontSize=11.sp,color=GreenDark,fontWeight=FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White),elevation=CardDefaults.cardElevation(2.dp)){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                Text("📦 Manual Backup",fontWeight=FontWeight.ExtraBold,fontSize=18.sp)
                Button(onClick=onBackup,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){
                    Icon(Icons.Default.CloudUpload,null);Spacer(Modifier.width(8.dp));Text("Backup बनाएं",fontWeight=FontWeight.Bold)
                }
                OutlinedButton(onClick=onRestore,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){
                    Icon(Icons.Default.CloudDownload,null);Spacer(Modifier.width(8.dp));Text("Backup Restore करें",fontWeight=FontWeight.Bold)
                }
                Text("Restore से पहले Android screen lock पूछा जाएगा। Restore करने पर मौजूदा app data backup के data से replace होगा।",fontSize=11.sp,color=Color.Gray)
            }
        }
        if(status.isNotBlank()){
            Spacer(Modifier.height(12.dp))
            Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFF0F7FF))){Text(status,Modifier.padding(14.dp),fontWeight=FontWeight.SemiBold,color=GreenDark)}
        }
    }
}

@Composable private fun PaymentDialog(store:Store,labourId:String,preField:String?,preCrop:String?,onClose:()->Unit){
    var field by remember{mutableStateOf(preField?:"")}
    var crop by remember{mutableStateOf(preCrop?:"")}
    var amount by remember{mutableStateOf("")}
    val lockedField=preField?.isNotBlank()==true
    val crops=store.crops.filter{it.fieldId==field}
    LaunchedEffect(field){
        if(crop.isNotBlank() && crops.none{it.id==crop}) crop=""
        if(crop.isBlank() && crops.size==1) crop=crops.first().id
    }
    SimpleDialog("Cash Payment",onClose){
        if(lockedField){
            val name=store.fields.firstOrNull{it.id==field}?.name?:"खेत"
            Text("खेत: $name",fontWeight=FontWeight.Bold,color=Green)
        } else {
            ChoiceField("खेत (Optional)",listOf("" to "खेत नहीं चुनना")+store.fields.map{it.id to it.name},field){field=it}
        }
        if(field.isNotBlank() && crops.size>1){
            ChoiceField("फसल (Optional)",listOf("" to "फसल नहीं चुनना")+crops.map{it.id to it.name},crop){crop=it}
        }
        OutlinedTextField(value=amount,onValueChange={amount=it},label={Text("आज कितना दिया?")},singleLine=true)
        Button(onClick={
            val n=amount.toDoubleOrNull()
            if(n==null||n<=0||!n.isFinite()) return@Button
            store.addPayment(Payment(UUID.randomUUID().toString(),labourId,field,crop,today(),n))
            onClose()
        },modifier=Modifier.fillMaxWidth()){Text("Save Payment")}
    }
}

@Composable private fun RateDialog(store:Store,labourId:String,onClose:()->Unit){var rate by remember{mutableStateOf("")};var date by remember{mutableStateOf(today())};var error by remember{mutableStateOf("")};val current=store.rateFor(labourId,today());SimpleDialog("दिहाड़ी बदलें",onClose){Text("अभी की प्रभावी दिहाड़ी: ₹${money(current)}/दिन",fontWeight=FontWeight.SemiBold,color=Green);OutlinedTextField(value=rate,onValueChange={rate=it},label={Text("नई दिहाड़ी")},singleLine=true);OutlinedTextField(value=date,onValueChange={date=it},label={Text("लागू तारीख YYYY-MM-DD")},singleLine=true);if(error.isNotBlank())Text(error,color=Color(0xFFB3261E),fontSize=12.sp);Button(onClick={val n=rate.toDoubleOrNull();when{n==null||n<=0||!n.isFinite()->error="सही दिहाड़ी दर्ज करें";!validDate(date)->error="सही तारीख डालें: YYYY-MM-DD";else->{error="";store.setRate(WageRate(UUID.randomUUID().toString(),labourId,date.trim(),n));onClose()}}},modifier=Modifier.fillMaxWidth()){Text("Save नई दर")}}}

@Composable private fun CropDetail(store:Store,id:String,onBack:()->Unit,onExpense:()->Unit,onSale:()->Unit){val c=store.crops.firstOrNull{it.id==id}?:return;val f=store.fields.firstOrNull{it.id==c.fieldId};val exp=store.expenses.filter{it.cropId==id}.sumOf{it.amount};val sale=store.sales.filter{it.cropId==id}.sumOf{it.total};val wage=store.attendances.filter{it.cropId==id}.sumOf{it.fraction*it.rate};Column(Modifier.fillMaxSize()){DetailTopBar("🌱 ${c.name}",onBack);LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){this.item{Text("खेत: ${f?.name?:"नहीं चुना"}",fontWeight=FontWeight.Bold)};this.item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.weight(1f)){Stat("लागत",exp+wage)};Box(Modifier.weight(1f)){Stat("बिक्री",sale)};Box(Modifier.weight(1f)){Stat("लाभ",sale-exp-wage)}}};this.item{Text("मजदूरी ₹${money(wage)}",fontWeight=FontWeight.Bold)};this.item{Text("खेती खर्च ₹${money(exp)}",fontWeight=FontWeight.Bold)};this.item{Text("बिक्री ₹${money(sale)}",fontWeight=FontWeight.Bold)};this.item{SmallAction("💰 इस फसल के खर्च",onExpense)};this.item{SmallAction("🧺 इस फसल की बिक्री",onSale)}}}}

@Composable private fun DetailTopBar(title:String,onBack:()->Unit){
    Surface(color=Green,tonalElevation=2.dp){
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal=8.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}
            Text(title,Modifier.weight(1f),color=Color.White,fontWeight=FontWeight.Bold,fontSize=17.sp,maxLines=1)
        }
    }
}

@Composable private fun SectionTitle(title:String,sub:String,onAdd:()->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp);Text(sub,fontSize=12.sp,color=Color.Gray)};IconButton(onClick=onAdd){Icon(imageVector=Icons.Default.AddCircle,contentDescription=null,tint=Green)}}}
@Composable private fun SmallAction(text:String,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=CardBg)){Text(text,Modifier.padding(16.dp),fontWeight=FontWeight.SemiBold)}}
@Composable private fun SimpleDialog(title:String,onClose:()->Unit,content:@Composable ColumnScope.()->Unit){AlertDialog(onDismissRequest=onClose,title={Text(title,fontWeight=FontWeight.Bold)},text={Column(Modifier.fillMaxWidth().heightIn(max=520.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)},confirmButton={},dismissButton={TextButton(onClick=onClose){Text("बंद")}})}
@Composable private fun ConfirmDialog(title:String,message:String,onYes:()->Unit,onNo:()->Unit){AlertDialog(onDismissRequest=onNo,title={Text(title)},text={Text(message)},confirmButton={Button(onClick=onYes){Text("हटाएँ")}},dismissButton={TextButton(onClick=onNo){Text("रद्द")}})}
@Composable
private fun ChoiceField(label:String,options:List<Pair<String,String>>,selected:String,onSelected:(String)->Unit){
    var open by remember{mutableStateOf(false)}
    Column{
        Text(label,fontSize=12.sp,color=Color.Gray)
        Box{
            OutlinedButton(onClick={open=true},modifier=Modifier.fillMaxWidth()){
                Text(options.firstOrNull{it.first==selected}?.second?.ifBlank{"नहीं चुना"} ?: "चुनें")
            }
            DropdownMenu(expanded=open,onDismissRequest={open=false}){
                options.forEach{(id,name)->
                    DropdownMenuItem(text={Text(name.ifBlank{"नहीं चुना"})},onClick={onSelected(id);open=false})
                }
            }
        }
    }
}
