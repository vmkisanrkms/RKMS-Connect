# Majdoor Hisaab PRO — Dashboard Fix Audit (2026-10-13)

## Changes applied
1. Dashboard `आज की हाजरी` continues to open `AttendanceFields` directly.
2. Dashboard `दिहाड़ी मजदूर` quick-start and other old entry routes no longer open the two-button `DailyLabourHomeScreen`; they route to field selection or the worker list as appropriate.
3. Removed the obsolete `DailyLabourHomeScreen` composable (the two-button intermediate screen).
4. Dashboard summary cards remain non-clickable: `DashboardStat` is a plain `Card` without clickable/onClick modifiers.
5. Payment/advance summary now displays today's payment total as the main value and total worker advance as supporting text (`आज भुगतान • एडवांस ₹...`).
6. In the former `हाल के रिकॉर्ड` section location, added a full-width `दिहाड़ी मजदूर` button directly below the `गन्ना पर्ची` / `गन्ना छिलाई` row.
7. Removed the duplicate `दिहाड़ी मजदूर` button from `जल्दी शुरू करें`, so the dashboard has one dedicated shortcut in the requested location. The `गन्ना पर्ची` and `गन्ना छिलाई` module implementations were not changed.

## Static checks
- Confirmed no remaining `DailyLabourHomeScreen` symbol.
- Confirmed dashboard routing sends `attendance` and `daily_labour` to `Screen.AttendanceFields`.
- Confirmed `DashboardStat` has no click handler.
- Confirmed `advanceTotal` derives from existing `store.balanceBreakdown(worker.id).advance` accounting logic.
- ZIP integrity checked after packaging.

## Limitation
Android Gradle/Kotlin compilation was attempted but could not start because the Gradle wrapper attempted to download bootstrap files from `raw.githubusercontent.com` and network DNS was unavailable. APK compilation and device runtime behavior therefore remain unverified.


## Placement follow-up
- The single `दिहाड़ी मजदूर` dashboard button is now placed in the former recent-records area, directly beneath the `गन्ना छिलाई` row.
- Static source assertions and ZIP integrity were rechecked after this placement change.
