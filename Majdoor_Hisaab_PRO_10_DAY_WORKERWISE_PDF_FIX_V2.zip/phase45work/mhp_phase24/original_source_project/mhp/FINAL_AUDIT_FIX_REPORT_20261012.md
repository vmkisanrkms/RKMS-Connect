# Majdoor Hisaab PRO — Consolidated Audit & Fix Report
Date: 2026-10-12

## Baseline and constraints
- Baseline: latest supplied `Majdoor_Hisaab_PRO_FANDI_RATE_DECIMAL_DUPLICATE_CONTROL_FIXED_20261012.zip`.
- Preserved the existing app data model and did not redesign Ganna Parchi or the Ganna Chhilai workflows.
- This is a corrected source archive, not a claim that an Android APK has been built or phone-tested.

## Fixes in this consolidated pass

### FANDI-01 — Decimal rate entry
- File: `app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt`, `CanePeelingHome`.
- Input accepts `.` and `,` as decimal separators and normalizes comma to period; multiple decimal separators are discarded after the first.
- Save parses the normalized value as `Double`, validates positive finite values, and uses the existing synchronous `SharedPreferences.commit()` persistence path.
- Source check: PASS.

### FANDI-02 — Fractional wage display
- Cane Chhilai totals that depend on a fractional rate now use the fractional formatter instead of the whole-rupee `money()` formatter. This avoids making a ₹6.50 total appear as ₹7 in Fandi-specific totals/reports.
- Existing general-app `money()` formatting was not changed globally.
- Source check: PASS. Device calculation/restart test: NOT TESTED.

### FANDI-03 — Single rate control
- Removed inline duplicate rate card retained from previous patch; the header `रेट बदलें` dialog and `रेट सेव करें` remain the only rate-setting control on CanePeelingHome.
- Historical CanePeeling records continue to use their saved `rate`.
- Source check: PASS.

### BUILD-01 — GitHub Actions archive selection
- Workflow now prefers the configured current archive name, and if absent accepts exactly one root-level ZIP; if selection is ambiguous it stops with an explicit error instead of silently choosing an arbitrary archive.
- Extraction uses the selected archive step output, not a stale hard-coded name.
- Added the Phase 45 handover and Fandi quick-entry static audits to the workflow.
- Workflow static checks: PASS. GitHub Actions run: NOT TESTED.

### NAV-01 — Monthly account payment action label
- `भुगतान दर्ज करें` changed to `मजदूर चुनकर भुगतान करें`, matching the current `Screen.LabourList` destination and avoiding the false impression that it opens a standalone payment-history screen.
- No new payment screen or accounting path was invented.
- Source check: PASS.

## Static test results
- `scripts_phase45_handover_audit.py`: 14/14 PASS.
- `scripts_daily_labour_audit_check.py`: emitted 26/26 source checks passed; runner did not exit cleanly within the command time limit, so treat process completion as PARTIAL despite the printed check count.
- `scripts_phase29_fandi_labour_quick_entry_audit.py`: 14/14 PASS in the prior focused run against this source family; rerun in CI.
- ZIP archive integrity: to be checked on the delivered archive.

## Full app inventory / remaining audit items
- Source contains 25 screen-model variants, 78 composable declarations, 164 named `onClick` occurrences, 32 `.clickable {}` occurrences, and 193 button-like call occurrences. These are source inventory counts, not unique visible buttons.
- A complete one-row-per-button route matrix and physical-device traversal of every screen are still NOT COMPLETE.
- Monthly `खेतवार हिसाब` still opens `Screen.FieldList`; this is a field list/detail flow, not a dedicated date-filtered labour report. Kept the existing destination to avoid inventing a new report/accounting path; further implementation remains open.
- `भुगतान` now has an honest worker-selection label; a separate global payment-history route is not present in the screen enum and was not fabricated.
- Backup/Restore, Google Drive consent, PDF/CSV output, locked-month payments, restart persistence, Android Back navigation, and active/inactive worker behavior still need runtime/regression verification.

## Build and runtime
- Kotlin compilation: NOT TESTED. The local bootstrap script stopped because Gradle 8.11.1 was not provisioned in this environment.
- Release APK assembly and permanent signing: NOT TESTED.
- Install and phone runtime: NOT TESTED.

## Verdict
The Fandi decimal-entry/display path and workflow archive selection received focused source fixes and static checks. This is NOT a verified final APK and the full all-screen/all-button audit is not complete until CI and device testing succeed.
