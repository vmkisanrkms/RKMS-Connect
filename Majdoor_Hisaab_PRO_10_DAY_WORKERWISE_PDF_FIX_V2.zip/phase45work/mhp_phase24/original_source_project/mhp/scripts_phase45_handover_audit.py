#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
s=(root/'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt').read_text(encoding='utf-8')
w=(root/'.github/workflows/majdoor-hisaab.yml').read_text(encoding='utf-8')
checks={
 'single inline fandi-rate card removed from CanePeelingHome':'private fun CanePeelingHome' in s and '⚙️ फांदी रेट' not in s[s.index('private fun CanePeelingHome'):s.index('private fun CanePeelingSearch')],
 'primary fandi rate dialog remains available':'फांदी का रेट बदलें' in s and 'रेट बदलें' in s and 'store.updateFandiRate(r)' in s,
 'rate parsing accepts decimal Double and comma-decimal input':"rateText.trim().replace(',','.').toDoubleOrNull()" in s,
 'rate persistence commits before UI state update':'prefs.edit().putString("fandiRate",value.toString()).commit()' in s and 'fandiRate=value' in s,
 "decimal input accepts comma and single separator":"input.replace(',','.')" in s and 'replace(".","")' in s,
 'fractional Fandi totals remain visible':'formatFandiRate(todayAmount)' in s and 'formatFandiRate(row.total)' in s,
 'rate validation rejects non-finite and non-positive values':'if(!value.isFinite() || value<=0.0) return false' in s,
 'historical fandi rows use saved rate':'x.fandi * x.rate' in s or 'x.fandi*x.rate' in s or 'fandiRate' in s,
 'dashboard wage-rate history label is explicit':'मजदूरी-दर इतिहास' in s,
 'all-options label matches profile/settings destination':'सेटिंग व अन्य विकल्प' in s,
 'Phase 45 workflow selects an existing source archive robustly':'Select and verify source ZIP' in w and 'steps.archive.outputs.zip_name' in w,
 'workflow compiles Kotlin before Release assembly':w.find(':app:compileReleaseKotlin') < w.find(':app:clean :app:assembleRelease'),
 'workflow validates package and APK signature':'verify --verbose "$APK"' in w and 'EXPECTED_PACKAGE' in w,
 'cane parchi screen and data model retained':'Screen.CaneParchi' in s and 'CaneParchiDashboardScreen' in s and 'caneParchis' in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' | '+k)
print(f'RESULT: {sum(checks.values())}/{len(checks)} PASS, {sum(not v for v in checks.values())} FAIL')
sys.exit(0 if all(checks.values()) else 1)
