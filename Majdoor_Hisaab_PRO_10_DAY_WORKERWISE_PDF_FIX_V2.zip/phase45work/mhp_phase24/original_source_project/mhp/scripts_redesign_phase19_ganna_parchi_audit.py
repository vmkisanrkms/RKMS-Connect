from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
text = SOURCE.read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('Store add validates parchi and returns Boolean', '@Synchronized fun addCaneParchi(x:CaneParchi):Boolean' in text and 'if(!validCaneParchi(normalized)) return false' in text)
check('Store update rejects missing IDs', 'if(caneParchis.none{it.id==x.id} || !validDate(x.date)) return false' in text)
check('Store duplicate prevention is season scoped', 'it.season==normalized.season && normalizedParchiCode(it.code)==normalized.code' in text)
check('Duplicate prevention applies during update', 'it.id!=normalized.id && it.season==normalized.season' in text)
check('Code normalization removes non-digit variants', 'private fun normalizedParchiCode(code:String)=code.trim().filter{it.isDigit()}' in text)
check('Code length is checked at Store boundary', 'Regex("\\\\d{6,7}").matches(normalizedParchiCode(x.code))' in text)
check('Invalid date is rejected before season derivation on add', 'if(!validDate(x.date)) return false' in text)
check('Future dates are rejected at Store boundary', 'validDate(x.date) && x.date<=today()' in text)
check('Season is derived from ticket date', 'season=caneSeason(x.date)' in text)
check('Invalid/non-positive weight rejected', 'x.weight.isFinite() && x.weight>0.0' in text)
check('Invalid/non-positive rate rejected', 'x.rate.isFinite() && x.rate>0.0' in text)
check('Overflow/non-finite ticket amount rejected', '(x.weight*x.rate).isFinite()' in text)
check('ALL season selection is preserved', 'if (season != "ALL" && season !in seasons)' in text)
check('All-season view includes all stored records', 'val allRows = if (season == "ALL") store.caneParchis' in text)
check('Search filters name/father/code/remark', 'searchMatches(query, it.name, it.fatherName, it.code, it.remark)' in text or 'listOf(it.name, it.fatherName, it.code, it.remark)' in text)
check('CSV export uses selected filtered list', 'exportCaneCsv(context, store, exportRows' in text)
check('CSV includes season column', '"सीजन","नाम","पिता का नाम"' in text)
check('CSV includes ISO date', 'q(p.date)' in text)
check('CSV summary totals use exported rows', 'val totalWeight=list.sumOf{it.weight}' in text and 'val totalAmount=list.sumOf{it.weight*it.rate}' in text)
check('CSV exports total row', 'कुल (${list.size} पर्चियां)' in text)
check('CSV uses UTF-8 BOM for spreadsheet Hindi support', 'byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte())' in text)
check('CSV protects against spreadsheet formula injection', "first in listOf('=','+','-','@','\\t','\\r')" in text)
check('Empty CSV/PDF export is blocked with message', 'चुने हुए सीजन/खोज में कोई पर्ची नहीं है।' in text)
check('PDF rows include each ticket season', '"सीजन ${p.season} • ${p.name}' in text)
check('PDF totals derive from filtered rows', 'exportRows.sumOf{it.weight*it.rate}' in text)
check('Historical ticket rate remains stable if date unchanged', 'if(existing!=null && existing.date==date.trim()) existing.rate' in text)
check('Form reports Store-level save failures', 'if(saved) onClose() else error="पर्ची सेव नहीं हुई।' in text)
check('Delete rejects blank/missing ID', 'if(id.isBlank() || caneParchis.none{it.id==id}) return false' in text)

# Explicit boundary examples matching caneSeason() business rule (season rolls over in April).
def season(date):
    y, m = int(date[:4]), int(date[5:7])
    return f'{y}-{str(y+1)[-2:]}' if m >= 4 else f'{y-1}-{str(y)[-2:]}'
check('Season boundary: March 31 stays prior season', season('2026-03-31') == '2025-26')
check('Season boundary: April 1 starts next season', season('2026-04-01') == '2026-27')
check('Season boundary: January remains current cane season', season('2027-01-01') == '2026-27')

# CSV quoting/escaping behavior examples are also verified independently.
def q(raw):
    first = raw[0] if raw else None
    safe = "'" + raw if first in ['=', '+', '-', '@', '\t', '\r'] else raw
    return '"' + safe.replace('"','""').replace('\r',' ').replace('\n',' ') + '"'
check('CSV escapes embedded quotes', q('A"B') == '"A""B"')
check('CSV neutralizes formula-like text', q('=1+1').startswith('"\'=1+1'))
check('CSV normalizes embedded line breaks', '\n' not in q('a\nb'))

out = ROOT / 'PHASE19_STATIC_AUDIT_RESULTS.txt'
lines = [f'{"PASS" if ok else "FAIL"}: {name}' for name, ok in checks]
lines.append(f'RESULT: {sum(ok for _,ok in checks)}/{len(checks)} PASS, {sum(not ok for _,ok in checks)} FAIL')
out.write_text('\n'.join(lines)+'\n', encoding='utf-8')
print('\n'.join(lines))
raise SystemExit(1 if any(not ok for _,ok in checks) else 0)
