# Fandi Rate Fix Audit — 2026-10-12

## Root cause
The shared `money(Double)` helper intentionally formats all values with `%.0f`. The Fandi rate field was initialized with `money(store.fandiRate)`, which rounded 6.5 to `7` before the user could edit/save it. The stored preference itself was a string and `updateFandiRate(Double)` already used synchronous `commit()`.

## Source changes
- Added `formatFandiRate(Double)` to retain up to two decimal places without trailing zeroes.
- Fandi rate input initialization and reopening now use `formatFandiRate`, so 6.5 opens as `6.5`, 6.3 as `6.3`, and 6.25 as `6.25`.
- Fandi rate labels/history/filters/exports use fractional formatting instead of the whole-rupee `money()` formatter.
- Kept the single rate editor on the main Ganna Chhilai screen (`रेट बदलें` + `रेट सेव करें`) and removed the duplicate rate-setting card from the Fandi labour list screen.
- Preserved synchronous SharedPreferences commit and existing historical record rates; unrelated Ganna Parchi logic was not changed.

## Verification
- Static source assertions: PASS.
- Formatter behavior model: PASS for 6.5, 6.3, 6.25, 6.0.
- Arithmetic check: PASS for 10 fandi × 6.5 = 65.0.
- ZIP integrity: PASS.
- Kotlin compile / Release APK / phone restart test: NOT TESTED (Gradle wrapper JAR absent in source archive; no successful build evidence).
