# Phase 35 — Single-source merge audit (2026-10-12)

## Structure
- The only buildable Android project is `original_source_project/mhp`.
- The duplicate `Majdoor_Hisaab_PRO_V99_SOURCE_FIXES` project has been removed.
- V99 audit notes and feature checklist are retained in `MERGE_REFERENCE_V99/` for review; these are not a second buildable app.

## Preserved in the main source
- Professional redesign project and its current feature set.
- Phase 29 optional same-day fandi entry when adding a Ganna Chhilai worker.
- Phase 30/32 fandi decimal-rate related source fixes already present in the supplied tree.
- Phase 31 Backup & Restore clean UI source changes already present in the supplied tree.
- Existing backup, restore, worker, attendance, payments, cane peeling/parchi, field/crop, report and settings source in the canonical project.

## V99-only code review notes
The V99 source had unique routines/entry points including `setLabourActive`, attendance reminder scheduling/receiver routines, `recordBackupHistory`, `restoreBackupZipWithInjectedFailureForTest`, and additional recovery helpers. These were reviewed and are listed in `V99_FEATURE_MERGE_REVIEW.md`. They were NOT blindly pasted into the redesigned `MainActivity.kt`, because their data-store/UI wiring differs and doing so without integration tests could break accounting or backup/restore.

## Audit status
- Input ZIP integrity: passed.
- Output ZIP integrity: checked after creation.
- Buildable project count: exactly 1 `settings.gradle.kts`.
- MainActivity count in buildable project: exactly 1.
- Kotlin/Gradle compilation: NOT run in this environment.
- Device/runtime and backup/restore restore-cycle tests: NOT run.
- Therefore this is a structural single-source consolidation with current redesigned source preserved, not a claim that every V99-only behavior has been fully ported and runtime-verified.
