# Phase 27 — Requested UI fixes

## Implemented in both Android source trees
1. Ganna Chhilai recent-date cards are tappable and open a dialog listing all saved entries for that date, including each worker name, field, fandi count, saved rate and amount.
2. Ganna Parchi form has an optional field selector. Field ID is stored with each ticket; older records remain compatible with a blank field. Parchi details/list and exports display the field name when available.
3. Parchi list has per-ticket checkboxes and a select-all control. PDF/CSV exports use the selected IDs (across date/query/season changes); if none are selected, they export the current filtered list. CSV/PDF include name, father name, code, date, field, weight, rate and total.
4. Dashboard finance summary now has five tiles: wages, expenses, sales, today's payments/advance, and all-worker outstanding. The old separate payment/advance and outstanding cards were removed.
5. Quick actions include direct Ganna Parchi and Ganna Chhilai shortcuts.

## Verification
- Focused audit: 15/15 PASS in canonical source and 15/15 PASS in V99 build source.
- Regression audit Phase 8: 31/31 PASS.
- Regression audit Phase 19: 34/34 PASS.
- V99 empty-export guard: 5/5 PASS.
- Workflow YAML parsed successfully in both source trees.
- ZIP archive integrity verified.
- Android/Kotlin compilation and on-device testing have NOT been run in this environment.
