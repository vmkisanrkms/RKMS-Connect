# V99 Feature Merge Review

V99-only function names found by source comparison:

- `MoreScreen`
- `PaymentHistoryScreen`
- `attendanceCalendarCells`
- `buildCanePeelingCsv`
- `buildDateFieldReportCsv`
- `cancelDailyAttendanceReminder`
- `copyDirectory`
- `dailyReminderPendingIntent`
- `decodeScreen`
- `downloadToFile`
- `enableReminder`
- `encodeScreen`
- `exportDateFieldReportCsv`
- `fallbackToDeviceCredential`
- `filterCaneParchiSeason`
- `normalizedFandiName`
- `onReceive`
- `outstandingBalance`
- `preserveRawForRecovery`
- `readZipEntryLimited`
- `requestMultipartFile`
- `restoreBackupZipImpl`
- `restoreBackupZipWithInjectedFailureForTest`
- `runCoreStoreRuntimeRegression`
- `scheduleDailyAttendanceReminder`
- `screenSubtitle`
- `screenTitle`
- `setLabourActive`
- `validMonthKey`

These were not automatically pasted into the redesigned source because the surrounding models, state holders, callbacks, and UI call sites differ. Port each feature with tests before claiming behavioral parity.
