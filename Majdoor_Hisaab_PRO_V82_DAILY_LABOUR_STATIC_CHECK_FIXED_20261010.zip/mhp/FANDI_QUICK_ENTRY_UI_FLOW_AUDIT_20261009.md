# Fandi Quick Entry UI Flow Fix Audit — 2026-10-09

## Implemented
- Added `नया फांदी मजदूर जोड़ें + आज की फांदी` directly inside the `आज की छिलाई दर्ज करें` bulk-entry dialog.
- Tapping the button closes the daily entry dialog and opens the existing Fandi Labour screen.
- The Fandi Labour add dialog retains the optional `आज की फांदी भी साथ में सेव करें` option, with date, field, quantity, configured rate and calculated amount.
- One save action saves the new worker and, when selected, the same-day cane-peeling record using the same worker ID.
- The separate home-screen shortcut remains available. Existing edit flows and stored records are not intentionally changed.
- GitHub Actions `ZIP_NAME` points to this ZIP and verifies the new callback wiring.

## Source checks
- New button label and callback wiring: PASS
- Optional combined worker + fandi save: PASS
- ZIP integrity: checked after packaging
- Android Release compilation and real-device interaction: NOT VERIFIED here; run GitHub Actions and test the resulting APK.
