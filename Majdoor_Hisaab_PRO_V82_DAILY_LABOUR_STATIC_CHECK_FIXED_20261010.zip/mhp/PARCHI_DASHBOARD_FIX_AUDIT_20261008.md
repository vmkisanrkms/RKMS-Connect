# Majdoor Hisaab PRO V82 — गन्ना पर्ची Dashboard Fix Audit

## User-reported gap
नई गन्ना पर्ची form खुल रहा था, लेकिन Home → गन्ना पर्ची पर tap करने के बाद dedicated पर्ची dashboard नहीं था। इसलिए saved/old records, edit/delete, session history और export options सीधे उपलब्ध नहीं थे।

## Fixed
1. **Home → गन्ना पर्ची** अब `CaneParchiDashboardScreen` खोलता है; form सीधे नहीं खुलता।
2. **नई पर्ची** button dashboard से form खोलता है। Existing save/update logic retained.
3. **Saved parchis list** — नाम, पिता, code, date, weight, rate और total amount दिखता है।
4. **Detail view** — पूरी पर्ची detail और photo देखने की सुविधा retained/connected.
5. **Edit** — हर saved parchi पर edit action; Android screen-lock credential gate के बाद update form खुलता है।
6. **Delete** — हर saved parchi पर delete action; credential gate के बाद permanent deletion.
7. **पुराने session/season** — season selector में सभी saved seasons + current season; `सभी सीजन` option भी।
8. **Search** — नाम, पिता का नाम, पर्ची code और remark से search.
9. **Dashboard summary** — selected season के लिए कुल पर्ची, कुल वजन, कुल राशि, औसत भाव और season count.
10. **भाव इतिहास** — selected season का cane price history dialog.
11. **Excel/CSV** — selected/filter किए गए records का CSV export/share; Excel-compatible format.
12. **PDF** — selected/filter किए गए records का PDF report/share.
13. **Existing local persistence** — `caneParchi` storage और backup key unchanged; existing saved data को migrate/delete नहीं किया गया।
14. **Existing photo support** — camera/gallery photo flow unchanged.

## Verification performed
- ZIP extracted successfully.
- `MainActivity.kt` inspected for CaneParchi model, persistence, add/update/delete, backup key, export helpers and Home routing.
- New dashboard routing and UI source inserted.
- Fixed source ZIP was rebuilt from the audited project directory.
- Gradle debug build was attempted, but this environment could not download the Gradle distribution because outbound DNS/network access to `raw.githubusercontent.com` was unavailable. Therefore **APK compilation is not claimed as verified here**.

## Important
The source-level fix is included in this ZIP. A GitHub Actions build should be used for the final APK verification in an environment with Gradle distribution/cache access.
