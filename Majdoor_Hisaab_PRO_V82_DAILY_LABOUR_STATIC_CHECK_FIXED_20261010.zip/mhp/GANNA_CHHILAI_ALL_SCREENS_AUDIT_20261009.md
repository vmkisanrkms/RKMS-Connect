# Majdoor Hisaab PRO V82 — Ganna Chhilai Section Redesign Audit

Date: 2026-10-09

## Scope boundary

Only the Ganna Chhilai / Fandi section was changed. The main Home dashboard, Parchi screens, general Labour screens, crop/expense/sale screens, and Backup & Restore screens were not redesigned or intentionally modified. The only workflow change is the expected source ZIP filename.

## Ganna Chhilai screens updated

1. Ganna Chhilai internal dashboard: redesigned summary hero, date badge, today's fandi/amount/payment stats, primary entry actions, search/payment actions, and recent-date cards.
2. Bulk daily entry: field is optional, empty field option is available, totals remain visible, and duplicate worker/date/field rows are rejected before any rows in that batch are saved.
3. Single entry/edit: field is optional; a duplicate new worker/date/field entry shows an error instead of silently accumulating into the old row.
4. Fandi worker list: redesigned header and rate card; worker search by name/mobile/address; each worker card shows entry count, fandi total and amount.
5. Add worker + today's fandi flow: after successful save it returns to the Ganna Chhilai dashboard instead of opening another entry dialog.
6. Duplicate worker-name guard: normalized names (case and repeated spaces ignored) cannot be saved twice; the user sees “यह नाम पहले से सेव है…”. Duplicate phone numbers are also rejected rather than merging records silently.
7. Worker detail: existing per-worker totals, entries, payments, edit/delete confirmation flow preserved.
8. Field detail: redesigned summary card, worker-wise totals and date-wise records.
9. Search/filter: clearer Hindi search prompt, filter reset action, summary metrics, worker and entry records retained.
10. Payments: redesigned payment summary shows total wages, total payments and balance; search/edit/delete flow retained.
11. PDF/CSV export: existing export actions retained.
12. Internal tabs and navigation: remain within Ganna Chhilai section; no global Home/Parchi/Labour navigation redesign.

## Data-safety changes

- `addCanePeeling` no longer silently adds a duplicate row's fandi into an existing worker/date/field row.
- Bulk entry checks the whole batch for duplicate worker/date/field records before writing anything.
- Single entry rejects a duplicate worker/date/field record and asks the user to edit the existing record.
- Field selection is optional in the Ganna Chhilai forms; the UI does not show `*` for the field.
- A duplicate worker name is blocked before either the worker or the optional same-time fandi can be saved.

## Verification

- Source assertions: checked for new dashboard labels, optional-field labels, duplicate-name message, duplicate-row guards, and expected workflow ZIP name.
- ZIP archive integrity: checked after packaging.
- Release Kotlin compilation: NOT VERIFIED in this environment. Gradle wrapper could not download the Gradle distribution because `raw.githubusercontent.com` was unreachable. A GitHub Actions Release build and real-device test are still required before calling this production verified.
