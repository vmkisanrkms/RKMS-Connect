# Fandi + Google Drive OAuth fix audit (2026-10-09)

## Source changes
- Fandi quick-entry duplicate result is handled by its caller so failed/duplicate saves are not treated as success.
- Google Drive upload/download temporary files are cleaned up in `finally`/failure paths.
- Downloaded Drive backups are structurally validated (ZIP path safety, size/count limits, app name, schema version) before the restore confirmation appears.
- Drive errors provide specific next steps for OAuth status 10 and Drive permission failures.
- Release signing workflow requires configured GitHub Secrets instead of unsafe fallback passwords and prints the permanent release certificate SHA-1 for Google OAuth setup.

## External requirement that cannot be solved by source alone
`DEVELOPER_ERROR` (status 10) is a Google Cloud OAuth configuration issue. The Android OAuth client must use package `com.majdoor.hisaabpro` and the SHA-1 of the exact permanent release keystore used to sign the installed APK; Google Drive API must be enabled. The credentials and Cloud Console cannot be changed from this source ZIP.

## Verification status
- Static code checks and ZIP integrity can be run locally.
- Android Release compilation and live Google sign-in / Drive upload / restore require Gradle dependencies, GitHub secrets, Google Cloud configuration, and a real Android device. Do not claim those are verified until performed.
