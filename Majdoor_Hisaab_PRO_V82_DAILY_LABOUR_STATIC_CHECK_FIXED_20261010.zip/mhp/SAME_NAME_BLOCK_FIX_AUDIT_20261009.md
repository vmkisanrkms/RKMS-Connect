# Same-name duplicate block audit — 2026-10-09

## Requested behavior
When a user attempts to save a Fandi worker with a name already present in the Fandi worker list, do not save a second worker. Show: “यह नाम पहले से सेव है। उसी मजदूर को सूची से चुनें; नाम दोबारा सेव नहीं होगा।”

## Source change
- `MainActivity.kt` normalizes names by trimming leading/trailing whitespace, collapsing repeated spaces, and lowercasing.
- Before any write to the worker list or today's fandi, it searches for an existing worker with the same normalized name (excluding the record currently being edited).
- If found, save is blocked and the message is shown. No worker or fandi record is written in this branch.

## Static checks
- Name normalization exists.
- Existing-name lookup excludes the record being edited.
- Duplicate-name branch sets the requested error message before the save branch.
- ZIP integrity check performed after packaging.

## Limitations
This is a source-level fix. Android Release compilation and on-device UI testing are not claimed as passed.
