# Attendance List — Hide Absent/Bhanji Workers (2026-10-10)

- Attendance records with `fraction == 0.0` remain stored so the leave/absence record and audit history are not deleted.
- Today's attendance screen displays only workers with `fraction > 0.0`; its Photo/PDF exports also omit absent/bhanji names.
- Attendance history builds its visible date groups from workers with `fraction > 0.0`, so a worker marked bhanji or otherwise not present is not listed for that date. Dates with no attending workers do not appear in the history list.
- Attendance history totals continue to use all records, so zero-fraction records do not change wage totals. Monthly worker count reflects workers who actually attended.
- Example: 8 workers attended at ₹300 each and one worker was marked bhanji: displayed names = 8, total wage = ₹2,400.
- Static source edits made. Gradle/Android compilation and runtime behavior have not been verified in this environment.
