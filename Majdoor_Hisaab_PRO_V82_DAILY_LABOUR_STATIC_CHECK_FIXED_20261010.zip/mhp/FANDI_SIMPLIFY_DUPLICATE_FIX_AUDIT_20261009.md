# Fandi Simplify + Duplicate Save Fix Audit — 2026-10-09

## Changes applied
- The quick-add action from today's peeling entry now passes the selected date and field into the new-worker form.
- The quick-add form opens automatically; after saving/canceling it returns to the daily entry dialog so the next worker can be entered without navigating through the full list.
- Optional address, mobile and photo fields are collapsed under an optional-details control by default for a shorter form.
- Existing duplicate Fandi worker records are normalized on startup by normalized name and compatible phone; old peeling and payment records are remapped to the canonical worker ID.
- Existing duplicate peeling rows are normalized by worker + field + date, retaining the latest stored row for that key.
- Saving a worker with a matching name/compatible phone reuses the existing worker ID instead of appending another worker.
- Repeated save taps are guarded while save is in progress.
- Adding a peeling record for the same worker + field + date upserts the existing row and preserves its ID instead of creating a second row.
- Quick-entry date and field are carried into the form and back to the daily entry screen.
- Workflow ZIP_NAME updated to this archive.

## Static checks
- ZIP integrity: PASS
- Workflow ZIP_NAME matches archive name: PASS
- Quick-add callback carries date and field: PASS
- Return-to-bulk-entry wiring: PASS
- Duplicate worker normalization + alias remapping: PASS
- Duplicate daily peeling upsert: PASS
- Save-in-progress guards: PASS
- Android compilation: NOT VERIFIED; Gradle wrapper tried to fetch its launcher from raw.githubusercontent.com but network DNS was unavailable in this environment.
- Real-device test: NOT VERIFIED.

## Important data behavior
When duplicate Fandi worker profiles have the same normalized name and blank/compatible mobile numbers, the oldest canonical profile is kept and records are remapped to it. If multiple peeling rows become the same worker + field + date, the latest row in stored order is retained to stop duplicate totals. Review a backup before installing if preserving every historical duplicate row separately is important.
