# Fandi Quick Entry Fix Audit — 2026-10-09

## Requested workflow
- Add a clear button on the Cane Peeling home screen to open the Fandi Labour screen.
- While adding a new Fandi labourer, optionally save today's fandi record in the same save action.
- Keep existing labourer edit flow and existing records unchanged.

## Changes
- Cane Peeling home now has a dedicated purple action: `नया फांदी मजदूर जोड़ें + आज की फांदी`, which opens the existing Fandi Labour screen.
- New Fandi Labour dialog includes a checked-by-default option `आज की फांदी भी साथ में सेव करें`.
- With the option enabled, the dialog includes date, field, fandi quantity, saved current rate and calculated amount.
- One save action validates the name, field, date, quantity and rate, then saves the new labourer and its CanePeeling record using the same generated labour ID.
- If the option is unchecked, only the labourer is saved. Editing an existing labourer does not create a new fandi entry.
- Workflow ZIP_NAME now points to `Majdoor_Hisaab_PRO_V82_FANDI_QUICK_ENTRY_FIXED_20261009.zip` and checks the new UI strings.

## Checks run
- Source-level assertions for button, optional fandi section, combined save, and validations: PASS.
- Workflow filename reference: PASS.
- ZIP integrity (`unzip -t`): PASS.
- Android Release compilation / runtime: NOT VERIFIED in this environment; run GitHub Actions and test on device.
