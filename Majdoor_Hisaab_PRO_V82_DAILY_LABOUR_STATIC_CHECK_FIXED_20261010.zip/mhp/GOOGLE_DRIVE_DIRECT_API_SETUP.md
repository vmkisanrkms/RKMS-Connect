# Google Drive Backup / Restore — Release setup and verification

The Android source uses Google Sign-In and the Google Drive REST API with the `drive.file` scope. The app does not store the Google password. Before Drive backup can work on a release build, configure the external Google Cloud OAuth client to match the *actual release signing certificate*.

## Required GitHub Actions secrets

Configure these repository secrets using the permanent release signing key already used for the app:

- `MAJDOOR_KEYSTORE_BASE64` — base64-encoded `.jks`/`.keystore` file
- `MAJDOOR_KEYSTORE_PASSWORD` — keystore password
- `MAJDOOR_KEY_ALIAS` — exact signing key alias
- `MAJDOOR_KEY_PASSWORD` — key password

The release workflow intentionally has no fallback passwords. Do not commit keys/passwords to source control. Do not generate a different release key on each run; doing so changes the SHA-1 and breaks Google OAuth.

## Google Cloud configuration for status 10 / DEVELOPER_ERROR

1. Open the Google Cloud project used by this app and enable **Google Drive API**.
2. Open **Google Auth Platform / Credentials** and create or update an **Android OAuth client**.
3. Set package name exactly to `com.majdoor.hisaabpro`.
4. Set its SHA-1 certificate fingerprint to the `SHA1` value printed by the `Prepare signing key` step in the GitHub Actions log. Use the SHA-1 for the permanent release keystore that signs the APK installed on the phone, not the debug key. If a different signing key signs the installed APK, register that key's SHA-1 instead.
5. Ensure the consent screen / audience and test-user setup permits the Google account used on the device. Wait for Google configuration propagation, then rebuild and install a new APK signed with the same key.
6. In the app, select the Google account again and test both **Backup to Drive** and **Restore from Drive**. Restore now validates the downloaded archive and app/schema before enabling confirmation.

`status=10 (DEVELOPER_ERROR)` cannot be fully resolved by Kotlin source alone: it means Google's OAuth configuration does not match the installed app/signature or its Google Cloud setup. This ZIP improves diagnostics and Drive transfer safety, but the Cloud credentials must be configured and a real-device test completed before marking it fixed.

## Drive behavior

- Upload creates a `Majdoor Hisaab PRO` folder and uploads a `.mhbackup` archive.
- Restore selects the newest `.mhbackup` in that folder, validates it, then asks for explicit restore confirmation.
- Temporary upload/download files are deleted after use/failure.
- A successful static source check is not proof that live Google OAuth works; real release signing and device verification are required.
