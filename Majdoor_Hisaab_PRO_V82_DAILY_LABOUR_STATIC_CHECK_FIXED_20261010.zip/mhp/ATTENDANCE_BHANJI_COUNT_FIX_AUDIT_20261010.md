# Attendance Bhanji Count Fix — 2026-10-10

- Attendance history day cards count workers who actually attended (`fraction > 0`) separately from Bhanji/absent entries (`fraction == 0`).
- History list labels all attendance states correctly: full day, half day, Bhanji (did not come), or fractional day.
- Photo/PDF history summaries count distinct workers with positive attendance as workers present; the full row list still includes Bhanji records for audit transparency.
- Today's attendance summary excludes Bhanji from workers-present count while preserving its ₹0 wage row.
- Wage calculation remains `fraction * rate`; therefore 8 full days at ₹300 remains ₹2,400, unchanged.
