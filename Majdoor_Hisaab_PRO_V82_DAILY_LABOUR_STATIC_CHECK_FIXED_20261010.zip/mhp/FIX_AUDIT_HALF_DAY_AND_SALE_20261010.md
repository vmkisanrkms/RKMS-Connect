# Fix audit — fractional attendance and sale save UI (2026-10-10)

## Changes made
- Added a dedicated `quantity()` formatter for attendance/day quantities. It keeps up to two fractional digits and removes unnecessary trailing zeros, so 6.5 remains 6.5 rather than being rounded to 7.
- Updated the common stats display, selected-workers PDF table and total, selected-workers report/photo text, and individual worker ledger PDF work-day total to use the fractional formatter. Wage and payment amounts still use the currency formatter.
- Reworked the Sale dialog so the save action is in the dialog's fixed confirm-button area and remains visible while the form scrolls. The form validates field, quantity, unit, rate and date; computes amount as quantity × rate; uses the existing Store add/update functions; and only closes after the save call succeeds.
- Sale persistence continues through the project's existing `Store`/`write("sale", ...)` mechanism; no destructive data/schema migration was introduced.

## Verification status
- Source-level checks: reviewed formatter call sites and sale add/update persistence path.
- Android build: NOT VERIFIED in this environment. `./gradlew assembleDebug --no-daemon` failed before Gradle ran because the wrapper script could not resolve `raw.githubusercontent.com` (network/DNS unavailable). Do not treat this ZIP as a build-verified APK.
- Lock/settlement-period redesign was not changed in this patch; it requires its own implementation and regression testing.
