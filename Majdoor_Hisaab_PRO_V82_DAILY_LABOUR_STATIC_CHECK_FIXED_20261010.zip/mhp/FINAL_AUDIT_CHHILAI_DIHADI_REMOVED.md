# Final Chhilai/Fandi Labour Audit

- Fandi/Chhilai worker dialog: daily-wage field removed.
- Normal Labour dialog: rupees/day field retained.
- Normal Labour and Fandi Labour remain separate data flows.
- Workflow ZIP_NAME matches this canonical source ZIP filename.
- GitHub Actions is required for actual Kotlin compile and signed APK verification.
