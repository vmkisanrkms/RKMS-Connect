# Workflow Fix V4 Audit

- Uses repository secrets RELEASE_KEYSTORE_BASE64, RELEASE_KEYSTORE_PASSWORD, RELEASE_KEY_ALIAS, RELEASE_KEY_PASSWORD.
- Fails closed when any permanent signing secret is missing; no ephemeral release key fallback.
- Extract step exposes Android project root using step outputs, then all working-directory fields reference steps.project.outputs.root (not dynamic GITHUB_ENV).
- Prints SHA-1 from the same permanent keystore configured for Gradle release signing.
- Checks package ID, APK signature and zipalign, then uploads the generated APK.
- Required source ZIP filename is the V4 filename in workflow env.

Not verified by this audit: successful remote GitHub Actions run, Google Cloud OAuth client settings, Google Drive sign-in/backup/restore on a device, and physical device UI behavior.
