# Majdoor Hisaab PRO — Agreed Changes Audit (2026-10-10)

## Implemented in source

1. Attendance list/history output excludes records with `fraction == 0.0` (भांजी/absent); attendance-entry controls remain unchanged so the user can still record or correct attendance status.
2. Individual worker PDF keeps the approved green-and-white report layout, uses the payment column instead of a daily-rate column in the work table, leaves payment blank on dates with no payment, omits absence rows, and omits the note box.
3. Combined workers report supports either a date range or multi-select dates and multi-select fields.
4. Combined workers PDF uses the approved green-and-white branded layout, summary figures, one worker per table row, a total row, and footer; it does not append an Excel/CSV section.
5. Workers can be selected in the combined report and their accounts finalized through a chosen date. Closure snapshots persist in local preferences and are included in backup/restore data.
6. After a worker's account is finalized through a date, the worker detail totals and worker PDF show only records dated after that cutoff. Older records remain available through historical date-filtered reports and the closure summary.
7. Attendance and payment changes/deletions for dates already finalized are blocked; new attendance continues through the existing attendance screens. No extra attendance-entry screen was added.

## Static checks

- `scripts_daily_labour_audit_check.py`: 26/26 source checks passed after updating the all-workers report expectation.
- Kotlin parser pass: no syntax/`expecting`/unexpected-token diagnostics from `kotlinc`.
- ZIP integrity checked after packaging.

## Not verified

- Full Android Gradle compilation, signed Release APK build, and on-device PDF/runtime behavior were not verified in this environment because the Gradle wrapper distribution could not be downloaded (network/DNS unavailable). Run the existing GitHub Actions release workflow before installing the APK.
