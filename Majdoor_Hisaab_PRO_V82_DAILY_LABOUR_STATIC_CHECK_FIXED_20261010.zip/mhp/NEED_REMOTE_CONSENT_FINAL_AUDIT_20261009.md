# Majdoor Hisaab PRO V82 — NeedRemoteConsent final patch audit

## Source examined
- `app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt`
- `app/build.gradle.kts` (application ID `com.majdoor.hisaabpro`, compile/target SDK 36, Play Services Auth 21.3.0)
- Existing `FANDI_AND_DRIVE_OAUTH_FIX_AUDIT_20261009.md` and Google Drive direct REST implementation.

## Root cause found in supplied V3
`GoogleDriveDirect.token()` caught `UserRecoverableAuthException`, launched its consent Intent itself from the token worker thread using legacy `startActivityForResult`, then threw a generic `IllegalStateException`. The UI therefore had no typed signal to associate consent with the original Backup/Restore operation, and the `onActivityResult` only saved an unused preference flag. Consent success did not resume the interrupted operation.

## Actual changes
1. Added typed `NeedRemoteConsent` carrying the exact recoverable consent `Intent` from Google Play Services. Token acquisition no longer launches UI from an IO thread.
2. Removed the legacy `MainActivity.onActivityResult` handler and fixed request-code path. Added Compose `rememberLauncherForActivityResult(StartActivityForResult())` consent handling.
3. Centralized Google Drive Backup/Restore execution in one `startDriveAction` callback. The action type is held in saveable UI state while consent is pending.
4. On consent success, consume/clear the pending action before starting exactly one fresh operation. A second consent exception during that one retry is surfaced as an error and does not relaunch consent, preventing loops.
5. On consent cancellation, clear pending action and busy state and show a Hindi cancellation message that tells the user to tap Backup/Restore to retry manually.
6. Kept the existing direct Drive API upload/download, ZIP validation, schema validation, screen-lock restore confirmation, and local backup/restore flows. No new parallel backup subsystem was added.

## Static verification performed
- Original input ZIP integrity: PASS (`unzip -t`, no errors).
- Source-level assertions: PASS (typed recoverable exception, Activity Result consent launcher, pending action consumed before retry, saveable retry guard, consent-pending duplicate-tap guard, cancellation messages, ZIP validation call still present, no old request-code/onActivityResult handler).
- Changed application source: `app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt`.

## Build and runtime verification limits
- `:app:compileReleaseKotlin` was attempted. It did **not** run: the supplied wrapper script tried downloading `gradle-wrapper.jar` from `raw.githubusercontent.com`, but network DNS failed (`curl: (6) Could not resolve host`). The ZIP does not contain `gradle/wrapper/gradle-wrapper.jar`; no Android SDK installation was available in this environment. Therefore Kotlin compilation and Release APK build are **NOT VERIFIED**.
- No Google account, OAuth Cloud configuration, or Android device was available. Live consent accept/cancel, Drive upload/download, actual restore, and real double-tap behavior are **NOT DEVICE-TESTED**.
- OAuth status 10 / `DEVELOPER_ERROR` remains dependent on the Google Cloud Android OAuth client matching application ID `com.majdoor.hisaabpro` and the signing certificate SHA-1 of the APK actually installed; this source-only patch cannot change cloud configuration.

## Manual device test matrix (required before release)
1. Fresh Google account / Drive scope missing → tap Drive Backup → Google consent opens once.
2. Accept consent → original Backup runs once; verify exactly one new `.mhbackup` file in Drive.
3. Repeat for Drive Restore → download and ZIP/schema validation happen once; existing screen-lock confirmation is still required before replacing data.
4. Cancel consent → Hindi cancellation message; no automatic retry; manual button tap starts a new attempt.
5. Force token failure after consent → real error is displayed; no repeated consent loop.
6. Double-tap Backup/Restore while busy/consent pending → ignored by `driveBusy` guard.
7. Recreate Activity while consent is open; verify the pending action remains busy and result is consumed once. Recreate during the retry; verify the retry guard remains saved and a manual new action resets it.
8. Confirm existing local ZIP Backup/Restore, PIN/device screen lock, and all unrelated crop/fandi/parchi/attendance screens on device.
