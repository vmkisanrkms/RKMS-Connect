# Report Selection Fix Audit — 2026-10-10

## Defect corrected
The all-workers report screen previously exported every worker matching the date/field filter even when the user had checked only a subset of workers. The export buttons also appeared before the worker selection list, making the intended workflow unclear.

## Changes
- Derive `selectedRows` from the currently filtered rows and checked worker IDs.
- Move Photo/PDF export controls after the worker list, so selection happens before export.
- Require at least one selected worker before creating a Photo/PDF.
- Calculate exported worker count, wages, payments, and balances from selected rows only.
- Pass only `selectedRows` into the combined ledger PDF and photo exporter.
- Keep date and field filters as the source set; selected workers are intersected with that set, so out-of-filter workers cannot leak into the export.
- Use the visible selected-row count for select-all/finalize messaging and handle stale selection IDs safely.

## Verification
- `scripts_report_selection_fix_check.py`: 10/10 checks passed.
- `scripts_daily_labour_audit_check.py`: 26/26 checks passed.
- ZIP integrity checked after packaging.
- Android/Kotlin compilation could not run: Gradle wrapper bootstrap requires `raw.githubusercontent.com`, which is unreachable in this environment. Release APK and device-runtime verification remain required in GitHub Actions.
