# Majdoor Hisaab PRO V82 — Final 14 Point Fix Audit

1. Fandi/chhilai record Edit opens directly and saves changes.
2. All Fandi workers are listed; tapping a worker opens that worker's full record.
3. Worker detail shows days, fields, records, fandi, earned, paid and balance.
4. PDF/Excel export opens worker selection first.
5. Export supports Mark All / clear all / individual worker selection.
6. PDF exports only selected workers.
7. CSV/Excel-compatible export exports only selected workers.
8. Fandi rate is stored once in Settings and reused for new entries; old record rates are preserved.
9. Daily-wage input was removed from the Fandi/chhilai worker-add dialog.
10. Fandi/chhilai entry uses fandi x saved rate; no daily-wage field.
11. Google Drive account sign-in flow no longer forces sign-out on the initial account-add action; Drive backup/restore controls remain disabled until an account is connected.
12. Google Drive backup/restore status is retained in the Backup screen and latest backup restore uses the app backup folder.
13. Worker detail screen was redesigned with a professional agriculture-style summary, field-wise section, date-wise timeline and payment history.
14. App/launcher and header logo artwork was scaled down by approximately 5% with centered transparent padding.

## Build target
- Package: `com.majdoor.hisaabpro`
- Android API: 36
- Build Tools: 36.0.0
- Java: 21
- Gradle: 8.11.1
- Final APK: `Majdoor-Hisaab-PRO-V82-FINAL-SIGNED.apk`
- GitHub artifact: `Majdoor-Hisaab-PRO-V82-FINAL-SIGNED-APK`

## Verification note
The source was syntax-checked with the available Kotlin compiler. A full Android Gradle build could not be executed in the current offline environment because the Gradle executable/distribution and Android dependency resolution are not available here. GitHub Actions remains the authoritative full build check.
