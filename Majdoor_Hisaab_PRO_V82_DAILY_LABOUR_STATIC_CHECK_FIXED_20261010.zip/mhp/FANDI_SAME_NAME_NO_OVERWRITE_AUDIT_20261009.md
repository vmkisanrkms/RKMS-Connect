# Fandi same-name / overwrite fix audit — 2026-10-09

## Changes
- Fandi worker profiles are no longer merged by name alone. Two different workers named Ram can have separate IDs and separate peeling records.
- Existing worker profile is reused automatically only when a valid mobile number (7+ digits) matches exactly.
- Adding a peeling row for the same worker ID + field + date adds the new fandi and amount to the existing total; it does not replace the old 10 with 15.
- Legacy duplicate rows with the same worker ID + field + date are consolidated by summing fandi and total, rather than keeping only the last row.
- Workflow ZIP_NAME updated to this archive name.

## Validation
- ZIP integrity: PASS (checked after archive creation).
- Static source assertions: PASS.
- Android compile: NOT VERIFIED. Gradle wrapper download attempted to access raw.githubusercontent.com, but network DNS was unavailable.

## Important data note
This prevents future same-name merging and overwrite. If an older build already overwrote a 10-fandi value with 15 and did not retain the earlier value anywhere, this source change cannot reconstruct that lost value.
