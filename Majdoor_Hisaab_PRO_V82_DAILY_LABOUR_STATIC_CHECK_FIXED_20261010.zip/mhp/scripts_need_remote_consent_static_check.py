from pathlib import Path
p = Path(__file__).parent / 'app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt'
s = p.read_text()
checks = {
    'typed NeedRemoteConsent exception': 'class NeedRemoteConsent(val consentIntent: Intent' in s,
    'token returns consent intent instead of launching activity': 'throw NeedRemoteConsent(' in s and 'host.startActivityForResult' not in s,
    'Activity Result consent launcher': 'rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult())' in s and 'driveConsentLauncher.launch(error.consentIntent)' in s,
    'pending action cleared before retry': 'pendingDriveAction="" // consume before any retry' in s,
    'retry only once': 'error is NeedRemoteConsent && !consentRetryInProgress' in s,
    'retry guard survives Activity recreation': 'var consentRetryInProgress by rememberSaveable' in s,
    'consent-pending action blocks duplicate taps': 'driveBusy || pendingDriveAction.isNotBlank()' in s and 'driveBusy || pendingDriveAction.isNotBlank(),' in s,
    'manual retry resets guard; automatic retry preserves it': 'if(!isConsentRetry) consentRetryInProgress=false' in s and 'startDriveAction(action, true)' in s,
    'cancel message in Hindi': 'अनुमति नहीं दी गई। दोबारा कोशिश करने के लिए' in s,
    'Drive restore validates ZIP/schema': 'store.validateBackupZip(temp)' in s,
    'legacy consent request handler removed': 'DRIVE_CONSENT_REQUEST_CODE' not in s and 'override fun onActivityResult' not in s,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
if not all(checks.values()):
    raise SystemExit(1)
