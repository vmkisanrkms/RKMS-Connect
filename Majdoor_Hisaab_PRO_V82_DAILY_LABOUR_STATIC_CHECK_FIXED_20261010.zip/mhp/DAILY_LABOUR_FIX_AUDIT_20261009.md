# Daily Labour Fix Audit — 2026-10-09

## Changes applied in this source patch
- Daily labour name is required before saving.
- Duplicate labour names are blocked across the shared general labour list, ignoring case and repeated/leading/trailing whitespace.
- Editing a worker checks for duplicate names while excluding the current worker's own ID.
- Dashboard attendance action is renamed to `हाजिरी लगाएँ` and the duplicate `आज की हाजिरी` primary button is removed from that card. Attendance history remains available in the existing history screens.
- Existing independent Fandi / Cane Peeling data and screens were not intentionally edited.

## Verification status
- Source patch applied.
- Kotlin compilation attempted with `bash gradlew :app:compileDebugKotlin --no-daemon` but could not run because the Gradle wrapper attempted to download from `raw.githubusercontent.com` and this environment has no DNS/network access.
- Therefore APK build/install verification is **NOT VERIFIED**.

## Still required before calling the whole requested redesign complete
- Implement the complete field-card-first attendance flow and persistent field ordering.
- Implement a dedicated consolidated daily-labour ledger/report/share PDF screen and verify balances against attendance and payments.
- Run Gradle compile, release build, install and real-device regression tests in GitHub Actions/device.
- Verify app lock, edit/delete confirmations and preserve existing backup/restore data.
