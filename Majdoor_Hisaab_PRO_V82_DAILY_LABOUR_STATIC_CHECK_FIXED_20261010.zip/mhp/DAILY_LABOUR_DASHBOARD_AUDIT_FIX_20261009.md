# Daily Labour Dashboard Audit — Bhanji Attendance Fix

Date: 2026-10-09

## User clarification
“भांजी” means the worker did not come to work. It is recorded as an attendance-status row with `fraction = 0.0`, so earned wage is `0.0 * rate = ₹0`. The label remains “भांजी”; reports clarify “काम पर नहीं आया”.

## Source changes
- `app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt`: added a third “भांजी” attendance option; choosing it writes a zero-fraction attendance record for the selected worker/field/date, and selecting it on an existing attendance uses the existing protected edit confirmation flow.
- Updated attendance-list, daily report, worker history, and PDF labels so a zero-fraction row is not misreported as half-day or generic attendance.
- Updated `scripts_daily_labour_audit_check.py` with explicit Bhanji checks.

## Data and module safety
- No database reset or schema migration performed. Existing JSON/SharedPreferences data model retained.
- Existing attendance upsert key (worker + field + date) retained, so selecting Bhanji for an existing row updates that row instead of creating another row.
- Wage calculation remains fraction × recorded rate, making Bhanji wage zero without changing rate history.
- No intentional changes to Ganna Chhilai/Fandi or Ganna Parchi source behavior.

## Verification
- ZIP integrity and extraction: to be run on packaged output.
- Static source checks: to be run after patch.
- Kotlin compilation / Release APK / real-device tests: not claimed unless separately run successfully.
