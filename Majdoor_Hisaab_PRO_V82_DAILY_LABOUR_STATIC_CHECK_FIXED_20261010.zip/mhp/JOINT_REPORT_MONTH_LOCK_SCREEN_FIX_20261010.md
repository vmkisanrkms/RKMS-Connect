# Joint Report Month Lock Screen Fix — 2026-10-10

## Changed
- Updated the existing `Home → दिहाड़ी मजदूर → हिसाब देखें → सभी मजदूरों की संयुक्त रिपोर्ट / PDF` screen in `MainActivity.kt`.
- Removed the old worker-selection “पुराना हिसाब फाइनल करें” card and “फाइनल किए गए पुराने हिसाब” list from this screen.
- Added month rows displaying only month name and lock/unlock icon. Tapping a month opens its attendance, half-day totals, wages, payments, balance, and month lock/unlock control.
- Kept date/field filters, worker selection, and combined PDF/photo export for the joint report.
- Existing separate “हिसाब देखें” monthly section remains unchanged.

## Verification / limitations
- Source inspection confirms the old finalization section and old finalized-history list are removed from `AllLabourReportScreen`.
- Month detail screen uses stored attendance fractions directly, so half-day totals are not rounded to whole days.
- Android compilation/runtime testing is not confirmed in this environment; Gradle wrapper JAR is not present in the supplied ZIP and network downloads may be unavailable.
- This UI change does not claim to implement oldest-outstanding-first payment allocation. That accounting behavior remains a separate task.
