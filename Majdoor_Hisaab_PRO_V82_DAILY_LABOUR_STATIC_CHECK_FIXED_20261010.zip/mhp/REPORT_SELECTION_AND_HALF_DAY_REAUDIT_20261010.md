# Report Selection + Half-Day + Sale Re-audit — 2026-10-10

## Fix applied
- Corrected `scripts_report_selection_fix_check.py`: photo export assertion now expects the dedicated `quantity(workDays)` formatter rather than the currency formatter `money(workDays)`. This aligns the test with the intended behavior: fractional days display as days, while wages/payments display as currency.
- Expanded the script to check fractional formatter availability, sale save button presence, positive finite quantity/rate validation, quantity × rate total, existing add/update persistence, and close-only-on-success behavior.

## Results
- `scripts_report_selection_fix_check.py`: 16/16 PASS.
- `scripts_daily_labour_audit_check.py`: 26/26 PASS.
- `scripts_need_remote_consent_static_check.py`: 11/11 PASS.
- ZIP integrity test: run after packaging.

## Limitations
- These are source/static checks. Android Gradle build and real-device runtime tests are not claimed as passed. They require a working Gradle distribution/network and Android runtime.
- This patch corrects the stale audit assertion; it does not redesign lock/settlement periods.
