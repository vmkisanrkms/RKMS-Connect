# Monthly Labour Lock + Tap-to-Open Fix — 2026-10-10

## Implemented
- Added persistent `lockedLabourMonths` in the existing local SharedPreferences JSON store. Existing app data is not migrated or deleted.
- Monthly list displays only the month title and lock/unlock icon; no helper instruction is shown on each row.
- Tapping a month opens its detail screen with month wage, payments, balance, worker attendance days (including fractional days), and per-worker wage/payment/balance.
- Month details include Lock/Unlock action. Locked months remain readable.
- Attendance creation/edit and deletion are blocked for locked months. New month attendance remains available.
- Monthly lock does not block later payments merely because the earlier earning month is locked; the existing payment flow remains separate.

## Verification
- ZIP integrity is checked separately.
- Static source assertions are used for the monthly list, tap handler, persisted lock store, and attendance write/delete guards.
- Android Gradle compile could not run because the wrapper script attempts to download from `raw.githubusercontent.com` and DNS/network resolution failed. Do not treat this as a verified APK build.
