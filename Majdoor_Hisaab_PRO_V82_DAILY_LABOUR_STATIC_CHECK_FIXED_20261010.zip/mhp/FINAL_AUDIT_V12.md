# Majdoor Hisaab PRO V82 — Final Fix Audit V12

## Fixed in this package
- **फांदी रेट:** daily छिलाई entry no longer has an editable rate field.
- **New फांदी entry:** automatically uses the saved `fandiRate` from the app setting.
- **Old फांदी records:** keep their original saved rate when edited; changing the setting does not rewrite history.
- **Save button:** clearly says `✓ फांदी सेव करें`.
- **Popup behavior:** `SimpleDialog` keeps outside-touch disabled (`onDismissRequest={}`) and Android Back closes the popup through `BackHandler`.
- **फांदी wording:** visible duplicate/misleading `रुपये/फांदी` labour field was renamed to `मजदूरी / दिन` and Fandi labels were normalized to `फांदी`.
- **Backup:** `fandiRate` is included in backup and restored back into the app setting.
- **Google Drive:** direct Drive flow remains available; OAuth setup requirements are documented. The package cannot manufacture a Google Cloud OAuth client/SHA configuration, so real-device Google sign-in must be verified with the project's release certificate configured in Google Cloud.
- **Gradle CI:** added a GitHub Actions workflow that uses Gradle 8.11.1 directly instead of the broken custom wrapper JAR. It compiles, assembles, and optionally signs/verifies the release APK when signing secrets are present.

## Not falsely claimed
A real Android device and GitHub-hosted build cannot be executed from this offline packaging environment. Therefore this package is source-fixed, but **final runtime and signed-release verification must be confirmed by the GitHub Actions run and one device test**.


## 2026-10-08 UI correction audit
- Cane peeling worker detail summary no longer formats count fields as currency.
- कुल खेत displays `N खेत`, कुल रिकॉर्ड displays `N रिकॉर्ड`, and फांदी displays `N फांदी`.
- Renamed the summary label `रिकॉर्ड` to `कुल रिकॉर्ड` for clarity.
- Currency remains only on monetary fields such as कुल छिलाई राशि, कुल भुगतान, बाकी and per-field totals.
