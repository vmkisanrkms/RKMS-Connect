# Ganna Chhilai / Fandi Rate Fix Audit — 2026-10-11

## Changes in this patch
- Added a clearly visible `रेट बदलें` action inside the green hero card on the Ganna Chhilai home screen.
- The action opens a dedicated rate dialog with current rate, new-rate field, validation, save and cancel actions.
- The existing rate card and its save flow remain available further down the screen.
- The existing one-worker-at-a-time fandi entry flow remains in place (`CanePeelingSingleEntryDialog`).
- The entry flow calculates the amount from the current saved rate and stores the rate on the record; historical records retain their saved rate.
- Duplicate detection remains keyed by labour, field and date.
- Only `app/src/main/java/com/majdoor/hisaabpro/MainActivity.kt` was changed for app behavior. Home Dashboard outside this module, regular Labour, and Cane Parchi screens were not intentionally changed.

## Static checks
- ZIP integrity check: passed on input archive.
- Source inspection: rate persistence uses `Store.updateFandiRate`, and the store persists `fandiRate` in preferences/backup.
- Source inspection: single-entry flow stores rate and amount on the `CanePeeling` record.
- Source inspection: duplicate guard checks worker ID, field ID and date.

## Not verified
- Gradle/Kotlin compilation and APK assembly could not run in this environment because the Gradle wrapper distribution download failed due to unavailable DNS/network (`raw.githubusercontent.com` / Gradle distribution unavailable).
- No device runtime test has been performed. Do not treat this source ZIP as a verified APK until GitHub Actions build and on-device checks pass.

## Required release checks
1. Build signed Release APK in GitHub Actions.
2. Install APK and open Ganna Chhilai.
3. Confirm `रेट बदलें` is visible in the top green card; change rate, save, leave/reopen module and confirm persistence.
4. Add one worker entry; verify fandi × saved rate = total.
5. Change rate again and confirm prior record's rate/amount remains unchanged.
6. Attempt duplicate worker/date/field entry and confirm it is blocked.
7. Smoke-test Home Dashboard, regular Labour and Cane Parchi unchanged.
