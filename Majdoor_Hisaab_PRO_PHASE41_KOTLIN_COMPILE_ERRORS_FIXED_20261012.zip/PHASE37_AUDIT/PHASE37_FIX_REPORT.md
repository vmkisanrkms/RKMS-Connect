# Phase 37 — Duplicate/build setup fixes

## Changes
- Kept the one canonical Android project at `mhp_phase24/original_source_project/mhp`.
- Removed 1 exact duplicate audit/reference document copies only where both copies were non-source documentation.
- Did not delete duplicate app resources, Kotlin source, manifests, or build configuration automatically, because those can be intentionally reused by resource references.
- Added `scripts/bootstrap-gradle-wrapper.sh` to generate a Gradle 8.11.1 wrapper on CI when Gradle is already installed.
- No app data/database was cleared or modified.

## Validation
- Input ZIP integrity: PASS.
- Output ZIP integrity: checked after repack.
- Single Gradle root: PASS.
- Single main activity: checked after repack.
- Android compilation/device test: NOT RUN.
- V99 feature parity: NOT VERIFIED; this phase addresses the structural audit findings, not all feature-porting work.

## Removed duplicate documentation copies
- `mhp_phase24/MERGE_REFERENCE_V99/A_TO_Z_REMAINING_FIX_LIST_V91.csv`