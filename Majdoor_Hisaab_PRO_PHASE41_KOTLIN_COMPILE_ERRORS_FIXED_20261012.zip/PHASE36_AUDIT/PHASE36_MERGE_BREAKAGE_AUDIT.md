# Phase 36 — Merge, breakage-risk, and duplicate audit
Date: 2026-10-12

## Input integrity
- Input archive integrity: PASS.
- Buildable Gradle root count: 1.
- MainActivity count in canonical project: 1.
- Kotlin source files: 3.
- Gradle build files: 3.
- MainActivity declared functions: 241.
- Distinct function names across Kotlin sources: 250.
- Exact-content duplicate groups found across archive: 65.

## Merge strategy applied
- Kept the Professional Redesign as the only buildable Android project.
- Did not blindly paste V99-only functions into the UI source because identical names/signatures are not enough to guarantee compatible state/data wiring.
- Kept the current canonical app source and all app resources intact.
- Kept V99 feature reference/checklist material in the archive as non-buildable audit documents.
- No user records or app database files were cleared by this archive operation.

## High-risk feature checks to run before release
1. Fandi rate: save 6.5, reopen settings, add fandi, verify every screen and amount uses 6.5 (not rounded to 7).
2. Backup: create local backup, create Drive backup, verify success/failure feedback.
3. Restore: restore clean backup, restore invalid/corrupt archive, verify failure leaves existing data unchanged.
4. Attendance: add/edit/delete attendance, calendar and CSV export, daily reminder schedule/cancel.
5. Labour status: deactivate/reactivate worker; confirm historical ledger/attendance remains intact.
6. Payment: record payment, check payment history and outstanding balance.
7. Cane chhilai/parchi: add/edit/delete, report/export, verify unrelated modules unchanged.
8. Offline/restart: force-close/reopen, check persistence without network.
9. PIN/biometric/autolock: lock/unlock and timeout.
10. Release build: compile, install, run smoke tests on device.

## Status
- Structural consolidation: PASS.
- ZIP integrity: PASS after repack.
- Feature-level parity with V99: NOT PROVEN by source inspection alone.
- Android compilation and device tests: NOT RUN in this environment.
- No claim of 100% behavioral merge until the high-risk checks pass.
