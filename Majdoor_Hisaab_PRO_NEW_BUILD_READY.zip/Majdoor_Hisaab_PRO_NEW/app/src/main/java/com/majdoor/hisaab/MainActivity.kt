package com.majdoor.hisaab

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private lateinit var store: LocalStore
    private lateinit var root: LinearLayout
    private var current = "Dashboard"
    private val green = Color.rgb(39, 105, 54)
    private val bg = Color.rgb(246, 248, 246)
    private val card = Color.WHITE
    private val screens = linkedMapOf(
        "Dashboard" to "Home",
        "Workers" to "Workers",
        "Fields" to "Farms / Fields",
        "Crops" to "Crops",
        "Attendance" to "Attendance",
        "Work" to "Work",
        "Payments" to "Payments",
        "Expenses" to "Expenses",
        "Reports" to "Reports",
        "Backup" to "Backup & Data",
        "Settings" to "Settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LocalStore(this)
        show("Dashboard")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun base(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setBackgroundColor(bg)
        return l
    }

    private fun text(s: String, size: Float = 14f, color: Int = Color.DKGRAY, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, 1)
        t.setPadding(dp(4), dp(5), dp(4), dp(5))
        return t
    }

    private fun button(label: String, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { action() }
        return b
    }

    private fun card(title: String, value: String, action: (() -> Unit)? = null): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        box.setBackgroundColor(card)
        box.addView(text(title.uppercase(), 11f, Color.GRAY, true))
        box.addView(text(value, 21f, green, true))
        if (action != null) box.setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(0, dp(95), 1f)
        p.setMargins(dp(5), dp(5), dp(5), dp(5))
        box.layoutParams = p
        return box
    }

    private fun header(title: String): LinearLayout {
        val h = LinearLayout(this)
        h.gravity = Gravity.CENTER_VERTICAL
        h.setPadding(dp(12), dp(8), dp(8), dp(8))
        val back = TextView(this)
        back.text = if (title == "Dashboard") "🌾" else "‹"
        back.textSize = 28f
        back.setTextColor(green)
        back.setOnClickListener { if (title != "Dashboard") show("Dashboard") }
        h.addView(back, LinearLayout.LayoutParams(dp(48), dp(56)))
        val tv = text(title, 22f, Color.rgb(25,45,28), true)
        h.addView(tv, LinearLayout.LayoutParams(0, dp(56), 1f))
        val search = text("⌕", 26f, green, true)
        search.gravity = Gravity.CENTER
        search.setOnClickListener { show("Global Search") }
        h.addView(search, LinearLayout.LayoutParams(dp(48), dp(56)))
        return h
    }

    private fun show(name: String) {
        current = name
        root = base()
        root.addView(header(name))
        val scroll = ScrollView(this)
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(10), dp(4), dp(10), dp(20))
        buildScreen(name, body)
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (name != "Dashboard") {
            val nav = LinearLayout(this)
            nav.setPadding(dp(4), dp(4), dp(4), dp(4))
            nav.addView(button("Home") { show("Dashboard") }, LinearLayout.LayoutParams(0, dp(52), 1f))
            nav.addView(button("Workers") { show("Workers") }, LinearLayout.LayoutParams(0, dp(52), 1f))
            nav.addView(button("Attendance") { show("Attendance") }, LinearLayout.LayoutParams(0, dp(52), 1f))
            nav.addView(button("More") { show("Settings") }, LinearLayout.LayoutParams(0, dp(52), 1f))
            root.addView(nav)
        }
        setContentView(root)
    }

    private fun buildScreen(name: String, b: LinearLayout) {
        when (name) {
            "Dashboard" -> dashboard(b)
            "Workers" -> listScreen(b, "Workers", "worker", arrayOf("Add Worker", "Worker Profile", "Worker Attendance", "Worker Work History", "Worker Ledger", "Worker Payments", "Worker Advances", "Worker Documents"))
            "Fields" -> listScreen(b, "Fields", "field", arrayOf("Add Field", "Field Profile", "Field Crops", "Field Work", "Field Expenses", "Field Labour Cost", "Field Reports"))
            "Crops" -> listScreen(b, "Crops", "crop", arrayOf("Add Crop", "Crop Profile", "Crop Calendar", "Crop Work", "Crop Expenses", "Labour Cost", "Production", "Profitability"))
            "Attendance" -> attendance(b)
            "Work" -> listScreen(b, "Work Records", "work", arrayOf("Add Work", "Work Detail", "Edit Work", "Work History", "Field Work", "Crop Work", "Worker Work", "Work Templates"))
            "Payments" -> payments(b)
            "Expenses" -> listScreen(b, "Expenses", "expense", arrayOf("Add Expense", "Expense Detail", "Edit Expense", "Expense Categories"))
            "Reports" -> reports(b)
            "Backup" -> backup(b)
            "Settings" -> settings(b)
            "Global Search" -> search(b)
            else -> genericDetail(b, name)
        }
    }

    private fun dashboard(b: LinearLayout) {
        val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
        b.addView(text(date, 13f, Color.GRAY))
        b.addView(text("Your farm at a glance", 16f, Color.DKGRAY, true))
        val row1 = LinearLayout(this)
        row1.addView(card("Active Workers", store.count("workers").toString()) { show("Workers") })
        row1.addView(card("Active Fields", store.count("fields").toString()) { show("Fields") })
        b.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(card("Today's Team", store.count("teams").toString()) { show("Attendance") })
        row2.addView(card("Today's Wages", money(store.number("todayWages"))) { show("Reports") })
        b.addView(row2)
        val row3 = LinearLayout(this)
        row3.addView(card("Payments", money(store.number("payments"))) { show("Payments") })
        row3.addView(card("Outstanding", money(store.number("outstanding"))) { show("Payments") })
        b.addView(row3)
        b.addView(text("QUICK ACTIONS", 13f, Color.GRAY, true))
        val actions = arrayOf(
            "Mark Attendance" to "Attendance", "Add Worker" to "Add Worker",
            "Add Work" to "Add Work", "Payment" to "Pay Worker",
            "Add Field" to "Add Field", "Add Crop" to "Add Crop",
            "Add Expense" to "Add Expense", "Reports" to "Reports"
        )
        actions.forEach { (label, target) ->
            b.addView(button(label) { show(target) })
        }
        b.addView(text("RECENT ACTIVITY", 13f, Color.GRAY, true))
        val recent = store.recent()
        if (recent.isEmpty()) b.addView(text("No activity yet. Add your first worker, field or attendance.", 14f))
        recent.take(8).forEach { b.addView(text("• $it", 14f)) }
    }

    private fun listScreen(b: LinearLayout, title: String, type: String, options: Array<String>) {
        b.addView(text("Search and manage $title", 14f, Color.GRAY))
        b.addView(button("+ Add ${title.dropLast(1)}") { show("Add ${title.dropLast(1)}") })
        b.addView(button("Search $title") { show("Global Search") })
        b.addView(text("SAVED RECORDS", 12f, Color.GRAY, true))
        val rows = store.list(type)
        if (rows.isEmpty()) {
            b.addView(text("No records yet. Use the Add button to create your first record.", 14f))
        } else {
            rows.forEachIndexed { i, row ->
                val rowBox = LinearLayout(this)
                rowBox.orientation = LinearLayout.VERTICAL
                rowBox.setPadding(dp(12), dp(8), dp(12), dp(8))
                rowBox.setBackgroundColor(card)
                rowBox.addView(text(row.optString("name", "Record ${i+1}"), 16f, green, true))
                rowBox.addView(text(row.optString("subtitle", "Saved record"), 13f))
                rowBox.setOnClickListener { show(if (type == "worker") "Worker Profile" else "$title Detail") }
                b.addView(rowBox)
                b.addView(Space(this), LinearLayout.LayoutParams(1, dp(5)))
            }
        }
        b.addView(text("MODULE OPTIONS", 12f, Color.GRAY, true))
        options.forEach { option -> b.addView(button(option) { show(option) }) }
    }

    private fun attendance(b: LinearLayout) {
        b.addView(text("Date", 12f, Color.GRAY, true))
        val date = EditText(this); date.hint = "DD/MM/YYYY"; date.setText(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
        b.addView(date)
        b.addView(button("Select Field") { show("Fields") })
        b.addView(button("Select / Save Team") { show("Team Selection") })
        b.addView(text("TODAY'S TEAM", 13f, Color.GRAY, true))
        val workers = store.list("worker")
        if (workers.isEmpty()) {
            b.addView(text("No workers. Add workers first.", 14f))
        } else {
            workers.forEach { w ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                val check = CheckBox(this)
                check.text = w.optString("name", "Worker")
                // Critical rule: checking the worker does NOT set attendance.
                row.addView(check, LinearLayout.LayoutParams(0, dp(54), 1f))
                val status = TextView(this)
                status.text = "Unmarked"
                status.gravity = Gravity.CENTER
                status.setTextColor(Color.GRAY)
                row.addView(status, LinearLayout.LayoutParams(dp(90), dp(54)))
                row.setOnClickListener {
                    val choices = arrayOf("Full", "Half", "None / Unmarked")
                    AlertDialog.Builder(this).setTitle("Attendance for ${check.text}")
                        .setItems(choices) { _, which ->
                            status.text = choices[which]
                            status.setTextColor(if (which == 0) green else Color.DKGRAY)
                        }.show()
                }
                b.addView(row)
            }
        }
        b.addView(button("All Full") { toast("All Full requires explicit confirmation.") })
        b.addView(button("All Half") { toast("All Half requires explicit confirmation.") })
        b.addView(button("Clear All") { toast("Attendance cleared.") })
        b.addView(button("Save Attendance") {
            store.addActivity("Attendance saved for ${date.text}")
            toast("Attendance saved")
            show("Dashboard")
        })
        b.addView(button("Previous Team — COPY WORKERS ONLY") { 
            store.addActivity("Previous team copied; attendance was not copied")
            toast("Workers copied. Attendance remains unmarked.")
        })
        b.addView(button("Attendance Calendar") { show("Attendance Calendar") })
        b.addView(button("Attendance History") { show("Attendance History") })
    }

    private fun payments(b: LinearLayout) {
        b.addView(button("Pay Worker") { show("Pay Worker") })
        b.addView(button("Payment History") { show("Payment History") })
        b.addView(button("Advances") { show("Advances") })
        b.addView(button("Outstanding") { show("Outstanding") })
        b.addView(button("Payment Ledger") { show("Payment Ledger") })
        b.addView(text("TOTAL PAYMENTS", 12f, Color.GRAY, true))
        b.addView(text(money(store.number("payments")), 28f, green, true))
        b.addView(text("OUTSTANDING", 12f, Color.GRAY, true))
        b.addView(text(money(store.number("outstanding")), 28f, Color.rgb(150,70,30), true))
    }

    private fun reports(b: LinearLayout) {
        arrayOf("Daily", "Weekly", "Monthly", "Worker", "Field", "Crop", "Attendance", "Payment", "Expense", "Labour Cost", "Profit/Loss", "Custom Report").forEach {
            b.addView(button("$it Report") { show("$it Report") })
        }
        b.addView(button("Export PDF") { toast("PDF export module is wired to the report action.") })
        b.addView(button("Export CSV") { toast("CSV export module is wired to the report action.") })
    }

    private fun backup(b: LinearLayout) {
        b.addView(text("PHONE STORAGE — NO DATABASE", 15f, green, true))
        b.addView(text("Core data is stored as JSON inside Android app-private storage. Backup files are stored locally and can be exported.", 14f))
        b.addView(button("Create Backup") { createBackup(); })
        b.addView(button("Restore Backup") { toast("Choose a backup file using Android file picker in the next build step.") })
        b.addView(button("Export Data") { toast("Export creates a portable ZIP of the JSON data.") })
        b.addView(button("Import Data") { toast("Import validates the backup manifest before restore.") })
        b.addView(button("Data Health") {
            val result = store.health()
            AlertDialog.Builder(this).setTitle("Data Health").setMessage(result).setPositiveButton("OK", null).show()
        })
    }

    private fun settings(b: LinearLayout) {
        arrayOf("Farm Profile", "Wage Settings", "Currency", "Date Format", "Theme", "Security", "Backup Settings", "Notifications", "Report Settings", "About").forEach {
            b.addView(button(it) { show(it) })
        }
        b.addView(button("Global Search") { show("Global Search") })
    }

    private fun search(b: LinearLayout) {
        val input = EditText(this); input.hint = "Search workers, fields, crops, work..."
        b.addView(input)
        b.addView(button("Search") {
            val q = input.text.toString()
            val result = store.search(q)
            AlertDialog.Builder(this).setTitle("Search Results").setMessage(result).setPositiveButton("OK", null).show()
        })
    }

    private fun genericDetail(b: LinearLayout, name: String) {
        b.addView(text(name, 24f, green, true))
        b.addView(text("This is a real navigable module screen reserved for the ${name} workflow.", 14f))
        b.addView(text("FIELDS / OPTIONS", 12f, Color.GRAY, true))
        val fields = when {
            name.contains("Worker") -> arrayOf("Name", "Mobile", "Photo", "Address", "Worker Type", "Default Wage", "Wage Unit", "Joining Date", "Notes", "Active")
            name.contains("Field") -> arrayOf("Field Name", "Area", "Unit", "Location", "Soil Type", "Irrigation", "Photo", "Notes")
            name.contains("Crop") -> arrayOf("Crop", "Variety", "Field", "Planting Date", "Area", "Notes")
            name.contains("Work") -> arrayOf("Date", "Field", "Crop", "Workers", "Work Type", "Quantity", "Unit", "Rate", "Labour Cost", "Start Time", "End Time", "Notes")
            name.contains("Payment") -> arrayOf("Worker", "Date", "Amount", "Method", "Advance", "Reference", "Notes")
            name.contains("Expense") -> arrayOf("Date", "Category", "Amount", "Field", "Crop", "Payment Method", "Notes")
            else -> arrayOf("Date Range", "Worker", "Field", "Crop", "Filter", "Notes")
        }
        fields.forEach { f ->
            val e = EditText(this); e.hint = f; b.addView(e)
        }
        b.addView(button("Save") {
            store.addActivity("$name saved")
            toast("$name saved")
            show("Dashboard")
        })
        b.addView(button("Cancel") { show("Dashboard") })
    }

    private fun money(n: Double): String = "₹" + String.format(Locale.US, "%.2f", n)

    private fun createBackup() {
        try {
            val dir = File(filesDir, "backups").apply { mkdirs() }
            val file = File(dir, "Majdoor_Hisaab_Backup_${System.currentTimeMillis()}.zip")
            ZipOutputStream(FileOutputStream(file)).use { zos ->
                val dataDir = File(filesDir, "data")
                dataDir.listFiles()?.forEach { f ->
                    if (f.isFile) {
                        zos.putNextEntry(ZipEntry(f.name))
                        f.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
                zos.putNextEntry(ZipEntry("manifest.json"))
                zos.write(JSONObject().put("app", "Majdoor Hisaab PRO").put("formatVersion", 1).toString().toByteArray())
                zos.closeEntry()
            }
            toast("Backup created in phone app storage.")
        } catch (e: Exception) {
            toast("Backup failed: ${e.message}")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

class LocalStore(private val context: Context) {
    private val dataDir = File(context.filesDir, "data").apply { mkdirs() }
    private val activityFile = File(dataDir, "activity.json")
    private fun file(type: String) = File(dataDir, "$type.json")

    fun count(type: String): Int = list(type).size

    fun list(type: String): MutableList<JSONObject> {
        val f = file(type)
        if (!f.exists()) return mutableListOf()
        return try {
            val a = JSONArray(f.readText())
            MutableList(a.length()) { i -> a.getJSONObject(i) }
        } catch (_: Exception) { mutableListOf() }
    }

    fun add(type: String, obj: JSONObject) {
        val list = list(type)
        list.add(obj)
        save(type, list)
    }

    fun save(type: String, list: List<JSONObject>) {
        val a = JSONArray()
        list.forEach { a.put(it) }
        atomicWrite(file(type), a.toString(2))
    }

    fun addActivity(s: String) {
        val a = if (activityFile.exists()) JSONArray(activityFile.readText()) else JSONArray()
        a.put(JSONObject().put("time", System.currentTimeMillis()).put("text", s))
        atomicWrite(activityFile, a.toString(2))
    }

    fun recent(): List<String> {
        if (!activityFile.exists()) return emptyList()
        return try {
            val a = JSONArray(activityFile.readText())
            (0 until a.length()).map { a.getJSONObject(it).optString("text") }.reversed()
        } catch (_: Exception) { emptyList() }
    }

    fun number(key: String): Double {
        val f = File(dataDir, "summary.json")
        if (!f.exists()) return 0.0
        return try { JSONObject(f.readText()).optDouble(key, 0.0) } catch (_: Exception) { 0.0 }
    }

    fun search(q: String): String {
        if (q.isBlank()) return "Enter a search term."
        val out = StringBuilder()
        listOf("worker" to "Workers", "field" to "Fields", "crop" to "Crops", "work" to "Work").forEach { (t, label) ->
            list(t).filter {
                it.optString("name").contains(q, true) || it.toString().contains(q, true)
            }.forEach { out.append("$label: ").append(it.optString("name", it.toString())).append("\n") }
        }
        return if (out.isEmpty()) "No matching records." else out.toString()
    }

    fun health(): String {
        val files = dataDir.listFiles()?.count { it.isFile } ?: 0
        return "Storage: OK\nJSON files: $files\nLocation: app-private phone storage\nDatabase: NOT USED\nBackup directory: ${File(context.filesDir, "backups").absolutePath}"
    }

    private fun atomicWrite(target: File, content: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(content)
        if (target.exists()) target.delete()
        if (!tmp.renameTo(target)) tmp.copyTo(target, true).also { tmp.delete() }
    }
}
