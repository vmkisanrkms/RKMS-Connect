# Initial Build/Audit Checklist

## Storage
- [x] No SQLite/Room/database dependency
- [x] JSON storage in app-private filesDir
- [x] Atomic file writes
- [x] Backup ZIP generation
- [ ] Restore file picker + validation end-to-end
- [ ] Android external export/share verification

## Attendance
- [x] Selecting worker does not set Full
- [x] Full / Half / None are explicit
- [x] Previous Team does not copy attendance
- [x] Bulk action entry points exist
- [ ] Persistent attendance records and editing UI complete
- [ ] Automated calculation tests

## Core modules
- [x] Dashboard
- [x] Workers
- [x] Fields
- [x] Crops
- [x] Attendance
- [x] Work
- [x] Payments
- [x] Expenses
- [x] Reports
- [x] Backup
- [x] Settings

## Release
- [x] GitHub Actions release build workflow
- [x] Android SDK 35 target
- [x] Java 17
- [x] Gradle 8.11.1
- [ ] Signing secrets configured by repository owner
- [ ] Final GitHub build verified
- [ ] Device QA on Android 16
