# Majdoor Hisaab PRO — New Project

A completely new Android agricultural labour-management application.

## Important architecture decision

**No SQLite, Room, Realm, Supabase, Firebase database, or other database is used.**

All application records are stored as versioned JSON files in Android app-private internal storage:

`/data/data/com.majdoor.hisaab/files/data/`

Backups are created as ZIP files in the app's private `backups/` directory and can be exported later through Android's share/save mechanism.

## Build

The project is designed for GitHub Actions with:
- Java 17
- Android SDK 35
- Gradle 8.11.1
- Android Gradle Plugin 8.9.1
- Kotlin 2.1.21

## Modules / screens

The application includes the blueprint screen map:
Dashboard, Workers, Worker Profile, Fields, Field Profile, Crops, Crop Profile,
Attendance, Teams, Work, Payments, Expenses, Reports, Backup/Restore, Settings,
Security, Search, and detail/edit flows.

## Storage

The `LocalStore` class is the single storage gateway. It uses JSON documents and
atomic temporary-file replacement. There is no database layer.

## Critical attendance rule

Selecting a worker does NOT mark Full Day. Attendance must be explicitly set to
Full, Half, or None/Unmarked.

Previous Team copies only worker membership, never attendance status.
